#!/usr/bin/env python3
"""IT VIP local license control-plane reference service (stdlib only).

Loopback-only by default. Remote deployment requires an authenticated TLS reverse proxy.
This service does not sign licenses; export its revocation JSON and sign it offline with
Sign-ITVIPUserEdition.ps1 so clients retain the existing RSA trust model.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, hmac, json, os, re, sqlite3, ssl
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

GUID = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$")

def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00', 'Z')

class Store:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('''CREATE TABLE IF NOT EXISTS revocations (
                edition_id TEXT PRIMARY KEY, reason TEXT NOT NULL, revoked_utc TEXT NOT NULL,
                actor TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT NOT NULL,
                edition_id TEXT NOT NULL, reason TEXT NOT NULL, occurred_utc TEXT NOT NULL,
                actor TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0)''')
            columns = {row[1] for row in db.execute('PRAGMA table_info(audit)')}
            if 'revision' not in columns:
                db.execute('ALTER TABLE audit ADD COLUMN revision INTEGER NOT NULL DEFAULT 0')
            if 'prev_hash' not in columns:
                db.execute("ALTER TABLE audit ADD COLUMN prev_hash TEXT NOT NULL DEFAULT ''")
            if 'audit_hash' not in columns:
                db.execute("ALTER TABLE audit ADD COLUMN audit_hash TEXT NOT NULL DEFAULT ''")
            db.execute('''CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY, value TEXT NOT NULL)''')
            db.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('revision','0')")
            self._migrate_audit_chain(db)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        try:
            db.execute('PRAGMA foreign_keys=ON')
            db.execute('PRAGMA synchronous=FULL')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _audit_digest(row: dict) -> str:
        fields = {k: row[k] for k in ('id','event','edition_id','reason','occurred_utc','actor','revision','prev_hash')}
        canonical = json.dumps(fields, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        return hashlib.sha256(canonical).hexdigest()

    @classmethod
    def _migrate_audit_chain(cls, db) -> None:
        rows = db.execute('SELECT id,event,edition_id,reason,occurred_utc,actor,revision,prev_hash,audit_hash FROM audit ORDER BY id').fetchall()
        previous = ''
        for row in rows:
            item = dict(zip(('id','event','edition_id','reason','occurred_utc','actor','revision','prev_hash','audit_hash'), row))
            if not item['audit_hash']:
                item['prev_hash'] = previous
                digest = cls._audit_digest(item)
                db.execute('UPDATE audit SET prev_hash=?,audit_hash=? WHERE id=?', (previous,digest,item['id']))
                item['audit_hash'] = digest
            previous = item['audit_hash']

    @classmethod
    def _append_audit(cls, db, event: str, edition_id: str, reason: str, occurred_utc: str, actor: str, revision: int) -> None:
        last = db.execute('SELECT audit_hash FROM audit ORDER BY id DESC LIMIT 1').fetchone()
        previous = last[0] if last else ''
        cur = db.execute('INSERT INTO audit(event,edition_id,reason,occurred_utc,actor,revision,prev_hash,audit_hash) VALUES(?,?,?,?,?,?,?,?)',
                         (event,edition_id,reason,occurred_utc,actor,revision,previous,''))
        item = {'id':cur.lastrowid,'event':event,'edition_id':edition_id,'reason':reason,'occurred_utc':occurred_utc,'actor':actor,'revision':revision,'prev_hash':previous}
        digest = cls._audit_digest(item)
        db.execute('UPDATE audit SET audit_hash=? WHERE id=?', (digest,cur.lastrowid))

    def verify_audit(self) -> dict:
        with self.connect() as db:
            rows = db.execute('SELECT id,event,edition_id,reason,occurred_utc,actor,revision,prev_hash,audit_hash FROM audit ORDER BY id').fetchall()
        previous = ''
        for row in rows:
            item = dict(zip(('id','event','edition_id','reason','occurred_utc','actor','revision','prev_hash','audit_hash'), row))
            expected = self._audit_digest(item)
            if item['prev_hash'] != previous or not hmac.compare_digest(item['audit_hash'], expected):
                return {'valid':False,'checked':len(rows),'first_bad_id':item['id'],'head':previous}
            previous = item['audit_hash']
        return {'valid':True,'checked':len(rows),'first_bad_id':None,'head':previous}

    def revoke(self, edition_id: str, reason: str, actor: str = 'admin') -> bool:
        if not GUID.fullmatch(edition_id):
            raise ValueError('EditionId must be a canonical UUID.')
        reason = reason.strip()[:500]
        if not reason:
            raise ValueError('A non-empty revocation reason is required.')
        now = utc_now(); eid = edition_id.lower()
        with self.connect() as db:
            # Acquire the SQLite write reservation before reading/updating the
            # monotonic revision and audit-chain head. This serializes writers.
            db.execute('BEGIN IMMEDIATE')
            cur = db.execute('INSERT OR IGNORE INTO revocations VALUES (?,?,?,?)', (eid, reason, now, actor))
            if cur.rowcount:
                revision = self._next_revision(db)
                self._append_audit(db, 'REVOKE', eid, reason, now, actor, revision)
            return bool(cur.rowcount)

    def restore(self, edition_id: str, reason: str, actor: str = 'admin') -> bool:
        if not GUID.fullmatch(edition_id):
            raise ValueError('EditionId must be a canonical UUID.')
        reason = reason.strip()[:500]
        if not reason:
            raise ValueError('A non-empty restoration reason is required.')
        now = utc_now(); eid = edition_id.lower()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            cur = db.execute('DELETE FROM revocations WHERE edition_id=?', (eid,))
            if cur.rowcount:
                revision = self._next_revision(db)
                self._append_audit(db, 'RESTORE', eid, reason, now, actor, revision)
            return bool(cur.rowcount)

    @staticmethod
    def _next_revision(db) -> int:
        row = db.execute("SELECT value FROM metadata WHERE key='revision'").fetchone()
        revision = int(row[0]) + 1 if row else 1
        db.execute("INSERT INTO metadata(key,value) VALUES('revision',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(revision),))
        return revision

    def snapshot(self) -> dict:
        with self.connect() as db:
            rows = db.execute('SELECT edition_id FROM revocations ORDER BY edition_id').fetchall()
            revision_row = db.execute("SELECT value FROM metadata WHERE key='revision'").fetchone()
        return {'Schema':'ITVIP-REVOCATIONS-1', 'Revision':int(revision_row[0]) if revision_row else 0,
                'GeneratedUtc':utc_now(), 'RevokedEditionIds':[r[0] for r in rows]}

    def audit_rows(self) -> list[dict]:
        with self.connect() as db:
            db.row_factory = sqlite3.Row
            return [dict(r) for r in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 500')]

    def audit_export(self) -> dict:
        """Return a complete, single-snapshot audit export with chain verification."""
        with self.connect() as db:
            db.row_factory = sqlite3.Row
            rows = [dict(r) for r in db.execute(
                'SELECT id,event,edition_id,reason,occurred_utc,actor,revision,prev_hash,audit_hash '
                'FROM audit ORDER BY id ASC')]
        previous = ''
        first_bad_id = None
        for item in rows:
            expected = self._audit_digest(item)
            if item['prev_hash'] != previous or not hmac.compare_digest(item['audit_hash'], expected):
                first_bad_id = item['id']
                break
            previous = item['audit_hash']
        return {
            'Schema': 'ITVIP-AUDIT-EXPORT-1',
            'GeneratedUtc': utc_now(),
            'Integrity': {
                'valid': first_bad_id is None,
                'checked': len(rows),
                'first_bad_id': first_bad_id,
                'head': previous,
            },
            'Events': rows,
        }

class Handler(BaseHTTPRequestHandler):
    server_version = 'ITVIP-LicenseAuthority/1.0'
    def send_json(self, status: int, payload: dict):
        data = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(data)

    @staticmethod
    def _unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f'Duplicate JSON property: {key}')
            result[key] = value
        return result

    @staticmethod
    def _reject_json_constant(value):
        raise ValueError(f'Invalid JSON constant: {value}')

    def read_json(self):
        # Do not accept ambiguous framing or permissive JSON extensions.
        if self.headers.get('Transfer-Encoding'):
            raise ValueError('Transfer-Encoding is not supported.')
        raw_length = self.headers.get('Content-Length', '')
        if not raw_length or not raw_length.isascii() or not raw_length.isdigit():
            raise ValueError('A valid Content-Length header is required.')
        length = int(raw_length, 10)
        if length < 2 or length > 8192:
            raise ValueError('Request body must be between 2 and 8192 bytes.')
        content_type = self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
        if content_type != 'application/json':
            raise ValueError('Content-Type must be application/json.')
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise ValueError('Request body ended before Content-Length bytes were received.')
        try:
            value = json.loads(raw.decode('utf-8', errors='strict'),
                               object_pairs_hook=self._unique_object,
                               parse_constant=self._reject_json_constant)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError('Request body must contain valid UTF-8 JSON.') from exc
        if not isinstance(value, dict):
            raise ValueError('JSON object required.')
        return value

    def bearer(self) -> str:
        supplied = self.headers.get('Authorization','')
        return supplied[7:] if supplied.startswith('Bearer ') else ''

    def authorized(self, write: bool = False) -> bool:
        candidate = self.bearer().encode()
        expected = self.server.admin_token if write else self.server.read_token
        return bool(expected) and hmac.compare_digest(candidate, expected.encode())

    def actor(self) -> str:
        # Never accept an audit principal from the request: the caller controls
        # arbitrary headers and could otherwise impersonate another operator.
        # This identifies the configured service credential, not an individual
        # human behind a shared bearer token.
        return self.server.admin_actor

    def do_GET(self):
        route = urlparse(self.path).path
        if route == '/health': return self.send_json(200, {'status':'ok','service':'IT VIP License Authority','time':utc_now()})
        if not self.authorized(write=False): return self.send_json(401, {'error':'Unauthorized'})
        if route == '/v1/revocations': return self.send_json(200, self.server.store.snapshot())
        if route == '/v1/audit': return self.send_json(200, {'events':self.server.store.audit_rows()})
        if route == '/v1/audit/verify': return self.send_json(200, self.server.store.verify_audit())
        if route == '/v1/audit/export': return self.send_json(200, self.server.store.audit_export())
        return self.send_json(404, {'error':'Not found'})

    def do_POST(self):
        if not self.authorized(write=True): return self.send_json(401, {'error':'Admin authorization required'})
        route = urlparse(self.path).path
        try:
            body = self.read_json(); eid = str(body.get('EditionId','')); reason = str(body.get('Reason',''))
            if route == '/v1/revoke':
                changed = self.server.store.revoke(eid, reason, self.actor())
                return self.send_json(200, {'changed':changed,'EditionId':eid.lower(),'status':'Revoked'})
            if route == '/v1/restore':
                changed = self.server.store.restore(eid, reason, self.actor())
                return self.send_json(200, {'changed':changed,'EditionId':eid.lower(),'status':'Active' if changed else 'Unchanged'})
            return self.send_json(404, {'error':'Not found'})
        except (ValueError, json.JSONDecodeError) as exc:
            return self.send_json(400, {'error':str(exc)})

    def log_message(self, fmt, *args):
        # Keep access logs concise and avoid reflecting request headers/secrets.
        print('%s - %s' % (self.address_string(), fmt % args))

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--database', default='data/license_authority.sqlite3')
    ap.add_argument('--allow-remote', action='store_true', help='permit non-loopback bind; requires --tls-cert and --tls-key')
    ap.add_argument('--tls-cert', default='', help='PEM TLS certificate chain for direct HTTPS')
    ap.add_argument('--tls-key', default='', help='PEM TLS private key for direct HTTPS')
    args = ap.parse_args()
    remote = args.host not in ('127.0.0.1','::1','localhost')
    if remote and not args.allow_remote:
        ap.error('Non-loopback bind refused. Add --allow-remote only with TLS enabled.')
    if bool(args.tls_cert) != bool(args.tls_key):
        ap.error('Provide both --tls-cert and --tls-key.')
    if remote and not (args.tls_cert and args.tls_key):
        ap.error('Remote binding requires --tls-cert and --tls-key; plaintext remote HTTP is forbidden.')
    admin_token = os.environ.get('ITVIP_ADMIN_TOKEN','')
    read_token = os.environ.get('ITVIP_READ_TOKEN', admin_token)
    admin_actor = os.environ.get('ITVIP_ADMIN_ACTOR', 'license-authority-admin').strip()
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,64}', admin_actor):
        ap.error('ITVIP_ADMIN_ACTOR must contain 1-64 ASCII letters, digits, dot, underscore, at-sign, or hyphen.')
    if len(admin_token) < 32:
        ap.error('Set ITVIP_ADMIN_TOKEN to a random secret of at least 32 characters.')
    if len(read_token) < 32:
        ap.error('Set ITVIP_READ_TOKEN (or reuse the admin token) to at least 32 characters.')
    if hmac.compare_digest(admin_token, read_token) and os.environ.get('ITVIP_READ_TOKEN'):
        ap.error('ITVIP_READ_TOKEN must differ from ITVIP_ADMIN_TOKEN.')
    store = Store(args.database)
    class Server(ThreadingHTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    httpd = Server((args.host,args.port),Handler); httpd.store=store; httpd.admin_token=admin_token; httpd.read_token=read_token; httpd.admin_actor=admin_actor
    if args.tls_cert:
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version=ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(args.tls_cert,args.tls_key)
        httpd.socket=context.wrap_socket(httpd.socket,server_side=True)
    scheme='https' if args.tls_cert else 'http'
    print(f'IT VIP License Authority listening on {scheme}://{args.host}:{args.port}; database={args.database}')
    if not args.tls_cert:
        print('Notice: TLS is disabled for loopback-only local development.')
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally: httpd.server_close()
    return 0

if __name__ == '__main__': raise SystemExit(main())
