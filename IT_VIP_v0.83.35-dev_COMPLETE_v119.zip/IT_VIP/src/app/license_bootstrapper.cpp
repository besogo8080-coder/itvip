#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <filesystem>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
std::wstring quoteArg(const std::wstring& value) {
    std::wstring out = L"\"";
    unsigned slashes = 0;
    for (wchar_t ch : value) {
        if (ch == L'\\') { ++slashes; continue; }
        if (ch == L'\"') {
            out.append(slashes * 2 + 1, L'\\');
            out.push_back(L'\"');
            slashes = 0;
            continue;
        }
        out.append(slashes, L'\\');
        slashes = 0;
        out.push_back(ch);
    }
    out.append(slashes * 2, L'\\');
    out.push_back(L'\"');
    return out;
}

fs::path executablePath() {
    std::vector<wchar_t> buffer(32768);
    const DWORD n = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (n == 0 || n >= buffer.size()) return {};
    return fs::path(std::wstring(buffer.data(), n));
}

bool runAndWait(const fs::path& application, const std::wstring& args,
                const fs::path& workingDirectory, DWORD& exitCode) {
    std::wstring command = quoteArg(application.wstring());
    if (!args.empty()) command += L" " + args;
    std::vector<wchar_t> mutableCommand(command.begin(), command.end());
    mutableCommand.push_back(L'\0');
    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(application.c_str(), mutableCommand.data(), nullptr, nullptr, FALSE,
                        CREATE_UNICODE_ENVIRONMENT, nullptr, workingDirectory.c_str(), &si, &pi))
        return false;
    CloseHandle(pi.hThread);
    const DWORD wait = WaitForSingleObject(pi.hProcess, INFINITE);
    const bool ok = wait == WAIT_OBJECT_0 && GetExitCodeProcess(pi.hProcess, &exitCode);
    CloseHandle(pi.hProcess);
    return ok;
}

int fail(const wchar_t* message, UINT code) {
    MessageBoxW(nullptr, message, L"IT VIP — Security Check", MB_OK | MB_ICONERROR | MB_TOPMOST);
    return static_cast<int>(code);
}
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    try {
        const fs::path self = executablePath();
        if (self.empty()) return fail(L"Cannot resolve the bootstrapper path.", 10);
        const fs::path root = self.parent_path();
        const fs::path verifier = root / L"deployment" / L"Test-ITVIPUserEdition.ps1";
        const fs::path nativeVerifier = root / L"build" / L"ITVIPNativeVerify.exe";
        const fs::path publicKey = root / L"deployment" / L"authority.public.xml";
        const fs::path dashboard = root / L"build" / L"ITVIP.exe";
        if (!fs::is_regular_file(verifier) || !fs::is_regular_file(nativeVerifier) || !fs::is_regular_file(publicKey) || !fs::is_regular_file(dashboard))
            return fail(L"A required license verifier, public key, or dashboard file is missing. Launch blocked.", 11);

        wchar_t windowsDir[MAX_PATH]{};
        const UINT winLen = GetWindowsDirectoryW(windowsDir, MAX_PATH);
        if (winLen == 0 || winLen >= MAX_PATH) return fail(L"Cannot locate the Windows directory.", 12);
        const fs::path powershell = fs::path(windowsDir) / L"System32" / L"WindowsPowerShell" / L"v1.0" / L"powershell.exe";
        if (!fs::is_regular_file(powershell)) return fail(L"Windows PowerShell was not found. Launch blocked.", 13);

        DWORD nativeExit = STILL_ACTIVE;
        const std::wstring nativeArgs = L"--edition " + quoteArg(root.wstring()) + L" --public-key " + quoteArg(publicKey.wstring());
        if (!runAndWait(nativeVerifier, nativeArgs, root, nativeExit) || nativeExit != 0)
            return fail(L"Native CNG signature or file-integrity verification failed. Launch blocked.", 17);

        const std::wstring args = L"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " +
            quoteArg(verifier.wstring()) + L" -EditionDirectory " + quoteArg(root.wstring()) +
            L" -PublicKeyFile " + quoteArg(publicKey.wstring());
        DWORD verifierExit = STILL_ACTIVE;
        if (!runAndWait(powershell, args, root, verifierExit))
            return fail(L"Could not start or complete the license verification process. Launch blocked.", 14);
        if (verifierExit != 0)
            return fail(L"IT VIP license or file-integrity verification failed. The dashboard was not started.", 15);

        SHELLEXECUTEINFOW sei{}; sei.cbSize = sizeof(sei); sei.fMask = SEE_MASK_NOCLOSEPROCESS;
        sei.lpVerb = L"open"; sei.lpFile = dashboard.c_str(); sei.lpDirectory = root.c_str();
        sei.nShow = SW_SHOWNORMAL;
        if (!ShellExecuteExW(&sei)) return fail(L"Verification passed, but the IT VIP dashboard could not be started.", 16);
        if (sei.hProcess) CloseHandle(sei.hProcess);
        return 0;
    } catch (...) {
        return fail(L"Unexpected bootstrapper error. Launch blocked.", 19);
    }
}
