#pragma once
// Small dependency-free JSON DOM/parser for the IT VIP signed-edition verifier.
// Implements RFC 8259 syntax, UTF-8 validation, surrogate-pair decoding,
// duplicate-key rejection, and bounded resource use. No comments/trailing commas.
#include <cstddef>
#include <cstdint>
#include <map>
#include <string>
#include <utility>
#include <vector>
#include <stdexcept>
#include <limits>

namespace itvip::json {
struct Value {
    enum class Kind { Null, Boolean, Number, String, Array, Object } kind = Kind::Null;
    bool boolean = false;
    std::string scalar; // exact number spelling or decoded UTF-8 string
    std::vector<Value> array;
    std::map<std::string, Value> object;
    const Value* find(const std::string& key) const {
        if (kind != Kind::Object) return nullptr;
        auto it = object.find(key); return it == object.end() ? nullptr : &it->second;
    }
};
struct Limits {
    std::size_t maxDocument = 16u * 1024u * 1024u;
    std::size_t maxString = 1024u * 1024u;
    std::size_t maxNodes = 500000;
    unsigned maxDepth = 64;
};
class Parser {
    const std::string& s; Limits lim; std::size_t i=0, nodes=0;
    [[noreturn]] void fail(const char* m) const { throw std::runtime_error(std::string("JSON: ")+m); }
    void ws(){ while(i<s.size() && (s[i]==' '||s[i]=='\t'||s[i]=='\r'||s[i]=='\n')) ++i; }
    static void utf8(std::string& out, std::uint32_t cp) {
        if(cp<=0x7f) out.push_back(static_cast<char>(cp));
        else if(cp<=0x7ff){out.push_back(static_cast<char>(0xc0|(cp>>6)));out.push_back(static_cast<char>(0x80|(cp&63)));}
        else if(cp<=0xffff){out.push_back(static_cast<char>(0xe0|(cp>>12)));out.push_back(static_cast<char>(0x80|((cp>>6)&63)));out.push_back(static_cast<char>(0x80|(cp&63)));}
        else {out.push_back(static_cast<char>(0xf0|(cp>>18)));out.push_back(static_cast<char>(0x80|((cp>>12)&63)));out.push_back(static_cast<char>(0x80|((cp>>6)&63)));out.push_back(static_cast<char>(0x80|(cp&63)));}
    }
    std::uint32_t hex4(){ if(i+4>s.size()) fail("truncated Unicode escape"); std::uint32_t n=0; for(int k=0;k<4;++k){char c=s[i++];n<<=4;if(c>='0'&&c<='9')n|=c-'0';else if(c>='a'&&c<='f')n|=c-'a'+10;else if(c>='A'&&c<='F')n|=c-'A'+10;else fail("invalid Unicode escape");} return n; }
    void validateRawUtf8(std::string& out, unsigned char c){
        // Copy one complete UTF-8 sequence while rejecting overlong forms,
        // surrogate encodings, invalid continuation bytes, and > U+10FFFF.
        int n=0; std::uint32_t cp=0, min=0;
        if(c<0x80){out.push_back(static_cast<char>(c));return;}
        if((c&0xe0)==0xc0){n=1;cp=c&0x1f;min=0x80;}
        else if((c&0xf0)==0xe0){n=2;cp=c&0x0f;min=0x800;}
        else if((c&0xf8)==0xf0){n=3;cp=c&7;min=0x10000;}
        else fail("invalid UTF-8 lead byte");
        if(i+static_cast<std::size_t>(n)>s.size()) fail("truncated UTF-8 sequence");
        std::string seq(1,static_cast<char>(c));
        for(int k=0;k<n;++k){unsigned char d=static_cast<unsigned char>(s[i++]);if((d&0xc0)!=0x80)fail("invalid UTF-8 continuation");cp=(cp<<6)|(d&63);seq.push_back(static_cast<char>(d));}
        if(cp<min||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))fail("non-canonical UTF-8");
        out+=seq;
    }
    std::string string(){
        if(i>=s.size()||s[i++]!='"') fail("expected string");
        std::string out;
        while(i<s.size()){
            unsigned char c=static_cast<unsigned char>(s[i++]);
            if(c=='"') return out;
            if(c<0x20) fail("unescaped control character");
            if(c=='\\'){
                if(i>=s.size()) fail("truncated escape");
                char e=s[i++];
                switch(e){case '"':out+='"';break;case '\\':out+='\\';break;case '/':out+='/';break;case 'b':out+='\b';break;case 'f':out+='\f';break;case 'n':out+='\n';break;case 'r':out+='\r';break;case 't':out+='\t';break;
                case 'u':{std::uint32_t cp=hex4();if(cp>=0xd800&&cp<=0xdbff){if(i+2>s.size()||s[i]!='\\'||s[i+1]!='u')fail("missing low surrogate");i+=2;std::uint32_t lo=hex4();if(lo<0xdc00||lo>0xdfff)fail("invalid low surrogate");cp=0x10000+((cp-0xd800)<<10)+(lo-0xdc00);}else if(cp>=0xdc00&&cp<=0xdfff)fail("unpaired low surrogate");utf8(out,cp);break;}
                default:fail("invalid escape");}
            } else if(c<0x80) out.push_back(static_cast<char>(c));
            else validateRawUtf8(out,c);
            if(out.size()>lim.maxString)fail("string limit exceeded");
        }
        fail("unterminated string");
    }
    std::string number(){
        std::size_t b=i;if(i<s.size()&&s[i]=='-')++i;if(i>=s.size())fail("invalid number");
        if(s[i]=='0')++i;else{if(s[i]<'1'||s[i]>'9')fail("invalid integer part");while(i<s.size()&&s[i]>='0'&&s[i]<='9')++i;}
        if(i<s.size()&&s[i]=='.'){++i;auto p=i;while(i<s.size()&&s[i]>='0'&&s[i]<='9')++i;if(i==p)fail("invalid fraction");}
        if(i<s.size()&&(s[i]=='e'||s[i]=='E')){++i;if(i<s.size()&&(s[i]=='+'||s[i]=='-'))++i;auto p=i;while(i<s.size()&&s[i]>='0'&&s[i]<='9')++i;if(i==p)fail("invalid exponent");}
        return s.substr(b,i-b);
    }
    Value value(unsigned depth){
        if(depth>lim.maxDepth) fail("nesting limit exceeded");
        if(++nodes>lim.maxNodes) fail("node limit exceeded");
        ws(); if(i>=s.size()) fail("missing value");
        Value v;
        if(s[i]=='{'){
            v.kind=Value::Kind::Object;++i;ws();if(i<s.size()&&s[i]=='}'){++i;return v;}
            for(;;){ws();if(i>=s.size()||s[i]!='"')fail("object key must be string");auto k=string();ws();if(i>=s.size()||s[i++]!=':')fail("missing colon");auto child=value(depth+1);if(!v.object.emplace(std::move(k),std::move(child)).second)fail("duplicate object key");ws();if(i>=s.size())fail("unterminated object");char c=s[i++];if(c=='}')break;if(c!=',')fail("invalid object separator");}
        } else if(s[i]=='['){v.kind=Value::Kind::Array;++i;ws();if(i<s.size()&&s[i]==']'){++i;return v;}for(;;){v.array.push_back(value(depth+1));ws();if(i>=s.size())fail("unterminated array");char c=s[i++];if(c==']')break;if(c!=',')fail("invalid array separator");}}
        else if(s[i]=='"'){v.kind=Value::Kind::String;v.scalar=string();}
        else if(s.compare(i,4,"true")==0){v.kind=Value::Kind::Boolean;v.boolean=true;i+=4;}
        else if(s.compare(i,5,"false")==0){v.kind=Value::Kind::Boolean;v.boolean=false;i+=5;}
        else if(s.compare(i,4,"null")==0){v.kind=Value::Kind::Null;i+=4;}
        else {v.kind=Value::Kind::Number;v.scalar=number();}
        return v;
    }
public:
    Parser(const std::string& text, Limits limits={}):s(text),lim(limits){}
    Value parse(){if(s.size()>lim.maxDocument)fail("document size limit exceeded");auto v=value(0);ws();if(i!=s.size())fail("trailing data");return v;}
};
inline const Value& required(const Value& obj,const std::string& key,Value::Kind kind){auto p=obj.find(key);if(!p||p->kind!=kind)throw std::runtime_error("JSON field missing or wrong type: "+key);return *p;}
inline std::string stringField(const Value& obj,const std::string& key,bool requiredField=false){auto p=obj.find(key);if(!p){if(requiredField)throw std::runtime_error("JSON string field missing: "+key);return {};}if(p->kind!=Value::Kind::String)throw std::runtime_error("JSON field is not a string: "+key);return p->scalar;}
inline std::string nullableStringField(const Value& obj,const std::string& key){auto p=obj.find(key);if(!p||p->kind==Value::Kind::Null)return {};if(p->kind!=Value::Kind::String)throw std::runtime_error("JSON field is not a string or null: "+key);return p->scalar;}
inline long long integerField(const Value& obj,const std::string& key,long long fallback){auto p=obj.find(key);if(!p)return fallback;if(p->kind!=Value::Kind::Number||p->scalar.empty()||p->scalar.find_first_of(".eE")!=std::string::npos)throw std::runtime_error("JSON field is not an integer: "+key);try{std::size_t n=0;long long v=std::stoll(p->scalar,&n);if(n!=p->scalar.size())throw std::runtime_error("bad");return v;}catch(...){throw std::runtime_error("JSON integer out of range: "+key);}}
} // namespace itvip::json
