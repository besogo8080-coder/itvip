// IT VIP bilingual branded front-end for the legacy, safety-reviewed CLI engines.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "itvip_branding.hpp"
#include "itvip_ui_audio.hpp"
#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include <filesystem>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>
#include <mutex>
#include <atomic>
namespace fs=std::filesystem;
#ifndef ITVIP_TOOL_KIND
#define ITVIP_TOOL_KIND 0
#endif
namespace {
HWND gWindow{},gHeading{},gPath{},gUser{},gInfo{},gOutput{},gProgress{},gStop{}; bool gAr{}; UINT gDpi=96;
std::thread gWorker; std::mutex gProcessMutex; HANDLE gProcess{}; std::atomic_bool gRunning{false};
constexpr UINT WM_ITVIP_OUTPUT=WM_APP+41, WM_ITVIP_FINISHED=WM_APP+42;
fs::path appRoot(){wchar_t b[32768]{};GetModuleFileNameW(nullptr,b,32768);return fs::path(b).parent_path().parent_path();}
void language(){wchar_t b[32]{};GetPrivateProfileStringW(L"Appearance",L"Language",L"ar",b,32,(appRoot()/L"config"/L"appearance.ini").c_str());gAr=std::wstring(b)==L"ar";}
std::wstring T(const wchar_t*a,const wchar_t*e){return gAr?a:e;}
void label(HWND h,const wchar_t*s){SetWindowTextW(h,s);}
HWND ctl(const wchar_t*cls,const wchar_t*text,DWORD style,int x,int y,int w,int h,int id){return CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,gWindow,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);}
void info(const std::wstring&s){label(gInfo,s.c_str());}
UINT windowDpi(HWND w){using Fn=UINT(WINAPI*)(HWND);static auto fn=(Fn)GetProcAddress(GetModuleHandleW(L"user32.dll"),"GetDpiForWindow");UINT value=fn?fn(w):96u;return value?value:96u;}
int scale96(int value){return MulDiv(value,(int)gDpi,96);}
void layoutToolOutput(HWND w){
 if(!w||!gOutput)return;
 RECT client{};GetClientRect(w,&client);
 const int margin=scale96(30),gap=scale96(12),rowHeight=scale96(42);
 const int clientWidth=std::max(0,(int)client.right);
 const int fullWidth=std::max(scale96(240),clientWidth-margin*2);
 // Keep all input and action controls inside the client area.  A second action
 // moves to its own row when the window is too narrow instead of being clipped.
 if(gHeading)SetWindowPos(gHeading,nullptr,margin,scale96(18),std::max(scale96(260),fullWidth),scale96(40),SWP_NOZORDER|SWP_NOACTIVATE);
 if(HWND subtitle=GetDlgItem(w,122))SetWindowPos(subtitle,nullptr,margin,scale96(62),fullWidth,scale96(28),SWP_NOZORDER|SWP_NOACTIVATE);
 if(HWND pathLabel=GetDlgItem(w,120))SetWindowPos(pathLabel,nullptr,margin,scale96(120),fullWidth,scale96(25),SWP_NOZORDER|SWP_NOACTIVATE);
 if(HWND path=GetDlgItem(w,20)){int browseWidth=scale96(110);int browseX=std::max(margin,clientWidth-margin-browseWidth);int editWidth=std::max(scale96(150),browseX-margin-gap);SetWindowPos(path,nullptr,margin,scale96(150),editWidth,scale96(30),SWP_NOZORDER|SWP_NOACTIVATE);if(HWND browseButton=GetDlgItem(w,21))SetWindowPos(browseButton,nullptr,browseX,scale96(150),browseWidth,scale96(30),SWP_NOZORDER|SWP_NOACTIVATE);}
 if(HWND userLabel=GetDlgItem(w,121))SetWindowPos(userLabel,nullptr,margin,scale96(120),fullWidth,scale96(25),SWP_NOZORDER|SWP_NOACTIVATE);
 if(gUser)SetWindowPos(gUser,nullptr,margin,scale96(150),std::max(scale96(180),fullWidth),scale96(30),SWP_NOZORDER|SWP_NOACTIVATE);
 int actionY=scale96(220),firstWidth=scale96(180),secondWidth=scale96(210),secondY=actionY;
 HWND first=GetDlgItem(w,10),second=GetDlgItem(w,11);
 if(first){if(ITVIP_TOOL_KIND==4)firstWidth=scale96(260);else if(ITVIP_TOOL_KIND==5)firstWidth=scale96(240);SetWindowPos(first,nullptr,margin,actionY,firstWidth,rowHeight,SWP_NOZORDER|SWP_NOACTIVATE);}
 bool hasSecond=second&&IsWindowVisible(second);
 if(hasSecond){if(ITVIP_TOOL_KIND==3)secondWidth=scale96(180);int firstRight=margin+firstWidth; if(firstRight+gap+secondWidth<=clientWidth-margin){SetWindowPos(second,nullptr,firstRight+gap,actionY,secondWidth,rowHeight,SWP_NOZORDER|SWP_NOACTIVATE);}else{secondY=actionY+rowHeight+scale96(10);SetWindowPos(second,nullptr,margin,secondY,secondWidth,rowHeight,SWP_NOZORDER|SWP_NOACTIVATE);}}
 int actionBottom=(hasSecond&&secondY!=actionY)?secondY+rowHeight:actionY+rowHeight;
 int infoY=actionBottom+scale96(24),progressY=infoY+scale96(34),outputY=progressY+scale96(24);
 if(gInfo)SetWindowPos(gInfo,nullptr,margin,infoY,std::max(scale96(180),fullWidth-scale96(190)),scale96(28),SWP_NOZORDER|SWP_NOACTIVATE);
 if(gStop)SetWindowPos(gStop,nullptr,std::max(margin,clientWidth-margin-scale96(170)),infoY-scale96(3),scale96(170),scale96(34),SWP_NOZORDER|SWP_NOACTIVATE);
 if(gProgress)SetWindowPos(gProgress,nullptr,margin,progressY,fullWidth,scale96(14),SWP_NOZORDER|SWP_NOACTIVATE);
 int outputHeight=std::max(scale96(80),(int)client.bottom-outputY-margin);
 SetWindowPos(gOutput,nullptr,margin,outputY,fullWidth,outputHeight,SWP_NOZORDER|SWP_NOACTIVATE);
}
void enablePerMonitorDpi(){using Fn=BOOL(WINAPI*)(HANDLE);HMODULE user32=GetModuleHandleW(L"user32.dll");auto fn=(Fn)GetProcAddress(user32,"SetProcessDpiAwarenessContext");if(fn)fn(reinterpret_cast<HANDLE>(-4));else SetProcessDPIAware();}

// Quote one Windows argv element using the CommandLineToArgvW-compatible rules.
std::wstring quoteArg(const std::wstring& value){
 std::wstring out=L"\""; size_t slashes=0;
 for(wchar_t ch:value){
  if(ch==L'\\'){++slashes;continue;}
  if(ch==L'\"'){out.append(slashes*2+1,L'\\');out.push_back(ch);slashes=0;continue;}
  out.append(slashes,L'\\');slashes=0;out.push_back(ch);
 }
 out.append(slashes*2,L'\\');out.push_back(L'\"');return out;
}
void appendOutput(const std::wstring& value){if(!gOutput)return;int n=GetWindowTextLengthW(gOutput);SendMessageW(gOutput,EM_SETSEL,n,n);SendMessageW(gOutput,EM_REPLACESEL,FALSE,(LPARAM)value.c_str());}
void run(const std::wstring&exe,const std::wstring&args){
 if(gRunning.load()){info(T(L"توجد عملية قيد التشغيل بالفعل.",L"A process is already running."));return;}
 fs::path p=appRoot()/L"build"/exe; if(!fs::exists(p)||!fs::is_regular_file(p)){MessageBoxW(gWindow,T(L"ملف المحرك غير موجود داخل مجلد build.",L"The engine executable is missing from build." ).c_str(),L"IT VIP",MB_ICONERROR);return;}
 SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,TRUE}; HANDLE readPipe{},writePipe{};
 if(!CreatePipe(&readPipe,&writePipe,&sa,0)){info(T(L"تعذر إنشاء قناة إخراج العملية.",L"Could not create the process output pipe."));return;}
 SetHandleInformation(readPipe,HANDLE_FLAG_INHERIT,0);
 std::wstring cmd=quoteArg(p.wstring())+(args.empty()?L"":L" "+args); STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=writePipe;si.hStdError=writePipe;si.hStdInput=GetStdHandle(STD_INPUT_HANDLE); PROCESS_INFORMATION pi{};std::vector<wchar_t>b(cmd.begin(),cmd.end());b.push_back(0);
 if(!CreateProcessW(p.c_str(),b.data(),nullptr,nullptr,TRUE,CREATE_NO_WINDOW,nullptr,appRoot().c_str(),&si,&pi)){DWORD e=GetLastError();CloseHandle(readPipe);CloseHandle(writePipe);info(T(L"تعذر تشغيل المحرك. رمز الخطأ: ",L"Could not launch engine. Error: ")+std::to_wstring(e));return;}
 CloseHandle(writePipe);CloseHandle(pi.hThread);{std::lock_guard<std::mutex> lock(gProcessMutex);gProcess=pi.hProcess;}gRunning=true;
 if(gOutput)SetWindowTextW(gOutput,L"");if(gProgress)SendMessageW(gProgress,PBM_SETMARQUEE,TRUE,35);if(gStop)EnableWindow(gStop,TRUE);info(T(L"الأداة تعمل في الخلفية؛ تظهر النتائج هنا.",L"Tool is running in the background; output appears here."));
 if(gWorker.joinable())gWorker.join(); HWND target=gWindow; HANDLE process=pi.hProcess;
 gWorker=std::thread([readPipe,process,target](){char buf[2048];DWORD got=0;while(ReadFile(readPipe,buf,sizeof(buf),&got,nullptr)&&got){int chars=MultiByteToWideChar(CP_UTF8,0,buf,(int)got,nullptr,0);UINT cp=CP_UTF8;if(chars==0){cp=CP_ACP;chars=MultiByteToWideChar(cp,0,buf,(int)got,nullptr,0);}if(chars>0){std::wstring part(chars,L'\0');MultiByteToWideChar(cp,0,buf,(int)got,part.data(),chars);PostMessageW(target,WM_ITVIP_OUTPUT,0,(LPARAM)new std::wstring(std::move(part)));}}CloseHandle(readPipe);WaitForSingleObject(process,INFINITE);DWORD code=1;GetExitCodeProcess(process,&code);{std::lock_guard<std::mutex> lock(gProcessMutex);if(gProcess==process)gProcess=nullptr;}CloseHandle(process);PostMessageW(target,WM_ITVIP_FINISHED,(WPARAM)code,0);});
}
void stopProcess(){std::lock_guard<std::mutex> lock(gProcessMutex);if(gProcess&&gRunning.load())TerminateProcess(gProcess,ERROR_CANCELLED);}
void browse(){std::wstring title=T(L"اختر مجلدًا",L"Select a folder");BROWSEINFOW bi{};bi.hwndOwner=gWindow;bi.lpszTitle=title.c_str();bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;PIDLIST_ABSOLUTE id=SHBrowseForFolderW(&bi);if(id){wchar_t p[32768]{};if(SHGetPathFromIDListW(id,p))label(gPath,p);CoTaskMemFree(id);}}
void action(int id){std::wstring path(32768,L'\0');GetWindowTextW(gPath,path.data(),(int)path.size());path.resize(wcsnlen(path.c_str(),path.size()));std::wstring user(256,L'\0');GetWindowTextW(gUser,user.data(),(int)user.size());user.resize(wcsnlen(user.c_str(),user.size()));
#if ITVIP_TOOL_KIND == 1 // Scanner
 if(id==10){if(path.empty()){browse();return;}run(L"scanner.exe",quoteArg(path)+L" -o "+quoteArg((appRoot()/L"reports"/L"scanner_gui_report.json").wstring()));}
#elif ITVIP_TOOL_KIND == 2 // USB Guard
 if(id==10){if(path.empty()){browse();return;}run(L"usb_guard.exe",L"scan "+quoteArg(path));} else if(id==11){if(path.empty()){browse();return;}if(MessageBoxW(gWindow,T(L"سيتم تطبيق إعداد الحماية على محرك USB المحدد. هل تريد المتابعة؟",L"Apply the USB protection action to the selected drive?" ).c_str(),L"IT VIP",MB_YESNO|MB_ICONWARNING)==IDYES)run(L"usb_guard.exe",L"immunize "+quoteArg(path));}
#elif ITVIP_TOOL_KIND == 3 // Temp cleaner
 if(id==10)run(L"tempclean.exe",L"--older-than-days 7"); else if(id==11){if(MessageBoxW(gWindow,T(L"سيتم حذف الملفات المؤقتة المؤهلة. هل تريد المتابعة؟",L"Eligible temporary files will be deleted. Continue?" ).c_str(),L"IT VIP",MB_YESNO|MB_ICONWARNING)==IDYES)run(L"tempclean.exe",L"--older-than-days 7 --apply");}
#elif ITVIP_TOOL_KIND == 4 // Activation
 if(id==10)run(L"activator.exe",L"--windows --office --status");
#elif ITVIP_TOOL_KIND == 5 // Password recovery
 if(id==10){if(user.empty()){MessageBoxW(gWindow,T(L"اكتب اسم الحساب المحلي أولاً.",L"Enter the local account name first.").c_str(),L"IT VIP",MB_ICONINFORMATION);return;}if(MessageBoxW(gWindow,T(L"ستفتح أداة Windows الآمنة لإعادة تعيين كلمة مرور حساب محلي. لا يتم استخراج كلمات المرور.",L"The secure Windows local-account password reset workflow will open. Passwords are never extracted.").c_str(),L"IT VIP",MB_YESNO|MB_ICONWARNING)==IDYES)run(L"pwrecover.exe",L"live "+quoteArg(user));}
#elif ITVIP_TOOL_KIND == 6 // Security
 if(id==10)run(L"security_center.exe",L"");
#endif
}
LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){switch(m){case WM_CREATE:{gWindow=w;language();itvip::applyBranding(w,GetModuleHandleW(nullptr));gHeading=CreateWindowW(L"STATIC",L"IT VIP",WS_CHILD|WS_VISIBLE,28,18,620,40,w,nullptr,nullptr,nullptr);CreateWindowW(L"STATIC",T(L"أداة من مجموعة IT VIP",L"An IT VIP toolkit module").c_str(),WS_CHILD|WS_VISIBLE,30,62,500,28,w,(HMENU)(INT_PTR)122,nullptr,nullptr);
#if ITVIP_TOOL_KIND==1
 label(gHeading,T(L"فاحص الملفات",L"File Scanner").c_str());
#elif ITVIP_TOOL_KIND==2
 label(gHeading,T(L"حماية USB",L"USB Guard").c_str());
#elif ITVIP_TOOL_KIND==3
 label(gHeading,T(L"منظف الملفات المؤقتة",L"Temporary File Cleaner").c_str());
#elif ITVIP_TOOL_KIND==4
 label(gHeading,T(L"مدير حالة التنشيط",L"Activation Status Manager").c_str());
#elif ITVIP_TOOL_KIND==5
 label(gHeading,T(L"مساعدة استعادة الحساب المحلي",L"Local Account Recovery").c_str());
#else
 label(gHeading,T(L"مركز الأمان",L"Security Center").c_str());
#endif
#if ITVIP_TOOL_KIND==1 || ITVIP_TOOL_KIND==2
 CreateWindowW(L"STATIC",T(L"المجلد / محرك USB:",L"Folder / USB drive:").c_str(),WS_CHILD|WS_VISIBLE,30,120,220,25,w,(HMENU)(INT_PTR)120,nullptr,nullptr);gPath=ctl(L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,30,150,520,30,20);ctl(L"BUTTON",T(L"استعراض...",L"Browse...").c_str(),BS_PUSHBUTTON,560,150,110,30,21);
#elif ITVIP_TOOL_KIND==5
 CreateWindowW(L"STATIC",T(L"اسم الحساب المحلي:",L"Local account name:").c_str(),WS_CHILD|WS_VISIBLE,30,120,220,25,w,(HMENU)(INT_PTR)121,nullptr,nullptr);gUser=ctl(L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,30,150,400,30,22);
#endif
#if ITVIP_TOOL_KIND==1 || ITVIP_TOOL_KIND==6
 ctl(L"BUTTON",T(L"بدء الفحص",L"Start scan").c_str(),BS_PUSHBUTTON,30,220,180,42,10);
#elif ITVIP_TOOL_KIND==2
 ctl(L"BUTTON",T(L"فحص USB",L"Scan USB").c_str(),BS_PUSHBUTTON,30,220,180,42,10);ctl(L"BUTTON",T(L"تجهيز الحماية",L"Apply USB protection").c_str(),BS_PUSHBUTTON,230,220,210,42,11);
#elif ITVIP_TOOL_KIND==3
 ctl(L"BUTTON",T(L"معاينة التنظيف",L"Preview cleanup").c_str(),BS_PUSHBUTTON,30,220,180,42,10);ctl(L"BUTTON",T(L"تنفيذ التنظيف",L"Apply cleanup").c_str(),BS_PUSHBUTTON,230,220,180,42,11);
#elif ITVIP_TOOL_KIND==4
 ctl(L"BUTTON",T(L"عرض حالة Windows وOffice",L"Check Windows and Office status").c_str(),BS_PUSHBUTTON,30,220,260,42,10);
#elif ITVIP_TOOL_KIND==5
 ctl(L"BUTTON",T(L"فتح إجراء إعادة التعيين",L"Open reset workflow").c_str(),BS_PUSHBUTTON,30,220,240,42,10);
#endif
 gInfo=CreateWindowW(L"STATIC",T(L"اختر الإجراء المطلوب. العمليات الحساسة تتطلب تأكيدًا.",L"Choose an action. Sensitive operations require confirmation.").c_str(),WS_CHILD|WS_VISIBLE,30,300,700,28,w,nullptr,nullptr,nullptr);
 gProgress=CreateWindowW(PROGRESS_CLASSW,L"",WS_CHILD|WS_VISIBLE|PBS_MARQUEE,30,334,620,14,w,nullptr,GetModuleHandleW(nullptr),nullptr);gOutput=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,30,358,700,210,w,nullptr,nullptr,nullptr);gStop=CreateWindowW(L"BUTTON",T(L"إيقاف العملية",L"Stop process").c_str(),WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,560,290,170,34,w,(HMENU)(INT_PTR)31,GetModuleHandleW(nullptr),nullptr);EnableWindow(gStop,FALSE);gDpi=windowDpi(w);layoutToolOutput(w);return 0;}
 case WM_GETMINMAXINFO:{auto* limits=reinterpret_cast<MINMAXINFO*>(b);if(limits){limits->ptMinTrackSize.x=scale96(440);limits->ptMinTrackSize.y=scale96(560);}return 0;}case WM_SIZE:layoutToolOutput(w);return 0;case WM_DPICHANGED:{gDpi=HIWORD(a)?HIWORD(a):windowDpi(w);auto* suggested=reinterpret_cast<RECT*>(b);if(suggested)SetWindowPos(w,nullptr,suggested->left,suggested->top,suggested->right-suggested->left,suggested->bottom-suggested->top,SWP_NOZORDER|SWP_NOACTIVATE);layoutToolOutput(w);return 0;}case WM_COMMAND:if(HIWORD(a)==BN_CLICKED)itvip::audio::click();if(LOWORD(a)==21){browse();return 0;}if(LOWORD(a)==31){stopProcess();return 0;}action(LOWORD(a));return 0;
 case WM_ITVIP_OUTPUT:{auto part=(std::wstring*)b;if(part){appendOutput(*part);delete part;}return 0;}
 case WM_ITVIP_FINISHED:if(gProgress)SendMessageW(gProgress,PBM_SETMARQUEE,FALSE,0);if(gStop)EnableWindow(gStop,FALSE);gRunning=false;if((WPARAM)a==0)itvip::audio::success();else itvip::audio::warning();itvip::audio::complete();info((WPARAM)a==0?T(L"انتهت العملية بنجاح.",L"Process completed successfully."):T(L"انتهت العملية برمز خروج غير صفري: ",L"Process finished with non-zero exit code: ")+std::to_wstring((DWORD)a));return 0;
 case WM_CLOSE:itvip::audio::back();return DefWindowProcW(w,m,a,b);case WM_DESTROY:stopProcess();if(gWorker.joinable())gWorker.join();PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,b);}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int show){enablePerMonitorDpi();INITCOMMONCONTROLSEX x{sizeof(x),ICC_STANDARD_CLASSES|ICC_PROGRESS_CLASS};InitCommonControlsEx(&x);WNDCLASSW c{};c.lpfnWndProc=proc;c.hInstance=h;c.lpszClassName=L"ITVIPBrandedTool";c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hbrBackground=itvip::backgroundBrush();RegisterClassW(&c);HWND w=CreateWindowExW(0,c.lpszClassName,L"IT VIP — Toolkit",WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,CW_USEDEFAULT,800,650,nullptr,nullptr,h,nullptr);if(!w)return 1;itvip::applyBranding(w,h);ShowWindow(w,show);UpdateWindow(w);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;}
