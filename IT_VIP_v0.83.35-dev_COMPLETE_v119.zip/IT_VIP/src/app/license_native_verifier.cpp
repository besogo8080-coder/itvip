// Native cryptographic verifier for IT VIP user editions (Windows CNG).
// Verifies RSA-3072/SHA-256 signatures and every file listed in the signed inventory.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <regex>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <stdexcept>
#include <cctype>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <set>
#include <cwctype>
#include <sddl.h>
#include <dpapi.h>
#include "strict_json.hpp"
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")
namespace fs = std::filesystem;
namespace {
BCRYPT_ALG_HANDLE gRsaAlg = nullptr;
std::vector<BYTE> readBytes(const fs::path& p, std::uint64_t maxBytes = 512ULL * 1024ULL * 1024ULL) {
    // Check the size before allocating. Reading through iterators alone allowed an
    // unexpectedly large file to consume unbounded memory before policy checks ran.
    std::error_code sizeError;
    const auto size = fs::file_size(p, sizeError);
    if (sizeError) throw std::runtime_error("Cannot determine file size: " + p.string());
    if (size > maxBytes || size > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()))
        throw std::runtime_error("File exceeds the bounded read limit: " + p.string());
    std::ifstream f(p, std::ios::binary);
    if (!f) throw std::runtime_error("Cannot read: " + p.string());
    std::vector<BYTE> bytes(static_cast<std::size_t>(size));
    if (!bytes.empty()) {
        f.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!f || static_cast<std::size_t>(f.gcount()) != bytes.size())
            throw std::runtime_error("File changed or could not be read completely: " + p.string());
    }
    return bytes;
}
std::vector<BYTE> decodeB64(const std::string& s) {
    DWORD n=0; if(!CryptStringToBinaryA(s.c_str(),0,CRYPT_STRING_BASE64,nullptr,&n,nullptr,nullptr)) throw std::runtime_error("Invalid Base64 signature");
    std::vector<BYTE> out(n); if(!CryptStringToBinaryA(s.c_str(),0,CRYPT_STRING_BASE64,out.data(),&n,nullptr,nullptr)) throw std::runtime_error("Cannot decode signature"); out.resize(n); return out;
}
std::wstring widen(const std::string& s) { if(s.empty()) return {}; int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),nullptr,0); if(!n) throw std::runtime_error("Invalid UTF-8 path"); std::wstring w(n,L'\0'); MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),w.data(),n); return w; }
std::vector<BYTE> sha256(const std::vector<BYTE>& data) {
    BCRYPT_ALG_HANDLE alg=nullptr; BCRYPT_HASH_HANDLE hash=nullptr; DWORD objLen=0, got=0, hashLen=0;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0) throw std::runtime_error("CNG SHA-256 unavailable");
    try { BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&objLen,sizeof(objLen),&got,0); BCryptGetProperty(alg,BCRYPT_HASH_LENGTH,(PUCHAR)&hashLen,sizeof(hashLen),&got,0); std::vector<BYTE> obj(objLen), out(hashLen);
        if(BCryptCreateHash(alg,&hash,obj.data(),objLen,nullptr,0,0)<0) throw std::runtime_error("Cannot create SHA-256 hash");
        if(!data.empty() && BCryptHashData(hash,const_cast<PUCHAR>(data.data()),(ULONG)data.size(),0)<0) throw std::runtime_error("SHA-256 input too large");
        if(BCryptFinishHash(hash,out.data(),hashLen,0)<0) throw std::runtime_error("Cannot finish SHA-256"); BCryptDestroyHash(hash); BCryptCloseAlgorithmProvider(alg,0); return out;
    } catch(...) { if(hash) BCryptDestroyHash(hash); if(alg) BCryptCloseAlgorithmProvider(alg,0); throw; }
}
std::string hex(const std::vector<BYTE>& b) { static const char* h="0123456789ABCDEF"; std::string s; for(BYTE x:b){s+=h[x>>4];s+=h[x&15];} return s; }
std::string jsonString(const itvip::json::Value& value,const char* name,bool required=false) {
    return itvip::json::stringField(value,name,required);
}
long long jsonInteger(const itvip::json::Value& value,const char* name,long long fallback) {
    return itvip::json::integerField(value,name,fallback);
}
// Accept ISO-8601 UTC timestamps emitted by the edition signer (fractional seconds optional).
std::time_t parseUtc(const std::string& value,const char* field) {
    if(value.empty()) return 0;
    int y=0,mo=0,d=0,h=0,mi=0,se=0;
    static const std::regex utcPattern(R"(^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,7})?(Z|\+00:00)$)");
    if(!std::regex_match(value,utcPattern) ||
       std::sscanf(value.c_str(),"%4d-%2d-%2dT%2d:%2d:%2d",&y,&mo,&d,&h,&mi,&se)!=6)
        throw std::runtime_error(std::string("Invalid UTC ISO-8601 timestamp: ")+field);
    if(mo<1||mo>12||d<1||d>31||h>23||mi>59||se>60) throw std::runtime_error(std::string("Out-of-range timestamp: ")+field);
    SYSTEMTIME st{}; st.wYear=(WORD)y; st.wMonth=(WORD)mo; st.wDay=(WORD)d; st.wHour=(WORD)h; st.wMinute=(WORD)mi; st.wSecond=(WORD)se;
    FILETIME ft{}; if(!SystemTimeToFileTime(&st,&ft)) throw std::runtime_error(std::string("Invalid calendar timestamp: ")+field);
    ULARGE_INTEGER u{}; u.LowPart=ft.dwLowDateTime; u.HighPart=ft.dwHighDateTime;
    constexpr unsigned long long epoch=116444736000000000ULL;
    if(u.QuadPart<epoch) throw std::runtime_error(std::string("Timestamp before Unix epoch: ")+field);
    return static_cast<std::time_t>((u.QuadPart-epoch)/10000000ULL);
}
std::string currentWindowsSidHash() {
    HANDLE token=nullptr; if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token)) throw std::runtime_error("Cannot open current Windows access token");
    DWORD needed=0; GetTokenInformation(token,TokenUser,nullptr,0,&needed);
    std::vector<BYTE> buffer(needed); if(!needed || !GetTokenInformation(token,TokenUser,buffer.data(),needed,&needed)){CloseHandle(token);throw std::runtime_error("Cannot read current Windows account SID");}
    CloseHandle(token); auto* user=reinterpret_cast<TOKEN_USER*>(buffer.data()); LPWSTR sidText=nullptr;
    if(!ConvertSidToStringSidW(user->User.Sid,&sidText)) throw std::runtime_error("Cannot convert current Windows SID");
    int n=WideCharToMultiByte(CP_UTF8,0,sidText,-1,nullptr,0,nullptr,nullptr); if(!n){LocalFree(sidText);throw std::runtime_error("Cannot size current Windows SID encoding");}
    std::string sid(static_cast<size_t>(n),'\0');
    if(WideCharToMultiByte(CP_UTF8,0,sidText,-1,sid.data(),n,nullptr,nullptr)==0){LocalFree(sidText);throw std::runtime_error("Cannot encode current Windows SID");}
    LocalFree(sidText); sid.pop_back(); std::vector<BYTE> bytes(sid.begin(),sid.end()); return hex(sha256(bytes));
}
void enforceBindingAndExpiry(const itvip::json::Value& manifest) {
    const auto issued=jsonString(manifest,"IssuedUtc",true); const auto expiry=itvip::json::nullableStringField(manifest,"ExpiresUtc");
    const auto now=std::time(nullptr);
    if(!issued.empty() && parseUtc(issued,"IssuedUtc")>now+300) throw std::runtime_error("Edition issue timestamp is in the future");
    if(!expiry.empty() && parseUtc(expiry,"ExpiresUtc")<=now) throw std::runtime_error("Edition has expired");
    const auto mode=jsonString(manifest,"BindingMode");
    if(mode.empty() || mode=="None") return;
    if(mode!="WindowsSid") throw std::runtime_error("Unsupported license binding mode");
    const auto expected=jsonString(manifest,"BindingValue",true); if(expected.size()!=64) throw std::runtime_error("Invalid Windows SID binding hash");
    std::string actual=currentWindowsSidHash(), a=expected; std::transform(a.begin(),a.end(),a.begin(),[](unsigned char c){return static_cast<char>(toupper(c));});
    if(actual!=a) throw std::runtime_error("This edition is bound to a different Windows account");
}
void enforceAntiRollback(const itvip::json::Value& manifest,const itvip::json::Value& revocations) {
    const auto editionId=jsonString(manifest,"EditionId",true);
    if(editionId.size()!=36) throw std::runtime_error("Invalid EditionId");
    const long long revision=jsonInteger(revocations,"Revision",0); if(revision<0) throw std::runtime_error("Negative revocation revision");
    DWORD localLen=GetEnvironmentVariableW(L"LOCALAPPDATA",nullptr,0); if(!localLen) throw std::runtime_error("LOCALAPPDATA is unavailable; anti-rollback state cannot be protected");
    std::vector<wchar_t> local(localLen); if(!GetEnvironmentVariableW(L"LOCALAPPDATA",local.data(),localLen)) throw std::runtime_error("Cannot read LOCALAPPDATA");
    fs::path stateDir=fs::path(local.data())/L"ITVIP"/L"LicenseState";
    std::string safeId=editionId; std::replace(safeId.begin(),safeId.end(),'-','_');
    fs::path statePath=stateDir/(widen(safeId)+L".bin");
    const BYTE entropyRaw[]={'I','T','V','I','P','-','L','i','c','e','n','s','e','S','t','a','t','e','-','v','1'};
    DATA_BLOB entropy{static_cast<DWORD>(sizeof(entropyRaw)),const_cast<BYTE*>(entropyRaw)};
    long long highest=0;
    if(fs::exists(statePath)) {
        auto protectedBytes=readBytes(statePath, 64ULL * 1024ULL); DATA_BLOB in{static_cast<DWORD>(protectedBytes.size()),protectedBytes.data()}, out{};
        if(!CryptUnprotectData(&in,nullptr,&entropy,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&out)) throw std::runtime_error("Cannot unprotect anti-rollback state; refusing launch");
        std::string plain(reinterpret_cast<char*>(out.pbData),out.cbData); LocalFree(out.pbData);
        const auto stored=itvip::json::Parser(plain).parse();
        if(stored.kind!=itvip::json::Value::Kind::Object) throw std::runtime_error("Stored anti-rollback state is not an object");
        const auto storedId=jsonString(stored,"EditionId",true); if(storedId!=editionId) throw std::runtime_error("Anti-rollback state identity mismatch");
        highest=jsonInteger(stored,"HighestRevision",-1); if(highest<0) throw std::runtime_error("Stored anti-rollback revision is invalid");
    }
    if(revision<highest) throw std::runtime_error("Rollback detected: signed revocation snapshot is older than accepted state");
    if(revision>highest) {
        fs::create_directories(stateDir); std::string plain="{\"EditionId\":\""+editionId+"\",\"HighestRevision\":"+std::to_string(revision)+"}";
        DATA_BLOB raw{static_cast<DWORD>(plain.size()),reinterpret_cast<BYTE*>(plain.data())}, sealed{};
        if(!CryptProtectData(&raw,L"IT VIP license anti-rollback state",&entropy,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&sealed)) throw std::runtime_error("Cannot protect anti-rollback state; refusing launch");
        fs::path tmp=statePath; tmp+=L".tmp"; HANDLE file=CreateFileW(tmp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(file==INVALID_HANDLE_VALUE){LocalFree(sealed.pbData);throw std::runtime_error("Cannot create anti-rollback state file");}
        DWORD written=0; BOOL ok=WriteFile(file,sealed.pbData,sealed.cbData,&written,nullptr); FlushFileBuffers(file); CloseHandle(file); LocalFree(sealed.pbData);
        if(!ok || written!=sealed.cbData || !MoveFileExW(tmp.c_str(),statePath.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(tmp.c_str());throw std::runtime_error("Cannot commit anti-rollback state; refusing launch");}
    }
}
std::wstring xmlValue(const std::string& xml,const char* tag) { std::regex r(std::string("<")+tag+">([^<]+)</"+tag+">"); std::smatch m; if(!std::regex_search(xml,m,r)) throw std::runtime_error(std::string("Public key missing ")+tag); return widen(m[1].str()); }
std::vector<BYTE> b64Wide(const std::wstring& w) { std::string s(w.begin(),w.end()); return decodeB64(s); }
BCRYPT_KEY_HANDLE importPublic(const fs::path& p) {
    std::string xml=readText(p); auto mod=b64Wide(xmlValue(xml,"Modulus")); auto exp=b64Wide(xmlValue(xml,"Exponent"));
    if(mod.size()!=384 || exp.empty() || exp.size()>8) throw std::runtime_error("Authority key must be RSA-3072 public XML");
    BCRYPT_RSAKEY_BLOB hdr{}; hdr.Magic=BCRYPT_RSAPUBLIC_MAGIC; hdr.BitLength=3072; hdr.cbPublicExp=(ULONG)exp.size(); hdr.cbModulus=(ULONG)mod.size();
    std::vector<BYTE> blob(sizeof(hdr)+exp.size()+mod.size()); memcpy(blob.data(),&hdr,sizeof(hdr)); size_t off=sizeof(hdr); memcpy(blob.data()+off,exp.data(),exp.size()); off+=exp.size(); memcpy(blob.data()+off,mod.data(),mod.size());
    BCRYPT_KEY_HANDLE key=nullptr;
    if(BCryptOpenAlgorithmProvider(&gRsaAlg,BCRYPT_RSA_ALGORITHM,nullptr,0)<0) throw std::runtime_error("CNG RSA provider unavailable");
    NTSTATUS st=BCryptImportKeyPair(gRsaAlg,nullptr,BCRYPT_RSAPUBLIC_BLOB,&key,blob.data(),(ULONG)blob.size(),0);
    if(st<0) { BCryptCloseAlgorithmProvider(gRsaAlg,0); gRsaAlg=nullptr; throw std::runtime_error("Cannot import authority RSA public key"); } return key;
}
void verify(BCRYPT_KEY_HANDLE key,const std::vector<BYTE>& payload,const fs::path& sigPath) {
    auto sig=decodeB64(readText(sigPath)); auto digest=sha256(payload); BCRYPT_PKCS1_PADDING_INFO pad{BCRYPT_SHA256_ALGORITHM};
    if(BCryptVerifySignature(key,&pad,digest.data(),(ULONG)digest.size(),sig.data(),(ULONG)sig.size(),BCRYPT_PAD_PKCS1)<0) throw std::runtime_error("RSA signature verification failed: "+sigPath.filename().string());
}
std::vector<BYTE> concat(const std::vector<BYTE>& a,const std::vector<BYTE>& b) { std::vector<BYTE> p; p.reserve(a.size()+b.size()); p.insert(p.end(),a.begin(),a.end()); p.insert(p.end(),b.begin(),b.end()); return p; }
std::wstring pathKey(std::wstring value) {
    std::transform(value.begin(), value.end(), value.begin(), [](wchar_t c) { return static_cast<wchar_t>(std::towlower(c)); });
    return value;
}
void rejectReparsePoint(const fs::path& path) {
    const DWORD attrs = GetFileAttributesW(path.c_str());
    if (attrs == INVALID_FILE_ATTRIBUTES) throw std::runtime_error("Cannot inspect edition path attributes: " + path.string());
    if ((attrs & FILE_ATTRIBUTE_REPARSE_POINT) != 0) throw std::runtime_error("Reparse points and symbolic links are forbidden in a signed edition");
}
void checkInventory(const fs::path& root,const itvip::json::Value& inventory) {
    if(inventory.kind!=itvip::json::Value::Kind::Array || inventory.array.empty()) throw std::runtime_error("Signed file inventory must be a non-empty JSON array");
    if(inventory.array.size()>100000) throw std::runtime_error("Signed file inventory exceeds the 100,000-entry policy limit");
    std::uint64_t totalBytes=0;
    std::set<std::wstring> seen;
    for(const auto& entry:inventory.array){
        if(entry.kind!=itvip::json::Value::Kind::Object || entry.object.size()!=2) throw std::runtime_error("Inventory entry must contain exactly Path and SHA256");
        std::string rel=itvip::json::stringField(entry,"Path",true);
        std::string expected=itvip::json::stringField(entry,"SHA256",true);
        if(expected.size()!=64 || !std::all_of(expected.begin(),expected.end(),[](unsigned char c){return std::isxdigit(c)!=0;})) throw std::runtime_error("Invalid inventory SHA256 value");
        if (rel.empty() || rel.find('\0') != std::string::npos) throw std::runtime_error("Empty or NUL-containing inventory path");
        fs::path rp=fs::u8path(rel);
        if(rp.empty()||rp.is_absolute()||rp.has_root_name()||rp.has_root_directory()) throw std::runtime_error("Unsafe inventory path");
        for(auto& part:rp) if(part==L".." || part==L".") throw std::runtime_error("Traversal or ambiguous component in inventory path");
        fs::path full=(root/rp).lexically_normal();
        auto r=root.lexically_normal().wstring(), f=full.wstring();
        if(f.size()<=r.size()||_wcsnicmp(f.c_str(),r.c_str(),r.size())!=0||f[r.size()]!=L'\\') throw std::runtime_error("Inventory path escapes edition root");
        if(!seen.insert(pathKey(rp.wstring())).second) throw std::runtime_error("Duplicate inventory path (case-insensitive)");
        // Check every component, not only the leaf: a junction in a parent directory
        // can redirect an otherwise ordinary-looking file outside the edition.
        fs::path walk=root;
        for (const auto& part : rp) { walk /= part; rejectReparsePoint(walk); }
        if(!fs::is_regular_file(full)) throw std::runtime_error("Missing or non-regular inventory file: "+rel);
        const auto fileBytes=fs::file_size(full);
        if(fileBytes>512ULL*1024ULL*1024ULL) throw std::runtime_error("Inventory file exceeds the 512 MiB per-file verification limit: "+rel);
        if(fileBytes>4ULL*1024ULL*1024ULL*1024ULL-totalBytes) throw std::runtime_error("Edition exceeds the 4 GiB aggregate inventory limit");
        totalBytes+=fileBytes;
        auto actual=hex(sha256(readBytes(full)));
        std::transform(expected.begin(),expected.end(),expected.begin(),[](unsigned char c){return (char)toupper(c);});
        if(actual!=expected) throw std::runtime_error("SHA-256 mismatch: "+rel);
    }
    // Match the PowerShell verifier's exact-tree policy: an unlisted payload file
    // must not be smuggled into a signed edition after inventory generation.
    std::set<std::wstring> allowed=seen;
    for (const wchar_t* metadata : {L"EDITION_SHA256.json", L"EDITION_SIGNATURE.sha256rsa", L"EDITION_REVOCATIONS.sha256rsa"})
        allowed.insert(pathKey(metadata));
    std::error_code ec;
    fs::recursive_directory_iterator cur(root, fs::directory_options::none, ec), last;
    if (ec) throw std::runtime_error("Cannot start complete edition-tree enumeration");
    for (; cur!=last; cur.increment(ec)) {
        if (ec) throw std::runtime_error("Cannot enumerate complete edition tree");
        rejectReparsePoint(cur->path());
        if (cur->is_regular_file(ec)) {
            if (ec) throw std::runtime_error("Cannot inspect edition file type");
            auto rel=cur->path().lexically_relative(root).wstring();
            if (!allowed.count(pathKey(rel))) throw std::runtime_error("Unlisted file in signed edition: " + cur->path().filename().string());
        } else if (!cur->is_directory(ec) || ec) {
            throw std::runtime_error("Unsupported filesystem object in signed edition");
        }
    }
}
}
int wmain(int argc,wchar_t** argv) {
    try {
        if(argc!=5 || std::wstring(argv[1])!=L"--edition" || std::wstring(argv[3])!=L"--public-key") { std::wcerr<<L"Usage: ITVIPNativeVerify.exe --edition <folder> --public-key <authority.public.xml>\n"; return 2; }
        fs::path root=fs::canonical(argv[2]), pub=fs::canonical(argv[4]);
        auto manifest=readBytes(root/L"EDITION_MANIFEST.json", 4ULL * 1024ULL * 1024ULL);
        auto inventory=readBytes(root/L"EDITION_SHA256.json", 64ULL * 1024ULL * 1024ULL);
        auto rev=readBytes(root/L"EDITION_REVOCATIONS.json", 16ULL * 1024ULL * 1024ULL);
        BCRYPT_KEY_HANDLE key=importPublic(pub);
        try {
            verify(key,concat(manifest,inventory),root/L"EDITION_SIGNATURE.sha256rsa");
            verify(key,rev,root/L"EDITION_REVOCATIONS.sha256rsa");
        } catch(...) { BCryptDestroyKey(key); throw; }
        BCryptDestroyKey(key); if(gRsaAlg){BCryptCloseAlgorithmProvider(gRsaAlg,0);gRsaAlg=nullptr;}
        std::string m(manifest.begin(),manifest.end()), invText(inventory.begin(),inventory.end()), r(rev.begin(),rev.end());
        // Parse signed JSON into a typed DOM. All subsequent policy decisions use
        // typed values; no regex-based extraction from raw JSON remains.
        auto manifestDoc=itvip::json::Parser(m).parse();
        auto inventoryDoc=itvip::json::Parser(invText).parse();
        auto revocationDoc=itvip::json::Parser(r).parse();
        if(manifestDoc.kind!=itvip::json::Value::Kind::Object || revocationDoc.kind!=itvip::json::Value::Kind::Object) throw std::runtime_error("Manifest and revocation snapshot must be JSON objects");
        checkInventory(root,inventoryDoc);
        if(jsonString(manifestDoc,"Schema",true)!="ITVIP-USER-EDITION-2") throw std::runtime_error("Unsupported edition manifest schema");
        if(jsonString(manifestDoc,"Status")=="Revoked") throw std::runtime_error("Edition profile is revoked");
        enforceBindingAndExpiry(manifestDoc);
        if(jsonString(revocationDoc,"Schema",true)!="ITVIP-REVOCATIONS-1") throw std::runtime_error("Unsupported revocation schema");
        // Enforce the complete signed snapshot schema; unknown or omitted fields are rejected.
        if(revocationDoc.object.size()!=4) throw std::runtime_error("Revocation snapshot must contain exactly Schema, Revision, GeneratedUtc, and RevokedEditionIds");
        const auto revision=jsonInteger(revocationDoc,"Revision",-1);
        if(revision<0) throw std::runtime_error("Revocation Revision is missing or negative");
        const auto generatedUtc=jsonString(revocationDoc,"GeneratedUtc",true);
        (void)parseUtc(generatedUtc,"GeneratedUtc");
        // Check revocation membership before changing protected anti-rollback state.
        const auto editionId=jsonString(manifestDoc,"EditionId",true);
        const auto validGuid=[](const std::string& id){if(id.size()!=36)return false;for(std::size_t i=0;i<id.size();++i){if(i==8||i==13||i==18||i==23){if(id[i]!='-')return false;}else if(!std::isxdigit(static_cast<unsigned char>(id[i])))return false;}return true;};
        if(!validGuid(editionId)) throw std::runtime_error("EditionId missing or invalid in signed manifest");
        const auto* revokedIds=revocationDoc.find("RevokedEditionIds");
        if(!revokedIds || revokedIds->kind!=itvip::json::Value::Kind::Array) throw std::runtime_error("RevokedEditionIds must be an array");
        if(revokedIds->array.size()>100000) throw std::runtime_error("RevokedEditionIds exceeds the 100,000-entry policy limit");
        std::set<std::string> uniqueRevokedIds;
        std::string target=editionId; std::transform(target.begin(),target.end(),target.begin(),[](unsigned char c){return (char)tolower(c);});
        for(const auto& item:revokedIds->array){
            if(item.kind!=itvip::json::Value::Kind::String || !validGuid(item.scalar)) throw std::runtime_error("Invalid EditionId in signed revocation list");
            std::string candidate=item.scalar; std::transform(candidate.begin(),candidate.end(),candidate.begin(),[](unsigned char c){return (char)tolower(c);});
            if(!uniqueRevokedIds.insert(candidate).second) throw std::runtime_error("Duplicate EditionId in signed revocation list");
            if(candidate==target) throw std::runtime_error("EditionId is revoked in signed snapshot");
        }
        // Mutate the protected high-water mark only after every signed policy field
        // and the current EditionId revocation decision have passed.
        enforceAntiRollback(manifestDoc,revocationDoc);
        std::wcout<<L"PASS: native RSA signatures, typed JSON DOM, policy, and signed file inventory verified.\n"; return 0;
    } catch(const std::exception& e) { std::cerr<<"IT VIP native verification failed: "<<e.what()<<"\n"; return 1; }
}
