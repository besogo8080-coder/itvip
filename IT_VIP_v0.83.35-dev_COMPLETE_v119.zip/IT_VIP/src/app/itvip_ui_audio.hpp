#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <mmsystem.h>
#include <filesystem>
#include <string>
#include <system_error>
#pragma comment(lib, "winmm.lib")

// Small, optional UI earcons shared by the dashboard and native tool windows.
// Audio is non-blocking and can be disabled in config/appearance.ini.
namespace itvip::audio {
enum class Cue { Click, Back, Success, Warning, Complete, Notification, Startup, Shutdown };
inline const wchar_t* cueFile(Cue cue) {
    switch (cue) {
    case Cue::Back: return L"ui_back.wav";
    case Cue::Success: return L"ui_success.wav";
    case Cue::Warning: return L"ui_warning.wav";
    case Cue::Complete: return L"ui_complete.wav";
    case Cue::Notification: return L"ui_notification.wav";
    case Cue::Startup: return L"ui_startup.wav";
    case Cue::Shutdown: return L"ui_shutdown.wav";
    default: return L"ui_click.wav";
    }
}
inline const wchar_t* cueSetting(Cue cue) {
    switch (cue) {
    case Cue::Success: return L"SuccessEnabled";
    case Cue::Warning: return L"WarningEnabled";
    case Cue::Complete: return L"CompleteEnabled";
    case Cue::Notification: return L"NotificationEnabled";
    case Cue::Startup: return L"StartupEnabled";
    case Cue::Shutdown: return L"ShutdownEnabled";
    case Cue::Back: return L"BackEnabled";
    default: return L"ClickEnabled";
    }
}
inline std::filesystem::path projectRoot() {
    wchar_t buffer[32768]{};
    const DWORD length = GetModuleFileNameW(nullptr, buffer, static_cast<DWORD>(sizeof(buffer) / sizeof(buffer[0])));
    if (!length || length >= (sizeof(buffer) / sizeof(buffer[0]))) return {};
    std::filesystem::path executable(std::wstring(buffer, length));
    auto directory = executable.parent_path();
    std::error_code ec;
    if (std::filesystem::exists(directory / L"config" / L"appearance.ini", ec)) return directory;
    if (std::filesystem::exists(directory.parent_path() / L"config" / L"appearance.ini", ec)) return directory.parent_path();
    return directory.parent_path();
}
inline bool enabled() {
    const auto root = projectRoot();
    if (root.empty()) return true;
    return GetPrivateProfileIntW(L"Audio", L"Enabled", 1,
        (root / L"config" / L"appearance.ini").c_str()) != 0;
}
inline const wchar_t* cueFileSetting(Cue cue) {
    switch (cue) {
    case Cue::Back: return L"BackFile";
    case Cue::Success: return L"SuccessFile";
    case Cue::Warning: return L"WarningFile";
    case Cue::Complete: return L"CompleteFile";
    case Cue::Notification: return L"NotificationFile";
    case Cue::Startup: return L"StartupFile";
    case Cue::Shutdown: return L"ShutdownFile";
    default: return L"ClickFile";
    }
}
inline void play(Cue cue, bool synchronous = false) {
    if (!enabled()) return;
    const auto root = projectRoot();
    const auto ini = root / L"config" / L"appearance.ini";
    const int defaultCueEnabled = (cue == Cue::Startup || cue == Cue::Shutdown) ? 0 : 1;
    if (!root.empty() && GetPrivateProfileIntW(L"Audio", cueSetting(cue), defaultCueEnabled, ini.c_str()) == 0) return;
    wchar_t custom[32768]{};
    if (!root.empty()) GetPrivateProfileStringW(L"Audio", cueFileSetting(cue), L"", custom, 32768, ini.c_str());
    std::filesystem::path file;
    std::error_code ec;
    if (custom[0]) {
        std::filesystem::path configured(custom);
        auto candidate = configured.is_absolute() ? configured : (root / configured);
        if (std::filesystem::is_regular_file(candidate, ec) && !ec) file = candidate;
    }
    if (file.empty()) file = root / L"assets" / L"audio" / cueFile(cue);
    ec.clear();
    if (std::filesystem::is_regular_file(file, ec) && !ec) {
        const DWORD playbackFlags = SND_FILENAME | SND_NODEFAULT | (synchronous ? SND_SYNC : SND_ASYNC);
        if (PlaySoundW(file.c_str(), nullptr, playbackFlags)) return;
    }
    // Keep interaction feedback available if optional sound assets are missing.
    UINT fallback = MB_OK;
    if (cue == Cue::Warning) fallback = MB_ICONWARNING;
    else if (cue == Cue::Success || cue == Cue::Complete) fallback = MB_ICONASTERISK;
    MessageBeep(fallback);
}
inline void click() { play(Cue::Click); }
inline void startup() { play(Cue::Startup); }
inline void shutdown() { play(Cue::Shutdown, true); }
inline void back() { play(Cue::Back); }
inline void success() { play(Cue::Success); }
inline void warning() { play(Cue::Warning); }
inline void complete() { play(Cue::Complete); }
inline void notification() { play(Cue::Notification); }
} // namespace itvip::audio
