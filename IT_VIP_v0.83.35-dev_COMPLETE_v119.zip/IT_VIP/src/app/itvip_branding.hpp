#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <commctrl.h>
#include <filesystem>
#include <string>

// Shared visual identity for every standalone IT VIP Windows tool.
// Deliberately uses stock Win32 controls so it remains dependency-light.
namespace itvip {
inline HBRUSH backgroundBrush() { static HBRUSH b=CreateSolidBrush(RGB(9,12,28)); return b; }
inline HBRUSH controlBrush() { static HBRUSH b=CreateSolidBrush(RGB(18,23,45)); return b; }
inline LRESULT CALLBACK brandSubclass(HWND w,UINT m,WPARAM a,LPARAM b,UINT_PTR, DWORD_PTR data) {
    switch(m) {
    case WM_ERASEBKGND: {
        RECT r{}; GetClientRect(w,&r); HDC dc=(HDC)a; FillRect(dc,&r,backgroundBrush());
        // Low-contrast diagonal circuit traces keep controls readable while
        // carrying the shared violet/cyan cyberpunk identity.
        HPEN trace=CreatePen(PS_SOLID,1,RGB(17,27,51)); auto oldTrace=(HPEN)SelectObject(dc,trace);
        for(int x=-r.bottom;x<r.right;x+=118){MoveToEx(dc,x,0,nullptr);LineTo(dc,x+r.bottom,r.bottom);}
        SelectObject(dc,oldTrace); DeleteObject(trace);
        HBRUSH accent=CreateSolidBrush(RGB(139,82,255)); RECT top{0,0,r.right,4}; FillRect(dc,&top,accent); DeleteObject(accent);
        HPEN pen=CreatePen(PS_SOLID,1,RGB(25,190,220)); auto old=(HPEN)SelectObject(dc,pen); MoveToEx(dc,14,r.bottom-2,nullptr); LineTo(dc,r.right-14,r.bottom-2); SelectObject(dc,old); DeleteObject(pen);
        return 1;
    }
    case WM_CTLCOLORSTATIC: {
        HDC dc=(HDC)a; SetTextColor(dc,RGB(226,233,250)); SetBkMode(dc,TRANSPARENT); return (LRESULT)backgroundBrush();
    }
    case WM_CTLCOLOREDIT: case WM_CTLCOLORLISTBOX: case WM_CTLCOLORBTN: case WM_CTLCOLORSCROLLBAR: {
        HDC dc=(HDC)a; SetTextColor(dc,RGB(232,239,255)); SetBkColor(dc,RGB(18,23,45)); return (LRESULT)controlBrush();
    }
    case WM_NCDESTROY: {
        HICON big=(HICON)GetPropW(w,L"ITVIP.Brand.BigIcon"); HICON small=(HICON)GetPropW(w,L"ITVIP.Brand.SmallIcon");
        if(big)DestroyIcon(big); if(small)DestroyIcon(small);
        RemovePropW(w,L"ITVIP.Brand.BigIcon"); RemovePropW(w,L"ITVIP.Brand.SmallIcon");
        RemoveWindowSubclass(w,brandSubclass,1); break;
    }
    }
    (void)data; return DefSubclassProc(w,m,a,b);
}
inline std::filesystem::path assetIconPath() {
    wchar_t exe[32768]{}; DWORD n=GetModuleFileNameW(nullptr,exe,32768); if(!n||n>=32768)return L"assets\\itvip.ico";
    std::filesystem::path dir=std::filesystem::path(exe).parent_path(); std::error_code ec;
    auto p=dir/L"assets"/L"itvip.ico"; if(std::filesystem::exists(p,ec))return p;
    p=dir.parent_path()/L"assets"/L"itvip.ico"; if(std::filesystem::exists(p,ec))return p;
    return L"assets\\itvip.ico";
}
inline void applyBranding(HWND w,HINSTANCE) {
    if(!w)return;
    SetWindowSubclass(w,brandSubclass,1,0);
    HICON big=(HICON)LoadImageW(nullptr,assetIconPath().c_str(),IMAGE_ICON,48,48,LR_LOADFROMFILE|LR_DEFAULTCOLOR);
    HICON small=(HICON)LoadImageW(nullptr,assetIconPath().c_str(),IMAGE_ICON,16,16,LR_LOADFROMFILE|LR_DEFAULTCOLOR);
    if(big){SetPropW(w,L"ITVIP.Brand.BigIcon",big);SendMessageW(w,WM_SETICON,ICON_BIG,(LPARAM)big);}
    if(small){SetPropW(w,L"ITVIP.Brand.SmallIcon",small);SendMessageW(w,WM_SETICON,ICON_SMALL,(LPARAM)small);}
    // Ask DWM for a dark title bar where supported (Windows 10 20H1+ / Windows 11).
    HMODULE dwm=LoadLibraryW(L"dwmapi.dll"); if(dwm){using Fn=HRESULT(WINAPI*)(HWND,DWORD,LPCVOID,DWORD);auto fn=(Fn)GetProcAddress(dwm,"DwmSetWindowAttribute");if(fn){BOOL yes=TRUE;fn(w,20,&yes,sizeof(yes));fn(w,19,&yes,sizeof(yes));}FreeLibrary(dwm);}
    EnumChildWindows(w,[](HWND child,LPARAM){SendMessageW(child,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);return TRUE;},0);
    InvalidateRect(w,nullptr,TRUE);
}
}
