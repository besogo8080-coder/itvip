// language: C++17, file: usb_guard.cpp, target: Windows 10/11 x64/x86, compiler: MSVC/MinGW
// APIs: RegOpenKeyExW, RegCreateKeyExW, RegQueryValueExW, RegSetValueExW, RegDeleteValueW, RegFlushKey, CreateMutexW, CreateDirectoryW, SetFileAttributesW, FindFirstFileW, BCryptHashData, FormatMessageW
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cwctype>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <type_traits>
#include <unordered_set>
#include <fcntl.h>
#include <io.h>

namespace fs = std::filesystem;
struct Failure { std::wstring text; };
struct HandleDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value);
    }
};
struct FindDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) FindClose(value);
    }
};
struct KeyDeleter { void operator()(HKEY value) const noexcept { if (value) RegCloseKey(value); } };
struct AlgorithmDeleter {
    void operator()(void* value) const noexcept { if (value) BCryptCloseAlgorithmProvider(value, 0); }
};
struct HashDeleter {
    void operator()(void* value) const noexcept { if (value) BCryptDestroyHash(value); }
};
using UniqueHandle = std::unique_ptr<void, HandleDeleter>;
using UniqueFind = std::unique_ptr<void, FindDeleter>;
using UniqueKey = std::unique_ptr<std::remove_pointer_t<HKEY>, KeyDeleter>;
using UniqueAlgorithm = std::unique_ptr<void, AlgorithmDeleter>;
using UniqueHash = std::unique_ptr<void, HashDeleter>;

std::wstring error_text(DWORD code) {
    wchar_t buffer[2048]{};
    const DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, code, 0, buffer, static_cast<DWORD>(std::size(buffer)), nullptr);
    std::wstring result(buffer, count);
    while (!result.empty() && (result.back() == L'\r' || result.back() == L'\n')) result.pop_back();
    return L"[" + std::to_wstring(code) + L"] " + result;
}

void check_registry(LSTATUS status, const std::wstring& operation) {
    if (status != ERROR_SUCCESS) throw Failure{operation + L": " + error_text(static_cast<DWORD>(status))};
}

void check_nt(NTSTATUS status, const wchar_t* operation) {
    if (status >= 0) return;
    std::wostringstream output;
    output << operation << L": NTSTATUS 0x" << std::hex << static_cast<ULONG>(status);
    throw Failure{output.str()};
}

std::wstring from_utf8(const char* text) {
    const int count = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (count <= 0) return L"Unrepresentable diagnostic";
    std::wstring result(static_cast<std::size_t>(count), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, result.data(), count);
    result.pop_back();
    return result;
}

class RegistryLock {
    UniqueHandle mutex_;
    bool owned_ = false;
public:
    RegistryLock() : mutex_(CreateMutexW(nullptr, FALSE, L"Global\\NativeUsbGuard_State_v1")) {
        if (!mutex_) throw Failure{L"CreateMutexW: " + error_text(GetLastError())};
        const DWORD result = WaitForSingleObject(mutex_.get(), 30000);
        if (result == WAIT_OBJECT_0 || result == WAIT_ABANDONED) owned_ = true;
        else if (result == WAIT_FAILED) throw Failure{L"WaitForSingleObject: " + error_text(GetLastError())};
        else throw Failure{L"Another usb_guard policy operation is running"};
    }
    RegistryLock(const RegistryLock&) = delete;
    RegistryLock& operator=(const RegistryLock&) = delete;
    ~RegistryLock() { if (owned_) ReleaseMutex(mutex_.get()); }
};

struct Setting { const wchar_t* key; const wchar_t* name; DWORD blocked; };
constexpr std::array<Setting, 4> settings{{
    {L"SYSTEM\\CurrentControlSet\\Services\\USBSTOR", L"Start", 4},
    {L"SOFTWARE\\Policies\\Microsoft\\Windows\\RemovableStorageDevices", L"Deny_All", 1},
    {L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", L"NoDriveTypeAutoRun", 255},
    {L"SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer", L"NoAutoplayfornonVolume", 1}
}};
constexpr wchar_t backup_path[] = L"SOFTWARE\\NativeUsbGuard\\StateV1";
constexpr DWORD backup_magic = 0x55424731U;
struct SavedValue { DWORD present = 0; DWORD value = 0; };
struct Snapshot {
    DWORD magic = backup_magic;
    DWORD version = 1;
    std::array<SavedValue, 4> values{};
};
static_assert(sizeof(Snapshot) == 40, "Snapshot layout must be identical on x86 and x64");

UniqueKey open_key(const wchar_t* path, REGSAM access, bool create) {
    HKEY raw = nullptr;
    const LSTATUS status = create
        ? RegCreateKeyExW(HKEY_LOCAL_MACHINE, path, 0, nullptr, 0,
            access | KEY_WOW64_64KEY, nullptr, &raw, nullptr)
        : RegOpenKeyExW(HKEY_LOCAL_MACHINE, path, 0, access | KEY_WOW64_64KEY, &raw);
    if (!create && (status == ERROR_FILE_NOT_FOUND || status == ERROR_PATH_NOT_FOUND)) return {};
    check_registry(status, std::wstring(L"Open registry key ") + path);
    return UniqueKey(raw);
}

std::optional<DWORD> read_setting(const Setting& setting) {
    auto key = open_key(setting.key, KEY_QUERY_VALUE, false);
    if (!key) return std::nullopt;
    DWORD value = 0, type = 0, size = sizeof(value);
    const LSTATUS status = RegQueryValueExW(key.get(), setting.name, nullptr, &type,
        reinterpret_cast<BYTE*>(&value), &size);
    if (status == ERROR_FILE_NOT_FOUND) return std::nullopt;
    check_registry(status, std::wstring(L"Read ") + setting.name);
    if (type != REG_DWORD || size != sizeof(value))
        throw Failure{std::wstring(L"Unexpected registry type for ") + setting.name};
    return value;
}

void write_setting(const Setting& setting, std::optional<DWORD> value) {
    auto key = open_key(setting.key, KEY_SET_VALUE | KEY_QUERY_VALUE, value.has_value());
    if (!key) return;
    if (value) {
        const DWORD data = *value;
        check_registry(RegSetValueExW(key.get(), setting.name, 0, REG_DWORD,
            reinterpret_cast<const BYTE*>(&data), sizeof(data)), std::wstring(L"Set ") + setting.name);
    } else {
        const LSTATUS status = RegDeleteValueW(key.get(), setting.name);
        if (status != ERROR_FILE_NOT_FOUND) check_registry(status, std::wstring(L"Remove ") + setting.name);
    }
    check_registry(RegFlushKey(key.get()), L"RegFlushKey");
}

std::optional<Snapshot> read_snapshot(HKEY key) {
    if (!key) return std::nullopt;
    Snapshot snapshot{};
    DWORD type = 0, size = sizeof(snapshot);
    const LSTATUS status = RegQueryValueExW(key, L"OriginalValues", nullptr, &type,
        reinterpret_cast<BYTE*>(&snapshot), &size);
    if (status == ERROR_FILE_NOT_FOUND) return std::nullopt;
    check_registry(status, L"Read policy snapshot");
    if (type != REG_BINARY || size != sizeof(snapshot) || snapshot.magic != backup_magic || snapshot.version != 1)
        throw Failure{L"Invalid policy snapshot; no settings changed"};
    for (const auto& value : snapshot.values)
        if (value.present > 1) throw Failure{L"Invalid policy snapshot entry"};
    return snapshot;
}

void save_snapshot(HKEY key, const Snapshot& snapshot) {
    check_registry(RegSetValueExW(key, L"OriginalValues", 0, REG_BINARY,
        reinterpret_cast<const BYTE*>(&snapshot), sizeof(snapshot)), L"Save policy snapshot");
    check_registry(RegFlushKey(key), L"Flush policy snapshot");
}

std::optional<DWORD> original_value(const SavedValue& value) {
    return value.present ? std::optional<DWORD>(value.value) : std::nullopt;
}

bool restore_snapshot(const Snapshot& snapshot) {
    bool restored = true;
    for (std::size_t index = 0; index < settings.size(); ++index) {
        try { write_setting(settings[index], original_value(snapshot.values[index])); }
        catch (const Failure& error) { std::wcerr << error.text << L'\n'; restored = false; }
    }
    return restored;
}

void clear_snapshot(HKEY key) {
    const LSTATUS status = RegDeleteValueW(key, L"OriginalValues");
    if (status != ERROR_FILE_NOT_FOUND) check_registry(status, L"Remove policy snapshot");
    check_registry(RegFlushKey(key), L"Flush policy snapshot removal");
}

int set_blocked(bool block) {
    RegistryLock lock;
    auto backup = open_key(backup_path, KEY_QUERY_VALUE | KEY_SET_VALUE, block);
    auto saved = read_snapshot(backup.get());
    if (!block && !saved) throw Failure{L"No saved usb_guard policy state; no settings changed"};
    if (block && !saved) {
        Snapshot snapshot{};
        for (std::size_t index = 0; index < settings.size(); ++index) {
            const auto current = read_setting(settings[index]);
            snapshot.values[index].present = current.has_value() ? 1U : 0U;
            snapshot.values[index].value = current.value_or(0);
        }
        save_snapshot(backup.get(), snapshot);
        saved = snapshot;
    }
    if (block) {
        try {
            for (const auto& setting : settings) write_setting(setting, setting.blocked);
        } catch (const Failure& error) {
            std::wcerr << error.text << L"\nRestoring the saved settings.\n";
            if (restore_snapshot(*saved)) clear_snapshot(backup.get());
            else std::wcerr << L"Partial rollback; snapshot retained for usb_guard unblock.\n";
            return 2;
        }
        std::wcout << L"Storage/AutoRun policy values set; original values saved.\n"
                   << L"Existing device access may require reconnection or restart to change.\n";
        return 0;
    }
    for (std::size_t index = 0; index < settings.size(); ++index) {
        const auto current = read_setting(settings[index]);
        if (current != std::optional<DWORD>(settings[index].blocked) &&
            current != original_value(saved->values[index]))
            throw Failure{std::wstring(L"Policy changed externally; snapshot retained: ") + settings[index].name};
    }
    if (!restore_snapshot(*saved)) return 2;
    clear_snapshot(backup.get());
    std::wcout << L"Original values restored; this does not override other storage policies.\n";
    return 0;
}

fs::path drive_root(const std::wstring& argument) {
    if ((argument.size() != 2 && argument.size() != 3) ||
        !((argument[0] >= L'A' && argument[0] <= L'Z') || (argument[0] >= L'a' && argument[0] <= L'z')) ||
        argument[1] != L':' || (argument.size() == 3 && argument[2] != L'\\' && argument[2] != L'/'))
        throw Failure{L"Drive must be a letter such as E: or E:\\"};
    std::wstring root{static_cast<wchar_t>(std::towupper(argument[0])), L':', L'\\'};
    const UINT type = GetDriveTypeW(root.c_str());
    if (type != DRIVE_REMOVABLE && type != DRIVE_FIXED)
        throw Failure{L"Drive must be a local fixed or removable volume"};
    return fs::path(root);
}

int immunize(const fs::path& root) {
    if (GetDriveTypeW(root.c_str()) != DRIVE_REMOVABLE)
        throw Failure{L"Directory marker creation is restricted to removable drives"};
    const auto marker = root / L"autorun.inf";
    if (!CreateDirectoryW(marker.c_str(), nullptr))
        throw Failure{L"Create autorun.inf directory (existing entries are not replaced): " + error_text(GetLastError())};
    if (!SetFileAttributesW(marker.c_str(), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM | FILE_ATTRIBUTE_READONLY))
        throw Failure{L"Set marker attributes (directory retained): " + error_text(GetLastError())};
    std::wcout << L"Created " << marker.native()
               << L"\nDirectory marker only; it is removable and is not a malware protection guarantee.\n";
    return 0;
}

bool executable_extension(const fs::path& path) {
    static const std::unordered_set<std::wstring> extensions{
        L".exe", L".dll", L".scr", L".bat", L".cmd", L".ps1", L".vbs", L".js",
        L".hta", L".lnk", L".pif", L".com", L".msi", L".jar"};
    auto extension = path.extension().native();
    std::transform(extension.begin(), extension.end(), extension.begin(),
        [](wchar_t character) { return static_cast<wchar_t>(std::towlower(character)); });
    return extensions.count(extension) != 0;
}

std::wstring sha256(const fs::path& path, BCRYPT_ALG_HANDLE algorithm) {
    UniqueHandle file(CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
        nullptr, OPEN_EXISTING, FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_SEQUENTIAL_SCAN, nullptr));
    if (file.get() == INVALID_HANDLE_VALUE) throw Failure{L"CreateFileW: " + error_text(GetLastError())};
    BY_HANDLE_FILE_INFORMATION information{};
    if (!GetFileInformationByHandle(file.get(), &information))
        throw Failure{L"GetFileInformationByHandle: " + error_text(GetLastError())};
    if (information.dwFileAttributes & (FILE_ATTRIBUTE_REPARSE_POINT | FILE_ATTRIBUTE_DIRECTORY))
        throw Failure{L"Entry changed into a directory or reparse point"};
    BCRYPT_HASH_HANDLE raw_hash = nullptr;
    check_nt(BCryptCreateHash(algorithm, &raw_hash, nullptr, 0, nullptr, 0, 0), L"BCryptCreateHash");
    UniqueHash hash(raw_hash);
    std::array<unsigned char, 65536> buffer{};
    for (;;) {
        DWORD count = 0;
        if (!ReadFile(file.get(), buffer.data(), static_cast<DWORD>(buffer.size()), &count, nullptr))
            throw Failure{L"ReadFile: " + error_text(GetLastError())};
        if (count == 0) break;
        check_nt(BCryptHashData(hash.get(), buffer.data(), count, 0), L"BCryptHashData");
    }
    std::array<unsigned char, 32> digest{};
    check_nt(BCryptFinishHash(hash.get(), digest.data(), static_cast<ULONG>(digest.size()), 0), L"BCryptFinishHash");
    static constexpr wchar_t digits[] = L"0123456789abcdef";
    std::wstring result(digest.size() * 2, L'0');
    for (std::size_t index = 0; index < digest.size(); ++index) {
        result[index * 2] = digits[digest[index] >> 4];
        result[index * 2 + 1] = digits[digest[index] & 15];
    }
    return result;
}

int scan(const fs::path& root) {
    BCRYPT_ALG_HANDLE raw_algorithm = nullptr;
    check_nt(BCryptOpenAlgorithmProvider(&raw_algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0), L"BCryptOpenAlgorithmProvider");
    UniqueAlgorithm algorithm(raw_algorithm);
    WIN32_FIND_DATAW entry{};
    UniqueFind search(FindFirstFileW((root / L"*").c_str(), &entry));
    if (search.get() == INVALID_HANDLE_VALUE) {
        const DWORD code = GetLastError();
        if (code == ERROR_FILE_NOT_FOUND) return 0;
        throw Failure{L"FindFirstFileW: " + error_text(code)};
    }
    unsigned int failures = 0;
    do {
        const std::wstring name = entry.cFileName;
        if (name == L"." || name == L"..") continue;
        const auto path = root / name;
        if (_wcsicmp(name.c_str(), L"autorun.inf") == 0)
            std::wcout << L"AUTORUN_ENTRY " << std::quoted(path.native())
                       << ((entry.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? L" directory\n" : L" file\n");
        if (entry.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
            std::wcout << L"SKIPPED_REPARSE " << std::quoted(path.native()) << L'\n';
            continue;
        }
        if (entry.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        try {
            const auto digest = sha256(path, algorithm.get());
            std::wcout << digest << L"  " << std::quoted(path.native())
                       << (executable_extension(path) ? L"  executable-extension" : L"")
                       << ((entry.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) ? L"  hidden" : L"") << L'\n';
        } catch (const Failure& error) {
            ++failures;
            std::wcerr << std::quoted(path.native()) << L": " << error.text << L'\n';
        }
    } while (FindNextFileW(search.get(), &entry));
    const DWORD code = GetLastError();
    if (code != ERROR_NO_MORE_FILES) throw Failure{L"FindNextFileW: " + error_text(code)};
    std::wcout << L"Root-only inventory; filename flags do not establish malware.\n";
    return failures ? 2 : 0;
}

int wmain(int argc, wchar_t** argv) {
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stderr), _O_U16TEXT);
    try {
        if (argc == 2 && std::wstring(argv[1]) == L"block") return set_blocked(true);
        if (argc == 2 && std::wstring(argv[1]) == L"unblock") return set_blocked(false);
        if (argc == 3 && std::wstring(argv[1]) == L"immunize") return immunize(drive_root(argv[2]));
        if (argc == 3 && std::wstring(argv[1]) == L"scan") return scan(drive_root(argv[2]));
        std::wcerr << L"Usage: usb_guard block | unblock | immunize <drive> | scan <drive>\n";
    } catch (const Failure& error) { std::wcerr << error.text << L'\n'; }
      catch (const std::exception& error) { std::wcerr << from_utf8(error.what()) << L'\n'; }
    return 1;
}
