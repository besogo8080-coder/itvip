// language: C++17, file: pwrecover.cpp, target: Windows 10/11 x64/x86, compiler: MSVC/MinGW
// APIs: OpenProcessToken, GetTokenInformation, DsRoleGetPrimaryDomainInformation, NetUserGetInfo, NetUserSetInfo, NetApiBufferFree, ReadConsoleW, SetConsoleMode, ConvertSidToStringSidW, SecureZeroMemory, FormatMessageW
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <lm.h>
#include <dsrole.h>
#include <sddl.h>
#include <array>
#include <cstdint>
#include <iostream>
#include <memory>
#include <string>
#include <fcntl.h>
#include <io.h>

struct Failure { std::wstring text; };
struct HandleDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value);
    }
};
struct NetBufferDeleter {
    void operator()(void* value) const noexcept { if (value) NetApiBufferFree(value); }
};
struct RoleBufferDeleter {
    void operator()(void* value) const noexcept { if (value) DsRoleFreeMemory(value); }
};
struct LocalStringDeleter {
    void operator()(wchar_t* value) const noexcept { if (value) LocalFree(value); }
};
struct ConsoleModeDeleter {
    DWORD original = 0;
    void operator()(void* handle) const noexcept { if (handle) SetConsoleMode(handle, original); }
};
using UniqueHandle = std::unique_ptr<void, HandleDeleter>;
using UniqueNetBuffer = std::unique_ptr<void, NetBufferDeleter>;
using UniqueRoleBuffer = std::unique_ptr<void, RoleBufferDeleter>;
using UniqueLocalString = std::unique_ptr<wchar_t, LocalStringDeleter>;
using ConsoleModeGuard = std::unique_ptr<void, ConsoleModeDeleter>;

std::wstring error_text(DWORD code) {
    wchar_t buffer[2048]{};
    DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, code, 0, buffer, static_cast<DWORD>(std::size(buffer)), nullptr);
    if (count == 0) {
        const HMODULE module = GetModuleHandleW(L"netapi32.dll");
        if (module) count = FormatMessageW(FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_IGNORE_INSERTS,
            module, code, 0, buffer, static_cast<DWORD>(std::size(buffer)), nullptr);
    }
    std::wstring text(buffer, count);
    while (!text.empty() && (text.back() == L'\r' || text.back() == L'\n')) text.pop_back();
    return L"[" + std::to_wstring(code) + L"] " + text;
}

std::wstring from_utf8(const char* text) {
    const int count = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (count <= 0) return L"Unrepresentable diagnostic";
    std::wstring result(static_cast<std::size_t>(count), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, result.data(), count);
    result.pop_back();
    return result;
}

void require_elevation() {
    HANDLE raw = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &raw))
        throw Failure{L"OpenProcessToken: " + error_text(GetLastError())};
    UniqueHandle token(raw);
    TOKEN_ELEVATION elevation{};
    DWORD returned = 0;
    if (!GetTokenInformation(token.get(), TokenElevation, &elevation, sizeof(elevation), &returned))
        throw Failure{L"GetTokenInformation: " + error_text(GetLastError())};
    if (returned != sizeof(elevation) || !elevation.TokenIsElevated)
        throw Failure{L"An existing elevated administrator session is required"};
}

void require_local_account_database() {
    PBYTE raw = nullptr;
    const DWORD status = DsRoleGetPrimaryDomainInformation(nullptr, DsRolePrimaryDomainInfoBasic, &raw);
    UniqueRoleBuffer buffer(raw);
    if (status != ERROR_SUCCESS)
        throw Failure{L"DsRoleGetPrimaryDomainInformation: " + error_text(status)};
    const auto information = static_cast<const DSROLE_PRIMARY_DOMAIN_INFO_BASIC*>(buffer.get());
    if (!information) throw Failure{L"Machine role information was not returned"};
    if (information->MachineRole == DsRole_RoleBackupDomainController ||
        information->MachineRole == DsRole_RolePrimaryDomainController)
        throw Failure{L"Domain controllers are not supported; this tool manages local accounts only"};
}

UniqueNetBuffer user_information(const std::wstring& name, DWORD level) {
    LPBYTE raw = nullptr;
    const NET_API_STATUS status = NetUserGetInfo(nullptr, name.c_str(), level, &raw);
    UniqueNetBuffer buffer(raw);
    if (status != NERR_Success) throw Failure{L"NetUserGetInfo: " + error_text(status)};
    if (!buffer) throw Failure{L"NetUserGetInfo returned an empty buffer"};
    return buffer;
}

void validate_account(const std::wstring& name, const USER_INFO_4& information) {
    if (!(information.usri4_flags & UF_NORMAL_ACCOUNT))
        throw Failure{L"Only normal local user accounts are supported"};
    if (information.usri4_flags & UF_ACCOUNTDISABLE)
        throw Failure{L"The account is disabled; this tool does not enable accounts"};
    PSID sid = information.usri4_user_sid;
    if (!sid || !IsValidSid(sid)) throw Failure{L"Invalid local account SID"};
    const UCHAR count = *GetSidSubAuthorityCount(sid);
    if (count == 0 || *GetSidSubAuthority(sid, count - 1) < 1000)
        throw Failure{L"Built-in and service accounts are not supported"};
    auto identity = user_information(name, 24);
    if (static_cast<const USER_INFO_24*>(identity.get())->usri24_internet_identity)
        throw Failure{L"Internet-linked accounts are not supported; their passwords are managed by their identity provider"};
}

std::wstring sid_string(PSID sid) {
    LPWSTR raw = nullptr;
    if (!ConvertSidToStringSidW(sid, &raw))
        throw Failure{L"ConvertSidToStringSidW: " + error_text(GetLastError())};
    UniqueLocalString value(raw);
    return std::wstring(value.get());
}

std::wstring computer_name() {
    std::array<wchar_t, MAX_COMPUTERNAME_LENGTH + 1> buffer{};
    DWORD length = static_cast<DWORD>(buffer.size());
    if (!GetComputerNameW(buffer.data(), &length))
        throw Failure{L"GetComputerNameW: " + error_text(GetLastError())};
    return std::wstring(buffer.data(), length);
}

ConsoleModeGuard console_input(bool echo) {
    HANDLE input = GetStdHandle(STD_INPUT_HANDLE);
    if (!input || input == INVALID_HANDLE_VALUE)
        throw Failure{L"An interactive Windows console is required"};
    DWORD original = 0;
    if (!GetConsoleMode(input, &original))
        throw Failure{L"Interactive console input is required: " + error_text(GetLastError())};
    DWORD mode = original | ENABLE_LINE_INPUT | ENABLE_PROCESSED_INPUT;
    mode &= ~ENABLE_VIRTUAL_TERMINAL_INPUT;
    if (echo) mode |= ENABLE_ECHO_INPUT;
    else mode &= ~ENABLE_ECHO_INPUT;
    if (!SetConsoleMode(input, mode)) throw Failure{L"SetConsoleMode: " + error_text(GetLastError())};
    return ConsoleModeGuard(input, ConsoleModeDeleter{original});
}

class SecurePassword {
    std::array<wchar_t, 257> data_{};
    std::size_t length_ = 0;
public:
    SecurePassword() = default;
    SecurePassword(const SecurePassword&) = delete;
    SecurePassword& operator=(const SecurePassword&) = delete;
    ~SecurePassword() { clear(); }
    bool append(wchar_t character) noexcept {
        if (length_ >= data_.size() - 1) return false;
        data_[length_++] = character;
        data_[length_] = L'\0';
        return true;
    }
    void clear() noexcept {
        SecureZeroMemory(data_.data(), sizeof(data_));
        length_ = 0;
    }
    wchar_t* data() noexcept { return data_.data(); }
    std::size_t size() const noexcept { return length_; }
    bool equals(const SecurePassword& other) const noexcept {
        unsigned int difference = static_cast<unsigned int>(length_ ^ other.length_);
        for (std::size_t index = 0; index < data_.size(); ++index)
            difference |= static_cast<unsigned int>(static_cast<unsigned short>(data_[index])) ^
                          static_cast<unsigned int>(static_cast<unsigned short>(other.data_[index]));
        return difference == 0;
    }
};

void read_password(const wchar_t* prompt, SecurePassword& password) {
    auto input = console_input(false);
    std::wcout << prompt << std::flush;
    bool valid = true;
    for (;;) {
        wchar_t character = L'\0';
        DWORD count = 0;
        if (!ReadConsoleW(input.get(), &character, 1, &count, nullptr))
            throw Failure{L"ReadConsoleW: " + error_text(GetLastError())};
        if (count == 0) throw Failure{L"Console input ended before a complete password was entered"};
        if (character == L'\n') break;
        if (character == L'\r') continue;
        if (character < L' ' || !password.append(character)) valid = false;
        SecureZeroMemory(&character, sizeof(character));
    }
    std::wcout << L'\n';
    if (!valid || password.size() == 0) {
        password.clear();
        throw Failure{L"The password must contain 1..256 UTF-16 code units without control characters"};
    }
}

std::wstring read_confirmation(const std::wstring& expected) {
    auto input = console_input(true);
    std::wcout << L"Type " << expected << L" to confirm: " << std::flush;
    std::wstring result;
    for (;;) {
        wchar_t character = L'\0';
        DWORD count = 0;
        if (!ReadConsoleW(input.get(), &character, 1, &count, nullptr))
            throw Failure{L"ReadConsoleW: " + error_text(GetLastError())};
        if (count == 0) throw Failure{L"Console input ended before confirmation"};
        if (character == L'\n') break;
        if (character == L'\r') continue;
        if (result.size() >= 512) throw Failure{L"Confirmation is too long"};
        result.push_back(character);
    }
    return result;
}

int run(int argc, wchar_t** argv) {
    if (argc != 3 || std::wstring(argv[1]) != L"live") {
        std::wcerr << L"Usage: pwrecover live <local-user>\n"
                   << L"Passwords are entered interactively; command-line passwords are not accepted.\n";
        return 1;
    }
    const std::wstring name = argv[2];
    if (name.empty() || name.size() > UNLEN || name.find_first_of(L"\\/@") != std::wstring::npos)
        throw Failure{L"Use an unqualified local account name, not a domain or remote account"};
    require_elevation();
    require_local_account_database();
    auto original_buffer = user_information(name, 4);
    const auto original = static_cast<const USER_INFO_4*>(original_buffer.get());
    validate_account(name, *original);
    std::wcout << L"Target: " << computer_name() << L"\\" << name
               << L"\nSID: " << sid_string(original->usri4_user_sid)
               << L"\nAn administrative password reset can make EFS files, DPAPI-protected data, and saved credentials inaccessible.\n"
               << L"This changes the password; it does not recover the old password or change account enable/lockout policy.\n";
    SecurePassword password;
    SecurePassword repeated;
    read_password(L"New password: ", password);
    read_password(L"Repeat password: ", repeated);
    if (!password.equals(repeated)) throw Failure{L"Passwords do not match; nothing changed"};
    const std::wstring confirmation = L"RESET " + name;
    if (read_confirmation(confirmation) != confirmation) {
        std::wcout << L"Cancelled; nothing changed.\n";
        return 1;
    }
    require_local_account_database();
    auto current_buffer = user_information(name, 4);
    const auto current = static_cast<const USER_INFO_4*>(current_buffer.get());
    validate_account(name, *current);
    if (!EqualSid(original->usri4_user_sid, current->usri4_user_sid))
        throw Failure{L"The account identity changed while waiting; nothing changed"};
    USER_INFO_1003 information{};
    information.usri1003_password = password.data();
    DWORD parameter_error = 0;
    const NET_API_STATUS status = NetUserSetInfo(nullptr, name.c_str(), 1003,
        reinterpret_cast<LPBYTE>(&information), &parameter_error);
    password.clear();
    repeated.clear();
    information.usri1003_password = nullptr;
    if (status != NERR_Success)
        throw Failure{L"NetUserSetInfo: " + error_text(status) + L"; parameter=" + std::to_wstring(parameter_error)};
    std::wcout << L"Local password reset completed for " << name << L".\n";
    return 0;
}

int wmain(int argc, wchar_t** argv) {
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stderr), _O_U16TEXT);
    try { return run(argc, argv); }
    catch (const Failure& error) { std::wcerr << error.text << L'\n'; }
    catch (const std::exception& error) { std::wcerr << from_utf8(error.what()) << L'\n'; }
    return 1;
}
