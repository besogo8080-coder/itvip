#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <winsvc.h>
#include <string>
#include <iostream>
#include <iomanip>

static std::wstring service_state(const wchar_t* name) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (!scm) return L"Unavailable (SCM access denied)";
    SC_HANDLE svc = OpenServiceW(scm, name, SERVICE_QUERY_STATUS);
    if (!svc) { CloseServiceHandle(scm); return L"Not found / access denied"; }
    SERVICE_STATUS_PROCESS s{}; DWORD needed = 0;
    std::wstring result = L"Unknown";
    if (QueryServiceStatusEx(svc, SC_STATUS_PROCESS_INFO, reinterpret_cast<LPBYTE>(&s), sizeof(s), &needed)) {
        switch (s.dwCurrentState) {
            case SERVICE_RUNNING: result = L"Running"; break;
            case SERVICE_STOPPED: result = L"Stopped"; break;
            case SERVICE_START_PENDING: result = L"Starting"; break;
            case SERVICE_STOP_PENDING: result = L"Stopping"; break;
            case SERVICE_PAUSED: result = L"Paused"; break;
            default: result = L"State code " + std::to_wstring(s.dwCurrentState); break;
        }
    }
    CloseServiceHandle(svc); CloseServiceHandle(scm); return result;
}
static std::wstring uac_state() {
    DWORD value = 0, size = sizeof(value);
    LONG rc = RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"EnableLUA", RRF_RT_REG_DWORD, nullptr, &value, &size);
    if (rc != ERROR_SUCCESS) return L"Unknown / policy not readable";
    return value ? L"Enabled" : L"Disabled (restart may be required)";
}
static void print(const wchar_t* label, const std::wstring& value) { std::wcout << std::left << std::setw(30) << label << L": " << value << L"\n"; }
int wmain() {
    SetConsoleOutputCP(CP_UTF8);
    std::wcout << L"IT VIP — SECURITY CENTER (READ ONLY)\n" << std::wstring(48, L'=') << L"\n";
    print(L"Microsoft Defender service", service_state(L"WinDefend"));
    print(L"Windows Firewall service", service_state(L"MpsSvc"));
    print(L"UAC", uac_state());
    std::wcout << L"\nSmartScreen / Secure Boot: Not queried by this basic diagnostic.\n";
    std::wcout << L"This module does not change security settings or disable protection.\n\nPress Enter to close...";
    std::wstring wait; std::getline(std::wcin, wait); return 0;
}
