// language: C++17, file: activator.cpp, target: Windows 10/11 x64/x86, compiler: MSVC/MinGW
// APIs: CreateProcessW, WaitForSingleObject, GetExitCodeProcess, GetSystemWindowsDirectoryW, IsWow64Process, GetProductInfo, RegOpenKeyExW, RegQueryValueExW, GetFileAttributesW, FormatMessageW
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <algorithm>
#include <array>
#include <filesystem>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <type_traits>
#include <vector>
#include <fcntl.h>
#include <io.h>

namespace fs = std::filesystem;
struct Failure { std::wstring text; };
struct HandleDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value);
    }
};
struct KeyDeleter {
    void operator()(HKEY value) const noexcept { if (value) RegCloseKey(value); }
};
using UniqueHandle = std::unique_ptr<void, HandleDeleter>;
using UniqueKey = std::unique_ptr<std::remove_pointer_t<HKEY>, KeyDeleter>;

std::wstring error_text(DWORD code) {
    wchar_t buffer[2048]{};
    const DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, code, 0, buffer, static_cast<DWORD>(std::size(buffer)), nullptr);
    std::wstring text(buffer, count);
    while (!text.empty() && (text.back() == L'\r' || text.back() == L'\n')) text.pop_back();
    return L"[" + std::to_wstring(code) + L"] " + text;
}

std::wstring from_utf8(const char* text) {
    const int count = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (count <= 0) return L"Unrepresentable diagnostic";
    std::wstring result(static_cast<std::size_t>(count), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, result.data(), count);
    result.pop_back();
    return result;
}

std::wstring quote_argument(const std::wstring& argument) {
    std::wstring result(1, L'"');
    std::size_t backslashes = 0;
    for (const wchar_t character : argument) {
        if (character == L'\\') { ++backslashes; continue; }
        if (character == L'"') result.append(backslashes * 2 + 1, L'\\');
        else result.append(backslashes, L'\\');
        result.push_back(character);
        backslashes = 0;
    }
    result.append(backslashes * 2, L'\\');
    result.push_back(L'"');
    return result;
}

bool ordinary_file(const fs::path& path) {
    const DWORD attributes = GetFileAttributesW(path.c_str());
    if (attributes == INVALID_FILE_ATTRIBUTES) {
        const DWORD code = GetLastError();
        if (code == ERROR_FILE_NOT_FOUND || code == ERROR_PATH_NOT_FOUND) return false;
        throw Failure{path.native() + L": " + error_text(code)};
    }
    return (attributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT)) == 0;
}

std::optional<std::wstring> registry_string(HKEY key, const wchar_t* name) {
    DWORD type = 0, bytes = 0;
    LSTATUS status = RegQueryValueExW(key, name, nullptr, &type, nullptr, &bytes);
    if (status == ERROR_FILE_NOT_FOUND) return std::nullopt;
    if (status != ERROR_SUCCESS)
        throw Failure{std::wstring(L"Read ") + name + L": " + error_text(static_cast<DWORD>(status))};
    if ((type != REG_SZ && type != REG_EXPAND_SZ) || bytes == 0 || bytes > 65536 || bytes % sizeof(wchar_t) != 0)
        throw Failure{std::wstring(L"Invalid registry path: ") + name};
    std::vector<wchar_t> buffer(bytes / sizeof(wchar_t) + 1, L'\0');
    status = RegQueryValueExW(key, name, nullptr, &type, reinterpret_cast<BYTE*>(buffer.data()), &bytes);
    if (status != ERROR_SUCCESS)
        throw Failure{std::wstring(L"Read ") + name + L": " + error_text(static_cast<DWORD>(status))};
    if (type == REG_SZ) return std::wstring(buffer.data());
    if (type != REG_EXPAND_SZ) throw Failure{L"Registry path type changed"};
    const DWORD needed = ExpandEnvironmentStringsW(buffer.data(), nullptr, 0);
    if (needed == 0) throw Failure{L"ExpandEnvironmentStringsW: " + error_text(GetLastError())};
    std::wstring expanded(needed, L'\0');
    const DWORD written = ExpandEnvironmentStringsW(buffer.data(), expanded.data(), needed);
    if (written == 0) throw Failure{L"ExpandEnvironmentStringsW: " + error_text(GetLastError())};
    if (written > needed) throw Failure{L"Environment changed during path expansion"};
    expanded.resize(written - 1);
    return expanded;
}

std::vector<fs::path> program_files_roots() {
    HKEY raw = nullptr;
    const LSTATUS status = RegOpenKeyExW(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion", 0, KEY_QUERY_VALUE | KEY_WOW64_64KEY, &raw);
    if (status != ERROR_SUCCESS)
        throw Failure{L"Open Program Files configuration: " + error_text(static_cast<DWORD>(status))};
    UniqueKey key(raw);
    std::vector<fs::path> roots;
    for (const auto name : {L"ProgramFilesDir", L"ProgramFilesDir (x86)"}) {
        const auto value = registry_string(key.get(), name);
        if (!value || value->empty()) continue;
        const fs::path path = fs::path(*value).lexically_normal();
        if (!path.is_absolute() || path.native().rfind(L"\\\\", 0) == 0)
            throw Failure{L"Program Files must resolve to an absolute local drive path"};
        if (std::none_of(roots.begin(), roots.end(), [&](const fs::path& current) {
            return _wcsicmp(current.c_str(), path.c_str()) == 0;
        })) roots.push_back(path);
    }
    if (roots.empty()) throw Failure{L"No Program Files locations were found"};
    return roots;
}

fs::path find_office_script(const std::wstring& generation) {
    for (const auto& root : program_files_roots()) {
        const fs::path base = root / L"Microsoft Office";
        for (const auto& directory : {base / generation, base / L"root" / generation}) {
            const auto candidate = directory / L"OSPP.VBS";
            if (ordinary_file(candidate)) return candidate;
        }
    }
    throw Failure{L"OSPP.VBS was not found for " + generation + L" in the standard Office installation locations"};
}

struct SystemPaths {
    fs::path windows;
    fs::path cscript;
    fs::path windows_script;
    fs::path windows_script_probe;
};

SystemPaths system_paths() {
    std::wstring buffer(32768, L'\0');
    const UINT length = GetSystemWindowsDirectoryW(buffer.data(), static_cast<UINT>(buffer.size()));
    if (length == 0) throw Failure{L"GetSystemWindowsDirectoryW: " + error_text(GetLastError())};
    if (length >= buffer.size()) throw Failure{L"Windows directory exceeds the supported path length"};
    buffer.resize(length);
    BOOL wow64 = FALSE;
    if (!IsWow64Process(GetCurrentProcess(), &wow64))
        throw Failure{L"IsWow64Process: " + error_text(GetLastError())};
    SystemPaths paths;
    paths.windows = fs::path(buffer).lexically_normal();
    const auto native_directory = paths.windows / (wow64 ? L"Sysnative" : L"System32");
    paths.cscript = native_directory / L"cscript.exe";
    paths.windows_script_probe = native_directory / L"slmgr.vbs";
    paths.windows_script = paths.windows / L"System32" / L"slmgr.vbs";
    if (!ordinary_file(paths.cscript))
        throw Failure{L"Native cscript.exe is unavailable; no script host is downloaded or installed"};
    return paths;
}

bool valid_host(const std::wstring& host) {
    if (host.empty() || host.size() > 253 || host.front() == L'.' || host.back() == L'.') return false;
    auto alphanumeric = [](wchar_t value) {
        return (value >= L'a' && value <= L'z') || (value >= L'A' && value <= L'Z') ||
               (value >= L'0' && value <= L'9');
    };
    std::size_t start = 0;
    while (start < host.size()) {
        const auto end = host.find(L'.', start);
        const auto stop = end == std::wstring::npos ? host.size() : end;
        const auto length = stop - start;
        if (length == 0 || length > 63 || !alphanumeric(host[start]) || !alphanumeric(host[stop - 1])) return false;
        for (std::size_t index = start; index < stop; ++index)
            if (!alphanumeric(host[index]) && host[index] != L'-') return false;
        start = stop + 1;
    }
    return true;
}

struct Options {
    bool windows = false;
    bool office = false;
    bool activate = false;
    bool yes = false;
    bool help = false;
    std::wstring generation = L"Office16";
    std::optional<std::wstring> kms;
    unsigned int port = 1688;
};

Options parse_options(int argc, wchar_t** argv) {
    Options options;
    bool status_selected = false, port_selected = false, version_selected = false;
    for (int index = 1; index < argc; ++index) {
        const std::wstring argument = argv[index];
        if (argument == L"--windows") options.windows = true;
        else if (argument == L"--office") options.office = true;
        else if (argument == L"--activate") options.activate = true;
        else if (argument == L"--status") status_selected = true;
        else if (argument == L"--yes") options.yes = true;
        else if (argument == L"--help") options.help = true;
        else if (argument == L"--kms" && index + 1 < argc) {
            options.kms = argv[++index];
            if (!valid_host(*options.kms))
                throw Failure{L"--kms requires an ASCII DNS hostname or IPv4 address without a port"};
        } else if (argument == L"--port" && index + 1 < argc) {
            port_selected = true;
            const std::wstring value = argv[++index];
            if (value.empty() || value.size() > 5 || value.find_first_not_of(L"0123456789") != std::wstring::npos)
                throw Failure{L"--port requires an integer from 1 to 65535"};
            const auto port = std::stoul(value);
            if (port == 0 || port > 65535) throw Failure{L"--port is outside 1..65535"};
            options.port = static_cast<unsigned int>(port);
        } else if (argument == L"--office-ver" && index + 1 < argc) {
            version_selected = true;
            const std::wstring version = argv[++index];
            if (version == L"2010") options.generation = L"Office14";
            else if (version == L"2013") options.generation = L"Office15";
            else if (version == L"2016" || version == L"2019" || version == L"2021" || version == L"2024")
                options.generation = L"Office16";
            else throw Failure{L"Supported Office path versions: 2010, 2013, 2016, 2019, 2021, 2024"};
        } else throw Failure{L"Unknown or incomplete argument: " + argument};
    }
    if (options.help) return options;
    if (!options.windows && !options.office) options.windows = true;
    if (status_selected && options.activate) throw Failure{L"Choose --status or --activate, not both"};
    if ((options.kms || options.yes) && !options.activate) throw Failure{L"--kms and --yes require --activate"};
    if (port_selected && !options.kms) throw Failure{L"--port requires --kms"};
    if (version_selected && !options.office) throw Failure{L"--office-ver requires --office"};
    return options;
}

void check_windows_kms_edition() {
    DWORD product = PRODUCT_UNDEFINED;
    if (!GetProductInfo(10, 0, 0, 0, &product))
        throw Failure{L"GetProductInfo: " + error_text(GetLastError())};
    if (product == PRODUCT_UNDEFINED || product == PRODUCT_CORE || product == PRODUCT_CORE_N ||
        product == PRODUCT_CORE_COUNTRYSPECIFIC || product == PRODUCT_CORE_SINGLELANGUAGE || product == PRODUCT_CORE_ARM)
        throw Failure{L"Windows Home/Core does not support KMS; this tool does not change editions or install client keys"};
}

DWORD run_script(const SystemPaths& system, const fs::path& script,
                 const std::vector<std::wstring>& arguments) {
    std::wstring command = quote_argument(system.cscript.native()) + L" //nologo " + quote_argument(script.native());
    for (const auto& argument : arguments) command += L" " + quote_argument(argument);
    if (command.size() >= 32767) throw Failure{L"Command exceeds the Windows process command-line limit"};
    std::wcout << L"RUN " << command << L'\n' << std::flush;
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    if (!CreateProcessW(system.cscript.c_str(), command.data(), nullptr, nullptr, FALSE,
        CREATE_UNICODE_ENVIRONMENT, nullptr, system.windows.c_str(), &startup, &process))
        throw Failure{L"CreateProcessW: " + error_text(GetLastError())};
    UniqueHandle process_handle(process.hProcess);
    UniqueHandle thread_handle(process.hThread);
    thread_handle.reset();
    const DWORD wait = WaitForSingleObject(process_handle.get(), INFINITE);
    if (wait != WAIT_OBJECT_0)
        throw Failure{L"WaitForSingleObject: " + error_text(wait == WAIT_FAILED ? GetLastError() : ERROR_GEN_FAILURE)};
    DWORD exit_code = 0;
    if (!GetExitCodeProcess(process_handle.get(), &exit_code))
        throw Failure{L"GetExitCodeProcess: " + error_text(GetLastError())};
    std::wcout << L"Process exit code: " << exit_code << L'\n';
    return exit_code;
}

struct Plan {
    std::wstring label;
    fs::path script;
    std::vector<std::vector<std::wstring>> changes;
    std::vector<std::wstring> status_arguments;
};

int run(int argc, wchar_t** argv) {
    const auto options = parse_options(argc, argv);
    if (options.help) {
        std::wcout << L"Usage: activator [--windows] [--office] [--office-ver YEAR]\n"
                   << L"                 [--status | --activate [--kms HOST] [--port N] [--yes]]\n"
                   << L"Default: Windows licensing status. Uses installed licenses; installs no keys.\n";
        return 0;
    }
    const auto system = system_paths();
    std::vector<Plan> plans;
    if (options.windows) {
        if (!ordinary_file(system.windows_script_probe)) throw Failure{L"The native Windows slmgr.vbs was not found"};
        if (options.kms) check_windows_kms_edition();
        Plan plan{L"Windows", system.windows_script, {}, {L"/xpr"}};
        if (options.activate) {
            if (options.kms) plan.changes.push_back({L"/skms", *options.kms + L":" + std::to_wstring(options.port)});
            plan.changes.push_back({L"/ato"});
        }
        plans.push_back(std::move(plan));
    }
    if (options.office) {
        Plan plan{L"Office", find_office_script(options.generation), {}, {L"/dstatus"}};
        if (options.activate) {
            if (options.kms) {
                plan.changes.push_back({L"/sethst:" + *options.kms});
                plan.changes.push_back({L"/setprt:" + std::to_wstring(options.port)});
            }
            plan.changes.push_back({L"/act"});
        }
        plans.push_back(std::move(plan));
    }
    for (const auto& plan : plans) std::wcout << plan.label << L": " << plan.script.native() << L'\n';
    if (options.office)
        std::wcout << L"Office 2016/2019/2021/2024 share the Office16 directory generation; OSPP reports the installed license.\n";
    if (options.activate) {
        std::wcout << L"Activation uses installed licensing rights; no keys or activation servers are supplied.\n";
        if (options.kms) std::wcout << L"Requested KMS configuration: " << *options.kms << L":" << options.port << L'\n';
        if (!options.yes) {
            std::wcout << L"Type ACTIVATE to allow these licensing changes and activation requests: " << std::flush;
            std::wstring confirmation;
            if (!std::getline(std::wcin, confirmation) || confirmation != L"ACTIVATE") {
                std::wcout << L"Cancelled; no licensing commands were run.\n";
                return 1;
            }
        }
    }
    unsigned int failures = 0;
    for (const auto& plan : plans) {
        try {
            for (const auto& command : plan.changes) {
                if (run_script(system, plan.script, command) != 0) {
                    ++failures;
                    std::wcerr << L"Licensing command failed; earlier settings may already have changed.\n";
                    break;
                }
            }
            if (run_script(system, plan.script, plan.status_arguments) != 0) ++failures;
        } catch (const Failure& error) {
            ++failures;
            std::wcerr << plan.label << L": " << error.text << L'\n';
        }
    }
    std::wcout << L"A zero script exit code is not proof of activation. The licensing status above is authoritative.\n";
    return failures ? 2 : 0;
}

int wmain(int argc, wchar_t** argv) {
    _setmode(_fileno(stdin), _O_U16TEXT);
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stderr), _O_U16TEXT);
    try { return run(argc, argv); }
    catch (const Failure& error) { std::wcerr << error.text << L'\n'; }
    catch (const std::exception& error) { std::wcerr << from_utf8(error.what()) << L'\n'; }
    return 1;
}
