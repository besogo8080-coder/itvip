// language: C++17, file: tempclean.cpp, target: Windows 10/11 x64/x86, compiler: MSVC/MinGW
// APIs: SHGetKnownFolderPath, GetWindowsDirectoryW, RegEnumKeyExW, CreateFileW, GetFileInformationByHandle, GetFinalPathNameByHandleW, FindFirstFileW, SetFileInformationByHandle, SHEmptyRecycleBinW, FormatMessageW
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <type_traits>
#include <vector>
#include <fcntl.h>
#include <io.h>

namespace fs = std::filesystem;
struct Failure { std::wstring text; };
struct HandleDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value);
    }
};
struct FindDeleter {
    void operator()(void* value) const noexcept {
        if (value && value != INVALID_HANDLE_VALUE) FindClose(value);
    }
};
struct KeyDeleter { void operator()(HKEY value) const noexcept { if (value) RegCloseKey(value); } };
struct CoTaskDeleter { void operator()(wchar_t* value) const noexcept { CoTaskMemFree(value); } };
using UniqueHandle = std::unique_ptr<void, HandleDeleter>;
using UniqueFind = std::unique_ptr<void, FindDeleter>;
using UniqueKey = std::unique_ptr<std::remove_pointer_t<HKEY>, KeyDeleter>;
using UniqueString = std::unique_ptr<wchar_t, CoTaskDeleter>;

std::wstring error_text(DWORD code) {
    wchar_t buffer[2048]{};
    const DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr, code, 0, buffer, static_cast<DWORD>(std::size(buffer)), nullptr);
    std::wstring result(buffer, count);
    while (!result.empty() && (result.back() == L'\r' || result.back() == L'\n')) result.pop_back();
    return L"[" + std::to_wstring(code) + L"] " + result;
}

std::wstring from_utf8(const char* text) {
    const int count = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (count <= 0) return L"Unrepresentable diagnostic";
    std::wstring result(static_cast<std::size_t>(count), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, result.data(), count);
    result.pop_back();
    return result;
}

std::wstring native_path(const fs::path& path) {
    auto normalized = path.lexically_normal();
    normalized.make_preferred();
    std::wstring text = normalized.native();
    if (text.rfind(L"\\\\?\\", 0) == 0) text.erase(0, 4);
    if (text.size() < 3 || text[1] != L':' || text[2] != L'\\' ||
        !((text[0] >= L'A' && text[0] <= L'Z') || (text[0] >= L'a' && text[0] <= L'z')))
        throw Failure{L"Only absolute local drive paths are supported"};
    return L"\\\\?\\" + text;
}

bool equal_path(const std::wstring& left, const std::wstring& right) {
    return CompareStringOrdinal(left.c_str(), static_cast<int>(left.size()),
        right.c_str(), static_cast<int>(right.size()), TRUE) == CSTR_EQUAL;
}

std::wstring final_path(HANDLE handle) {
    const DWORD needed = GetFinalPathNameByHandleW(handle, nullptr, 0, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
    if (needed == 0) throw Failure{L"GetFinalPathNameByHandleW: " + error_text(GetLastError())};
    std::wstring result(static_cast<std::size_t>(needed) + 1, L'\0');
    const DWORD written = GetFinalPathNameByHandleW(handle, result.data(),
        static_cast<DWORD>(result.size()), FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
    if (written == 0) throw Failure{L"GetFinalPathNameByHandleW: " + error_text(GetLastError())};
    if (written >= result.size()) throw Failure{L"Final path changed during validation"};
    result.resize(written);
    return result;
}

std::uint64_t file_time(const FILETIME& value) {
    return (static_cast<std::uint64_t>(value.dwHighDateTime) << 32) | value.dwLowDateTime;
}

struct Options {
    bool apply = false;
    bool yes = false;
    bool system = false;
    bool all_users = false;
    bool recycle = false;
    unsigned int days = 7;
};
struct Counts {
    std::uint64_t files_seen = 0;
    std::uint64_t eligible_files = 0;
    std::uint64_t deleted_files = 0;
    std::uint64_t removed_directories = 0;
    std::uint64_t candidate_bytes = 0;
    std::uint64_t freed_bytes = 0;
    std::uint64_t skipped = 0;
    std::uint64_t failed = 0;
};

void report_failure(Counts& counts, const fs::path& path, const std::wstring& message) {
    ++counts.failed;
    std::wcerr << L"FAILED " << std::quoted(path.native()) << L": " << message << L'\n';
}

void skip(Counts& counts, const fs::path& path, const wchar_t* reason) {
    ++counts.skipped;
    std::wcout << L"SKIPPED " << std::quoted(path.native()) << L": " << reason << L'\n';
}

bool dispose(HANDLE handle, DWORD& error) {
    FILE_DISPOSITION_INFO disposition{};
    disposition.DeleteFile = TRUE;
    if (SetFileInformationByHandle(handle, FileDispositionInfo, &disposition, sizeof(disposition))) return true;
    error = GetLastError();
    return false;
}

void walk(const fs::path& path, const std::wstring& allowed_root, bool root,
          unsigned int depth, const Options& options, std::uint64_t cutoff, Counts& counts) {
    if (depth > 128) { skip(counts, path, L"depth limit"); return; }
    const std::wstring expected = native_path(path);
    const DWORD attributes = GetFileAttributesW(expected.c_str());
    if (attributes == INVALID_FILE_ATTRIBUTES) {
        const DWORD code = GetLastError();
        if (root && (code == ERROR_FILE_NOT_FOUND || code == ERROR_PATH_NOT_FOUND)) {
            skip(counts, path, L"directory does not exist");
            return;
        }
        report_failure(counts, path, L"GetFileAttributesW: " + error_text(code));
        return;
    }
    if (attributes & FILE_ATTRIBUTE_REPARSE_POINT) { skip(counts, path, L"reparse point"); return; }
    const bool directory = (attributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
    if (root && !directory) { skip(counts, path, L"approved root is not a directory"); return; }
    DWORD access = FILE_READ_ATTRIBUTES;
    if (directory) access |= FILE_LIST_DIRECTORY;
    if (options.apply && !root) access |= DELETE;
    const DWORD share = directory ? FILE_SHARE_READ | FILE_SHARE_WRITE : 0;
    UniqueHandle handle(CreateFileW(expected.c_str(), access, share, nullptr, OPEN_EXISTING,
        FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS, nullptr));
    if (handle.get() == INVALID_HANDLE_VALUE) {
        report_failure(counts, path, L"CreateFileW: " + error_text(GetLastError()));
        return;
    }
    BY_HANDLE_FILE_INFORMATION information{};
    if (!GetFileInformationByHandle(handle.get(), &information)) {
        report_failure(counts, path, L"GetFileInformationByHandle: " + error_text(GetLastError()));
        return;
    }
    if ((information.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) ||
        (((information.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0) != directory)) {
        skip(counts, path, L"entry type changed");
        return;
    }
    const std::wstring actual = final_path(handle.get());
    const bool inside = equal_path(actual, allowed_root) ||
        (actual.size() > allowed_root.size() && actual[allowed_root.size()] == L'\\' &&
         CompareStringOrdinal(actual.c_str(), static_cast<int>(allowed_root.size()),
             allowed_root.c_str(), static_cast<int>(allowed_root.size()), TRUE) == CSTR_EQUAL);
    if (!inside || !equal_path(actual, expected)) {
        skip(counts, path, L"resolved path differs from the approved local path");
        return;
    }
    const auto modified = file_time(information.ftLastWriteTime);
    const bool old_enough = modified != 0 && modified <= cutoff;
    if (!directory) {
        ++counts.files_seen;
        if (!old_enough) { ++counts.skipped; return; }
        if (information.nNumberOfLinks != 1) { skip(counts, path, L"multiple hard links"); return; }
        if (information.dwFileAttributes & FILE_ATTRIBUTE_READONLY) {
            skip(counts, path, L"read-only; attributes are not changed");
            return;
        }
        const auto size = (static_cast<std::uint64_t>(information.nFileSizeHigh) << 32) | information.nFileSizeLow;
        ++counts.eligible_files;
        counts.candidate_bytes += size;
        if (!options.apply) {
            std::wcout << L"WOULD_DELETE " << std::quoted(path.native()) << L" bytes=" << size << L'\n';
            return;
        }
        DWORD code = ERROR_SUCCESS;
        if (!dispose(handle.get(), code)) {
            report_failure(counts, path, L"SetFileInformationByHandle: " + error_text(code));
            return;
        }
        handle.reset();
        ++counts.deleted_files;
        counts.freed_bytes += size;
        std::wcout << L"DELETED " << std::quoted(path.native()) << L'\n';
        return;
    }
    bool enumeration_ok = true;
    {
        WIN32_FIND_DATAW entry{};
        UniqueFind search(FindFirstFileW((expected + L"\\*").c_str(), &entry));
        if (search.get() == INVALID_HANDLE_VALUE) {
            const DWORD code = GetLastError();
            if (code != ERROR_FILE_NOT_FOUND) {
                enumeration_ok = false;
                report_failure(counts, path, L"FindFirstFileW: " + error_text(code));
            }
        } else {
            do {
                const std::wstring name = entry.cFileName;
                if (name == L"." || name == L"..") continue;
                const auto child = path / name;
                try { walk(child, allowed_root, false, depth + 1, options, cutoff, counts); }
                catch (const Failure& error) { report_failure(counts, child, error.text); }
            } while (FindNextFileW(search.get(), &entry));
            const DWORD code = GetLastError();
            if (code != ERROR_NO_MORE_FILES) {
                enumeration_ok = false;
                report_failure(counts, path, L"FindNextFileW: " + error_text(code));
            }
        }
    }
    if (root || !enumeration_ok || !old_enough) return;
    if (!options.apply) {
        std::wcout << L"WOULD_REMOVE_IF_EMPTY " << std::quoted(path.native()) << L'\n';
        return;
    }
    DWORD code = ERROR_SUCCESS;
    if (dispose(handle.get(), code)) {
        handle.reset();
        ++counts.removed_directories;
    } else if (code == ERROR_DIR_NOT_EMPTY) ++counts.skipped;
    else report_failure(counts, path, L"Remove empty directory: " + error_text(code));
}

fs::path current_profile() {
    PWSTR raw = nullptr;
    const HRESULT status = SHGetKnownFolderPath(FOLDERID_Profile, KF_FLAG_DONT_VERIFY, nullptr, &raw);
    UniqueString profile(raw);
    if (FAILED(status)) throw Failure{L"SHGetKnownFolderPath: " + error_text(static_cast<DWORD>(status))};
    return fs::path(profile.get()).lexically_normal();
}

fs::path windows_directory() {
    std::wstring buffer(32768, L'\0');
    const UINT length = GetWindowsDirectoryW(buffer.data(), static_cast<UINT>(buffer.size()));
    if (length == 0) throw Failure{L"GetWindowsDirectoryW: " + error_text(GetLastError())};
    if (length >= buffer.size()) throw Failure{L"Windows directory path exceeds supported length"};
    buffer.resize(length);
    return fs::path(buffer).lexically_normal();
}

std::wstring profile_path(HKEY key) {
    DWORD type = 0, bytes = 0;
    LSTATUS status = RegQueryValueExW(key, L"ProfileImagePath", nullptr, &type, nullptr, &bytes);
    if (status == ERROR_FILE_NOT_FOUND) return {};
    if (status != ERROR_SUCCESS) throw Failure{L"Read profile path: " + error_text(static_cast<DWORD>(status))};
    if ((type != REG_SZ && type != REG_EXPAND_SZ) || bytes == 0 || bytes > 65536 || bytes % sizeof(wchar_t) != 0)
        throw Failure{L"Invalid ProfileImagePath value"};
    std::vector<wchar_t> buffer(bytes / sizeof(wchar_t) + 1, L'\0');
    status = RegQueryValueExW(key, L"ProfileImagePath", nullptr, &type,
        reinterpret_cast<BYTE*>(buffer.data()), &bytes);
    if (status != ERROR_SUCCESS) throw Failure{L"Read profile path: " + error_text(static_cast<DWORD>(status))};
    if (type == REG_SZ) return std::wstring(buffer.data());
    if (type != REG_EXPAND_SZ) throw Failure{L"ProfileImagePath type changed"};
    const DWORD needed = ExpandEnvironmentStringsW(buffer.data(), nullptr, 0);
    if (needed == 0) throw Failure{L"ExpandEnvironmentStringsW: " + error_text(GetLastError())};
    std::wstring expanded(needed, L'\0');
    const DWORD written = ExpandEnvironmentStringsW(buffer.data(), expanded.data(), needed);
    if (written == 0) throw Failure{L"ExpandEnvironmentStringsW: " + error_text(GetLastError())};
    if (written > needed) throw Failure{L"Profile environment changed during expansion"};
    expanded.resize(written - 1);
    return expanded;
}

void add_all_profiles(std::vector<fs::path>& roots) {
    HKEY raw = nullptr;
    LSTATUS status = RegOpenKeyExW(HKEY_LOCAL_MACHINE,
        L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList", 0,
        KEY_READ | KEY_WOW64_64KEY, &raw);
    if (status != ERROR_SUCCESS) throw Failure{L"Open ProfileList: " + error_text(static_cast<DWORD>(status))};
    UniqueKey profiles(raw);
    for (DWORD index = 0;; ++index) {
        std::array<wchar_t, 256> name{};
        DWORD length = static_cast<DWORD>(name.size());
        status = RegEnumKeyExW(profiles.get(), index, name.data(), &length, nullptr, nullptr, nullptr, nullptr);
        if (status == ERROR_NO_MORE_ITEMS) break;
        if (status != ERROR_SUCCESS) throw Failure{L"Enumerate profiles: " + error_text(static_cast<DWORD>(status))};
        const std::wstring sid(name.data(), length);
        if (sid.rfind(L"S-1-5-21-", 0) != 0 && sid.rfind(L"S-1-12-1-", 0) != 0) continue;
        HKEY raw_profile = nullptr;
        status = RegOpenKeyExW(profiles.get(), sid.c_str(), 0, KEY_READ | KEY_WOW64_64KEY, &raw_profile);
        if (status != ERROR_SUCCESS) throw Failure{L"Open profile: " + error_text(static_cast<DWORD>(status))};
        UniqueKey profile(raw_profile);
        const auto directory = profile_path(profile.get());
        if (!directory.empty()) roots.push_back((fs::path(directory) / L"AppData" / L"Local" / L"Temp").lexically_normal());
    }
}

Options parse_options(int argc, wchar_t** argv) {
    Options options;
    for (int index = 1; index < argc; ++index) {
        const std::wstring argument = argv[index];
        if (argument == L"--apply") options.apply = true;
        else if (argument == L"--yes") options.yes = true;
        else if (argument == L"--system") options.system = true;
        else if (argument == L"--all-users") options.all_users = true;
        else if (argument == L"--recycle") options.recycle = true;
        else if (argument == L"--older-than-days" && index + 1 < argc) {
            const std::wstring value = argv[++index];
            if (value.empty() || value.size() > 5 || value.find_first_not_of(L"0123456789") != std::wstring::npos)
                throw Failure{L"--older-than-days requires an integer from 0 to 36500"};
            const unsigned long days = std::stoul(value);
            if (days > 36500) throw Failure{L"--older-than-days exceeds 36500"};
            options.days = static_cast<unsigned int>(days);
        } else throw Failure{L"Usage: tempclean [--system] [--all-users] [--older-than-days N] [--recycle] [--apply [--yes]]"};
    }
    if (options.yes && !options.apply) throw Failure{L"--yes requires --apply"};
    return options;
}

int run(int argc, wchar_t** argv) {
    const Options options = parse_options(argc, argv);
    const auto profile = current_profile();
    std::vector<fs::path> roots{
        profile / L"AppData" / L"Local" / L"Temp",
        profile / L"AppData" / L"LocalLow" / L"Temp"};
    if (options.system) {
        const auto windows = windows_directory();
        roots.push_back(windows / L"Temp");
        roots.push_back(windows / L"SystemTemp");
    }
    if (options.all_users) add_all_profiles(roots);
    std::sort(roots.begin(), roots.end(), [](const fs::path& left, const fs::path& right) {
        return _wcsicmp(left.c_str(), right.c_str()) < 0;
    });
    roots.erase(std::unique(roots.begin(), roots.end(), [](const fs::path& left, const fs::path& right) {
        return _wcsicmp(left.c_str(), right.c_str()) == 0;
    }), roots.end());
    for (const auto& root : roots) {
        native_path(root);
        std::wcout << L"ROOT " << std::quoted(root.native()) << L'\n';
    }
    std::wcout << (options.apply ? L"APPLY" : L"PREVIEW") << L"; minimum age=" << options.days << L" day(s)"
               << (options.recycle ? L"; empty current account recycle bin on all drives" : L"") << L'\n';
    if (options.apply && !options.yes) {
        std::wcout << L"Type DELETE to confirm these deletions: " << std::flush;
        std::wstring confirmation;
        if (!std::getline(std::wcin, confirmation) || confirmation != L"DELETE") {
            std::wcout << L"Cancelled; nothing changed.\n";
            return 1;
        }
    }
    FILETIME now{};
    GetSystemTimeAsFileTime(&now);
    constexpr std::uint64_t ticks_per_day = 86400ULL * 10000000ULL;
    const auto current = file_time(now);
    const auto age = static_cast<std::uint64_t>(options.days) * ticks_per_day;
    const std::uint64_t cutoff = current > age ? current - age : 0;
    Counts counts;
    for (const auto& root : roots) {
        try { walk(root, native_path(root), true, 0, options, cutoff, counts); }
        catch (const Failure& error) { report_failure(counts, root, error.text); }
    }
    if (options.recycle) {
        if (!options.apply) std::wcout << L"WOULD_EMPTY_RECYCLE_BIN\n";
        else {
            const HRESULT status = SHEmptyRecycleBinW(nullptr, nullptr,
                SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);
            if (FAILED(status)) report_failure(counts, L"RecycleBin",
                L"SHEmptyRecycleBinW: " + error_text(static_cast<DWORD>(status)));
            else std::wcout << L"RECYCLE_BIN_EMPTIED\n";
        }
    }
    std::wcout << std::fixed << std::setprecision(2)
               << L"candidate_mb=" << static_cast<long double>(counts.candidate_bytes) / 1048576.0L
               << L" freed_logical_mb=" << static_cast<long double>(counts.freed_bytes) / 1048576.0L
               << L" files_seen=" << counts.files_seen << L" eligible=" << counts.eligible_files
               << L" deleted=" << counts.deleted_files << L" directories_removed=" << counts.removed_directories
               << L" acl_fixed=0 skipped=" << counts.skipped << L" failed=" << counts.failed << L'\n';
    return counts.failed ? 2 : 0;
}

int wmain(int argc, wchar_t** argv) {
    _setmode(_fileno(stdin), _O_U16TEXT);
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stderr), _O_U16TEXT);
    try { return run(argc, argv); }
    catch (const Failure& error) { std::wcerr << error.text << L'\n'; }
    catch (const std::exception& error) { std::wcerr << from_utf8(error.what()) << L'\n'; }
    return 1;
}
