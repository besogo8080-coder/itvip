#include "../app/itvip_branding.hpp"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "../app/itvip_ui_audio.hpp"
#include <bcrypt.h>
#include <commdlg.h>
#include <commctrl.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <cstdint>
#include <array>
#include <limits>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iterator>

namespace fs = std::filesystem;
namespace {
enum { ID_LIST=200, ID_ADD=201, ID_RUN=202, ID_REMOVE=203, ID_REFRESH=205, ID_EDIT=206,
       ID_NAME=210, ID_ICON=211, ID_CUSTOMICON=212, ID_APPLY=213, ID_CANCEL=214, ID_CLEARICON=215, ID_PREVIEW=216, ID_COLOR=217, ID_UP=218, ID_DOWN=219, ID_SIZE=220, ID_RELINK=221, ID_TEXTCOLOR=222, ID_FONTSIZE=223, ID_IMPORT_FOLDER=224, ID_STATUS=225, ID_PROGRESS=226, ID_STORAGE=227, ID_OPENFOLDER=228, ID_RENAME_FOLDER=229, ID_DELETE_FOLDER=230, ID_FAST_COPY=231 };
struct App { std::wstring name, path, icon=L"▣", iconFile; int color=0; int size=1; int textColor=0; int fontSize=1; };
struct IconPreset { const wchar_t* label; const wchar_t* glyph; };
const IconPreset presets[]={{L"تطبيق عام / General",L"▣"},{L"متصفح / Browser",L"◉"},{L"أمان / Security",L"⬡"},{L"أدوات نظام / System",L"⚙"},{L"ملفات / Files",L"▤"},{L"شبكات / Network",L"⌁"},{L"وسائط / Media",L"♫"},{L"ألعاب / Games",L"✦"},{L"طرفية / Terminal",L">_"},{L"نسخ احتياطي / Backup",L"⛁"},{L"مجلد / Folder",L"▰"},{L"نجمة VIP / VIP",L"★"}};
std::vector<App> apps; HWND listBox{},editor{},nameEdit{},iconCombo{},iconFileLabel{},iconPreview{},colorCombo{},sizeCombo{},textColorCombo{},fontSizeCombo{}; HFONT font{}; HICON previewIcon{}; int editing=-1, dragSource=-1; bool dragging=false; std::wstring pendingIconFile, pendingPath;
fs::path base(){wchar_t b[32768]{};GetModuleFileNameW(nullptr,b,32768);return fs::path(b).parent_path().parent_path();}
std::wstring to_wide(const std::string&s){if(s.empty())return {};int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring o(n,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),o.data(),n);return o;}
std::string to_utf8(const std::wstring&s){if(s.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);std::string o(n,'\0');WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),o.data(),n,nullptr,nullptr);return o;}
fs::path db(){return base()/L"config"/L"portable_apps.tsv";}
std::wstring stored_path(const fs::path&p){std::error_code ec;auto rel=fs::relative(p,base(),ec);if(!ec&&!rel.empty()&&*rel.begin()!=L"..")return L".\\"+rel.wstring();return p.wstring();}
fs::path resolve(const std::wstring&p){if(p.rfind(L".\\",0)==0||p.rfind(L"./",0)==0)return base()/p.substr(2);return fs::path(p);}
void save(){fs::create_directories(db().parent_path());std::ofstream f(db(),std::ios::binary|std::ios::trunc);for(auto&a:apps){auto iconPath=a.iconFile.empty()?L"":stored_path(resolve(a.iconFile));f<<to_utf8(a.name)<<'\t'<<to_utf8(a.path)<<'\t'<<to_utf8(a.icon)<<'\t'<<to_utf8(iconPath)<<'\t'<<a.color<<'\t'<<a.size<<'\t'<<a.textColor<<'\t'<<a.fontSize<<"\n";}}
void load(){apps.clear();std::ifstream f(db(),std::ios::binary);std::string line;while(std::getline(f,line)){std::stringstream ss(line);std::string n,p,i,ic,co,sz,tc,fsz;std::getline(ss,n,'\t');std::getline(ss,p,'\t');std::getline(ss,i,'\t');std::getline(ss,ic,'\t');std::getline(ss,co,'\t');std::getline(ss,sz,'\t');std::getline(ss,tc,'\t');std::getline(ss,fsz,'\t');if(p.empty())continue;int color=0,size=1,textColor=0,fontSize=1;try{if(!co.empty())color=std::clamp(std::stoi(co),0,4);}catch(...){}try{if(!sz.empty())size=std::clamp(std::stoi(sz),0,2);}catch(...){}try{if(!tc.empty())textColor=std::clamp(std::stoi(tc),0,3);}catch(...){}try{if(!fsz.empty())fontSize=std::clamp(std::stoi(fsz),0,2);}catch(...){}apps.push_back({to_wide(n),to_wide(p),i.empty()?L"▣":to_wide(i),to_wide(ic),color,size,textColor,fontSize});}}
std::wstring humanSize(uint64_t bytes){const wchar_t* units[]={L"B",L"KiB",L"MiB",L"GiB",L"TiB"};long double value=static_cast<long double>(bytes);size_t u=0;while(value>=1024.0L&&u<4){value/=1024.0L;++u;}wchar_t out[80]{};swprintf_s(out,L"%.2Lf %s",value,units[u]);return out;}
struct StorageInfo{uint64_t bytes=0;uint64_t files=0;bool scanOk=true;uint64_t freeBytes=0;std::wstring fileSystem=L"غير معروف";};
StorageInfo getStorageInfo(){StorageInfo info;std::error_code ec;fs::path root=base()/L"portable"/L"apps";if(fs::exists(root,ec)){for(fs::recursive_directory_iterator it(root,fs::directory_options::none,ec),end;it!=end;it.increment(ec)){if(ec){info.scanOk=false;ec.clear();continue;}auto st=it->symlink_status(ec);if(ec){info.scanOk=false;ec.clear();continue;}if(fs::is_symlink(st)){if(it->is_directory(ec))it.disable_recursion_pending();continue;}if(fs::is_regular_file(st)){auto n=it->file_size(ec);if(ec||n>std::numeric_limits<uint64_t>::max()-info.bytes){info.scanOk=false;ec.clear();continue;}info.bytes+=n;++info.files;}}if(ec)info.scanOk=false;}
 ULARGE_INTEGER freeSpace{};if(GetDiskFreeSpaceExW(base().c_str(),&freeSpace,nullptr,nullptr))info.freeBytes=freeSpace.QuadPart;else info.scanOk=false;
 wchar_t volume[MAX_PATH]{},fsName[64]{};DWORD serial=0,maxComp=0,flags=0;wchar_t path[MAX_PATH]{};if(GetVolumePathNameW(base().c_str(),path,MAX_PATH)&&GetVolumeInformationW(path,volume,MAX_PATH,&serial,&maxComp,&flags,fsName,64))info.fileSystem=fsName;return info;}
void updateStorageSummary(){if(!statusLabel)return;auto i=getStorageInfo();std::wstring t=L"التطبيقات المستوردة: "+std::to_wstring(i.files)+L" ملف | الحجم: "+humanSize(i.bytes)+L" | المساحة الحرة: "+humanSize(i.freeBytes)+L" | نظام الملفات: "+i.fileSystem;if(!i.scanOk)t+=L" | تحذير: تعذر فحص بعض العناصر";SetWindowTextW(statusLabel,t.c_str());}
void refresh(){SendMessageW(listBox,LB_RESETCONTENT,0,0);for(auto&a:apps){auto label=a.icon+L"   "+a.name+L"   —   "+a.path;SendMessageW(listBox,LB_ADDSTRING,0,(LPARAM)label.c_str());}updateStorageSummary();}
void showStorageInfo(HWND owner){auto i=getStorageInfo();std::wstring msg=L"ملخص مكتبة التطبيقات المحمولة\n\nعدد الملفات: "+std::to_wstring(i.files)+L"\nالحجم الإجمالي: "+humanSize(i.bytes)+L"\nالمساحة الحرة على وسيط IT VIP: "+humanSize(i.freeBytes)+L"\nنظام الملفات: "+i.fileSystem+L"\n\n"+(i.scanOk?L"اكتمل الفحص دون أخطاء ظاهرة.":L"تعذر فحص بعض العناصر؛ راجع صلاحيات الوصول وحالة وسيط التخزين.");if(i.fileSystem==L"FAT32")msg+=L"\n\nتنبيه: FAT32 لا يدعم ملفًا منفردًا أكبر من 4 GiB.";MessageBoxW(owner,msg.c_str(),L"IT VIP — USB Storage",MB_ICONINFORMATION);}
void openAppsFolder(HWND owner){fs::path p=base()/L"portable"/L"apps";std::error_code ec;fs::create_directories(p,ec);if(ec){MessageBoxW(owner,L"تعذر فتح مجلد التطبيقات المحمولة.",L"IT VIP",MB_ICONERROR);return;}ShellExecuteW(owner,L"open",p.c_str(),nullptr,base().c_str(),SW_SHOWNORMAL);}
void moveCard(int from,int to){if(from<0||to<0||from>=(int)apps.size()||to>=(int)apps.size()||from==to)return;App item=std::move(apps[(size_t)from]);apps.erase(apps.begin()+from);apps.insert(apps.begin()+to,std::move(item));save();refresh();SendMessageW(listBox,LB_SETCURSEL,(WPARAM)to,0);InvalidateRect(listBox,nullptr,TRUE);}
LRESULT CALLBACK listSubclass(HWND h,UINT m,WPARAM a,LPARAM l,UINT_PTR, DWORD_PTR){if(m==WM_LBUTTONDOWN){POINT pt{GET_X_LPARAM(l),GET_Y_LPARAM(l)};DWORD hit=(DWORD)SendMessageW(h,LB_ITEMFROMPOINT,0,MAKELPARAM(pt.x,pt.y));dragSource=HIWORD(hit)?-1:(int)LOWORD(hit);dragging=dragSource>=0;}else if(m==WM_LBUTTONUP&&dragging){POINT pt{GET_X_LPARAM(l),GET_Y_LPARAM(l)};DWORD hit=(DWORD)SendMessageW(h,LB_ITEMFROMPOINT,0,MAKELPARAM(pt.x,pt.y));int target=HIWORD(hit)?-1:(int)LOWORD(hit);int source=dragSource;dragging=false;dragSource=-1;LRESULT result=DefSubclassProc(h,m,a,l);if(target>=0&&source>=0)moveCard(source,target);return result;}else if(m==WM_CAPTURECHANGED){dragging=false;dragSource=-1;}return DefSubclassProc(h,m,a,l);}
void updateIconPreview(){if(previewIcon){DestroyIcon(previewIcon);previewIcon=nullptr;}if(!pendingIconFile.empty()){auto p=resolve(pendingIconFile);previewIcon=(HICON)LoadImageW(nullptr,p.c_str(),IMAGE_ICON,48,48,LR_LOADFROMFILE|LR_DEFAULTSIZE); }if(iconPreview)SendMessageW(iconPreview,STM_SETIMAGE,IMAGE_ICON,(LPARAM)previewIcon);}
void button(HWND w,int id,const wchar_t*t,int x,int y,int width,int height=36){CreateWindowW(L"BUTTON",t,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,x,y,width,height,w,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);}
HWND progressBar{}, statusLabel{};
struct CopyProgressContext { HWND owner{}; HWND bar{}; uint64_t total{}; uint64_t completed{}; };
// Hash files incrementally: large portable applications are never loaded into RAM.
bool sha256File(const fs::path& path, std::array<unsigned char, 32>& digest) {
    BCRYPT_ALG_HANDLE algorithm{}; BCRYPT_HASH_HANDLE hash{};
    if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) < 0) return false;
    DWORD objectBytes=0, returned=0, hashBytes=0;
    bool ok=BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH, reinterpret_cast<PUCHAR>(&objectBytes), sizeof(objectBytes), &returned, 0) >= 0 &&
            BCryptGetProperty(algorithm, BCRYPT_HASH_LENGTH, reinterpret_cast<PUCHAR>(&hashBytes), sizeof(hashBytes), &returned, 0) >= 0 && hashBytes==digest.size();
    std::vector<unsigned char> object(objectBytes);
    if (ok) ok=BCryptCreateHash(algorithm, &hash, object.data(), objectBytes, nullptr, 0, 0) >= 0;
    std::ifstream input(path, std::ios::binary);
    if (!input) ok=false;
    std::array<char, 1024*1024> buffer{};
    while (ok && input) {
        input.read(buffer.data(), static_cast<std::streamsize>(buffer.size()));
        const auto count=input.gcount();
        if (count>0 && BCryptHashData(hash, reinterpret_cast<PUCHAR>(buffer.data()), static_cast<ULONG>(count), 0) < 0) ok=false;
    }
    if (input.bad()) ok=false;
    if (ok) ok=BCryptFinishHash(hash, digest.data(), static_cast<ULONG>(digest.size()), 0) >= 0;
    if (hash) BCryptDestroyHash(hash);
    BCryptCloseAlgorithmProvider(algorithm, 0);
    return ok;
}
DWORD CALLBACK copyProgress(LARGE_INTEGER totalFile, LARGE_INTEGER transferred, LARGE_INTEGER, LARGE_INTEGER, DWORD, DWORD, HANDLE, HANDLE, LPVOID raw) {
    auto* c=static_cast<CopyProgressContext*>(raw);
    uint64_t current=transferred.QuadPart>0?static_cast<uint64_t>(transferred.QuadPart):0;
    uint64_t fileTotal=totalFile.QuadPart>0?static_cast<uint64_t>(totalFile.QuadPart):0;
    uint64_t done=c->completed+std::min(current,fileTotal);
    int pct=c->total?static_cast<int>(std::min<long double>(100.0L,(static_cast<long double>(done)*100.0L)/static_cast<long double>(c->total))):100;
    SendMessageW(c->bar,PBM_SETPOS,pct,0); UpdateWindow(c->bar); UpdateWindow(c->owner);
    return PROGRESS_CONTINUE;
}
std::wstring safeFolderName(std::wstring n) {
    for(auto& ch:n) if(ch==L'<'||ch==L'>'||ch==L':'||ch==L'"'||ch==L'/'||ch==L'\\'||ch==L'|'||ch==L'?'||ch==L'*') ch=L'_';
    while(!n.empty()&&(n.back()==L'.'||n.back()==L' ')) n.pop_back();
    if(n.empty()) n=L"ImportedApp"; if(n.size()>80)n.resize(80); return n;
}
void importFolder(HWND owner) {
    BROWSEINFOW bi{}; bi.hwndOwner=owner; bi.lpszTitle=L"اختر مجلد البرنامج بالكامل لاستيراده إلى الفلاشة"; bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;
    PIDLIST_ABSOLUTE pid=SHBrowseForFolderW(&bi); if(!pid)return;
    wchar_t selected[MAX_PATH]{}; bool got=SHGetPathFromIDListW(pid,selected)!=FALSE; CoTaskMemFree(pid); if(!got)return;
    fs::path source(selected); std::error_code ec;
    if(!fs::is_directory(source,ec)||ec){MessageBoxW(owner,L"المجلد المحدد غير صالح.",L"IT VIP",MB_ICONWARNING);return;}
    fs::path root=base()/L"portable"/L"apps"; fs::create_directories(root,ec); if(ec){MessageBoxW(owner,L"تعذر إنشاء مجلد Portable Apps على وسيط IT VIP.",L"IT VIP",MB_ICONERROR);return;}
    fs::path dest=root/safeFolderName(source.filename().wstring());
    for(unsigned suffix=2;fs::exists(dest,ec)&&suffix<10000;++suffix) dest=root/(safeFolderName(source.filename().wstring())+L"_"+std::to_wstring(suffix));
    if(ec||fs::exists(dest,ec)){MessageBoxW(owner,L"تعذر إيجاد اسم مجلد وجهة متاح.",L"IT VIP",MB_ICONERROR);return;}
    uint64_t total=0; size_t fileCount=0; bool scanError=false;
    for(fs::recursive_directory_iterator it(source,fs::directory_options::none,ec),end;it!=end;it.increment(ec)){
        if(ec){scanError=true;break;}
        auto st=it->symlink_status(ec); if(ec){scanError=true;break;}
        if(fs::is_symlink(st)){if(it->is_directory(ec))it.disable_recursion_pending();continue;}
        if(fs::is_regular_file(st)){auto z=it->file_size(ec);if(ec||z>std::numeric_limits<uint64_t>::max()-total){scanError=true;ec.clear();continue;}total+=z;++fileCount;}
    }
    if(ec)scanError=true;
    if(scanError){MessageBoxW(owner,L"تعذر قراءة بعض عناصر المجلد. لم يبدأ النسخ لتجنب استيراد ناقص.",L"IT VIP",MB_ICONERROR);return;}
    ULARGE_INTEGER freeBytes{}; if(!GetDiskFreeSpaceExW(root.c_str(),&freeBytes,nullptr,nullptr)||total>freeBytes.QuadPart){MessageBoxW(owner,L"المساحة المتاحة على وسيط التخزين غير كافية لاستيراد المجلد.",L"IT VIP",MB_ICONWARNING);return;}
    std::wstring confirm=L"سيتم نسخ "+std::to_wstring(fileCount)+L" ملفًا بإجمالي "+std::to_wstring(total/ (1024ull*1024ull))+L" MiB إلى:\n"+dest.wstring()+L"\n\nلن يتم حذف المصدر أو تعديله. هل تريد المتابعة؟";
    if(MessageBoxW(owner,confirm.c_str(),L"تأكيد استيراد تطبيق محمول",MB_YESNO|MB_ICONQUESTION)!=IDYES)return;
    fs::path staging=root/(L".itvip_import_"+std::to_wstring(GetTickCount64()));
    if(fs::exists(staging,ec)||ec){MessageBoxW(owner,L"تعذر حجز مجلد مؤقت آمن للاستيراد.",L"IT VIP",MB_ICONERROR);return;}
    fs::create_directories(staging,ec); if(ec){MessageBoxW(owner,L"تعذر إنشاء مجلد الاستيراد المؤقت.",L"IT VIP",MB_ICONERROR);return;}
    CopyProgressContext ctx{owner,progressBar,total,0}; SendMessageW(progressBar,PBM_SETRANGE32,0,100);SendMessageW(progressBar,PBM_SETPOS,0,0);ShowWindow(progressBar,SW_SHOW);ShowWindow(statusLabel,SW_SHOW);
    SetWindowTextW(statusLabel,L"جارٍ نسخ الملفات الكبيرة على أجزاء بواسطة Windows..."); EnableWindow(GetDlgItem(owner,ID_IMPORT_FOLDER),FALSE); UpdateWindow(owner);
    bool ok=true; size_t copied=0;
    for(fs::recursive_directory_iterator it(source,fs::directory_options::none,ec),end;it!=end;it.increment(ec)){
        if(ec){ok=false;break;} auto st=it->symlink_status(ec);if(ec){ok=false;break;} if(fs::is_symlink(st)){if(it->is_directory(ec))it.disable_recursion_pending();continue;}
        fs::path rel=fs::relative(it->path(),source,ec);if(ec){ok=false;break;}fs::path target=staging/rel;
        if(fs::is_directory(st)){fs::create_directories(target,ec);if(ec){ok=false;break;}continue;}
        if(!fs::is_regular_file(st))continue;fs::create_directories(target.parent_path(),ec);if(ec){ok=false;break;}
        BOOL cancelled=FALSE; if(!CopyFileExW(it->path().c_str(),target.c_str(),copyProgress,&ctx,&cancelled,COPY_FILE_FAIL_IF_EXISTS)){ok=false;break;}
        uint64_t z=it->file_size(ec);if(ec){ok=false;break;}std::error_code verifyEc;auto copiedSize=fs::file_size(target,verifyEc);if(verifyEc||copiedSize!=z){ok=false;break;}
        std::array<unsigned char,32> sourceHash{}, copiedHash{};
        if(!sha256File(it->path(),sourceHash)||!sha256File(target,copiedHash)||sourceHash!=copiedHash){ok=false;break;}
        ctx.completed+=z;++copied;int pct=total?static_cast<int>(std::min<long double>(100.0L,(static_cast<long double>(ctx.completed)*100.0L)/static_cast<long double>(total))):100;SendMessageW(progressBar,PBM_SETPOS,pct,0);UpdateWindow(progressBar);
    }
    if(ec)ok=false;
    EnableWindow(GetDlgItem(owner,ID_IMPORT_FOLDER),TRUE);
    if(ok&&(ctx.completed!=total||copied!=fileCount))ok=false;
    if(ok){fs::rename(staging,dest,ec);if(ec)ok=false;}
    if(!ok){std::error_code cleanupEc;fs::remove_all(staging,cleanupEc);SetWindowTextW(statusLabel,L"فشل الاستيراد؛ لم يتم اعتماد مجلد التطبيق.");MessageBoxW(owner,L"لم يكتمل الاستيراد. تم إلغاء المجلد المؤقت إن أمكن، والمصدر الأصلي لم يتم حذفه أو تعديله.",L"IT VIP",MB_ICONERROR);return;}
    SendMessageW(progressBar,PBM_SETPOS,100,0);SetWindowTextW(statusLabel,L"اكتمل الاستيراد والتحقق من SHA-256 لكل ملف."); updateStorageSummary();
    MessageBoxW(owner,(L"تم نسخ التطبيق والتحقق من بصمة SHA-256 لكل ملف إلى:\n"+dest.wstring()+L"\n\nيمكنك إضافته للقائمة عبر اختيار ملف EXE من المجلد الجديد.").c_str(),L"اكتمل الاستيراد",MB_ICONINFORMATION);
}
void openEditor(HWND owner,int index,const std::wstring&initialPath=L"");
void add(HWND w){wchar_t file[32768]{};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=w;ofn.lpstrFile=file;ofn.nMaxFile=32768;ofn.lpstrFilter=L"Applications (*.exe)\0*.exe\0All files (*.*)\0*.*\0\0";ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(!GetOpenFileNameW(&ofn))return;fs::path p(file);if(fs::exists(p))openEditor(w,-1,p.wstring());}
void runSelected(HWND w){int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);if(i<0||i>=(int)apps.size())return;auto p=resolve(apps[i].path);if(!fs::exists(p)){MessageBoxW(w,L"الملف غير موجود. ربما تغير مكان الفلاشة أو تم نقل التطبيق.",L"IT VIP Portable Manager",MB_ICONWARNING);return;}ShellExecuteW(w,L"open",p.c_str(),nullptr,p.parent_path().c_str(),SW_SHOWNORMAL);}
void removeSelected(HWND w){int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);if(i<0||i>=(int)apps.size())return;if(MessageBoxW(w,L"إزالة التطبيق من القائمة فقط؟ لن يتم حذف ملف EXE أو الأيقونة الأصلية.",L"تأكيد",MB_YESNO|MB_ICONQUESTION)!=IDYES)return;apps.erase(apps.begin()+i);save();refresh();}
void relinkSelected(HWND w){
 int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);
 if(i<0||i>=(int)apps.size()){MessageBoxW(w,L"اختر تطبيقًا من القائمة أولاً.",L"IT VIP",MB_ICONINFORMATION);return;}
 wchar_t file[32768]{};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=w;ofn.lpstrFile=file;ofn.nMaxFile=32768;ofn.lpstrFilter=L"Applications (*.exe)\0*.exe\0All files (*.*)\0*.*\0\0";ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
 if(!GetOpenFileNameW(&ofn))return;
 fs::path chosen(file);if(!fs::exists(chosen)||!fs::is_regular_file(chosen)){MessageBoxW(w,L"الملف المحدد غير صالح.",L"IT VIP",MB_ICONWARNING);return;}
 apps[(size_t)i].path=stored_path(chosen);save();refresh();SendMessageW(listBox,LB_SETCURSEL,(WPARAM)i,0);
}
// Resolve an EXE to its top-level imported application folder. Canonical paths
// prevent '..' and junction/symlink escapes from reaching outside portable/apps.
bool selectedImportedFolder(HWND owner, fs::path& root, fs::path& folder, size_t& selectedIndex) {
    int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);
    if(i<0||i>=(int)apps.size()){MessageBoxW(owner,L"اختر تطبيقًا من القائمة أولاً.",L"IT VIP",MB_ICONINFORMATION);return false;}
    std::error_code ec;const fs::path portableCandidate=base()/L"portable";const fs::path rootCandidate=portableCandidate/L"apps";
    auto portableStatus=fs::symlink_status(portableCandidate,ec);if(ec||fs::is_symlink(portableStatus)){MessageBoxW(owner,L"تم رفض العملية لأن مجلد portable مفقود أو رابط رمزي.",L"IT VIP",MB_ICONERROR);return false;}
    auto rootStatus=fs::symlink_status(rootCandidate,ec);if(ec||fs::is_symlink(rootStatus)||!fs::is_directory(rootStatus)){MessageBoxW(owner,L"مجلد التطبيقات غير موجود أو غير آمن.",L"IT VIP",MB_ICONERROR);return false;}
    root=fs::weakly_canonical(rootCandidate,ec);if(ec){MessageBoxW(owner,L"تعذر التحقق من المسار الحقيقي لمجلد التطبيقات.",L"IT VIP",MB_ICONERROR);return false;}
    fs::path exe=fs::weakly_canonical(resolve(apps[(size_t)i].path),ec);
    if(ec||!fs::is_regular_file(exe,ec)){MessageBoxW(owner,L"مسار EXE المحدد غير صالح.",L"IT VIP",MB_ICONWARNING);return false;}
    auto rel=exe.lexically_relative(root);
    if(rel.empty()||rel.is_absolute()||*rel.begin()==L".."||std::distance(rel.begin(),rel.end())<2){MessageBoxW(owner,L"هذه الوظيفة تعمل فقط مع تطبيق مستورد داخل portable\\apps.",L"IT VIP",MB_ICONINFORMATION);return false;}
    folder=(root/ *rel.begin()).lexically_normal();
    auto canonicalFolder=fs::weakly_canonical(folder,ec);
    if(ec||canonicalFolder.parent_path()!=root||fs::is_symlink(fs::symlink_status(folder,ec))){MessageBoxW(owner,L"تم رفض المسار لأنه لا يشير إلى مجلد تطبيق مباشر وآمن.",L"IT VIP",MB_ICONERROR);return false;}
    selectedIndex=(size_t)i;return true;
}
bool pathWithin(const fs::path& child,const fs::path& parent){
    auto c=child.begin(),p=parent.begin();
    for(;p!=parent.end();++p,++c){if(c==child.end()||CompareStringOrdinal(c->c_str(),-1,p->c_str(),-1,TRUE)!=CSTR_EQUAL)return false;}
    return true;
}
void renameImportedFolder(HWND owner){
    fs::path root,folder;size_t selected=0;if(!selectedImportedFolder(owner,root,folder,selected))return;
    // Use the selected card's display name as the folder name. The user can edit
    // that display name first with the existing card editor.
    std::wstring proposed=safeFolderName(apps[selected].name);
    if(proposed.empty()||proposed==folder.filename().wstring()){MessageBoxW(owner,L"اسم البطاقة يطابق اسم المجلد الحالي. غيّر اسم البطاقة أولاً ثم أعد المحاولة.",L"IT VIP",MB_ICONINFORMATION);return;}
    fs::path dest=root/proposed;std::error_code ec;if(fs::exists(dest,ec)||ec){MessageBoxW(owner,L"يوجد مجلد بهذا الاسم بالفعل؛ لم يتم استبدال أي ملفات.",L"IT VIP",MB_ICONWARNING);return;}
    if(MessageBoxW(owner,(L"سيتم إعادة تسمية المجلد إلى:\n"+proposed+L"\nوسيتم تحديث مسارات التطبيقات المسجلة داخله. متابعة؟").c_str(),L"تأكيد إعادة التسمية",MB_YESNO|MB_ICONWARNING)!=IDYES)return;
    if(!MoveFileExW(folder.c_str(),dest.c_str(),MOVEFILE_WRITE_THROUGH)){MessageBoxW(owner,L"فشلت إعادة التسمية. لم يتم استبدال مجلد موجود.",L"IT VIP",MB_ICONERROR);return;}
    for(auto& app:apps){std::error_code pathEc;auto old=fs::absolute(resolve(app.path),pathEc).lexically_normal();if(!pathEc&&pathWithin(old,folder)){auto rel=old.lexically_relative(folder);app.path=stored_path(dest/rel);}if(!app.iconFile.empty()){pathEc.clear();auto icon=fs::absolute(resolve(app.iconFile),pathEc).lexically_normal();if(!pathEc&&pathWithin(icon,folder)){auto rel=icon.lexically_relative(folder);app.iconFile=stored_path(dest/rel);}}}
    save();refresh();MessageBoxW(owner,L"تمت إعادة تسمية مجلد التطبيق وتحديث المسارات المسجلة.",L"IT VIP",MB_ICONINFORMATION);
}
void deleteImportedFolder(HWND owner){
    fs::path root,folder;size_t selected=0;if(!selectedImportedFolder(owner,root,folder,selected))return;
    std::wstring warning=L"سيتم حذف مجلد التطبيق بالكامل من الفلاشة، بما في ذلك كل ملفاته:\n\n"+folder.wstring()+L"\n\nلن يتم حذف أي شيء خارج portable\\apps. هذا الإجراء لا يمكن التراجع عنه. هل تريد المتابعة؟";
    if(MessageBoxW(owner,warning.c_str(),L"تأكيد حذف نهائي",MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2)!=IDYES)return;
    std::error_code ec;auto canonical=fs::weakly_canonical(folder,ec);
    if(ec||canonical.parent_path()!=root||canonical==root||fs::is_symlink(fs::symlink_status(folder,ec))){MessageBoxW(owner,L"تم رفض الحذف بسبب فشل فحص حدود المجلد.",L"IT VIP",MB_ICONERROR);return;}
    fs::remove_all(folder,ec);if(ec){MessageBoxW(owner,L"تعذر حذف المجلد بالكامل. قد تبقى بعض الملفات؛ افحص الفلاشة يدويًا.",L"IT VIP",MB_ICONERROR);return;}
    for(auto& app:apps){if(app.iconFile.empty())continue;std::error_code e;auto icon=fs::absolute(resolve(app.iconFile),e).lexically_normal();if(!e&&pathWithin(icon,folder))app.iconFile.clear();}
    apps.erase(std::remove_if(apps.begin(),apps.end(),[&](const App& app){std::error_code e;auto p=fs::absolute(resolve(app.path),e).lexically_normal();return !e&&pathWithin(p,folder);}),apps.end());
    save();refresh();MessageBoxW(owner,L"تم حذف مجلد التطبيق وإزالة إدخالاته من القائمة وتحديث مراجع الأيقونات.",L"IT VIP",MB_ICONINFORMATION);
}
LRESULT CALLBACK editorProc(HWND w,UINT m,WPARAM a,LPARAM l){switch(m){case WM_CREATE:{CreateWindowW(L"STATIC",L"اسم التطبيق الظاهر:",WS_CHILD|WS_VISIBLE,20,18,160,22,w,nullptr,nullptr,nullptr);nameEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,20,44,390,30,w,(HMENU)ID_NAME,nullptr,nullptr);CreateWindowW(L"STATIC",L"اختر شعارًا جاهزًا:",WS_CHILD|WS_VISIBLE,20,88,180,22,w,nullptr,nullptr,nullptr);iconCombo=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,20,114,390,220,w,(HMENU)ID_ICON,nullptr,nullptr);for(auto&p:presets){std::wstring label=std::wstring(p.glyph)+L"   "+p.label;SendMessageW(iconCombo,CB_ADDSTRING,0,(LPARAM)label.c_str());}SendMessageW(iconCombo,CB_SETCURSEL,0,0);button(w,ID_CUSTOMICON,L"اختيار ملف أيقونة .ICO",20,164,190);button(w,ID_CLEARICON,L"إزالة الأيقونة المخصصة",220,164,190);iconFileLabel=CreateWindowW(L"STATIC",L"استخدم رمزًا جاهزًا أو اختر ملف ICO",WS_CHILD|WS_VISIBLE,20,202,390,22,w,nullptr,nullptr,nullptr);CreateWindowW(L"STATIC",L"لون البطاقة:",WS_CHILD|WS_VISIBLE,20,232,90,22,w,nullptr,nullptr,nullptr);colorCombo=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,115,228,295,150,w,(HMENU)ID_COLOR,nullptr,nullptr);const wchar_t* colors[]={L"Violet Neon",L"Cyan Blue",L"Gold Chrome",L"Matrix Green",L"Neutral Dark"};for(auto label:colors)SendMessageW(colorCombo,CB_ADDSTRING,0,(LPARAM)label);SendMessageW(colorCombo,CB_SETCURSEL,0,0);CreateWindowW(L"STATIC",L"حجم البطاقة:",WS_CHILD|WS_VISIBLE,20,270,90,22,w,nullptr,nullptr,nullptr);sizeCombo=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,115,266,295,100,w,(HMENU)ID_SIZE,nullptr,nullptr);const wchar_t* sizes[]={L"Compact — صغير",L"Standard — متوسط",L"Large — كبير"};for(auto label:sizes)SendMessageW(sizeCombo,CB_ADDSTRING,0,(LPARAM)label);SendMessageW(sizeCombo,CB_SETCURSEL,1,0);CreateWindowW(L"STATIC",L"لون النص:",WS_CHILD|WS_VISIBLE,20,304,90,22,w,nullptr,nullptr,nullptr);textColorCombo=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,115,300,295,100,w,(HMENU)ID_TEXTCOLOR,nullptr,nullptr);const wchar_t* textColors[]={L"Ice White",L"Soft Cyan",L"Warm Gold",L"Neon Violet"};for(auto label:textColors)SendMessageW(textColorCombo,CB_ADDSTRING,0,(LPARAM)label);SendMessageW(textColorCombo,CB_SETCURSEL,0,0);CreateWindowW(L"STATIC",L"حجم الخط:",WS_CHILD|WS_VISIBLE,20,340,90,22,w,nullptr,nullptr,nullptr);fontSizeCombo=CreateWindowW(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,115,336,295,100,w,(HMENU)ID_FONTSIZE,nullptr,nullptr);const wchar_t* fontSizes[]={L"Small — صغير",L"Medium — متوسط",L"Large — كبير"};for(auto label:fontSizes)SendMessageW(fontSizeCombo,CB_ADDSTRING,0,(LPARAM)label);SendMessageW(fontSizeCombo,CB_SETCURSEL,1,0);iconPreview=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_ICON,425,105,56,56,w,(HMENU)ID_PREVIEW,nullptr,nullptr);button(w,ID_APPLY,L"حفظ",20,390,110);button(w,ID_CANCEL,L"إلغاء",145,390,110);SendMessageW(nameEdit,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(iconCombo,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(colorCombo,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(sizeCombo,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(textColorCombo,WM_SETFONT,(WPARAM)font,TRUE);SendMessageW(fontSizeCombo,WM_SETFONT,(WPARAM)font,TRUE);if(editing>=0&&editing<(int)apps.size()){SetWindowTextW(nameEdit,apps[editing].name.c_str());for(int i=0;i<(int)std::size(presets);++i)if(apps[editing].icon==presets[i].glyph)SendMessageW(iconCombo,CB_SETCURSEL,i,0);pendingIconFile=apps[editing].iconFile;SendMessageW(colorCombo,CB_SETCURSEL,apps[editing].color,0);SendMessageW(sizeCombo,CB_SETCURSEL,apps[editing].size,0);SendMessageW(textColorCombo,CB_SETCURSEL,apps[editing].textColor,0);SendMessageW(fontSizeCombo,CB_SETCURSEL,apps[editing].fontSize,0);if(!pendingIconFile.empty())SetWindowTextW(iconFileLabel,pendingIconFile.c_str());updateIconPreview();}else{auto p=fs::path(apps.empty()?L"":L"");(void)p;SetWindowTextW(nameEdit,L"");}return 0;}case WM_COMMAND:if(HIWORD(a)==BN_CLICKED)itvip::audio::click();if(LOWORD(a)==ID_CUSTOMICON){wchar_t file[32768]{};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=w;ofn.lpstrFile=file;ofn.nMaxFile=32768;ofn.lpstrFilter=L"Icon files (*.ico)\0*.ico\0\0";ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(GetOpenFileNameW(&ofn)){try{fs::path source(file);fs::path iconDir=base()/L"assets"/L"icons";fs::create_directories(iconDir);fs::path dest=iconDir/(L"app_icon_"+std::to_wstring(GetTickCount64())+source.extension().wstring());fs::copy_file(source,dest,fs::copy_options::overwrite_existing);pendingIconFile=stored_path(dest);SetWindowTextW(iconFileLabel,dest.c_str());updateIconPreview();}catch(...){MessageBoxW(w,L"تعذر نسخ الأيقونة إلى مجلد IT VIP.",L"IT VIP",MB_ICONERROR);}}return 0;}if(LOWORD(a)==ID_CLEARICON){pendingIconFile.clear();SetWindowTextW(iconFileLabel,L"تم اختيار الرمز الجاهز فقط");updateIconPreview();return 0;}if(LOWORD(a)==ID_APPLY){wchar_t name[512]{};GetWindowTextW(nameEdit,name,512);std::wstring n=name;if(n.empty()){MessageBoxW(w,L"اكتب اسمًا للتطبيق أولاً.",L"IT VIP",MB_ICONWARNING);return 0;}int ci=(int)SendMessageW(iconCombo,CB_GETCURSEL,0,0);if(ci<0)ci=0;if(!pendingIconFile.empty()&&!fs::exists(resolve(pendingIconFile))){MessageBoxW(w,L"ملف الأيقونة غير موجود. اختر ملفًا آخر.",L"IT VIP",MB_ICONWARNING);return 0;}int color=(int)SendMessageW(colorCombo,CB_GETCURSEL,0,0);if(color<0||color>4)color=0;int size=(int)SendMessageW(sizeCombo,CB_GETCURSEL,0,0);if(size<0||size>2)size=1;int textColor=(int)SendMessageW(textColorCombo,CB_GETCURSEL,0,0);if(textColor<0||textColor>3)textColor=0;int fontSize=(int)SendMessageW(fontSizeCombo,CB_GETCURSEL,0,0);if(fontSize<0||fontSize>2)fontSize=1;App item{n,L"",presets[ci].glyph,pendingIconFile,color,size,textColor,fontSize};if(editing>=0&&editing<(int)apps.size()){item.path=apps[editing].path;apps[editing]=item;}else{item.path=stored_path(fs::path(pendingPath));apps.push_back(item);}save();refresh();DestroyWindow(w);editor=nullptr;return 0;}if(LOWORD(a)==ID_CANCEL){DestroyWindow(w);editor=nullptr;return 0;}break;case WM_DESTROY:itvip::audio::back();if(previewIcon){DestroyIcon(previewIcon);previewIcon=nullptr;}editor=nullptr;return 0;}return DefWindowProcW(w,m,a,l);}
void openEditor(HWND owner,int index,const std::wstring&path){if(editor){SetForegroundWindow(editor);return;}editing=index;pendingIconFile.clear();pendingPath=path;WNDCLASSW c{};c.lpfnWndProc=editorProc;c.hInstance=GetModuleHandleW(nullptr);c.lpszClassName=L"ITVIPAppCardEditor";c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);RegisterClassW(&c);editor=CreateWindowExW(WS_EX_DLGMODALFRAME,c.lpszClassName,index>=0?L"تعديل بطاقة التطبيق — IT VIP":L"إضافة بطاقة تطبيق — IT VIP",WS_CAPTION|WS_SYSMENU|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,500,510,owner,nullptr,c.hInstance,nullptr);if(index<0&&!path.empty()){SetWindowTextW(nameEdit,fs::path(path).stem().c_str());}}
void launchFastCopy(HWND owner){
    fs::path tool=base()/L"build"/L"copy_manager.exe";
    if(!fs::exists(tool)){MessageBoxW(owner,L"أداة النسخ السريع غير مبنية بعد. أعد بناء المشروع باستخدام build.bat.",L"IT VIP",MB_ICONWARNING);return;}
    HINSTANCE r=ShellExecuteW(owner,L"open",tool.c_str(),nullptr,tool.parent_path().c_str(),SW_SHOWNORMAL);
    if(reinterpret_cast<INT_PTR>(r)<=32)MessageBoxW(owner,L"تعذر تشغيل أداة النسخ السريع.",L"IT VIP",MB_ICONERROR);
}
LRESULT CALLBACK wnd(HWND w,UINT m,WPARAM a,LPARAM l){switch(m){case WM_CREATE:font=CreateFontW(17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");listBox=CreateWindowExW(WS_EX_CLIENTEDGE,L"LISTBOX",nullptr,WS_CHILD|WS_VISIBLE|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT|LBS_OWNERDRAWVARIABLE|LBS_HASSTRINGS,20,75,760,300,w,(HMENU)ID_LIST,GetModuleHandleW(nullptr),nullptr);SendMessageW(listBox,WM_SETFONT,(WPARAM)font,TRUE);SetWindowSubclass(listBox,listSubclass,1,0);button(w,ID_ADD,L"إضافة تطبيق EXE",20,395,165);button(w,ID_EDIT,L"تعديل الاسم والأيقونة",195,395,190);button(w,ID_RUN,L"تشغيل المحدد",395,395,145);button(w,ID_REMOVE,L"إزالة من القائمة",550,395,155);button(w,ID_REFRESH,L"تحديث",715,395,80);button(w,ID_UP,L"لأعلى",20,438,100);button(w,ID_DOWN,L"لأسفل",130,438,100);button(w,ID_RELINK,L"إعادة ربط EXE",245,438,145);button(w,ID_IMPORT_FOLDER,L"استيراد مجلد كامل إلى الفلاشة",405,438,250);button(w,ID_STORAGE,L"مساحة الفلاشة",665,438,130);button(w,ID_OPENFOLDER,L"فتح مجلد التطبيقات",20,474,180);button(w,ID_RENAME_FOLDER,L"إعادة تسمية مجلد التطبيق",210,535,220);button(w,ID_DELETE_FOLDER,L"حذف مجلد التطبيق",445,535,180);button(w,ID_FAST_COPY,L"أداة النسخ السريع",635,535,160);statusLabel=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE,210,474,585,22,w,(HMENU)ID_STATUS,GetModuleHandleW(nullptr),nullptr);progressBar=CreateWindowW(PROGRESS_CLASSW,L"",WS_CHILD|PBS_SMOOTH,20,505,775,18,w,(HMENU)ID_PROGRESS,GetModuleHandleW(nullptr),nullptr);load();refresh();return 0;case WM_COMMAND:switch(LOWORD(a)){case ID_ADD:add(w);return 0;case ID_RUN:runSelected(w);return 0;case ID_REMOVE:removeSelected(w);return 0;case ID_EDIT:{int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);if(i>=0&&i<(int)apps.size())openEditor(w,i);else MessageBoxW(w,L"اختر تطبيقًا من القائمة أولاً.",L"IT VIP",MB_ICONINFORMATION);return 0;}case ID_REFRESH:load();refresh();return 0;case ID_RELINK:relinkSelected(w);return 0;case ID_IMPORT_FOLDER:importFolder(w);return 0;case ID_STORAGE:showStorageInfo(w);return 0;case ID_OPENFOLDER:openAppsFolder(w);return 0;case ID_RENAME_FOLDER:renameImportedFolder(w);return 0;case ID_DELETE_FOLDER:deleteImportedFolder(w);return 0;case ID_FAST_COPY:launchFastCopy(w);return 0;case ID_UP:case ID_DOWN:{int i=(int)SendMessageW(listBox,LB_GETCURSEL,0,0);int j=i+(LOWORD(a)==ID_UP?-1:1);if(i>=0&&j>=0&&j<(int)apps.size()){std::swap(apps[i],apps[j]);save();refresh();SendMessageW(listBox,LB_SETCURSEL,j,0);}return 0;}case ID_LIST:if(HIWORD(a)==LBN_DBLCLK)runSelected(w);return 0;}break;case WM_MEASUREITEM:{auto* mi=reinterpret_cast<MEASUREITEMSTRUCT*>(l);if(mi&&mi->CtlID==ID_LIST){int idx=(int)mi->itemID;mi->itemHeight=(idx>=0&&idx<(int)apps.size())?(apps[idx].size==0?46:(apps[idx].size==2?82:62)):62;return TRUE;}break;}case WM_DRAWITEM:{auto* di=reinterpret_cast<DRAWITEMSTRUCT*>(l);if(di&&di->CtlID==ID_LIST){int i=(int)di->itemID;if(i<0||i>=(int)apps.size())return TRUE;HDC dc=di->hDC;RECT r=di->rcItem;bool selected=(di->itemState&ODS_SELECTED)!=0;COLORREF palette[5]={RGB(25,18,42),RGB(12,35,48),RGB(43,34,16),RGB(16,40,27),RGB(18,22,38)};COLORREF chosen=palette[std::clamp(apps[i].color,0,4)];if(selected)chosen=RGB((GetRValue(chosen)+52)/2,(GetGValue(chosen)+34)/2,(GetBValue(chosen)+82)/2);HBRUSH bg=CreateSolidBrush(chosen);FillRect(dc,&r,bg);DeleteObject(bg);SetBkMode(dc,TRANSPARENT);if(selected){HPEN pen=CreatePen(PS_SOLID,1,RGB(180,110,255));auto oldPen=SelectObject(dc,pen);auto oldBrush=SelectObject(dc,GetStockObject(HOLLOW_BRUSH));Rectangle(dc,r.left,r.top,r.right,r.bottom);SelectObject(dc,oldBrush);SelectObject(dc,oldPen);DeleteObject(pen);}int iconSize=apps[i].size==0?28:(apps[i].size==2?52:40);int ix=r.left+12,iy=r.top+(r.bottom-r.top-iconSize)/2;bool iconDrawn=false;if(!apps[i].iconFile.empty()){auto ip=resolve(apps[i].iconFile);HICON hi=(HICON)LoadImageW(nullptr,ip.c_str(),IMAGE_ICON,iconSize,iconSize,LR_LOADFROMFILE|LR_DEFAULTSIZE);if(hi){DrawIconEx(dc,ix,iy,hi,iconSize,iconSize,0,nullptr,DI_NORMAL);DestroyIcon(hi);iconDrawn=true;}}if(!iconDrawn){HFONT f=CreateFontW(apps[i].size==0?22:(apps[i].size==2?36:28),0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI Symbol");auto old=SelectObject(dc,f);SetTextColor(dc,RGB(190,135,255));TextOutW(dc,ix+4,iy+3,apps[i].icon.c_str(),(int)apps[i].icon.size());SelectObject(dc,old);DeleteObject(f);}COLORREF textPalette[4]={RGB(235,240,250),RGB(100,220,245),RGB(245,205,115),RGB(205,150,255)};SetTextColor(dc,selected?RGB(255,255,255):textPalette[std::clamp(apps[i].textColor,0,3)]);int fontHeight=apps[i].fontSize==0?14:(apps[i].fontSize==2?22:18);HFONT cardFont=CreateFontW(fontHeight,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");HFONT oldFont=(HFONT)SelectObject(dc,cardFont);TextOutW(dc,ix+iconSize+14,r.top+(apps[i].size==0?5:8),apps[i].name.c_str(),(int)apps[i].name.size());SetTextColor(dc,RGB(135,150,180));TextOutW(dc,ix+iconSize+14,r.top+(apps[i].size==0?25:(apps[i].size==2?48:34)),apps[i].path.c_str(),(int)apps[i].path.size());SelectObject(dc,oldFont);DeleteObject(cardFont);if(di->itemState&ODS_FOCUS)DrawFocusRect(dc,&r);return TRUE;}break;}case WM_PAINT:{PAINTSTRUCT ps;auto dc=BeginPaint(w,&ps);RECT r;GetClientRect(w,&r);HBRUSH b=CreateSolidBrush(RGB(10,12,24));FillRect(dc,&r,b);DeleteObject(b);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(190,140,255));SelectObject(dc,font);TextOutW(dc,22,20,L"IT VIP — PORTABLE APPS STUDIO",30);SetTextColor(dc,RGB(190,200,220));TextOutW(dc,22,48,L"خصص اسم كل بطاقة وأيقونتها. اسحب البطاقة بالماوس لتغيير ترتيبها.",66);EndPaint(w,&ps);return 0;}case WM_DESTROY:if(listBox)RemoveWindowSubclass(listBox,listSubclass,1);if(font)DeleteObject(font);PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,l);}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int show){INITCOMMONCONTROLSEX icc{sizeof(icc),ICC_PROGRESS_CLASS};InitCommonControlsEx(&icc);WNDCLASSW c{};c.lpfnWndProc=wnd;c.hInstance=h;c.lpszClassName=L"ITVIPPortableManager";c.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassW(&c);HWND w=CreateWindowW(c.lpszClassName,L"IT VIP — Portable Manager",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,830,650,nullptr,nullptr,h,nullptr);if(!w)return 1;itvip::applyBranding(w,h);ShowWindow(w,show);UpdateWindow(w);MSG m;while(GetMessageW(&m,nullptr,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}return (int)m.wParam;}
