// language: C++17, file: scanner.cpp, target: Windows 10/11 x64/x86, compiler: MSVC/MinGW
// APIs: CreateFileW, GetFileInformationByHandle, ReadFile, GetFileAttributesW, BCryptOpenAlgorithmProvider, BCryptCreateHash, BCryptHashData, BCryptFinishHash, BCryptGenRandom, MoveFileExW, FormatMessageW
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <codecvt>
#include <cstdint>
#include <cwctype>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <memory>
#include <optional>
#include <sstream>
#include <string>
#include <system_error>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <fcntl.h>
#include <io.h>

namespace fs = std::filesystem;

struct HandleDeleter {
    void operator()(void* handle) const noexcept {
        if (handle && handle != INVALID_HANDLE_VALUE) CloseHandle(handle);
    }
};
struct AlgorithmDeleter {
    void operator()(void* handle) const noexcept {
        if (handle) BCryptCloseAlgorithmProvider(handle, 0);
    }
};
struct HashDeleter {
    void operator()(void* handle) const noexcept {
        if (handle) BCryptDestroyHash(handle);
    }
};
using UniqueHandle = std::unique_ptr<void, HandleDeleter>;
using UniqueAlgorithm = std::unique_ptr<void, AlgorithmDeleter>;
using UniqueHash = std::unique_ptr<void, HashDeleter>;
struct Failure { std::wstring text; };

std::wstring error_text(DWORD code) {
    wchar_t buffer[2048]{};
    const DWORD count = FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS, nullptr, code, 0, buffer,
        static_cast<DWORD>(std::size(buffer)), nullptr);
    std::wstring text(buffer, count);
    while (!text.empty() && (text.back() == L'\r' || text.back() == L'\n')) text.pop_back();
    return L"[" + std::to_wstring(code) + L"] " + text;
}

std::wstring nt_error(NTSTATUS status) {
    std::wostringstream stream;
    stream << L"NTSTATUS 0x" << std::hex << std::setw(8) << std::setfill(L'0')
           << static_cast<ULONG>(status);
    return stream.str();
}

std::wstring from_utf8(const char* text) {
    const int size = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (size <= 0) return L"Unrepresentable diagnostic";
    std::wstring output(static_cast<std::size_t>(size), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, output.data(), size);
    output.pop_back();
    return output;
}

fs::path absolute_path(const fs::path& path) {
    std::error_code ec;
    const auto result = fs::absolute(path, ec).lexically_normal();
    if (ec) throw Failure{L"absolute: " + error_text(static_cast<DWORD>(ec.value()))};
    return result;
}

std::wstring native_path(const fs::path& path) {
    std::wstring value = absolute_path(path).native();
    if (value.rfind(L"\\\\?\\", 0) == 0) return value;
    if (value.rfind(L"\\\\", 0) == 0) return L"\\\\?\\UNC\\" + value.substr(2);
    return L"\\\\?\\" + value;
}

std::wstring json_string(const std::wstring& value) {
    std::wostringstream output;
    output << L'"';
    for (const wchar_t character : value) {
        const auto unit = static_cast<unsigned int>(static_cast<unsigned short>(character));
        if (character == L'"') output << L"\\\"";
        else if (character == L'\\') output << L"\\\\";
        else if (unit < 0x20U || unit > 0x7eU) {
            output << L"\\u" << std::hex << std::setw(4) << std::setfill(L'0') << unit;
        } else output << character;
    }
    output << L'"';
    return output.str();
}

bool executable_extension(const fs::path& path) {
    static const std::unordered_set<std::wstring> extensions{
        L".exe", L".dll", L".scr", L".bat", L".cmd", L".ps1", L".vbs",
        L".js", L".hta", L".lnk", L".pif", L".com", L".msi", L".jar"};
    auto extension = path.extension().native();
    std::transform(extension.begin(), extension.end(), extension.begin(),
        [](wchar_t character) { return static_cast<wchar_t>(std::towlower(character)); });
    return extensions.count(extension) != 0;
}

std::string hex_string(const unsigned char* bytes, std::size_t count) {
    static constexpr char digits[] = "0123456789abcdef";
    std::string result(count * 2, '0');
    for (std::size_t index = 0; index < count; ++index) {
        result[index * 2] = digits[bytes[index] >> 4];
        result[index * 2 + 1] = digits[bytes[index] & 15];
    }
    return result;
}

struct Record {
    std::wstring path;
    std::optional<std::uint64_t> size;
    bool hidden = false;
    bool executable = false;
    std::optional<bool> mz;
    std::string sha256;
    std::wstring error;
};

Record inspect_file(const fs::path& path, DWORD attributes,
                    BCRYPT_ALG_HANDLE algorithm, ULONG object_size, bool hashing) {
    Record record;
    record.path = path.native();
    record.hidden = (attributes & FILE_ATTRIBUTE_HIDDEN) != 0;
    record.executable = executable_extension(path);
    UniqueHandle file(CreateFileW(native_path(path).c_str(), GENERIC_READ,
        FILE_SHARE_READ, nullptr, OPEN_EXISTING,
        FILE_FLAG_SEQUENTIAL_SCAN | FILE_FLAG_OPEN_REPARSE_POINT, nullptr));
    if (file.get() == INVALID_HANDLE_VALUE) {
        record.error = L"CreateFileW: " + error_text(GetLastError());
        return record;
    }
    BY_HANDLE_FILE_INFORMATION information{};
    if (!GetFileInformationByHandle(file.get(), &information)) {
        record.error = L"GetFileInformationByHandle: " + error_text(GetLastError());
        return record;
    }
    if (information.dwFileAttributes & (FILE_ATTRIBUTE_REPARSE_POINT | FILE_ATTRIBUTE_DIRECTORY)) {
        record.error = L"Skipped: entry became a directory or reparse point";
        return record;
    }
    record.size = (static_cast<std::uint64_t>(information.nFileSizeHigh) << 32) |
                  information.nFileSizeLow;
    record.hidden = (information.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) != 0;
    std::vector<unsigned char> object(hashing ? object_size : 0);
    UniqueHash hash;
    if (hashing) {
        BCRYPT_HASH_HANDLE raw_hash = nullptr;
        const NTSTATUS status = BCryptCreateHash(algorithm, &raw_hash, object.data(),
            object_size, nullptr, 0, 0);
        if (status < 0) {
            record.error = L"BCryptCreateHash: " + nt_error(status);
            return record;
        }
        hash.reset(raw_hash);
    }
    std::array<unsigned char, 65536> buffer{};
    bool first = true;
    for (;;) {
        DWORD count = 0;
        const DWORD requested = hashing ? static_cast<DWORD>(buffer.size()) : 2;
        if (!ReadFile(file.get(), buffer.data(), requested, &count, nullptr)) {
            record.error = L"ReadFile: " + error_text(GetLastError());
            return record;
        }
        if (first) {
            record.mz = count >= 2 && buffer[0] == 'M' && buffer[1] == 'Z';
            first = false;
        }
        if (count == 0) break;
        if (hashing) {
            const NTSTATUS status = BCryptHashData(hash.get(), buffer.data(), count, 0);
            if (status < 0) {
                record.error = L"BCryptHashData: " + nt_error(status);
                return record;
            }
        } else break;
    }
    if (hashing) {
        std::array<unsigned char, 32> digest{};
        const NTSTATUS status = BCryptFinishHash(hash.get(), digest.data(),
            static_cast<ULONG>(digest.size()), 0);
        if (status < 0) record.error = L"BCryptFinishHash: " + nt_error(status);
        else record.sha256 = hex_string(digest.data(), digest.size());
    }
    return record;
}

int run(int argc, wchar_t** argv) {
    if (argc < 2) {
        std::wcerr << L"Usage: scanner <root> [-o report.json] [--no-hash]\n";
        return 1;
    }
    const fs::path root = absolute_path(argv[1]);
    fs::path output = absolute_path(L"report.json");
    bool hashing = true;
    for (int index = 2; index < argc; ++index) {
        const std::wstring option = argv[index];
        if (option == L"--no-hash") hashing = false;
        else if (option == L"-o" && index + 1 < argc) output = absolute_path(argv[++index]);
        else throw Failure{L"Unknown or incomplete argument: " + option};
    }
    const DWORD root_attributes = GetFileAttributesW(native_path(root).c_str());
    if (root_attributes == INVALID_FILE_ATTRIBUTES)
        throw Failure{L"Root: " + error_text(GetLastError())};
    if (!(root_attributes & FILE_ATTRIBUTE_DIRECTORY) || (root_attributes & FILE_ATTRIBUTE_REPARSE_POINT))
        throw Failure{L"Root must be a directory, not a reparse point"};
    UniqueHandle root_handle(CreateFileW(native_path(root).c_str(), FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, nullptr));
    if (root_handle.get() == INVALID_HANDLE_VALUE)
        throw Failure{L"Open root: " + error_text(GetLastError())};
    const DWORD existing = GetFileAttributesW(native_path(output).c_str());
    if (existing != INVALID_FILE_ATTRIBUTES) throw Failure{L"Report already exists; choose a new -o path"};
    const DWORD probe_error = GetLastError();
    if (probe_error != ERROR_FILE_NOT_FOUND && probe_error != ERROR_PATH_NOT_FOUND)
        throw Failure{L"Report path: " + error_text(probe_error)};

    UniqueAlgorithm algorithm;
    ULONG object_size = 0;
    if (hashing) {
        BCRYPT_ALG_HANDLE raw_algorithm = nullptr;
        NTSTATUS status = BCryptOpenAlgorithmProvider(&raw_algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0);
        if (status < 0) throw Failure{L"BCryptOpenAlgorithmProvider: " + nt_error(status)};
        algorithm.reset(raw_algorithm);
        ULONG returned = 0;
        status = BCryptGetProperty(algorithm.get(), BCRYPT_OBJECT_LENGTH,
            reinterpret_cast<PUCHAR>(&object_size), sizeof(object_size), &returned, 0);
        if (status < 0) throw Failure{L"BCryptGetProperty: " + nt_error(status)};
        if (returned != sizeof(object_size) || object_size == 0)
            throw Failure{L"Invalid BCRYPT_OBJECT_LENGTH"};
    }
    std::vector<Record> records;
    std::vector<std::wstring> traversal_errors;
    std::uint64_t skipped_reparse_points = 0;
    std::error_code ec;
    fs::recursive_directory_iterator iterator(root, fs::directory_options::skip_permission_denied, ec);
    if (ec) throw Failure{L"Enumerate root: " + error_text(static_cast<DWORD>(ec.value()))};
    const fs::recursive_directory_iterator end;
    while (iterator != end) {
        const fs::path path = iterator->path();
        const DWORD attributes = GetFileAttributesW(native_path(path).c_str());
        if (attributes == INVALID_FILE_ATTRIBUTES) {
            const DWORD code = GetLastError();
            iterator.disable_recursion_pending();
            traversal_errors.push_back(path.native() + L": " + error_text(code));
        } else if (attributes & FILE_ATTRIBUTE_REPARSE_POINT) {
            iterator.disable_recursion_pending();
            ++skipped_reparse_points;
        } else if (!(attributes & FILE_ATTRIBUTE_DIRECTORY)) {
            records.push_back(inspect_file(path, attributes, algorithm.get(), object_size, hashing));
        } else {
            UniqueHandle directory(CreateFileW(native_path(path).c_str(), FILE_LIST_DIRECTORY,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, nullptr));
            if (directory.get() == INVALID_HANDLE_VALUE) {
                const DWORD code = GetLastError();
                iterator.disable_recursion_pending();
                traversal_errors.push_back(path.native() + L": " + error_text(code));
            }
        }
        iterator.increment(ec);
        if (ec) {
            traversal_errors.push_back(path.native() + L": " + error_text(static_cast<DWORD>(ec.value())));
            ec.clear();
        }
    }
    std::sort(records.begin(), records.end(), [](const Record& left, const Record& right) {
        return left.path < right.path;
    });
    std::unordered_map<std::string, std::vector<std::wstring>> duplicates;
    std::size_t file_errors = 0;
    for (const auto& record : records) {
        if (!record.sha256.empty()) duplicates[record.sha256].push_back(record.path);
        if (!record.error.empty()) ++file_errors;
    }
    std::vector<std::string> duplicate_hashes;
    for (const auto& entry : duplicates)
        if (entry.second.size() > 1) duplicate_hashes.push_back(entry.first);
    std::sort(duplicate_hashes.begin(), duplicate_hashes.end());

    std::array<unsigned char, 16> nonce{};
    const NTSTATUS random_status = BCryptGenRandom(nullptr, nonce.data(),
        static_cast<ULONG>(nonce.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG);
    if (random_status < 0) throw Failure{L"BCryptGenRandom: " + nt_error(random_status)};
    const std::string suffix = hex_string(nonce.data(), nonce.size());
    fs::path temporary = output;
    temporary += L"." + std::wstring(suffix.begin(), suffix.end()) + L".tmp";
    {
        UniqueHandle reservation(CreateFileW(native_path(temporary).c_str(), GENERIC_WRITE, 0,
            nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr));
        if (reservation.get() == INVALID_HANDLE_VALUE)
            throw Failure{L"Create report: " + error_text(GetLastError())};
    }
    std::wofstream report(fs::path(native_path(temporary)), std::ios::binary | std::ios::trunc);
    report.imbue(std::locale(std::locale::classic(), new std::codecvt_utf8_utf16<wchar_t>));
    if (!report) throw Failure{L"Open report stream: " + from_utf8(std::generic_category().message(errno).c_str())};
    report << L"{\n  \"root\": " << json_string(root.native())
           << L",\n  \"hashing\": " << (hashing ? L"true" : L"false")
           << L",\n  \"notice\": \"Extension and MZ are flags, not malware verdicts. Reparse points and inaccessible directories are skipped.\","
           << L"\n  \"files\": [\n";
    for (std::size_t index = 0; index < records.size(); ++index) {
        const auto& record = records[index];
        report << L"    {\"path\": " << json_string(record.path) << L", \"size\": ";
        if (record.size) report << *record.size; else report << L"null";
        report << L", \"hidden\": " << (record.hidden ? L"true" : L"false")
               << L", \"executable_extension\": " << (record.executable ? L"true" : L"false")
               << L", \"mz\": ";
        if (record.mz) report << (*record.mz ? L"true" : L"false"); else report << L"null";
        report << L", \"sha256\": ";
        if (record.sha256.empty()) report << L"null";
        else report << json_string(std::wstring(record.sha256.begin(), record.sha256.end()));
        report << L", \"error\": " << (record.error.empty() ? L"null" : json_string(record.error))
               << L"}" << (index + 1 == records.size() ? L"\n" : L",\n");
    }
    report << L"  ],\n  \"duplicates\": [\n";
    for (std::size_t index = 0; index < duplicate_hashes.size(); ++index) {
        const auto& digest = duplicate_hashes[index];
        report << L"    {\"sha256\": " << json_string(std::wstring(digest.begin(), digest.end())) << L", \"paths\": [";
        const auto& paths = duplicates.at(digest);
        for (std::size_t item = 0; item < paths.size(); ++item) {
            if (item) report << L", ";
            report << json_string(paths[item]);
        }
        report << L"]}" << (index + 1 == duplicate_hashes.size() ? L"\n" : L",\n");
    }
    report << L"  ],\n  \"traversal_errors\": [";
    for (std::size_t index = 0; index < traversal_errors.size(); ++index) {
        if (index) report << L", ";
        report << json_string(traversal_errors[index]);
    }
    report << L"],\n  \"summary\": {\"files\": " << records.size()
           << L", \"file_errors\": " << file_errors
           << L", \"traversal_errors\": " << traversal_errors.size()
           << L", \"skipped_reparse_points\": " << skipped_reparse_points
           << L", \"duplicate_groups\": " << duplicate_hashes.size() << L"}\n}\n";
    report.flush();
    if (!report) throw Failure{L"Report write failed; temporary report retained: " + temporary.native()};
    report.close();
    if (!report) throw Failure{L"Report close failed; temporary report retained: " + temporary.native()};
    if (!MoveFileExW(native_path(temporary).c_str(), native_path(output).c_str(), MOVEFILE_WRITE_THROUGH))
        throw Failure{L"Publish report (temporary file retained): " + error_text(GetLastError())};
    std::wcout << L"Report: " << output.native() << L"\nFiles: " << records.size()
               << L"; duplicate groups: " << duplicate_hashes.size()
               << L"; errors: " << file_errors + traversal_errors.size() << L'\n';
    return file_errors || !traversal_errors.empty() ? 2 : 0;
}

int wmain(int argc, wchar_t** argv) {
    _setmode(_fileno(stdout), _O_U16TEXT);
    _setmode(_fileno(stderr), _O_U16TEXT);
    try { return run(argc, argv); }
    catch (const Failure& error) { std::wcerr << error.text << L'\n'; }
    catch (const std::exception& error) { std::wcerr << from_utf8(error.what()) << L'\n'; }
    return 1;
}
