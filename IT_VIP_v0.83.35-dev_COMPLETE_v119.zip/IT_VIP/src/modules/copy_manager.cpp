#include "../app/itvip_branding.hpp"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "../app/itvip_ui_audio.hpp"
#include <commctrl.h>
#include <shlobj.h>
#include <shellapi.h>
#include <filesystem>
#include <vector>
#include <algorithm>
#include <string>
#include <thread>
#include <atomic>
#include <cstdint>
#include <limits>
#include <system_error>

namespace fs = std::filesystem;
namespace {
enum : int { ID_SOURCE=301, ID_DEST=302, ID_START=303, ID_CANCEL=304, ID_PROGRESS=305, ID_STATUS=306 };
constexpr UINT WM_COPY_PROGRESS = WM_APP + 31;
constexpr UINT WM_COPY_FINISHED = WM_APP + 32;
struct CopyItem { fs::path source, relative; uint64_t size=0; };
struct CopyJob { std::vector<CopyItem> items; std::vector<fs::path> directories; fs::path sourceRoot, destinationRoot; uint64_t total=0; };
HWND g_window{}, g_sourceLabel{}, g_destLabel{}, g_progress{}, g_status{}, g_start{}, g_cancel{};
HFONT g_font{};
std::wstring g_source, g_destination;
std::thread g_worker;
std::atomic<bool> g_cancelRequested{false};
std::atomic<bool> g_running{false};

std::wstring humanSize(uint64_t n) {
    const wchar_t* u[]={L"B",L"KiB",L"MiB",L"GiB",L"TiB"};
    long double v=static_cast<long double>(n); size_t i=0;
    while(v>=1024.0L && i<4){v/=1024.0L;++i;}
    wchar_t b[80]{}; swprintf_s(b,L"%.2Lf %s",v,u[i]); return b;
}
std::wstring pickFolder(HWND owner,const wchar_t* title) {
    BROWSEINFOW bi{}; bi.hwndOwner=owner; bi.lpszTitle=title;
    bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE|BIF_EDITBOX;
    PIDLIST_ABSOLUTE pid=SHBrowseForFolderW(&bi); if(!pid)return {};
    wchar_t path[32768]{}; bool ok=SHGetPathFromIDListW(pid,path)!=FALSE; CoTaskMemFree(pid);
    return ok?path:L"";
}
void setStatus(const std::wstring& s){SetWindowTextW(g_status,s.c_str());}
bool buildJob(CopyJob& job,std::wstring& error) {
    std::error_code ec; job.sourceRoot=fs::weakly_canonical(fs::path(g_source),ec);
    if(ec||!fs::is_directory(job.sourceRoot,ec)||ec){error=L"مجلد المصدر غير صالح أو غير متاح.";return false;}
    fs::path destBase=fs::weakly_canonical(fs::path(g_destination),ec);
    if(ec||!fs::is_directory(destBase,ec)||ec){error=L"مجلد الوجهة غير صالح أو غير متاح.";return false;}
    if(job.sourceRoot.filename().empty()){error=L"اختر مجلدًا داخل القرص، وليس جذر القرص نفسه.";return false;}
    job.destinationRoot=destBase/job.sourceRoot.filename();
    std::wstring s=job.sourceRoot.wstring(), d=job.destinationRoot.wstring();
    while(s.size()>3 && (s.back()==L'\\'||s.back()==L'/'))s.pop_back();
    while(d.size()>3 && (d.back()==L'\\'||d.back()==L'/'))d.pop_back();
    if(d.size()>=s.size() && CompareStringOrdinal(d.data(),static_cast<int>(s.size()),s.data(),static_cast<int>(s.size()),TRUE)==CSTR_EQUAL &&
       (d.size()==s.size() || d[s.size()]==L'\\' || d[s.size()]==L'/')){error=L"لا يمكن نسخ المجلد إلى داخله أو إلى مجلد تابع له.";return false;}
    if(fs::exists(job.destinationRoot,ec)){error=L"يوجد مجلد بنفس الاسم في الوجهة. غيّر اسم المصدر أو اختر وجهة أخرى؛ لن يتم استبدال الملفات.";return false;}
    for(fs::recursive_directory_iterator it(job.sourceRoot,fs::directory_options::none,ec),end;it!=end;it.increment(ec)){
        if(ec){error=L"تعذرت قراءة أحد عناصر المصدر. أوقفنا العملية قبل بدء النسخ.";return false;}
        auto st=it->symlink_status(ec); if(ec){error=L"تعذر فحص نوع أحد عناصر المصدر.";return false;}
        if(fs::is_symlink(st)){if(fs::is_directory(st))it.disable_recursion_pending();continue;}
        if(fs::is_directory(st)){
            job.directories.push_back(fs::relative(it->path(),job.sourceRoot,ec));
            if(ec){error=L"تعذر إنشاء المسار النسبي لأحد المجلدات.";return false;}
            continue;
        }
        if(fs::is_regular_file(st)){
            uint64_t z=it->file_size(ec); if(ec||z>std::numeric_limits<uint64_t>::max()-job.total){error=L"تعذر حساب الحجم الإجمالي أو حدث تجاوز في الحجم.";return false;}
            job.total+=z; job.items.push_back({it->path(),fs::relative(it->path(),job.sourceRoot,ec),z});
            if(ec){error=L"تعذر إنشاء المسار النسبي لأحد الملفات.";return false;}
        }
    }
    if(ec){error=L"تعذر إكمال فحص مجلد المصدر.";return false;}
    ULARGE_INTEGER freeBytes{};
    if(!GetDiskFreeSpaceExW(destBase.c_str(),&freeBytes,nullptr,nullptr)||job.total>freeBytes.QuadPart){error=L"المساحة الحرة في الوجهة غير كافية.";return false;}
    return true;
}
struct Progress { HWND window{}; uint64_t total=0, completed=0; };
DWORD CALLBACK copyCallback(LARGE_INTEGER totalFile,LARGE_INTEGER transferred,LARGE_INTEGER,LARGE_INTEGER,DWORD,DWORD,HANDLE,HANDLE,LPVOID raw){
    auto* p=static_cast<Progress*>(raw);
    if(g_cancelRequested.load())return PROGRESS_CANCEL;
    uint64_t current=transferred.QuadPart>0?static_cast<uint64_t>(transferred.QuadPart):0;
    uint64_t fileTotal=totalFile.QuadPart>0?static_cast<uint64_t>(totalFile.QuadPart):0;
    uint64_t done=p->completed+std::min(current,fileTotal);
    int pct=p->total?static_cast<int>(std::min<long double>(100.0L,static_cast<long double>(done)*100.0L/static_cast<long double>(p->total))):100;
    PostMessageW(p->window,WM_COPY_PROGRESS,(WPARAM)pct,(LPARAM)0); return PROGRESS_CONTINUE;
}
void runCopy(CopyJob job) {
    std::error_code ec; bool ok=true; bool cancelled=false; uint64_t completed=0; size_t count=0;
    // Cleanup is permitted only when this worker successfully created the destination.
    // If another process wins the create race, never remove its pre-existing directory.
    const bool destinationCreated=fs::create_directory(job.destinationRoot,ec);
    if(!destinationCreated||ec)ok=false;
    Progress progress{g_window,job.total,0};
    for(const auto& item:job.items){
        if(!ok)break;
        if(g_cancelRequested.load()){cancelled=true;ok=false;break;}
        fs::path target=job.destinationRoot/item.relative;
        fs::create_directories(target.parent_path(),ec); if(ec){ok=false;break;}
        BOOL cancelFlag=FALSE;
        if(!CopyFileExW(item.source.c_str(),target.c_str(),copyCallback,&progress,&cancelFlag,COPY_FILE_FAIL_IF_EXISTS)){
            cancelled=g_cancelRequested.load()||cancelFlag; ok=false; break;
        }
        std::error_code verify; auto copied=fs::file_size(target,verify);
        if(verify||copied!=item.size){ok=false;break;}
        completed+=item.size; progress.completed=completed; ++count;
        int pct=job.total?static_cast<int>(std::min<long double>(100.0L,static_cast<long double>(completed)*100.0L/static_cast<long double>(job.total))):100;
        PostMessageW(g_window,WM_COPY_PROGRESS,(WPARAM)pct,(LPARAM)0);
    }
    if(ok && (completed!=job.total || count!=job.items.size()))ok=false;
    if(!ok && destinationCreated){std::error_code cleanup;fs::remove_all(job.destinationRoot,cleanup);}
    g_running.store(false);
    // wParam: 1 success, 2 cancelled, 0 failure. Only this job's newly-created partial tree is cleaned.
    PostMessageW(g_window,WM_COPY_FINISHED,ok?1:(cancelled?2:0),0);
}
void chooseSource(){auto p=pickFolder(g_window,L"اختر مجلد المصدر: من الفلاشة إلى الكمبيوتر أو العكس");if(!p.empty()){g_source=p;SetWindowTextW(g_sourceLabel,p.c_str());}}
void chooseDestination(){auto p=pickFolder(g_window,L"اختر مجلد الوجهة على الكمبيوتر أو الفلاشة");if(!p.empty()){g_destination=p;SetWindowTextW(g_destLabel,p.c_str());}}
void startCopy(){
    if(g_running.load())return;
    if(g_source.empty()||g_destination.empty()){MessageBoxW(g_window,L"اختر مجلد المصدر ومجلد الوجهة أولاً.",L"IT VIP — Fast Copy",MB_ICONINFORMATION);return;}
    CopyJob job; std::wstring error;
    if(!buildJob(job,error)){MessageBoxW(g_window,error.c_str(),L"تعذر بدء النسخ",MB_ICONWARNING);return;}
    std::wstring message=L"سيتم نسخ "+std::to_wstring(job.items.size())+L" ملفًا، بإجمالي "+humanSize(job.total)+L" إلى:\n"+job.destinationRoot.wstring()+L"\n\nلن يتم حذف المصدر أو استبدال ملفات موجودة. هل تريد المتابعة؟";
    if(MessageBoxW(g_window,message.c_str(),L"تأكيد النسخ السريع",MB_YESNO|MB_ICONQUESTION)!=IDYES)return;
    if(g_worker.joinable())g_worker.join();
    g_cancelRequested.store(false);g_running.store(true);EnableWindow(g_start,FALSE);EnableWindow(g_cancel,TRUE);SendMessageW(g_progress,PBM_SETPOS,0,0);setStatus(L"جارٍ النسخ في الخلفية... يمكنك متابعة التقدم وإلغاء العملية.");
    try{g_worker=std::thread(runCopy,std::move(job));}
    catch(...){g_running.store(false);EnableWindow(g_start,TRUE);EnableWindow(g_cancel,FALSE);setStatus(L"تعذر إنشاء مهمة النسخ الخلفية.");MessageBoxW(g_window,L"تعذر بدء خيط النسخ. لم يتم نسخ أي ملفات.",L"IT VIP",MB_ICONERROR);}
}
LRESULT CALLBACK windowProc(HWND w,UINT m,WPARAM a,LPARAM l){
    switch(m){
    case WM_CREATE:{
        g_window=w;g_font=CreateFontW(17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
        auto label=[&](const wchar_t*t,int x,int y,int width,int height){HWND h=CreateWindowW(L"STATIC",t,WS_CHILD|WS_VISIBLE,x,y,width,height,w,nullptr,GetModuleHandleW(nullptr),nullptr);SendMessageW(h,WM_SETFONT,(WPARAM)g_font,TRUE);return h;};
        auto btn=[&](const wchar_t*t,int id,int x,int y,int width){HWND h=CreateWindowW(L"BUTTON",t,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|WS_TABSTOP,x,y,width,38,w,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);SendMessageW(h,WM_SETFONT,(WPARAM)g_font,TRUE);return h;};
        label(L"IT VIP — أداة النسخ السريع",24,20,700,30);
        label(L"اختر المصدر والوجهة. الأداة تنسخ المجلد كاملًا في الخلفية دون حذف المصدر.",24,55,740,26);
        btn(L"اختيار مجلد المصدر",ID_SOURCE,24,105,190);g_sourceLabel=label(L"لم يتم اختيار المصدر",230,112,570,26);
        btn(L"اختيار مجلد الوجهة",ID_DEST,24,165,190);g_destLabel=label(L"لم يتم اختيار الوجهة",230,172,570,26);
        g_progress=CreateWindowW(PROGRESS_CLASSW,L"",WS_CHILD|WS_VISIBLE|PBS_SMOOTH,24,235,760,24,w,(HMENU)ID_PROGRESS,GetModuleHandleW(nullptr),nullptr);SendMessageW(g_progress,PBM_SETRANGE32,0,100);
        g_status=label(L"جاهز للنسخ.",24,275,760,45);
        g_start=btn(L"ابدأ النسخ السريع",ID_START,24,345,210);g_cancel=btn(L"إلغاء النسخ",ID_CANCEL,250,345,150);EnableWindow(g_cancel,FALSE);
        return 0;}
    case WM_COMMAND:if(HIWORD(a)==BN_CLICKED)itvip::audio::click();switch(LOWORD(a)){case ID_SOURCE:chooseSource();return 0;case ID_DEST:chooseDestination();return 0;case ID_START:startCopy();return 0;case ID_CANCEL:if(g_running.load()){g_cancelRequested.store(true);setStatus(L"جارٍ إلغاء النسخ بأمان...");EnableWindow(g_cancel,FALSE);}return 0;}break;
    case WM_COPY_PROGRESS:SendMessageW(g_progress,PBM_SETPOS,(WPARAM)a,0);return 0;
    case WM_COPY_FINISHED:EnableWindow(g_start,TRUE);EnableWindow(g_cancel,FALSE);if(a==1){SendMessageW(g_progress,PBM_SETPOS,100,0);setStatus(L"اكتمل النسخ بنجاح. المصدر الأصلي لم يتغير.");MessageBoxW(w,L"اكتمل النسخ بنجاح.",L"IT VIP — Fast Copy",MB_ICONINFORMATION);}else if(a==2){setStatus(L"تم إلغاء النسخ. حُذفت الوجهة الجزئية إن أمكن.");MessageBoxW(w,L"تم إلغاء النسخ. تم تنظيف مجلد الوجهة الجزئي إن أمكن.",L"IT VIP",MB_ICONINFORMATION);}else{setStatus(L"فشل النسخ. حُذفت الوجهة الجزئية إن أمكن.");MessageBoxW(w,L"فشل النسخ. تحقق من صلاحيات الوصول وحالة وسيط التخزين.",L"IT VIP",MB_ICONERROR);}return 0;
    case WM_CLOSE:if(g_running.load()){if(MessageBoxW(w,L"النسخ ما زال جاريًا. هل تريد إلغاءه وإغلاق الأداة؟",L"تأكيد الإغلاق",MB_YESNO|MB_ICONQUESTION)!=IDYES)return 0;g_cancelRequested.store(true);if(g_worker.joinable())g_worker.join();}DestroyWindow(w);return 0;
    case WM_DESTROY:itvip::audio::back();if(g_worker.joinable())g_worker.join();if(g_font)DeleteObject(g_font);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(w,m,a,l);
}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int show){INITCOMMONCONTROLSEX icc{sizeof(icc),ICC_PROGRESS_CLASS};InitCommonControlsEx(&icc);WNDCLASSW c{};c.lpfnWndProc=windowProc;c.hInstance=h;c.lpszClassName=L"ITVIPFastCopyManager";c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClassW(&c);HWND w=CreateWindowW(c.lpszClassName,L"IT VIP — Fast Copy",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,830,455,nullptr,nullptr,h,nullptr);if(!w)return 1;itvip::applyBranding(w,h);ShowWindow(w,show);UpdateWindow(w);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;}
