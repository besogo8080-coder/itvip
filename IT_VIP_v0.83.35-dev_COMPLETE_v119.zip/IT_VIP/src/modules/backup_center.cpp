#include "../app/itvip_branding.hpp"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <shlobj.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <cwchar>
#include <algorithm>
#include <unordered_set>
#include <cwctype>
namespace fs=std::filesystem;
namespace {
HWND g_status{};
fs::path appRoot(){wchar_t b[32768]{};GetModuleFileNameW(nullptr,b,32768);return fs::path(b).parent_path().parent_path();}
// Windows Credential Manager secrets are intentionally not exported.
const std::vector<std::wstring> folders={L"config",L"data",L"assets",L"portable",L"reports"};
std::string hexBytes(const std::string&s){static const char*d="0123456789ABCDEF";std::string o;for(unsigned char c:s){o+=d[c>>4];o+=d[c&15];}return o;}
bool unhex(const std::string&s,std::string&o){if(s.size()%2)return false;o.clear();auto v=[](char c){if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;if(c>='a'&&c<='f')return c-'a'+10;return -1;};for(size_t i=0;i<s.size();i+=2){int a=v(s[i]),b=v(s[i+1]);if(a<0||b<0)return false;o.push_back((char)((a<<4)|b));}return true;}
bool sha256(const fs::path&p,std::string&out){std::ifstream f(p,std::ios::binary);if(!f)return false;BCRYPT_ALG_HANDLE alg{};BCRYPT_HASH_HANDLE hash{};DWORD objLen=0,hashLen=0,got=0;if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)return false;bool ok=BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,(PUCHAR)&objLen,sizeof(objLen),&got,0)>=0&&BCryptGetProperty(alg,BCRYPT_HASH_LENGTH,(PUCHAR)&hashLen,sizeof(hashLen),&got,0)>=0;std::vector<UCHAR>obj(objLen),digest(hashLen);if(ok)ok=BCryptCreateHash(alg,&hash,obj.data(),objLen,nullptr,0,0)>=0;std::vector<char>buf(65536);while(ok&&f){f.read(buf.data(),(std::streamsize)buf.size());auto n=f.gcount();if(n>0)ok=BCryptHashData(hash,(PUCHAR)buf.data(),(ULONG)n,0)>=0;}if(ok)ok=BCryptFinishHash(hash,digest.data(),hashLen,0)>=0;if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);if(!ok)return false;static const char*d="0123456789abcdef";out.clear();for(auto c:digest){out+=d[c>>4];out+=d[c&15];}return true;}
void setStatus(const std::wstring&s){if(g_status)SetWindowTextW(g_status,s.c_str());}
bool inside(const fs::path&p,const fs::path&base){auto a=fs::weakly_canonical(p),b=fs::weakly_canonical(base);auto ai=a.begin(),bi=b.begin();for(;bi!=b.end();++bi,++ai)if(ai==a.end()||*ai!=*bi)return false;return true;}
std::wstring chooseFolder(const wchar_t*title){BROWSEINFOW bi{};bi.lpszTitle=title;bi.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;PIDLIST_ABSOLUTE id=SHBrowseForFolderW(&bi);if(!id)return{};wchar_t p[MAX_PATH]{};bool ok=SHGetPathFromIDListW(id,p)!=FALSE;CoTaskMemFree(id);return ok?p:L"";}
std::wstring stamp(){SYSTEMTIME t{};GetLocalTime(&t);wchar_t b[40]{};std::swprintf(b,40,L"%04u%02u%02u_%02u%02u%02u",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond);return b;}
bool createBackup(){
    auto dest=chooseFolder(L"Choose a backup destination outside the IT VIP application folder");
    if(dest.empty())return false;
    fs::path destination(dest),app=appRoot();
    if(inside(destination,app)){setStatus(L"اختر وجهة خارج مجلد IT VIP (قرص أو فلاشة أخرى).");return false;}
    auto backup=destination/(L"ITVIP_Backup_"+stamp());
    std::error_code ec;
    const bool backupCreated=fs::create_directory(backup,ec);
    if(!backupCreated||ec){setStatus(L"تعذر إنشاء مجلد نسخة جديد؛ قد توجد نسخة بنفس التوقيت.");return false;}
    auto fail=[&](const wchar_t*message){std::error_code cleanup;fs::remove_all(backup,cleanup);setStatus(message);return false;};
    std::ofstream mf(backup/L"ITVIP_BACKUP.manifest",std::ios::binary|std::ios::trunc);
    if(!mf)return fail(L"تعذر إنشاء ملف manifest.");
    mf<<"ITVIP_BACKUP_V1\n";
    size_t count=0;
    for(const auto&folder:folders){
        mf<<"FOLDER\t"<<std::string(folder.begin(),folder.end())<<"\n";
        if(!mf)return fail(L"تعذرت كتابة بيانات مجلدات النسخة الاحتياطية.");
        auto src=app/folder;
        const bool sourceExists=fs::exists(src,ec);
        if(ec)return fail(L"تعذر فحص أحد مجلدات التطبيق.");
        if(!sourceExists)continue;
        if(!fs::is_directory(src,ec)||ec)return fail(L"أحد مسارات النسخ ليس مجلدًا صالحًا.");
        fs::recursive_directory_iterator it(src,fs::directory_options::none,ec),end;
        if(ec)return fail(L"تعذر فتح مجلد للنسخ؛ لم يتم تجاهل الملفات غير المقروءة.");
        while(it!=end){
            const auto item=it->path();
            auto st=it->symlink_status(ec);
            if(ec)return fail(L"تعذر فحص عنصر في المصدر؛ أُلغيت النسخة لتجنب نسخة ناقصة.");
            if(fs::is_symlink(st)){
                if(fs::is_directory(st))it.disable_recursion_pending();
            }else if(fs::is_regular_file(st)){
                auto rel=fs::relative(item,app,ec);
                if(ec)return fail(L"تعذر حساب المسار النسبي لأحد الملفات.");
                auto out=backup/rel;
                fs::create_directories(out.parent_path(),ec);
                if(ec)return fail(L"تعذر إنشاء مجلد داخل النسخة الاحتياطية.");
                if(!fs::copy_file(item,out,fs::copy_options::none,ec)||ec)
                    return fail(L"فشل نسخ أحد الملفات؛ تم حذف النسخة غير المكتملة.");
                std::string digest;
                if(!sha256(out,digest))return fail(L"فشل حساب SHA-256؛ تم حذف النسخة غير المكتملة.");
                auto u8=rel.generic_u8string();
                auto size=fs::file_size(out,ec);
                if(ec)return fail(L"تعذر قراءة حجم ملف النسخة الاحتياطية.");
                mf<<"FILE\t"<<hexBytes(std::string(u8.begin(),u8.end()))<<'\t'<<size<<'\t'<<digest<<"\n";
                if(!mf)return fail(L"تعذرت كتابة manifest؛ تم حذف النسخة غير المكتملة.");
                ++count;
            }
            it.increment(ec);
            if(ec)return fail(L"حدث خطأ أثناء تعداد الملفات؛ أُلغيت النسخة بدل تخطي ملفات.");
        }
    }
    mf.flush();
    const bool manifestOk=static_cast<bool>(mf);
    mf.close();
    if(!manifestOk||!mf)return fail(L"تعذر إكمال ملف manifest.");
    if(count==0)return fail(L"لم يتم العثور على ملفات؛ لم تُنشأ نسخة احتياطية فارغة.");
    setStatus(L"تم إنشاء النسخة والتحقق من ملفاتها: "+backup.wstring()+L" — عدد الملفات: "+std::to_wstring(count));
    return true;
}
struct RestoreFile{fs::path relative;std::uintmax_t size{};std::string digest;};
struct RestoreState{fs::path relative;bool existed{};bool committed{};};

// Persist a small recovery journal before and after each commit step. The journal
// is replaced with write-through semantics so an interrupted restore leaves a
// useful recovery record alongside its staged and original files.
bool writeRestoreJournal(const fs::path&transaction,const std::vector<RestoreState>&states,const wchar_t*phase,size_t index){
    std::ostringstream content;
    content<<"ITVIP_RESTORE_JOURNAL_V1\nPHASE\t";
    for(const wchar_t*c=phase;*c;++c)content<<(char)*c;
    content<<"\nINDEX\t"<<index<<"\n";
    for(const auto&state:states){
        auto u8=state.relative.generic_u8string();
        content<<"ITEM\t"<<hexBytes(std::string(u8.begin(),u8.end()))<<'\t'<<(state.existed?1:0)<<"\n";
    }
    const std::string bytes=content.str();
    const auto temp=transaction/L"restore.journal.tmp";
    const auto journal=transaction/L"restore.journal";
    HANDLE h=CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,nullptr);
    if(h==INVALID_HANDLE_VALUE)return false;
    size_t offset=0;bool ok=true;
    while(offset<bytes.size()){
        DWORD written=0;DWORD chunk=(DWORD)std::min<size_t>(bytes.size()-offset,1u<<20);
        if(!WriteFile(h,bytes.data()+offset,chunk,&written,nullptr)||written==0){ok=false;break;}
        offset+=written;
    }
    if(ok&&!FlushFileBuffers(h))ok=false;
    CloseHandle(h);
    if(!ok){DeleteFileW(temp.c_str());return false;}
    if(!MoveFileExW(temp.c_str(),journal.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))return false;
    return true;
}

std::vector<fs::path> findPendingRestoreTransactions(const fs::path&app){
    std::vector<fs::path> pending;std::error_code ec;
    for(fs::directory_iterator it(app,fs::directory_options::skip_permission_denied,ec),end;!ec&&it!=end;it.increment(ec)){
        const auto name=it->path().filename().wstring();
        if(name.rfind(L".itvip_restore_txn_",0)!=0)continue;
        std::error_code itemError;
        if(it->is_directory(itemError)&&!itemError&&fs::is_regular_file(it->path()/L"restore.journal",itemError)&&!itemError)
            pending.push_back(it->path());
    }
    return pending;
}

void notifyPendingRestoreTransactions(const fs::path&app){
    const auto pending=findPendingRestoreTransactions(app);
    if(pending.empty())return;
    const std::wstring message=L"تم العثور على معاملات استعادة سابقة ("+std::to_wstring(pending.size())+
        L"). قد تكون عملية استعادة قد انقطعت. لا تحذف مجلدات .itvip_restore_txn؛ افتح أول مجلد لمراجعة restore.journal وملفات old/new.\n\nفتح مجلد الاسترداد الآن؟";
    if(MessageBoxW(nullptr,message.c_str(),L"IT VIP — Restore Recovery",MB_YESNO|MB_ICONWARNING)==IDYES)
        ShellExecuteW(nullptr,L"open",pending.front().c_str(),nullptr,nullptr,SW_SHOWNORMAL);
}
bool hasReparseComponent(const fs::path&root,const fs::path&target){
    std::error_code ec;
    auto rel=target.lexically_relative(root);
    if(rel.empty()||rel.is_absolute())return true;
    fs::path cur=root;
    DWORD attr=GetFileAttributesW(cur.c_str());
    if(attr==INVALID_FILE_ATTRIBUTES||(attr&FILE_ATTRIBUTE_REPARSE_POINT))return true;
    for(const auto&part:rel){
        if(part==L"."||part.empty())continue;
        if(part==L"..")return true;
        cur/=part;
        attr=GetFileAttributesW(cur.c_str());
        if(attr==INVALID_FILE_ATTRIBUTES){if(GetLastError()==ERROR_FILE_NOT_FOUND||GetLastError()==ERROR_PATH_NOT_FOUND)continue;return true;}
        if(attr&FILE_ATTRIBUTE_REPARSE_POINT)return true;
    }
    return false;
}
bool safeManifestRelativePath(const std::string&utf8,fs::path&relative,std::wstring&canonicalKey){
    if(utf8.empty()||utf8.size()>32760||utf8.front()=='/'||utf8.find('\\')!=std::string::npos)return false;
    relative=fs::u8path(utf8);
    if(relative.empty()||relative.is_absolute()||relative.has_root_name()||relative.has_root_directory())return false;
    std::wstring key;bool first=true;
    for(const auto&part:relative){
        const std::wstring segment=part.wstring();
        if(segment.empty()||segment==L"."||segment==L".."||segment.back()==L'.'||segment.back()==L' ')return false;
        for(wchar_t c:segment)if(c<32||c==L':'||c==L'<'||c==L'>'||c==L'\"'||c==L'|'||c==L'?'||c==L'*')return false;
        std::wstring stem=segment.substr(0,segment.find(L'.'));
        std::transform(stem.begin(),stem.end(),stem.begin(),[](wchar_t c){return (wchar_t)towupper(c);});
        if(stem==L"CON"||stem==L"PRN"||stem==L"AUX"||stem==L"NUL"||
           (stem.size()==4&&(stem.rfind(L"COM",0)==0||stem.rfind(L"LPT",0)==0)&&stem[3]>=L'1'&&stem[3]<=L'9'))return false;
        if(!first)key+=L'\\';first=false;
        std::wstring folded=segment;
        int needed=LCMapStringEx(LOCALE_NAME_INVARIANT,LCMAP_LOWERCASE,segment.c_str(),(int)segment.size(),nullptr,0,nullptr,nullptr,0);
        if(needed<=0)return false;
        folded.resize((size_t)needed);
        if(LCMapStringEx(LOCALE_NAME_INVARIANT,LCMAP_LOWERCASE,segment.c_str(),(int)segment.size(),folded.data(),needed,nullptr,nullptr,0)!=needed)return false;
        key+=folded;
    }
    canonicalKey=std::move(key);
    return true;
}
bool validManifest(const fs::path&backup,std::vector<RestoreFile>&files){
    std::ifstream mf(backup/L"ITVIP_BACKUP.manifest",std::ios::binary);std::string line;
    if(!std::getline(mf,line)||line!="ITVIP_BACKUP_V1")return false;
    std::vector<std::string>seen;std::unordered_set<std::string>seenFolders;std::unordered_set<std::wstring>seenFiles;size_t count=0,lineCount=0;
    while(std::getline(mf,line)){
        if(line.size()>131072||++lineCount>200005)return false;
        if(line.rfind("FOLDER\t",0)==0){auto folder=line.substr(7);if(std::find(folders.begin(),folders.end(),std::wstring(folder.begin(),folder.end()))==folders.end()||!seenFolders.insert(folder).second)return false;seen.push_back(folder);continue;}
        if(line.rfind("FILE\t",0)!=0||count>=100000)return false;
        std::istringstream ss(line);std::string tag,hx,sizeText,digest,extra;
        if(!std::getline(ss,tag,'\t')||!std::getline(ss,hx,'\t')||!std::getline(ss,sizeText,'\t')||!std::getline(ss,digest)||std::getline(ss,extra))return false;
        std::string rel;if(!unhex(hx,rel)||rel.empty()||digest.size()!=64)return false;
        if(sizeText.empty()||!std::all_of(sizeText.begin(),sizeText.end(),[](unsigned char c){return c>='0'&&c<='9';}))return false;
        if(!std::all_of(digest.begin(),digest.end(),[](unsigned char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');}))return false;
        fs::path rp;std::wstring canonicalKey;if(!safeManifestRelativePath(rel,rp,canonicalKey))return false;
        if(!seenFiles.insert(canonicalKey).second)return false;
        auto it=rp.begin();if(it==rp.end())return false;std::wstring top=it->wstring();
        if(std::find(folders.begin(),folders.end(),top)==folders.end())return false;
        auto target=backup/rp;std::error_code ec;
        if(!inside(target,backup)||hasReparseComponent(backup,target)||!fs::is_regular_file(target,ec)||ec)return false;
        auto actualSize=fs::file_size(target,ec);if(ec||std::to_string(actualSize)!=sizeText)return false;
        std::string actual;if(!sha256(target,actual)||actual!=digest)return false;
        files.push_back({rp,actualSize,digest});++count;
    }
    if(!mf.eof()||count==0)return false;
    for(const auto&f:folders)if(std::find(seen.begin(),seen.end(),std::string(f.begin(),f.end()))==seen.end())return false;
    return true;
}
bool restoreBackup(){
    auto selected=chooseFolder(L"Choose an IT VIP backup folder");if(selected.empty())return false;
    fs::path backup(selected);std::vector<RestoreFile>files;
    if(!validManifest(backup,files)){setStatus(L"النسخة غير صالحة أو ملفّاتها لا تطابق SHA-256.");return false;}
    if(MessageBoxW(nullptr,L"A staged restore will validate every file, preserve existing files for rollback, then apply the restore. Continue?",L"Confirm IT VIP Restore",MB_YESNO|MB_ICONWARNING)!=IDYES)return false;
    const auto app=appRoot();
    fs::path transaction=app/(L".itvip_restore_txn_"+stamp()+L"_"+std::to_wstring(GetCurrentProcessId()));
    std::error_code ec;
    if(!fs::create_directory(transaction,ec)||ec){setStatus(L"تعذر إنشاء مساحة الاستعادة المؤقتة؛ لم يتم تغيير أي ملف.");return false;}
    auto cleanup=[&](){std::error_code ignored;fs::remove_all(transaction,ignored);};
    std::vector<RestoreState>states;states.reserve(files.size());
    // Phase 1: stage every incoming file and snapshot every existing destination.
    for(const auto&file:files){
        const auto dst=app/file.relative;
        if(!inside(dst,app)||hasReparseComponent(app,dst)){cleanup();setStatus(L"تم رفض مسار استعادة يحتوي على رابط أو مسار غير آمن.");return false;}
        const auto staged=transaction/L"new"/file.relative;
        const auto old=transaction/L"old"/file.relative;
        fs::create_directories(staged.parent_path(),ec);
        if(ec){cleanup();setStatus(L"تعذر تجهيز مساحة الملفات الجديدة؛ لم يتم تغيير ملفات التطبيق.");return false;}
        const auto source=backup/file.relative;
        if(!fs::copy_file(source,staged,fs::copy_options::none,ec)||ec){cleanup();setStatus(L"فشل تجهيز أحد ملفات النسخة؛ لم يتم تغيير ملفات التطبيق.");return false;}
        std::string stagedDigest;auto stagedSize=fs::file_size(staged,ec);
        if(ec||stagedSize!=file.size||!sha256(staged,stagedDigest)||stagedDigest!=file.digest){cleanup();setStatus(L"فشل التحقق من ملف مجهز للاستعادة؛ لم يتم تغيير ملفات التطبيق.");return false;}
        auto status=fs::symlink_status(dst,ec);
        bool exists=!ec&&fs::exists(status);
        if(ec&&ec!=std::errc::no_such_file_or_directory){cleanup();setStatus(L"تعذر فحص ملف الوجهة؛ لم يتم تغيير ملفات التطبيق.");return false;}
        ec.clear();
        if(exists){
            if(fs::is_symlink(status)||!fs::is_regular_file(status)){cleanup();setStatus(L"وجهة الاستعادة ليست ملفًا عاديًا آمنًا.");return false;}
            fs::create_directories(old.parent_path(),ec);
            if(ec||!fs::copy_file(dst,old,fs::copy_options::none,ec)||ec){cleanup();setStatus(L"تعذر حفظ نسخة تراجع لأحد الملفات؛ لم يتم تطبيق الاستعادة.");return false;}
        }
        states.push_back({file.relative,exists,false});
    }
    // Phase 2: commit staged files. Journal each boundary for next-launch recovery inspection.
    size_t committed=0;bool commitOk=writeRestoreJournal(transaction,states,L"PREPARED",0);
    for(size_t i=0;i<files.size()&&commitOk;++i){
        const auto dst=app/files[i].relative;
        if(!writeRestoreJournal(transaction,states,L"APPLYING",i+1)){commitOk=false;break;}
        fs::create_directories(dst.parent_path(),ec);
        if(ec||hasReparseComponent(app,dst)){commitOk=false;break;}
        DWORD flags=MOVEFILE_WRITE_THROUGH|(states[i].existed?MOVEFILE_REPLACE_EXISTING:0);
        if(!MoveFileExW((transaction/L"new"/files[i].relative).c_str(),dst.c_str(),flags)){commitOk=false;break;}
        states[i].committed=true;++committed;
        if(!writeRestoreJournal(transaction,states,L"APPLIED",committed)){commitOk=false;break;}
    }
    if(!commitOk){
        // The APPLYING journal deliberately includes the possibly interrupted item.
        writeRestoreJournal(transaction,states,L"ROLLING_BACK",committed);
        bool rollbackOk=true;
        for(size_t n=committed;n>0;--n){
            const auto i=n-1;const auto dst=app/states[i].relative;bool stepOk=true;
            if(states[i].existed){
                const auto old=transaction/L"old"/states[i].relative;
                if(!CopyFileW(old.c_str(),dst.c_str(),FALSE))stepOk=false;
            }else if(!DeleteFileW(dst.c_str())&&GetLastError()!=ERROR_FILE_NOT_FOUND)stepOk=false;
            if(!stepOk){rollbackOk=false;break;}
            if(!writeRestoreJournal(transaction,states,L"ROLLING_BACK",n-1)){rollbackOk=false;break;}
        }
        if(rollbackOk){cleanup();setStatus(L"فشلت مرحلة التطبيق؛ تم التراجع عن الملفات التي تغيرت ولم تُترك استعادة جزئية.");}
        else setStatus(L"فشل التطبيق وفشل جزء من التراجع. احتفظ بمجلد .itvip_restore_txn لاسترداد الملفات يدويًا؛ يحتوي restore.journal ونسخ old/new.");
        return false;
    }
    if(!writeRestoreJournal(transaction,states,L"COMMITTED",committed)){
        setStatus(L"اكتملت الاستعادة، لكن تعذر إنهاء سجل الاسترداد. احتفظ بمجلد .itvip_restore_txn لمراجعته.");
        return true;
    }
    cleanup();
    setStatus(L"اكتملت الاستعادة المرحلية والتحقق المسبق: "+std::to_wstring(committed)+L" ملف. أعد تشغيل الوحدات المفتوحة.");
    return true;
}
void openBackupFolder(){auto p=appRoot()/L"backups";std::error_code ec;fs::create_directories(p,ec);ShellExecuteW(nullptr,L"open",p.c_str(),nullptr,nullptr,SW_SHOWNORMAL);}
LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){if(m==WM_CREATE){g_status=CreateWindowW(L"STATIC",L"جاهز — النسخ الاحتياطي محلي.",WS_CHILD|WS_VISIBLE,22,205,760,48,w,nullptr,nullptr,nullptr);CreateWindowW(L"STATIC",L"IT VIP — BACKUP & RESTORE CENTER",WS_CHILD|WS_VISIBLE,22,18,700,30,w,nullptr,nullptr,nullptr);CreateWindowW(L"STATIC",L"يشمل config / data / assets / portable / reports مع SHA-256. مفاتيح Credential Manager لا تُصدّر.",WS_CHILD|WS_VISIBLE,22,58,760,45,w,nullptr,nullptr,nullptr);CreateWindowW(L"BUTTON",L"إنشاء نسخة احتياطية",WS_CHILD|WS_VISIBLE,22,120,190,38,w,(HMENU)1,nullptr,nullptr);CreateWindowW(L"BUTTON",L"استعادة نسخة",WS_CHILD|WS_VISIBLE,230,120,160,38,w,(HMENU)2,nullptr,nullptr);CreateWindowW(L"BUTTON",L"فتح مجلد النسخ",WS_CHILD|WS_VISIBLE,408,120,170,38,w,(HMENU)3,nullptr,nullptr);return 0;}if(m==WM_COMMAND){if(LOWORD(a)==1){EnableWindow(GetDlgItem(w,1),FALSE);createBackup();EnableWindow(GetDlgItem(w,1),TRUE);return 0;}if(LOWORD(a)==2){restoreBackup();return 0;}if(LOWORD(a)==3){openBackupFolder();return 0;}}if(m==WM_CLOSE){DestroyWindow(w);return 0;}if(m==WM_DESTROY){g_status=nullptr;PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,b);}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int show){notifyPendingRestoreTransactions(appRoot());WNDCLASSW c{};c.lpfnWndProc=proc;c.hInstance=h;c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);c.lpszClassName=L"ITVIPBackupCenter";RegisterClassW(&c);HWND w=CreateWindowW(c.lpszClassName,L"IT VIP — Backup & Restore",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,820,310,nullptr,nullptr,h,nullptr);if(!w)return 1;itvip::applyBranding(w,h);ShowWindow(w,show);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;}
