#include "../app/itvip_branding.hpp"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "../app/itvip_ui_audio.hpp"
#include <winhttp.h>
#include <wincred.h>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <algorithm>
#include <sstream>
#include <cstdio>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "advapi32.lib")

namespace {
constexpr int ID_KEY=101, ID_MODEL=102, ID_PROMPT=103, ID_SEND=104, ID_OUTPUT=105, ID_STATUS=106, ID_CLEAR=107;
HWND g_window=nullptr; bool g_busy=false;
std::wstring getText(HWND h){int n=GetWindowTextLengthW(h);std::wstring s((size_t)n+1,L'\0');if(n)GetWindowTextW(h,s.data(),n+1);s.resize((size_t)n);return s;}
std::string utf8(const std::wstring& s){if(s.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0,nullptr,nullptr);std::string r((size_t)n,'\0');WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),r.data(),n,nullptr,nullptr);return r;}
std::wstring wide(const std::string& s){if(s.empty())return {};int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),nullptr,0);std::wstring r((size_t)n,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),r.data(),n);return r;}
std::string jsonEscape(const std::string& s){std::string o;for(unsigned char c:s){switch(c){case '"':o+="\\\"";break;case '\\':o+="\\\\";break;case '\b':o+="\\b";break;case '\f':o+="\\f";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:if(c<0x20){char b[7];std::snprintf(b,sizeof(b),"\\u%04x",c);o+=b;}else o+=(char)c;}}return o;}
std::wstring loadKey(){PCREDENTIALW c=nullptr;if(!CredReadW(L"ITVIP_OPENAI_API_KEY",CRED_TYPE_GENERIC,0,&c))return {};std::wstring key;if(c->CredentialBlob&&c->CredentialBlobSize){const wchar_t*p=(const wchar_t*)c->CredentialBlob;key.assign(p,p+c->CredentialBlobSize/sizeof(wchar_t));}CredFree(c);return key;}
bool saveKey(const std::wstring& key){if(key.empty())return CredDeleteW(L"ITVIP_OPENAI_API_KEY",CRED_TYPE_GENERIC,0)!=FALSE;CREDENTIALW c{};c.Type=CRED_TYPE_GENERIC;c.TargetName=(LPWSTR)L"ITVIP_OPENAI_API_KEY";c.CredentialBlob=(LPBYTE)key.data();c.CredentialBlobSize=(DWORD)(key.size()*sizeof(wchar_t));c.Persist=CRED_PERSIST_LOCAL_MACHINE;c.UserName=(LPWSTR)L"IT VIP OpenAI Platform";return CredWriteW(&c,0)!=FALSE;}
std::string extractOutputText(const std::string& json){
    // Responses API emits output[].content[].text. This small parser handles escaped JSON strings.
    size_t p=0;while((p=json.find("\"type\":\"output_text\"",p))!=std::string::npos){size_t t=json.find("\"text\":\"",p);if(t==std::string::npos)return {};t+=8;std::string out;bool esc=false;for(;t<json.size();++t){char c=json[t];if(esc){switch(c){case 'n':out+='\n';break;case 'r':out+='\r';break;case 't':out+='\t';break;case 'b':out+='\b';break;case 'f':out+='\f';break;case '"':out+='"';break;case '\\':out+='\\';break;case '/':out+='/';break;default:out+=c;}esc=false;}else if(c=='\\')esc=true;else if(c=='"')return out;else out+=c;}return {}; }return {};
}
struct ApiResult{bool ok=false;std::wstring text;};
ApiResult askOpenAI(const std::wstring& key,const std::wstring& model,const std::wstring& prompt){
    ApiResult result;HINTERNET session=WinHttpOpen(L"IT-VIP-AI/1.0",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0);if(!session){result.text=L"تعذر بدء اتصال HTTPS.";return result;}
    WinHttpSetTimeouts(session,10000,10000,20000,90000);HINTERNET connect=WinHttpConnect(session,L"api.openai.com",INTERNET_DEFAULT_HTTPS_PORT,0);if(!connect){WinHttpCloseHandle(session);result.text=L"تعذر الاتصال بخادم OpenAI.";return result;}
    HINTERNET request=WinHttpOpenRequest(connect,L"POST",L"/v1/responses",nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE);if(!request){WinHttpCloseHandle(connect);WinHttpCloseHandle(session);result.text=L"تعذر إنشاء طلب API.";return result;}
    std::string body="{\"model\":\""+jsonEscape(utf8(model))+"\",\"input\":\""+jsonEscape(utf8(prompt))+"\",\"store\":false}";
    std::wstring headers=L"Authorization: Bearer "+key+L"\r\nContent-Type: application/json; charset=utf-8\r\n";
    BOOL sent=WinHttpSendRequest(request,headers.c_str(),(DWORD)-1,(LPVOID)body.data(),(DWORD)body.size(),(DWORD)body.size(),0);
    BOOL received=sent&&WinHttpReceiveResponse(request,nullptr);DWORD status=0,size=sizeof(status);if(received)WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&size,WINHTTP_NO_HEADER_INDEX);
    std::string response; if(received){DWORD available=0;while(WinHttpQueryDataAvailable(request,&available)&&available){std::vector<char> chunk(available);DWORD read=0;if(!WinHttpReadData(request,chunk.data(),available,&read)||!read)break;response.append(chunk.data(),read);}}
    WinHttpCloseHandle(request);WinHttpCloseHandle(connect);WinHttpCloseHandle(session);
    if(!received){result.text=L"فشل الاتصال. تحقق من الإنترنت وإعدادات الشبكة.";return result;}
    if(status<200||status>=300){result.text=L"خطأ من OpenAI API (HTTP "+std::to_wstring(status)+L"). راجع المفتاح والصلاحيات والرصيد وحدود الاستخدام.";return result;}
    std::string output=extractOutputText(response);if(output.empty()){result.text=L"وصل رد من API لكن لم أتمكن من استخراج النص. راجع سجل الاستجابة أو جرّب نموذجًا آخر.";return result;}result.ok=true;result.text=wide(output);return result;
}
void setBusy(bool busy){g_busy=busy;EnableWindow(GetDlgItem(g_window,ID_SEND),!busy);SetWindowTextW(GetDlgItem(g_window,ID_STATUS),busy?L"جارٍ الاتصال بـ OpenAI...":L"جاهز");}
void sendPrompt(){if(g_busy)return;std::wstring key=getText(GetDlgItem(g_window,ID_KEY));std::wstring model=getText(GetDlgItem(g_window,ID_MODEL));std::wstring prompt=getText(GetDlgItem(g_window,ID_PROMPT));if(key.empty()){MessageBoxW(g_window,L"أدخل API Key أولاً. المفتاح يُحفظ في Windows Credential Manager وليس داخل ملفات المشروع.",L"IT VIP AI",MB_ICONWARNING);return;}if(prompt.empty()){MessageBoxW(g_window,L"اكتب سؤالك أو الصق تقرير الفحص أولاً.",L"IT VIP AI",MB_ICONWARNING);return;}if(model.empty())model=L"gpt-5.5";if(!saveKey(key)){MessageBoxW(g_window,L"تعذر حفظ المفتاح في Windows Credential Manager. سيُستخدم لهذا الطلب فقط.",L"IT VIP AI",MB_ICONWARNING);}setBusy(true);std::thread([key,model,prompt](){ApiResult r=askOpenAI(key,model,prompt);auto* payload=new ApiResult(std::move(r));PostMessageW(g_window,WM_APP+1,0,(LPARAM)payload);}).detach();}
LRESULT CALLBACK proc(HWND w,UINT m,WPARAM a,LPARAM b){switch(m){case WM_CREATE:{g_window=w;CreateWindowW(L"STATIC",L"OpenAI Platform — IT VIP AI Assistant",WS_CHILD|WS_VISIBLE,20,14,620,28,w,nullptr,nullptr,nullptr);CreateWindowW(L"STATIC",L"API Key (يُحفظ مشفرًا عبر Windows Credential Manager):",WS_CHILD|WS_VISIBLE,20,52,430,22,w,nullptr,nullptr,nullptr);HWND key=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_PASSWORD|ES_AUTOHSCROLL,20,76,610,28,w,(HMENU)ID_KEY,nullptr,nullptr);std::wstring saved=loadKey();if(!saved.empty())SetWindowTextW(key,saved.c_str());CreateWindowW(L"STATIC",L"Model:",WS_CHILD|WS_VISIBLE,20,112,70,22,w,nullptr,nullptr,nullptr);HWND model=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"gpt-5.5",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,90,108,220,28,w,(HMENU)ID_MODEL,nullptr,nullptr);(void)model;CreateWindowW(L"STATIC",L"اكتب سؤالًا أو الصق تقريرًا نصيًا من IT VIP لتحليله:",WS_CHILD|WS_VISIBLE,20,146,500,22,w,nullptr,nullptr,nullptr);CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"اشرح لي المشكلة التالية واقترح خطوات آمنة لإصلاحها:",WS_CHILD|WS_VISIBLE|ES_MULTILINE|ES_AUTOVSCROLL|WS_VSCROLL,20,170,610,110,w,(HMENU)ID_PROMPT,nullptr,nullptr);CreateWindowW(L"BUTTON",L"إرسال إلى OpenAI",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,20,292,145,34,w,(HMENU)ID_SEND,nullptr,nullptr);CreateWindowW(L"BUTTON",L"مسح الرد",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,175,292,100,34,w,(HMENU)ID_CLEAR,nullptr,nullptr);CreateWindowW(L"STATIC",L"جاهز",WS_CHILD|WS_VISIBLE,300,298,300,22,w,(HMENU)ID_STATUS,nullptr,nullptr);CreateWindowW(L"STATIC",L"الرد:",WS_CHILD|WS_VISIBLE,20,338,100,22,w,nullptr,nullptr,nullptr);CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"سيظهر رد المساعد هنا...",WS_CHILD|WS_VISIBLE|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY|WS_VSCROLL,20,362,610,260,w,(HMENU)ID_OUTPUT,nullptr,nullptr);CreateWindowW(L"STATIC",L"تنبيه: استخدام API قد يستهلك رصيدًا مدفوعًا. لا تلصق كلمات مرور أو بيانات شخصية حساسة.",WS_CHILD|WS_VISIBLE,20,632,620,30,w,nullptr,nullptr,nullptr);return 0;}case WM_COMMAND:if(HIWORD(a)==BN_CLICKED)itvip::audio::click();if(LOWORD(a)==ID_SEND){sendPrompt();return 0;}if(LOWORD(a)==ID_CLEAR){SetWindowTextW(GetDlgItem(w,ID_OUTPUT),L"");return 0;}break;case WM_APP+1:{std::unique_ptr<ApiResult> r((ApiResult*)b);setBusy(false);SetWindowTextW(GetDlgItem(w,ID_OUTPUT),r->text.c_str());SetWindowTextW(GetDlgItem(w,ID_STATUS),r->ok?L"اكتمل الطلب":L"فشل الطلب");return 0;}case WM_CLOSE:if(g_busy){MessageBoxW(w,L"الطلب ما زال جاريًا. انتظر حتى يكتمل قبل إغلاق المساعد.",L"IT VIP AI",MB_ICONINFORMATION);return 0;}DestroyWindow(w);return 0;case WM_DESTROY:itvip::audio::back();g_window=nullptr;PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,a,b);}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,PWSTR,int show){SetProcessDPIAware();WNDCLASSW c{};c.lpfnWndProc=proc;c.hInstance=h;c.lpszClassName=L"ITVIPAIAssistant";c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClassW(&c);HWND w=CreateWindowExW(0,c.lpszClassName,L"IT VIP — AI Assistant",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,680,720,nullptr,nullptr,h,nullptr);if(!w)return 1;itvip::applyBranding(w,h);ShowWindow(w,show);UpdateWindow(w);MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;}
