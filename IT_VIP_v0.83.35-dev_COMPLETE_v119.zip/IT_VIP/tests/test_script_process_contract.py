from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")


def test_deployment_scripts_are_started_as_tracked_processes():
    assert "void launchScript(const fs::path& script)" in MAIN
    assert "GetSystemDirectoryW(systemDir,MAX_PATH)" in MAIN
    assert "L\"cmd.exe\"" in MAIN
    assert "CREATE_NEW_CONSOLE" in MAIN
    assert "CreateProcessW(cmdExe.c_str()" in MAIN
    assert "ModuleExitContext{pi.hProcess,mainWnd,script.filename().wstring(),pi.dwProcessId,GetTickCount64()}" in MAIN
    assert "activeTools.push_back({pi.dwProcessId,script.filename().wstring(),GetTickCount64()})" in MAIN
    assert MAIN.count("launchScript(script)") == 12


def test_script_exit_uses_existing_notification_watcher():
    assert "CreateThread(nullptr,0,moduleExitWatcher,context,0,nullptr)" in MAIN
    assert "GetExitCodeProcess(context->process,&code)" in MAIN
    assert "script.filename().wstring()" in MAIN
