#include "../../src/app/strict_json.hpp"
#include <cassert>
#include <iostream>
#include <string>
using itvip::json::Parser;
using itvip::json::Value;
static void rejects(const std::string& s) { bool failed=false; try { (void)Parser(s).parse(); } catch(const std::exception&) { failed=true; } assert(failed); }
int main() {
    {
        auto v=Parser(R"({"Schema":"ITVIP-USER-EDITION-2","Revision":17,"RevokedEditionIds":["00000000-0000-0000-0000-000000000001"],"nested":{"ok":true}})").parse();
        assert(v.kind==Value::Kind::Object);
        assert(itvip::json::stringField(v,"Schema",true)=="ITVIP-USER-EDITION-2");
        assert(itvip::json::integerField(v,"Revision",-1)==17);
        auto ids=itvip::json::required(v,"RevokedEditionIds",Value::Kind::Array);
        assert(ids.array.size()==1 && ids.array[0].scalar=="00000000-0000-0000-0000-000000000001");
    }
    {
        auto v=Parser(R"({"path":"folder/\u03A9-\uD83D\uDE80.txt"})").parse();
        const auto p=itvip::json::stringField(v,"path",true);
        assert(p.find("\xCE\xA9")!=std::string::npos);
        assert(p.find("\xF0\x9F\x9A\x80")!=std::string::npos);
    }
    rejects(R"({"a":1,"a":2})");
    rejects(R"({"a":01})");
    rejects(R"({"a":1.})");
    rejects(R"({"a":1e})");
    rejects(R"([1,2,])");
    rejects(R"({"a":"bad\q"})");
    rejects(R"({"a":"\uD800"})");
    rejects(R"({"a":true} trailing)");
    rejects(std::string("{\"a\":\"") + char(0xc0) + char(0xaf) + "\"}");
    {
        itvip::json::Limits limits; limits.maxDepth=2;
        bool failed=false; try { (void)Parser("[[[0]]]",limits).parse(); } catch(...) { failed=true; } assert(failed);
    }
    {
        itvip::json::Limits limits; limits.maxNodes=3;
        bool failed=false; try { (void)Parser("[1,2,3]",limits).parse(); } catch(...) { failed=true; } assert(failed);
    }
    {
        auto v=Parser(R"({"Revision":1.5})").parse();
        bool failed=false; try { (void)itvip::json::integerField(v,"Revision",0); } catch(...) { failed=true; } assert(failed);
    }
    std::cout << "strict_json: 12 test groups passed\n";
}
