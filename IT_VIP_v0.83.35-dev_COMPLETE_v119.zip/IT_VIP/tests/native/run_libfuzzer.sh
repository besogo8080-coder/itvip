#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CXX="${CXX:-clang++}"
RUNS="${RUNS:-20000}"
BIN="${TMPDIR:-/tmp}/itvip_strict_json_libfuzzer"
WORK_CORPUS="$(mktemp -d "${TMPDIR:-/tmp}/itvip_fuzz_corpus.XXXXXX")"
cleanup() { rm -f "$BIN"; rm -rf "$WORK_CORPUS"; }
trap cleanup EXIT
cp -a "$ROOT/tests/native/corpus/." "$WORK_CORPUS/"
"$CXX" -std=c++17 -Wall -Wextra -Wpedantic -Werror -O1 -g \
  -fsanitize=fuzzer,address,undefined -fno-omit-frame-pointer \
  "$ROOT/tests/native/fuzz_strict_json.cpp" -o "$BIN"
"$BIN" -runs="$RUNS" -max_len=4096 "$WORK_CORPUS"
