#include "../../src/app/strict_json.hpp"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>

static void exercise(const std::string& s) {
    try { (void)itvip::json::Parser(s).parse(); }
    catch (const std::exception&) { /* rejection is an expected parser outcome */ }
}
int main() {
    const std::vector<std::string> seeds = {
        "null", "true", "false", "0", "-1", "1.25e+8", "[]", "{}",
        R"({"Schema":"ITVIP-USER-EDITION-2","Revision":7})",
        R"({"x":"\\uD83D\\uDE80","a":[1,true,null]})",
        R"({"a":1,"a":2})", "[", "{\"x\":\"\\uD800\"}",
        std::string("\xC0\xAF", 2), std::string(1024, 'x')
    };
    for (const auto& s : seeds) exercise(s);
    std::mt19937_64 rng(0x495456495046555aULL); // stable reproducible seed
    const std::string alphabet = "{}[],:\\\"0123456789-+eE.truefalsnul abc\n\t";
    constexpr std::size_t iterations = 50000;
    for (std::size_t n = 0; n < iterations; ++n) {
        std::string s = seeds[static_cast<std::size_t>(rng() % seeds.size())];
        const unsigned edits = 1u + static_cast<unsigned>(rng() % 12u);
        for (unsigned j = 0; j < edits; ++j) {
            const auto op = rng() % 4u;
            if (op == 0 && !s.empty()) s.erase(static_cast<std::size_t>(rng() % s.size()), 1);
            else if (op == 1 && s.size() < 4096) s.insert(static_cast<std::size_t>(rng() % (s.size()+1)), 1, alphabet[static_cast<std::size_t>(rng()%alphabet.size())]);
            else if (op == 2 && !s.empty()) s[static_cast<std::size_t>(rng()%s.size())] = static_cast<char>(rng() & 0xffu);
            else if (s.size() < 4096) s.append(static_cast<std::size_t>(rng()%8u), static_cast<char>(rng()&0xffu));
        }
        exercise(s);
    }
    std::cout << "strict_json fuzz smoke: " << iterations << " deterministic mutations + " << seeds.size() << " seeds passed\n";
}
