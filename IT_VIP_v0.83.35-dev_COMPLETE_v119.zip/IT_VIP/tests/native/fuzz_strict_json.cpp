#include "../../src/app/strict_json.hpp"
#include <cstddef>
#include <cstdint>
#include <string>

// libFuzzer entry point. Any parser exception is an expected rejection;
// sanitizer findings, hangs, or unexpected process termination are failures.
extern "C" int LLVMFuzzerTestOneInput(const std::uint8_t* data, std::size_t size) {
    if (size > 16u * 1024u * 1024u) return 0;
    try {
        const std::string input(reinterpret_cast<const char*>(data), size);
        (void)itvip::json::Parser(input).parse();
    } catch (const std::exception&) {
        // Invalid JSON is normal fuzz input.
    }
    return 0;
}
