#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BIN="${TMPDIR:-/tmp}/itvip_strict_json_fuzz_smoke"
CXX="${CXX:-g++}"
"$CXX" -std=c++17 -Wall -Wextra -Wpedantic -Werror -O1 -g \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  "$ROOT/tests/native/fuzz_strict_json_smoke.cpp" -o "$BIN"
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 "$BIN"
rm -f "$BIN"
