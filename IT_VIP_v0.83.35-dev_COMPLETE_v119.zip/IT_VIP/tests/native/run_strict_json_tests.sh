#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BIN="${TMPDIR:-/tmp}/itvip_strict_json_tests"
CXX="${CXX:-g++}"
"$CXX" -std=c++17 -Wall -Wextra -Wpedantic -Werror -O2 \
  "$ROOT/tests/native/test_strict_json.cpp" -o "$BIN"
"$BIN"
rm -f "$BIN"
