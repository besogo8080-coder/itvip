from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/app/branded_tool_gui.cpp").read_text(encoding="utf-8")


def test_branded_tool_requests_per_monitor_dpi_awareness():
    assert "void enablePerMonitorDpi()" in SOURCE
    assert "SetProcessDpiAwarenessContext" in SOURCE
    assert "else SetProcessDPIAware()" in SOURCE
    assert "enablePerMonitorDpi();INITCOMMONCONTROLSEX" in SOURCE


def test_branded_tool_reflows_output_panel_on_resize_and_dpi_change():
    assert "void layoutToolOutput(HWND w)" in SOURCE
    assert "case WM_SIZE:layoutToolOutput(w);return 0;" in SOURCE
    assert "case WM_DPICHANGED:" in SOURCE
    assert "SetWindowPos(gOutput" in SOURCE
    assert "SetWindowPos(gProgress" in SOURCE
    assert "SetWindowPos(gInfo" in SOURCE
