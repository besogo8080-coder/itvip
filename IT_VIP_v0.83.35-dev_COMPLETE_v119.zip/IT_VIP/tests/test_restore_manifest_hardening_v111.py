from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKUP = (ROOT / "src/modules/backup_center.cpp").read_text(encoding="utf-8")


def test_manifest_rejects_windows_path_aliases_and_ads_syntax():
    assert "bool safeManifestRelativePath(const std::string&utf8,fs::path&relative,std::wstring&canonicalKey)" in BACKUP
    assert "utf8.find('\\\\')!=std::string::npos" in BACKUP
    assert "c==L':'" in BACKUP
    assert "segment.back()==L'.'||segment.back()==L' '" in BACKUP


def test_manifest_rejects_reserved_windows_device_names():
    for token in ("stem==L\"CON\"", "stem==L\"PRN\"", "stem==L\"AUX\"", "stem==L\"NUL\"", "stem.rfind(L\"COM\",0)==0", "stem.rfind(L\"LPT\",0)==0"):
        assert token in BACKUP


def test_manifest_detects_case_insensitive_duplicate_file_paths():
    assert "std::unordered_set<std::wstring>seenFiles" in BACKUP
    assert "LCMapStringEx(LOCALE_NAME_INVARIANT,LCMAP_LOWERCASE" in BACKUP
    assert "if(!seenFiles.insert(canonicalKey).second)return false;" in BACKUP


def test_manifest_bounds_line_size_and_file_count_and_rejects_duplicate_folder_records():
    assert "if(line.size()>131072||++lineCount>200005)return false;" in BACKUP
    assert "count>=100000" in BACKUP
    assert "std::unordered_set<std::string>seenFolders" in BACKUP
    assert "!seenFolders.insert(folder).second" in BACKUP
    assert "std::find(folders.begin(),folders.end(),std::wstring(folder.begin(),folder.end()))==folders.end()" in BACKUP
