from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_windows_10_entrypoint_discovers_visual_studio_and_builds_both_architectures():
    script = (ROOT / "BUILD_WINDOWS_10.bat").read_text(encoding="utf-8")
    assert "vswhere.exe" in script
    assert "VsDevCmd.bat" in script
    assert "-arch=x64" in script
    assert "-arch=x86" in script
    assert "build.bat msvc" in script
    assert "verify_windows_build.ps1" in script
    assert "Package-WindowsBuild.ps1" in script


def test_runtime_packager_requires_all_34_executables_and_preserves_runtime_layout():
    script = (ROOT / "tools" / "Package-WindowsBuild.ps1").read_text(encoding="utf-8")
    assert "ITVIP.exe" in script
    assert "ITVIPNativeVerify.exe" in script
    assert "ITVIPBootstrap.exe" in script
    assert "ExecutableCount = $expected.Count" in script
    assert "build/$exe" in script
    for directory in ("assets", "config", "deployment", "portable", "docs", "reports"):
        assert f"'{directory}'" in script
    block = re.search(r"\$expected\s*=\s*@\((.*?)\n\)", script, re.S)
    assert block is not None
    assert len(re.findall(r"'[A-Za-z0-9_]+\.exe'", block.group(1))) == 34
    assert "Get-FileHash" in script
    assert "Compress-Archive" in script


def test_windows_10_guide_explains_build_prerequisites_and_output_artifacts():
    guide = (ROOT / "docs" / "BUILD_ON_WINDOWS_10_AR.md").read_text(encoding="utf-8")
    for phrase in ("Desktop development with C++", "IT-VIP-Windows-x64.zip", "IT-VIP-Windows-x86.zip", "Start-ITVIP.cmd"):
        assert phrase in guide
