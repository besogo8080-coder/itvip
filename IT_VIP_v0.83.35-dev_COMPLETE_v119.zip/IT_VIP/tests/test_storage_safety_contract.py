from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COPY = (ROOT / "src/modules/copy_manager.cpp").read_text(encoding="utf-8")
BACKUP = (ROOT / "src/modules/backup_center.cpp").read_text(encoding="utf-8")


def test_copy_cleanup_is_limited_to_a_destination_created_by_this_worker():
    assert "const bool destinationCreated=fs::create_directory(job.destinationRoot,ec);" in COPY
    assert "if(!ok && destinationCreated){std::error_code cleanup;fs::remove_all(job.destinationRoot,cleanup);}" in COPY
    assert "if(fs::exists(job.destinationRoot,ec)){error=L\"يوجد مجلد بنفس الاسم" in COPY


def test_backup_enumeration_fails_closed_instead_of_silently_skipping_files():
    assert "fs::recursive_directory_iterator it(src,fs::directory_options::none,ec),end;" in BACKUP
    assert "if(ec)return fail(L\"حدث خطأ أثناء تعداد الملفات؛ أُلغيت النسخة بدل تخطي ملفات.\");" in BACKUP
    assert "fs::copy_file(item,out,fs::copy_options::none,ec)" in BACKUP
    assert "const bool backupCreated=fs::create_directory(backup,ec);" in BACKUP


def test_failed_backup_is_removed_and_manifest_writes_are_checked():
    assert "auto fail=[&](const wchar_t*message){std::error_code cleanup;fs::remove_all(backup,cleanup);setStatus(message);return false;};" in BACKUP
    assert "if(!mf)return fail(L\"تعذرت كتابة بيانات مجلدات النسخة الاحتياطية.\");" in BACKUP
    assert "if(!manifestOk||!mf)return fail(L\"تعذر إكمال ملف manifest.\");" in BACKUP
    assert "if(count==0)return fail(L\"لم يتم العثور على ملفات" in BACKUP


def test_backup_restore_still_validates_paths_and_sha256_before_writing():
    assert "bool validManifest(const fs::path&backup,std::vector<RestoreFile>&files)" in BACKUP
    assert "if(!inside(target,backup)" in BACKUP
    assert "if(!sha256(target,actual)||actual!=digest)return false;" in BACKUP
    assert "if(!inside(dst,app)||hasReparseComponent(app,dst))" in BACKUP


def test_restore_stages_all_files_and_records_originals_before_commit():
    assert "struct RestoreFile{fs::path relative;std::uintmax_t size{};std::string digest;};" in BACKUP
    assert "// Phase 1: stage every incoming file and snapshot every existing destination." in BACKUP
    assert "fs::copy_file(source,staged,fs::copy_options::none,ec)" in BACKUP
    assert "stagedDigest!=file.digest" in BACKUP
    assert "fs::copy_file(dst,old,fs::copy_options::none,ec)" in BACKUP
    assert "// Phase 2: commit staged files." in BACKUP


def test_restore_uses_replace_commit_and_rolls_back_in_reverse_order():
    assert "MoveFileExW((transaction/L\"new\"/files[i].relative).c_str(),dst.c_str(),flags)" in BACKUP
    assert "for(size_t n=committed;n>0;--n)" in BACKUP
    assert "CopyFileW(old.c_str(),dst.c_str(),FALSE)" in BACKUP
    assert "DeleteFileW(dst.c_str())" in BACKUP
    assert "if(rollbackOk){cleanup();" in BACKUP


def test_restore_rejects_reparse_points_and_preserves_recovery_data_on_rollback_failure():
    assert "bool hasReparseComponent(const fs::path&root,const fs::path&target)" in BACKUP
    assert "FILE_ATTRIBUTE_REPARSE_POINT" in BACKUP
    assert "hasReparseComponent(app,dst)" in BACKUP
    assert "if(rollbackOk){cleanup();" in BACKUP
    assert "احتفظ بمجلد .itvip_restore_txn" in BACKUP


def test_manifest_parser_retains_expected_size_and_digest_for_staging():
    assert "bool validManifest(const fs::path&backup,std::vector<RestoreFile>&files)" in BACKUP
    assert "files.push_back({rp,actualSize,digest});" in BACKUP
    assert "if(!mf.eof()||count==0)return false;" in BACKUP
