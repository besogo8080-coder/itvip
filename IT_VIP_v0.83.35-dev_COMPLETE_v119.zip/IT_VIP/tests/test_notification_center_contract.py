from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")


def test_animated_non_activating_toast_is_registered_and_shown():
    assert 'L"ITVIPToastWindow"' in MAIN
    assert "WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_LAYERED" in MAIN
    assert "SW_SHOWNOACTIVATE" in MAIN
    assert "SetLayeredWindowAttributes" in MAIN
    assert "SetTimer(w,1,30,nullptr)" in MAIN


def test_notifications_are_logged_and_clickable_into_center():
    assert 'L"ui_notifications.log"' in MAIN
    assert "appendNotificationLog(message)" in MAIN
    assert "WM_LBUTTONUP:showNotificationCenter()" in MAIN
    assert 'L"إشعار IT VIP — اضغط لفتح المركز"' in MAIN
    assert 'L"IT VIP NOTIFICATION — CLICK TO OPEN CENTER"' in MAIN


def test_notification_center_supports_search_clear_refresh_and_open_log():
    for token in (
        'L"ITVIPNotificationCenter"',
        "ID_NOTIFY_SEARCH",
        "ID_NOTIFY_LIST",
        "EN_CHANGE",
        "ID_NOTIFY_REFRESH",
        "ID_NOTIFY_CLEAR",
        "ID_NOTIFY_OPEN_LOG",
        "std::ios::trunc",
    ):
        assert token in MAIN


def test_notification_queue_is_bounded_and_drained_after_toast():
    assert "std::deque<std::pair<std::wstring,bool>> toastQueue" in MAIN
    assert "toastQueue.size()<50" in MAIN
    assert "showNextToast()" in MAIN
    assert "SetTimer(mainWnd,77,250,nullptr)" in MAIN
    assert "if(a==77)" in MAIN


def test_notification_log_has_bounded_retention():
    assert "void trimNotificationLog()" in MAIN
    assert "512u*1024u" in MAIN
    assert "lines.size()>1000" in MAIN


def test_notification_center_is_available_from_dashboard_and_vip_studio_has_button_effects():
    assert "ID_NOTIFICATION_CENTER" in MAIN
    assert "showNotificationCenter();return 0;" in MAIN
    assert "EnumChildWindows(customWnd,installDashboardButtonEffects,0)" in MAIN


def test_module_launch_feedback_uses_notification_center():
    assert "showToast(tr(L\"تم تشغيل الوحدة بنجاح.\"" in MAIN
    assert "showToast(tr(L\"الوحدة غير موجودة" in MAIN
    assert "itvip::audio::notification()" in MAIN


def test_per_monitor_dpi_awareness_has_legacy_fallback():
    assert "SetProcessDpiAwarenessContext" in MAIN
    assert "reinterpret_cast<HANDLE>(-4)" in MAIN
    assert "else SetProcessDPIAware()" in MAIN


def test_dashboard_reflows_controls_on_resize_and_scales_layout_for_dpi():
    assert "int dashboardDpi(HWND w)" in MAIN
    assert "void layoutDashboard(HWND w)" in MAIN
    assert "case WM_SIZE:layoutDashboard(w);return 0;" in MAIN
    assert "case WM_GETMINMAXINFO:" in MAIN
    assert "MulDiv(value,dashboardDpi(w),96)" in MAIN
    assert "const int moduleIds[]={ID_API_HUB" in MAIN


def test_standalone_module_exit_status_is_reported_to_notification_center():
    assert "WM_APP_MODULE_EXIT=WM_APP+0x52" in MAIN
    assert "DWORD WINAPI moduleExitWatcher(LPVOID raw)" in MAIN
    assert "WaitForSingleObject(context->process,INFINITE)" in MAIN
    assert "GetExitCodeProcess(context->process,&code)" in MAIN
    assert "PostMessageW(context->owner,WM_APP_MODULE_EXIT" in MAIN
    assert "case WM_APP_MODULE_EXIT:" in MAIN
    assert "CreateThread(nullptr,0,moduleExitWatcher,context,0,nullptr)" in MAIN
