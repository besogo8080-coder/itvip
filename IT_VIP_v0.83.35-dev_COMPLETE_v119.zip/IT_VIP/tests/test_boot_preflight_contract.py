from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / "deployment/BootManager-Preflight.ps1").read_text(encoding="utf-8")
LAUNCHER = (ROOT / "deployment/BootManager-Preflight.cmd").read_text(encoding="utf-8")


class BootPreflightContractTests(unittest.TestCase):
    def test_v3_schema_and_redaction_flag_are_reported(self):
        self.assertIn("ITVIP-BOOT-PREFLIGHT-3", SCRIPT)
        self.assertIn("HardwareIdentifiersRedacted=[bool]$RedactHardwareIdentifiers", SCRIPT)

    def test_redaction_switch_covers_computer_and_disk_identifiers(self):
        self.assertIn("[switch]$RedactHardwareIdentifiers", SCRIPT)
        self.assertIn("ComputerName=(Protect-HardwareIdentifier $env:COMPUTERNAME)", SCRIPT)
        self.assertIn("SerialNumber=(Protect-HardwareIdentifier $d.SerialNumber)", SCRIPT)
        self.assertIn("UniqueId=(Protect-HardwareIdentifier $d.UniqueId)", SCRIPT)
        self.assertIn("return '[REDACTED]'", SCRIPT)

    def test_text_report_discloses_redaction_state(self):
        self.assertIn("Hardware identifiers redacted:", SCRIPT)

    def test_launcher_forwards_user_switches(self):
        self.assertRegex(LAUNCHER, r'BootManager-Preflight\.ps1"\s+%\*')

    def test_preflight_remains_read_only(self):
        destructive = r"(?im)^\s*(Clear-Disk|Format-Volume|Initialize-Disk|New-Partition|Remove-Partition|Set-Disk|Set-Partition)\b"
        self.assertIsNone(re.search(destructive, SCRIPT))
        self.assertIn("DestructiveOperationsPerformed=$false", SCRIPT)


if __name__ == "__main__":
    unittest.main()
