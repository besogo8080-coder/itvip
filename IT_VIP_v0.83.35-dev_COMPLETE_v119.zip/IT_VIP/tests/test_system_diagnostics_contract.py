from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'deployment' / 'System-Diagnostics-ITVIP.ps1'
LAUNCHER = ROOT / 'deployment' / 'System-Diagnostics-ITVIP.cmd'


def test_diagnostics_script_and_launcher_exist():
    assert SCRIPT.is_file()
    assert LAUNCHER.is_file()


def test_sampling_is_bounded():
    text = SCRIPT.read_text(encoding='utf-8')
    assert "[ValidateRange(1,30)][int]$Samples = 5" in text
    assert "[ValidateRange(1,10)][int]$IntervalSeconds = 2" in text
    assert 'for ($i = 1; $i -le $effectiveSamples; $i++)' in text


def test_collects_required_diagnostic_areas():
    text = SCRIPT.read_text(encoding='utf-8')
    for token in (
        'Win32_OperatingSystem', 'Win32_Processor', 'Win32_LogicalDisk',
        'Get-NetAdapter -Physical', 'Get-NetAdapterStatistics',
        'MSAcpi_ThermalZoneTemperature', 'CpuLoadPercent',
        'MemoryUsedPercent', 'ThermalZones',
    ):
        assert token in text


def test_exports_multiple_report_formats():
    text = SCRIPT.read_text(encoding='utf-8')
    for token in ('ConvertTo-Json', 'Set-Content', 'ConvertTo-Html', 'Export-Csv'):
        assert token in text
    assert 'itvip_system_diagnostics_' in text


def test_read_only_boundary_and_limitations_are_explicit():
    text = SCRIPT.read_text(encoding='utf-8')
    assert 'ReadOnly=$true' in text
    assert 'No settings, services, processes, drivers, disks, or network configuration were changed.' in text
    assert 'not internet throughput or a speed test' in text


def test_launcher_forwards_parameters():
    text = LAUNCHER.read_text(encoding='utf-8')
    assert 'System-Diagnostics-ITVIP.ps1' in text
    assert '%*' in text


def test_alert_thresholds_are_bounded_and_configurable():
    text = SCRIPT.read_text(encoding='utf-8')
    assert "[ValidateRange(1,100)][int]$CpuAlertPercent = 85" in text
    assert "[ValidateRange(1,100)][int]$MemoryAlertPercent = 90" in text
    assert "[ValidateRange(1,50)][int]$DiskFreeAlertPercent = 10" in text
    assert 'AlertThresholds=' in text and 'Alerts=@($alerts)' in text


def test_threshold_alerts_cover_cpu_memory_and_disk_free_space():
    text = SCRIPT.read_text(encoding='utf-8')
    assert '$cpuLoad -ge $CpuAlertPercent' in text
    assert '$usedMemoryPercent -ge $MemoryAlertPercent' in text
    assert '$freePercent -le $DiskFreeAlertPercent' in text


def test_history_is_persisted_and_bounded():
    text = SCRIPT.read_text(encoding='utf-8')
    assert "'system_diagnostics_history.csv'" in text
    assert 'Export-Csv' in text and 'Import-Csv' in text
    assert '$allHistory.Count -gt 1000' in text


def test_html_report_has_status_styling_and_alert_summary():
    text = SCRIPT.read_text(encoding='utf-8')
    assert '$alertHtml' in text and '$style' in text
    assert 'ConvertTo-Html' in text and 'No alert thresholds crossed.' in text


def test_live_monitoring_is_bounded_and_optional():
    text = SCRIPT.read_text(encoding='utf-8')
    assert '[switch]$LiveMonitoring' in text
    assert '[ValidateRange(1,60)][int]$DurationMinutes = 5' in text
    assert '$effectiveSamples = [math]::Min(3601' in text
    assert 'for ($i = 1; $i -le $effectiveSamples; $i++)' in text
    assert 'LIVE {0}/{1}' in text


def test_network_throughput_uses_counter_deltas():
    text = SCRIPT.read_text(encoding='utf-8')
    assert 'Get-NetAdapterStatistics -Name $adapter.Name' in text
    assert '$rx - $prior.Rx' in text and '$tx - $prior.Tx' in text
    assert 'NetworkReceiveBytesPerSec' in text
    assert 'NetworkSendBytesPerSec' in text


def test_live_mode_remains_read_only_and_reported():
    text = SCRIPT.read_text(encoding='utf-8')
    assert 'LiveMonitoring=[bool]$LiveMonitoring' in text
    assert 'ReadOnly=$true' in text
    assert 'No settings, services, processes, drivers, disks, or network configuration were changed.' in text
