from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")


def test_completed_processes_are_recorded_with_timestamp_module_and_exit_code():
    assert "void appendToolExecutionHistory(const std::wstring& module,DWORD exitCode,DWORD pid,ULONGLONG durationMs)" in MAIN
    assert 'L"tool_execution_history.tsv"' in MAIN
    assert "appendToolExecutionHistory(context->module,code,context->pid,GetTickCount64()-context->started)" in MAIN
    assert "<<L'\\t'<<durationMs<<L'\\t'<<pid" in MAIN
    assert 'L"SUCCESS"' in MAIN
    assert 'L"NONZERO_EXIT"' in MAIN
    assert "void trimToolExecutionHistory()" in MAIN
    assert "lines.size()>2000" in MAIN
    assert "512u*1024u" in MAIN
    assert "std::lock_guard<std::mutex> guard(historyMutex)" in MAIN


def test_all_powershell_command_launchers_propagate_exit_codes():
    wrappers = [
        "Diagnostics-ITVIP.cmd", "EventLogs-ITVIP.cmd", "FirewallPrivacy-ITVIP.cmd",
        "Hardware-ITVIP.cmd", "Network-ITVIP.cmd", "Performance-ITVIP.cmd",
        "Repair-ITVIP.cmd", "Software-ITVIP.cmd", "System-Diagnostics-ITVIP.cmd",
        "Update-ITVIP.cmd", "WindowsUpdate-ITVIP.cmd", "Optimize-ITVIP.cmd",
        "Startup-ITVIP.cmd", "BootManager-Preflight.cmd",
    ]
    for name in wrappers:
        text = (ROOT / "deployment" / name).read_text(encoding="utf-8").lower()
        assert "powershell.exe" in text, name
        assert "errorlevel" in text, name
        assert "exit /b" in text, name
