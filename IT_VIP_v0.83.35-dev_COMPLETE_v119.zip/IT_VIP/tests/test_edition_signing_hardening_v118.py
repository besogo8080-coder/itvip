from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_signer_requires_existing_non_reparse_edition_root():
    source = (ROOT / "deployment/Sign-ITVIPUserEdition.ps1").read_text(encoding="utf-8")
    assert "Test-Path -LiteralPath $edition -PathType Container" in source
    assert "[IO.FileAttributes]::ReparsePoint" in source
    assert "Edition root must not be a reparse point" in source


def test_signer_rejects_reparse_points_and_unsafe_or_duplicate_windows_paths():
    source = (ROOT / "deployment/Sign-ITVIPUserEdition.ps1").read_text(encoding="utf-8")
    assert "Get-ChildItem -LiteralPath $edition -Recurse -Force" in source
    assert "Reparse points are not allowed in a signed edition" in source
    assert "$file.FullName.Equals((Join-Path $edition 'EDITION_SIGNATURE.sha256rsa'),[StringComparison]::OrdinalIgnoreCase)" in source
    assert "[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)" in source
    assert "Unsafe signed inventory path" in source
    assert "Windows-reserved inventory path" in source
    assert "Duplicate case-insensitive inventory path" in source
    assert "Refusing to sign an edition with an empty file inventory" in source


def test_signer_enforces_rsa3072_and_private_public_key_pair_match():
    source = (ROOT / "deployment/Sign-ITVIPUserEdition.ps1").read_text(encoding="utf-8")
    assert "$rsa.KeySize -ne 3072 -or $publicRsa.KeySize -ne 3072" in source
    assert "$rsa.ExportParameters($false)" in source
    assert "$publicRsa.ExportParameters($false)" in source
    assert "Private key does not match the supplied authority public key" in source
    assert "RSA-3072-SHA256" in source


def test_native_verifier_remains_the_required_runtime_gate_for_signed_editions():
    builder = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8")
    signer = (ROOT / "deployment/Sign-ITVIPUserEdition.ps1").read_text(encoding="utf-8")
    assert "ITVIPNativeVerify.exe" in builder
    assert "EDITION_SIGNATURE.sha256rsa" in signer
    assert "EDITION_REVOCATIONS.sha256rsa" in signer
