from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src" / "modules" / "system_monitor_gui.cpp"
MAIN = ROOT / "src" / "app" / "main.cpp"
BUILD = ROOT / "build.bat"
VERIFY = ROOT / "tools" / "verify_windows_build.ps1"


def test_native_monitor_collects_read_only_counters():
    text = SOURCE.read_text(encoding="utf-8")
    for token in ("GetSystemTimes", "GlobalMemoryStatusEx", "GetIfTable2", "GetDiskFreeSpaceExW"):
        assert token in text
    assert "TerminateProcess" not in text


def test_live_dashboard_controls_and_bounded_history_exist():
    text = SOURCE.read_text(encoding="utf-8")
    for token in ("ID_START", "ID_PAUSE", "ID_STOP", "gPaused", "gDuration*60", "gHistory.size()>90", "drawGraph"):
        assert token in text


def test_samples_are_saved_to_local_csv():
    text = SOURCE.read_text(encoding="utf-8")
    assert "system_monitor_live.csv" in text
    assert "timestamp,cpu_percent,ram_percent" in text


def test_dashboard_launches_monitor_in_both_languages():
    text = MAIN.read_text(encoding="utf-8")
    assert "ID_SYSTEM_MONITOR" in text
    assert "مراقبة النظام المباشرة" in text
    assert "Live System Monitor" in text
    assert 'launch(L"system_monitor_gui.exe")' in text


def test_monitor_is_built_and_verified_for_both_toolchains():
    build = BUILD.read_text(encoding="utf-8")
    verify = VERIFY.read_text(encoding="utf-8")
    assert ":build_system_monitor_msvc" in build and "call :build_system_monitor_msvc" in build
    assert ":build_system_monitor_mingw" in build and "call :build_system_monitor_mingw" in build
    assert "system_monitor_gui.exe" in verify


def test_owner_permissions_and_package_builders_include_monitor_capability():
    owner = (ROOT / "src" / "modules" / "permissions_center.cpp").read_text(encoding="utf-8")
    edition = (ROOT / "deployment" / "Build-UserEdition.ps1").read_text(encoding="utf-8")
    deploy = (ROOT / "deployment" / "Deploy-ITVIP.ps1").read_text(encoding="utf-8")
    assert '{L"system_monitor",L"مراقبة النظام المباشرة",L"Live System Monitor"}' in owner
    assert "system_monitor=@{Exe='system_monitor_gui.exe'}" in edition
    assert "system_monitor_gui.exe" in deploy
