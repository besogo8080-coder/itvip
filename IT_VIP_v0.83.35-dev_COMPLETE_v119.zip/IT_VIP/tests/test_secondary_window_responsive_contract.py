from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "src/app/branded_tool_gui.cpp").read_text(encoding="utf-8")


def test_branded_tool_reflows_all_primary_controls():
    assert "void layoutToolOutput(HWND w)" in SOURCE
    assert "GetDlgItem(w,120)" in SOURCE  # path label
    assert "GetDlgItem(w,121)" in SOURCE  # local account label
    assert "GetDlgItem(w,122)" in SOURCE  # subtitle
    assert "GetDlgItem(w,20)" in SOURCE   # path edit
    assert "GetDlgItem(w,21)" in SOURCE   # browse button
    assert "GetDlgItem(w,10)" in SOURCE   # primary action
    assert "GetDlgItem(w,11)" in SOURCE   # secondary action
    assert "SetWindowPos(gStop" in SOURCE
    assert "SetWindowPos(gOutput" in SOURCE


def test_secondary_action_wraps_when_window_is_narrow():
    assert "firstRight+gap+secondWidth<=clientWidth-margin" in SOURCE
    assert "secondY=actionY+rowHeight+scale96(10)" in SOURCE


def test_secondary_tool_has_minimum_size_and_dpi_relayout():
    assert "case WM_GETMINMAXINFO:" in SOURCE
    assert "limits->ptMinTrackSize.x=scale96(440)" in SOURCE
    assert "limits->ptMinTrackSize.y=scale96(560)" in SOURCE
    assert "case WM_SIZE:layoutToolOutput(w);return 0;" in SOURCE
    assert "case WM_DPICHANGED:" in SOURCE
    assert "layoutToolOutput(w);return 0;}case WM_COMMAND" in SOURCE
