from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKUP = (ROOT / "src/modules/backup_center.cpp").read_text(encoding="utf-8")


def test_restore_journal_is_durable_and_atomically_replaced():
    assert "bool writeRestoreJournal(" in BACKUP
    assert "FILE_FLAG_WRITE_THROUGH" in BACKUP
    assert "FlushFileBuffers(h)" in BACKUP
    assert "MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH" in BACKUP
    assert "ITVIP_RESTORE_JOURNAL_V1" in BACKUP


def test_journal_records_restore_boundaries_and_item_paths():
    for phase in ("PREPARED", "APPLYING", "APPLIED", "ROLLING_BACK", "COMMITTED"):
        assert f'L"{phase}"' in BACKUP
    assert 'content<<"ITEM\\t"' in BACKUP
    assert '\\nINDEX\\t' in BACKUP


def test_next_launch_detects_pending_transactions_without_auto_deleting_them():
    assert "findPendingRestoreTransactions" in BACKUP
    assert 'name.rfind(L".itvip_restore_txn_",0)!=0' in BACKUP
    assert 'it->path()/L"restore.journal"' in BACKUP
    assert "notifyPendingRestoreTransactions(appRoot())" in BACKUP
    assert "لا تحذف مجلدات .itvip_restore_txn" in BACKUP
    assert "fs::remove_all" not in BACKUP[BACKUP.index("void notifyPendingRestoreTransactions"):BACKUP.index("bool hasReparseComponent")]


def test_commit_is_journaled_before_move_and_after_move():
    before_move = BACKUP.index('writeRestoreJournal(transaction,states,L"APPLYING",i+1)')
    move = BACKUP.index("MoveFileExW((transaction/L\"new\"/files[i].relative).c_str(),dst.c_str(),flags)")
    after_move = BACKUP.index('writeRestoreJournal(transaction,states,L"APPLIED",committed)')
    assert before_move < move < after_move


def test_rollback_stops_if_a_recovery_checkpoint_cannot_be_persisted():
    rollback = BACKUP[BACKUP.index('writeRestoreJournal(transaction,states,L"ROLLING_BACK",committed)'):BACKUP.index('if(rollbackOk){cleanup();')]
    assert "if(!stepOk){rollbackOk=false;break;}" in rollback
    assert 'if(!writeRestoreJournal(transaction,states,L"ROLLING_BACK",n-1)){rollbackOk=false;break;}' in rollback
