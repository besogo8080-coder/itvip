"""Deterministic filesystem model for restore crash-boundary analysis.

This is deliberately a test model, not a Windows filesystem or power-loss test.
It mirrors the journal/replace ordering in backup_center.cpp and verifies what
must remain available for operator inspection at each abrupt-stop boundary.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil

PHASES = {"PREPARED", "APPLYING", "APPLIED", "ROLLING_BACK", "COMMITTED"}


class SimulatedCrash(RuntimeError):
    pass


def _write_journal(txn: Path, phase: str, index: int, items: list[tuple[str, bool]]) -> None:
    payload = {
        "format": "ITVIP_RESTORE_FAULT_MODEL_V1",
        "phase": phase,
        "index": index,
        "items": [{"path": path, "existed": existed} for path, existed in items],
    }
    tmp = txn / "restore.journal.tmp"
    tmp.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
    os.replace(tmp, txn / "restore.journal")


def _snapshot(root: Path, names: list[str]) -> dict[str, str | None]:
    result = {}
    for name in names:
        path = root / name
        result[name] = path.read_text(encoding="utf-8") if path.exists() else None
    return result


def _run_model(root: Path, failpoint: str | None = None) -> Path:
    names = ["config/a.ini", "data/b.dat", "reports/c.txt"]
    txn = root / ".itvip_restore_txn_fault_model"
    (txn / "new").mkdir(parents=True)
    (txn / "old").mkdir()
    items: list[tuple[str, bool]] = []

    # Stage all incoming files and preserve every pre-existing destination.
    for i, name in enumerate(names):
        dst = root / name
        incoming = txn / "new" / name
        incoming.parent.mkdir(parents=True, exist_ok=True)
        incoming.write_text(f"new-{i}", encoding="utf-8")
        existed = dst.exists()
        if existed:
            old = txn / "old" / name
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, old)
        items.append((name, existed))

    _write_journal(txn, "PREPARED", 0, items)
    if failpoint == "after_prepared":
        raise SimulatedCrash(failpoint)

    committed = 0
    for i, (name, existed) in enumerate(items):
        _write_journal(txn, "APPLYING", i + 1, items)
        if failpoint == f"after_applying_{i}":
            raise SimulatedCrash(failpoint)
        dst = root / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        os.replace(txn / "new" / name, dst)
        committed += 1
        if failpoint == f"after_move_{i}_before_applied":
            raise SimulatedCrash(failpoint)
        _write_journal(txn, "APPLIED", committed, items)
        if failpoint == f"after_applied_{i}":
            raise SimulatedCrash(failpoint)

    if failpoint == "before_committed":
        raise SimulatedCrash(failpoint)
    _write_journal(txn, "COMMITTED", committed, items)
    if failpoint == "after_committed_before_cleanup":
        raise SimulatedCrash(failpoint)
    shutil.rmtree(txn)
    return txn


def _assert_recovery_evidence(root: Path, txn: Path) -> None:
    assert txn.is_dir()
    journal = json.loads((txn / "restore.journal").read_text(encoding="utf-8"))
    assert journal["format"] == "ITVIP_RESTORE_FAULT_MODEL_V1"
    assert journal["phase"] in PHASES
    assert 0 <= journal["index"] <= len(journal["items"])
    # Every old file that existed before the transaction remains available.
    for item in journal["items"]:
        if item["existed"]:
            assert (txn / "old" / item["path"]).is_file()
        # An item not yet moved must still have its staged copy. A moved item
        # can be identified by the absence of its staged file and presence of dst.
        staged = txn / "new" / item["path"]
        destination = root / item["path"]
        assert staged.is_file() or destination.is_file()


def test_crash_at_each_commit_boundary_retains_inspectable_evidence(tmp_path: Path):
    failpoints = [
        "after_prepared",
        "after_applying_0", "after_move_0_before_applied", "after_applied_0",
        "after_applying_1", "after_move_1_before_applied", "after_applied_1",
        "after_applying_2", "after_move_2_before_applied", "after_applied_2",
        "before_committed", "after_committed_before_cleanup",
    ]
    for point in failpoints:
        case = tmp_path / point
        case.mkdir()
        (case / "config").mkdir()
        (case / "data").mkdir()
        (case / "reports").mkdir()
        (case / "config/a.ini").write_text("old-a", encoding="utf-8")
        (case / "data/b.dat").write_text("old-b", encoding="utf-8")
        # reports/c.txt intentionally did not exist before restore.
        txn = case / ".itvip_restore_txn_fault_model"
        try:
            _run_model(case, point)
        except SimulatedCrash:
            _assert_recovery_evidence(case, txn)
        else:
            raise AssertionError(f"failpoint was not reached: {point}")


def test_crash_after_move_before_applied_keeps_old_snapshot_and_new_target(tmp_path: Path):
    root = tmp_path
    (root / "config").mkdir()
    (root / "data").mkdir()
    (root / "reports").mkdir()
    (root / "config/a.ini").write_text("original", encoding="utf-8")
    txn = root / ".itvip_restore_txn_fault_model"
    try:
        _run_model(root, "after_move_0_before_applied")
    except SimulatedCrash:
        pass
    else:
        raise AssertionError("expected simulated abrupt stop")
    assert (txn / "old/config/a.ini").read_text(encoding="utf-8") == "original"
    assert (root / "config/a.ini").read_text(encoding="utf-8") == "new-0"
    journal = json.loads((txn / "restore.journal").read_text(encoding="utf-8"))
    assert journal["phase"] == "APPLYING" and journal["index"] == 1


def test_completed_transaction_is_journaled_before_cleanup(tmp_path: Path):
    root = tmp_path
    for folder in ("config", "data", "reports"):
        (root / folder).mkdir()
    txn = root / ".itvip_restore_txn_fault_model"
    try:
        _run_model(root, "after_committed_before_cleanup")
    except SimulatedCrash:
        pass
    else:
        raise AssertionError("expected simulated abrupt stop")
    journal = json.loads((txn / "restore.journal").read_text(encoding="utf-8"))
    assert journal["phase"] == "COMMITTED"
    assert journal["index"] == 3


def test_production_code_has_no_environment_controlled_fault_injection_switch():
    source = (Path(__file__).resolve().parents[1] / "src/modules/backup_center.cpp").read_text(encoding="utf-8")
    assert "ITVIP_RESTORE_FAILPOINT" not in source
    assert "getenv(" not in source


def test_model_covers_all_production_journal_boundaries_and_is_not_runtime_hooked():
    root = Path(__file__).resolve().parents[1]
    source = (root / "src/modules/backup_center.cpp").read_text(encoding="utf-8")
    for phase in ("PREPARED", "APPLYING", "APPLIED", "ROLLING_BACK", "COMMITTED"):
        assert f'L"{phase}"' in source
    assert source.index('writeRestoreJournal(transaction,states,L"APPLYING",i+1)') < source.index(
        'MoveFileExW((transaction/L"new"/files[i].relative).c_str(),dst.c_str(),flags)'
    )
    assert source.index('MoveFileExW((transaction/L"new"/files[i].relative).c_str(),dst.c_str(),flags)') < source.index(
        'writeRestoreJournal(transaction,states,L"APPLIED",committed)'
    )
    assert "ITVIP_RESTORE_FAILPOINT" not in source


def test_portable_ci_runs_fault_model_once_and_inspector_step_is_not_duplicated():
    workflow = (Path(__file__).resolve().parents[1] / ".github/workflows/windows-build.yml").read_text(encoding="utf-8")
    assert "Restore crash-boundary protocol model" in workflow
    assert workflow.count("run: ./tests/windows/Test-RestoreRecoveryInspector.ps1") == 1
