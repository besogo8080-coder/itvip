import importlib.util, json, tempfile, unittest, threading, urllib.request, urllib.error, uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('license_authority',ROOT/'server'/'license_authority.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

class AuthorityStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.store=mod.Store(Path(self.tmp.name)/'authority.db')
        self.eid='123e4567-e89b-42d3-a456-426614174000'
    def tearDown(self): self.tmp.cleanup()
    def test_revoke_snapshot_and_idempotency(self):
        self.assertTrue(self.store.revoke(self.eid,'chargeback'))
        self.assertFalse(self.store.revoke(self.eid,'duplicate'))
        self.assertEqual(self.store.snapshot()['RevokedEditionIds'],[self.eid])
        self.assertEqual(self.store.snapshot()['Revision'],1)
        self.assertEqual(len(self.store.audit_rows()),1)
        self.assertEqual(self.store.audit_rows()[0]['revision'],1)
    def test_restore_records_audit(self):
        self.store.revoke(self.eid,'test'); self.assertTrue(self.store.restore(self.eid,'appeal approved'))
        self.assertEqual(self.store.snapshot()['RevokedEditionIds'],[])
        self.assertEqual(self.store.snapshot()['Revision'],2)
        rows=list(reversed(self.store.audit_rows()))
        self.assertEqual([x['event'] for x in rows],['REVOKE','RESTORE'])
        self.assertEqual([x['revision'] for x in rows],[1,2])
    def test_revision_changes_only_when_state_changes(self):
        self.assertEqual(self.store.snapshot()['Revision'],0)
        self.assertTrue(self.store.revoke(self.eid,'first'))
        self.assertFalse(self.store.revoke(self.eid,'duplicate'))
        self.assertEqual(self.store.snapshot()['Revision'],1)
        self.assertTrue(self.store.restore(self.eid,'restore'))
        self.assertFalse(self.store.restore(self.eid,'duplicate restore'))
        self.assertEqual(self.store.snapshot()['Revision'],2)

    def test_reject_invalid_uuid_and_empty_reason(self):
        with self.assertRaises(ValueError): self.store.revoke('../bad','x')
        with self.assertRaises(ValueError): self.store.revoke(self.eid,'  ')

    def test_audit_hash_chain_valid_and_detects_tampering(self):
        self.store.revoke(self.eid,'initial')
        self.store.restore(self.eid,'approved')
        result=self.store.verify_audit()
        self.assertTrue(result['valid']); self.assertEqual(result['checked'],2)
        with self.store.connect() as db:
            db.execute("UPDATE audit SET reason='tampered' WHERE id=1")
        result=self.store.verify_audit()
        self.assertFalse(result['valid']); self.assertEqual(result['first_bad_id'],1)

    def test_audit_chain_migration_backfills_legacy_rows(self):
        with self.store.connect() as db:
            db.execute("INSERT INTO audit(event,edition_id,reason,occurred_utc,actor,revision) VALUES('LEGACY',?,?,?,'migration',0)",
                       (self.eid,'legacy row',mod.utc_now()))
            db.execute("UPDATE audit SET prev_hash='',audit_hash='' WHERE event='LEGACY'")
        migrated=mod.Store(self.store.path)
        self.assertTrue(migrated.verify_audit()['valid'])

    def test_concurrent_writers_keep_revision_and_audit_chain_serialized(self):
        ids=[str(uuid.uuid4()) for _ in range(24)]
        with ThreadPoolExecutor(max_workers=12) as pool:
            results=list(pool.map(lambda eid: self.store.revoke(eid, 'concurrent test'), ids))
        self.assertTrue(all(results))
        snapshot=self.store.snapshot()
        self.assertEqual(snapshot['Revision'],len(ids))
        integrity=self.store.verify_audit()
        self.assertTrue(integrity['valid'], integrity)
        rows=list(reversed(self.store.audit_rows()))
        self.assertEqual([row['revision'] for row in rows],list(range(1,len(ids)+1)))


class AuthorityHttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.httpd=ThreadingHTTPServer(('127.0.0.1',0),mod.Handler)
        self.httpd.store=mod.Store(Path(self.tmp.name)/'http.db')
        self.httpd.admin_token='A'*40
        self.httpd.read_token='R'*40
        self.httpd.admin_actor='configured-license-admin'
        self.thread=threading.Thread(target=self.httpd.serve_forever,daemon=True); self.thread.start()
        self.base=f'http://127.0.0.1:{self.httpd.server_port}'
    def tearDown(self):
        self.httpd.shutdown(); self.httpd.server_close(); self.thread.join(timeout=2); self.tmp.cleanup()
    def request(self, path, token=None, method='GET', body=None, actor=None):
        headers={}
        if token: headers['Authorization']='Bearer '+token
        if body is not None: headers['Content-Type']='application/json'
        if actor: headers['X-ITVIP-Actor']=actor
        data=json.dumps(body).encode() if body is not None else None
        req=urllib.request.Request(self.base+path,data=data,headers=headers,method=method)
        try:
            with urllib.request.urlopen(req,timeout=3) as response: return response.status,json.loads(response.read())
        except urllib.error.HTTPError as exc: return exc.code,json.loads(exc.read())
    def test_read_token_cannot_mutate_and_admin_can(self):
        eid='123e4567-e89b-42d3-a456-426614174000'
        status,_=self.request('/v1/revoke',self.httpd.read_token,'POST',{'EditionId':eid,'Reason':'test'})
        self.assertEqual(status,401)
        status,payload=self.request('/v1/revoke',self.httpd.admin_token,'POST',{'EditionId':eid,'Reason':'test'},'owner@example.test')
        self.assertEqual(status,200); self.assertTrue(payload['changed'])
        self.assertEqual(self.httpd.store.audit_rows()[0]['actor'],'configured-license-admin')
    def test_read_token_can_fetch_snapshot(self):
        status,payload=self.request('/v1/revocations',self.httpd.read_token)
        self.assertEqual(status,200); self.assertEqual(payload['Revision'],0)
    def test_caller_cannot_spoof_audit_actor_header(self):
        eid='123e4567-e89b-42d3-a456-426614174000'
        status,payload=self.request('/v1/revoke',self.httpd.admin_token,'POST',
                                    {'EditionId':eid,'Reason':'actor spoof test'},'ceo@example.test')
        self.assertEqual(status,200)
        self.assertEqual(self.httpd.store.audit_rows()[0]['actor'],'configured-license-admin')
        self.assertNotEqual(self.httpd.store.audit_rows()[0]['actor'],'ceo@example.test')

    def test_unauthenticated_health_only(self):
        status,payload=self.request('/health')
        self.assertEqual(status,200); self.assertEqual(payload['status'],'ok')
        status,_=self.request('/v1/audit')
        self.assertEqual(status,401)

    def test_authenticated_audit_integrity_endpoint(self):
        status,payload=self.request('/v1/audit/verify',self.httpd.read_token)
        self.assertEqual(status,200); self.assertTrue(payload['valid'])

    def test_audit_export_returns_complete_history_beyond_recent_view(self):
        for _ in range(505):
            self.httpd.store.revoke(str(uuid.uuid4()), 'export coverage')
        # The interactive recent-events endpoint is intentionally bounded to 500.
        self.assertEqual(len(self.httpd.store.audit_rows()), 500)
        status,payload=self.request('/v1/audit/export',self.httpd.read_token)
        self.assertEqual(status,200)
        self.assertEqual(payload['Schema'],'ITVIP-AUDIT-EXPORT-1')
        self.assertEqual(len(payload['Events']),505)
        self.assertTrue(payload['Integrity']['valid'])
        self.assertEqual(payload['Integrity']['checked'],505)

    def test_audit_export_reports_tampering_instead_of_claiming_validity(self):
        self.httpd.store.revoke('123e4567-e89b-42d3-a456-426614174000','export tamper')
        with self.httpd.store.connect() as db:
            db.execute("UPDATE audit SET reason='changed' WHERE id=1")
        status,payload=self.request('/v1/audit/export',self.httpd.read_token)
        self.assertEqual(status,200)
        self.assertFalse(payload['Integrity']['valid'])
        self.assertEqual(payload['Integrity']['first_bad_id'],1)

    def raw_post(self, body, content_type='application/json'):
        headers={'Content-Type':content_type,'Authorization':'Bearer '+self.httpd.admin_token}
        req=urllib.request.Request(self.base+'/v1/revoke',data=body,headers=headers,method='POST')
        try:
            with urllib.request.urlopen(req,timeout=3) as response: return response.status,json.loads(response.read())
        except urllib.error.HTTPError as exc: return exc.code,json.loads(exc.read())

    def test_reject_duplicate_json_properties(self):
        raw=b'{"EditionId":"123e4567-e89b-42d3-a456-426614174000","EditionId":"123e4567-e89b-42d3-a456-426614174001","Reason":"test"}'
        status,payload=self.raw_post(raw)
        self.assertEqual(status,400)
        self.assertIn('Duplicate JSON property',payload['error'])

    def test_reject_non_json_content_type(self):
        status,payload=self.raw_post(b'{"EditionId":"123e4567-e89b-42d3-a456-426614174000","Reason":"test"}', 'text/plain')
        self.assertEqual(status,400)
        self.assertIn('Content-Type',payload['error'])

    def test_reject_nonstandard_json_constants(self):
        status,payload=self.raw_post(b'{"EditionId":NaN,"Reason":"test"}')
        self.assertEqual(status,400)
        self.assertIn('Invalid JSON constant',payload['error'])

if __name__=='__main__': unittest.main()
