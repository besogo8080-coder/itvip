[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Join-Path ([IO.Path]::GetTempPath()) ('itvip-recovery-inspector-' + [guid]::NewGuid().ToString('N'))
$app = Join-Path $root 'app'
$txn = Join-Path $app '.itvip_restore_txn_fixture'
$tool = Join-Path (Split-Path -Parent $PSScriptRoot) 'tools/Inspect-RestoreRecovery.ps1'
try {
    New-Item -ItemType Directory -Path (Join-Path $app 'config') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $txn 'old/config') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $txn 'new/config') -Force | Out-Null
    [IO.File]::WriteAllText((Join-Path $app 'config/settings.json'), 'current')
    [IO.File]::WriteAllText((Join-Path $txn 'old/config/settings.json'), 'old')
    [IO.File]::WriteAllText((Join-Path $txn 'new/config/settings.json'), 'new')
    $hex = -join ([Text.Encoding]::UTF8.GetBytes('config/settings.json') | ForEach-Object { $_.ToString('X2') })
    $journal = @('ITVIP_RESTORE_JOURNAL_V1', "PHASE`tAPPLYING", "INDEX`t1", "ITEM`t$hex`t1")
    [IO.File]::WriteAllLines((Join-Path $txn 'restore.journal'), $journal, [Text.UTF8Encoding]::new($false))

    $output = & $tool -TransactionPath $txn -AppRoot $app -AsJson
    if ($LASTEXITCODE -ne 0) { throw 'Inspector rejected a valid fixture journal.' }
    $report = ($output -join "`n") | ConvertFrom-Json
    if ($report.Phase -ne 'APPLYING' -or $report.ItemCount -ne 1 -or -not $report.InspectionOnly) { throw 'Inspector report metadata is incorrect.' }
    if (-not $report.Items[0].TargetPresent -or -not $report.Items[0].OriginalSnapshotPresent -or -not $report.Items[0].StagedNewFilePresent) { throw 'Inspector did not report fixture files correctly.' }

    [IO.File]::WriteAllText((Join-Path $txn 'restore.journal'), "ITVIP_RESTORE_JOURNAL_V1`nPHASE`tUNKNOWN`nINDEX`t0`n")
    $null = & $tool -TransactionPath $txn -AppRoot $app -AsJson 2>$null
    if ($LASTEXITCODE -ne 2) { throw 'Inspector did not reject an invalid phase.' }
    Write-Output 'Restore recovery inspector fixture: PASS'
}
finally {
    if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force }
}
