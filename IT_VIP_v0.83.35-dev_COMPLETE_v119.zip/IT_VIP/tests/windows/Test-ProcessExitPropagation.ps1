[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string]$PowerShellExe
)

$ErrorActionPreference = 'Stop'
$comspec = Join-Path $env:SystemRoot 'System32\cmd.exe'
if (-not (Test-Path -LiteralPath $comspec -PathType Leaf)) {
    throw "cmd.exe was not found at $comspec"
}

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('IT VIP Process Exit Test ' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

function Invoke-CmdFixture {
    param(
        [Parameter(Mandatory = $true)][string]$CmdPath,
        [Parameter(Mandatory = $true)][string]$ShellPath,
        [Parameter(Mandatory = $true)][string]$ScriptPath
    )

    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = $comspec
    $start.Arguments = '/d /c call "' + $CmdPath + '"'
    $start.WorkingDirectory = Split-Path -Parent $CmdPath
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.EnvironmentVariables['ITVIP_TEST_POWERSHELL'] = $ShellPath
    $start.EnvironmentVariables['ITVIP_TEST_SCRIPT'] = $ScriptPath

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    if (-not $process.Start()) { throw 'Could not start cmd.exe fixture.' }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    $process.WaitForExit()
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    return [pscustomobject]@{
        ExitCode = $process.ExitCode
        StdOut = $stdout
        StdErr = $stderr
    }
}

try {
    $fixtureScript = Join-Path $tempRoot 'fixture.ps1'
    $fixtureCmd = Join-Path $tempRoot 'wrapper.cmd'

    # Mirrors the deployment launchers: capture ERRORLEVEL immediately, then
    # return it after ENDLOCAL so the dashboard's process watcher sees it.
    @'
@echo off
setlocal EnableExtensions
"%ITVIP_TEST_POWERSHELL%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%ITVIP_TEST_SCRIPT%"
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
'@ | Set-Content -LiteralPath $fixtureCmd -Encoding ASCII

    foreach ($expected in @(0, 23)) {
        "exit [int]$env:ITVIP_TEST_EXIT" | Set-Content -LiteralPath $fixtureScript -Encoding UTF8
        $env:ITVIP_TEST_EXIT = [string]$expected
        $result = Invoke-CmdFixture -CmdPath $fixtureCmd -ShellPath $PowerShellExe -ScriptPath $fixtureScript
        if ($result.ExitCode -ne $expected) {
            throw "Exit propagation failed for expected code $expected; got $($result.ExitCode). stdout=$($result.StdOut) stderr=$($result.StdErr)"
        }
        Write-Host "PASS: CMD propagated PowerShell exit code $expected"
    }

    Write-Host "PASS: process exit propagation verified with $PowerShellExe"
}
finally {
    Remove-Item Env:ITVIP_TEST_EXIT -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
