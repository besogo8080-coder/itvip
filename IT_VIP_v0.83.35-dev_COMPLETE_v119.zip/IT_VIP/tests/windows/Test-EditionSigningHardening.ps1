[CmdletBinding()]
param([string]$PowerShellExe='powershell.exe')
$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$signer=Join-Path $root 'deployment/Sign-ITVIPUserEdition.ps1'
if(-not (Test-Path -LiteralPath $signer -PathType Leaf)){throw 'Edition signer is missing.'}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('ITVIP-Signing-v118-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp | Out-Null
function New-TestEdition([string]$Name,[string]$PublicXml,[string]$PrivateXml){
 $edition=Join-Path $temp $Name
 New-Item -ItemType Directory -Path (Join-Path $edition 'deployment') -Force | Out-Null
 [IO.File]::WriteAllText((Join-Path $edition 'EDITION_MANIFEST.json'),'{"Schema":"ITVIP-USER-EDITION-2","EditionId":"11111111-2222-3333-4444-555555555555"}',[Text.UTF8Encoding]::new($false))
 [IO.File]::WriteAllText((Join-Path $edition 'EDITION_SHA256.json'),'[]',[Text.UTF8Encoding]::new($false))
 New-Item -ItemType Directory -Path (Join-Path $edition 'nested') | Out-Null
 [IO.File]::WriteAllText((Join-Path $edition 'nested/payload.txt'),'signed payload',[Text.UTF8Encoding]::new($false))
 $publicPath=Join-Path $temp ($Name+'.public.xml');[IO.File]::WriteAllText($publicPath,$PublicXml,[Text.UTF8Encoding]::new($false))
 $privatePath=Join-Path $temp ($Name+'.private.secure');$secure=ConvertTo-SecureString $PrivateXml -AsPlainText -Force
 ConvertFrom-SecureString $secure | Set-Content -LiteralPath $privatePath -Encoding ASCII
 return @{Edition=$edition;Public=$publicPath;Private=$privatePath}
}
function Invoke-Signer($Fixture){
 $output=& $PowerShellExe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $signer -EditionDirectory $Fixture.Edition -PrivateKeyFile $Fixture.Private -PublicKeyFile $Fixture.Public 2>&1
 return @{ExitCode=$LASTEXITCODE;Output=($output -join "`n")}
}
try {
 $keyA=New-Object Security.Cryptography.RSACryptoServiceProvider
 $keyB=New-Object Security.Cryptography.RSACryptoServiceProvider
 try {
  $keyA.KeySize=3072;$keyB.KeySize=3072
  $valid=New-TestEdition 'valid' $keyA.ToXmlString($false) $keyA.ToXmlString($true)
  $result=Invoke-Signer $valid
  if($result.ExitCode -ne 0){throw "Matching RSA-3072 key pair signing failed: $($result.Output)"}
  foreach($name in @('EDITION_SIGNATURE.sha256rsa','EDITION_REVOCATIONS.json','EDITION_REVOCATIONS.sha256rsa')){if(-not(Test-Path -LiteralPath (Join-Path $valid.Edition $name) -PathType Leaf)){throw "Signer did not produce $name"}}
  $inventory=@(Get-Content -LiteralPath (Join-Path $valid.Edition 'EDITION_SHA256.json') -Raw | ConvertFrom-Json)
  if(-not ($inventory | Where-Object {$_.Path -ceq 'nested/payload.txt'})){throw 'Nested inventory path was not normalized to forward slashes.'}
  $manifestBytes=[IO.File]::ReadAllBytes((Join-Path $valid.Edition 'EDITION_MANIFEST.json'))
  $inventoryBytes=[IO.File]::ReadAllBytes((Join-Path $valid.Edition 'EDITION_SHA256.json'))
  $payload=New-Object byte[] ($manifestBytes.Length+$inventoryBytes.Length)
  [Array]::Copy($manifestBytes,0,$payload,0,$manifestBytes.Length);[Array]::Copy($inventoryBytes,0,$payload,$manifestBytes.Length,$inventoryBytes.Length)
  $signature=[Convert]::FromBase64String([IO.File]::ReadAllText((Join-Path $valid.Edition 'EDITION_SIGNATURE.sha256rsa')))
  if(-not $keyA.VerifyData($payload,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'),$signature)){throw 'Generated edition signature did not verify with the matching public key.'}
  $wrong=New-TestEdition 'mismatched' $keyB.ToXmlString($false) $keyA.ToXmlString($true)
  $wrongResult=Invoke-Signer $wrong
  if($wrongResult.ExitCode -eq 0){throw 'Signer accepted a private key that does not match the supplied public key.'}
  if(Test-Path -LiteralPath (Join-Path $wrong.Edition 'EDITION_SIGNATURE.sha256rsa')){throw 'Mismatched-key signing left a signature artifact.'}
  Write-Host 'PASS: RSA-3072 matching key pair signs and verifies; mismatched key pair is rejected; nested inventory path is normalized.' -ForegroundColor Green
 } finally {$keyA.Dispose();$keyB.Dispose()}
} finally {Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue}
