from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "build.bat").read_text(encoding="utf-8")
VERIFY = (ROOT / "tools/verify_windows_build.ps1").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/windows-build.yml").read_text(encoding="utf-8")

EXPECTED = {
    "scanner.exe", "usb_guard.exe", "tempclean.exe", "activator.exe", "pwrecover.exe",
    "portable_manager.exe", "security_center.exe", "copy_manager.exe",
    "ai_assistant.exe", "github_hub.exe", "api_manager.exe", "agent_studio.exe",
    "provider_hub.exe", "provider_runtime.exe", "team_studio.exe", "team_runner.exe",
    "workflow_studio.exe", "workflow_runner.exe", "run_history.exe", "memory_center.exe",
    "session_center.exe", "backup_center.exe", "settings_center.exe", "permissions_center.exe",
    "scanner_gui.exe", "usb_guard_gui.exe", "tempclean_gui.exe", "activator_gui.exe",
    "pwrecover_gui.exe", "security_center_gui.exe", "system_monitor_gui.exe",
    "ITVIP.exe", "ITVIPNativeVerify.exe", "ITVIPBootstrap.exe",
}


def test_verifier_covers_all_native_build_outputs():
    block = VERIFY.split("$expected = @(", 1)[1].split(")", 1)[0]
    actual = set(re.findall(r"'([^']+\.exe)'", block, re.IGNORECASE))
    assert actual == EXPECTED


def test_build_script_cleans_every_verified_output_before_build():
    clean_line = next(line for line in BUILD.splitlines() if line.startswith("for %%F in ("))
    cleaned = {item if item.lower().endswith(".exe") else f"{item}.exe" for item in clean_line.split("(", 1)[1].split(")", 1)[0].split()}
    assert EXPECTED <= cleaned


def test_verifier_supports_msvc_and_mingw_pe_inspection():
    assert "ValidateSet('dumpbin','objdump')" in VERIFY
    assert "file format pei-x86-64" in VERIFY
    assert "file format pei-i386" in VERIFY
    assert "dumpbin.exe" in VERIFY and "objdump.exe" in VERIFY


def test_windows_ci_contains_msvc_x86_x64_and_mingw_x64_jobs():
    assert "arch: [x64, x86]" in WORKFLOW
    assert "name: MinGW x64 build" in WORKFLOW
    assert "msystem: MINGW64" in WORKFLOW
    assert "./tools/verify_windows_build.ps1 -ExpectedArchitecture x64 -Compiler objdump" in WORKFLOW
    assert "call build.bat mingw" in WORKFLOW
