from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")


def test_command_center_is_integrated_into_dashboard_and_capabilities():
    assert "ID_COMMAND_CENTER=407" in MAIN
    assert 'case ID_COMMAND_CENTER:return L"command_center"' in MAIN
    assert "case ID_COMMAND_CENTER:showCommandCenter();return 0;" in MAIN
    assert "ID_COMMAND_CENTER,tr(L\"مركز متابعة العمليات\",L\"Command Center\")" in MAIN
    assert "ID_COMMAND_CENTER};" in MAIN


def test_command_center_has_live_list_search_filters_and_export():
    assert "LVS_REPORT|LVS_SINGLESEL|LVS_SHOWSELALWAYS" in MAIN
    assert "LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES|LVS_EX_DOUBLEBUFFER" in MAIN
    assert "ID_CMD_SEARCH&&HIWORD(a)==EN_CHANGE" in MAIN
    assert "ID_CMD_FILTER&&HIWORD(a)==CBN_SELCHANGE" in MAIN
    assert "SetTimer(w,1,1000,nullptr)" in MAIN
    assert "info->ptMinTrackSize.x=760;info->ptMinTrackSize.y=480" in MAIN
    assert "int y=std::max(110,height-58)" in MAIN
    assert "GetSaveFileNameW(&ofn)" in MAIN
    assert "completion_time,tool,exit_code,status,duration_ms,pid" in MAIN


def test_process_lifecycle_tracks_pid_duration_and_refreshes_center():
    assert "struct ActiveTool{DWORD pid;std::wstring module;ULONGLONG started;}" in MAIN
    assert "activeTools.push_back({pi.dwProcessId" in MAIN
    assert "GetTickCount64()-context->started" in MAIN
    assert "removeActiveTool(context->pid)" in MAIN
    assert "WM_APP_COMMAND_REFRESH" in MAIN
    assert "appendToolExecutionHistory(context->module,code,context->pid" in MAIN


def test_history_reader_accepts_legacy_four_field_rows_and_new_six_field_rows():
    assert "if(f.size()<4)continue" in MAIN
    assert "f.size()>4?f[4]+L\" ms\"" in MAIN
    assert "f.size()>5?f[5]:L\"—\"" in MAIN
    assert "while(f.size()<6)f.push_back(L\"\")" in MAIN


def test_listview_common_controls_are_initialized():
    assert "ICC_BAR_CLASSES|ICC_LISTVIEW_CLASSES" in MAIN


def test_command_center_permission_is_available_in_owner_profiles_and_editions():
    permissions = (ROOT / "src/modules/permissions_center.cpp").read_text(encoding="utf-8")
    builder = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8")
    assert '{L"command_center",L"مركز متابعة العمليات",L"Command Center"}' in permissions
    assert "command_center=@{}" in builder
    assert "ID_SYSTEM_MONITOR,ID_COMMAND_CENTER" in MAIN


def test_older_permission_profiles_default_new_command_center_to_disabled():
    builder = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8")
    assert "$key -eq 'command_center' -and $null -eq $value" in builder
    assert "$value='0'" in builder
    assert "command_center=0" in builder


def test_command_center_status_filtering_uses_canonical_codes_and_localized_labels():
    assert 'if(mode==1&&status!=L"RUNNING")return;' in MAIN
    assert 'displayStatus=tr(L"ناجح",L"SUCCESS")' in MAIN
    assert 'displayStatus=tr(L"فشل",L"FAILED")' in MAIN
    assert 'tr(L"فاشل",L"Failed")' in MAIN
    assert 'displayStatus+L" "+status' in MAIN
