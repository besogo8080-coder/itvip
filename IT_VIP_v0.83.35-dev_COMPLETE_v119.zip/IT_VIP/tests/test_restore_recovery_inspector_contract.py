from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSPECTOR = (ROOT / "tools/Inspect-RestoreRecovery.ps1").read_text(encoding="utf-8")
FIXTURE = (ROOT / "tests/windows/Test-RestoreRecoveryInspector.ps1").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/windows-build.yml").read_text(encoding="utf-8")


def test_inspector_is_explicitly_read_only_and_reports_file_state():
    assert "InspectionOnly = $true" in INSPECTOR
    assert "does not restore, roll back, delete, or modify files" in INSPECTOR
    assert "TargetPresent = $targetExists" in INSPECTOR
    assert "OriginalSnapshotPresent = $oldExists" in INSPECTOR
    assert "StagedNewFilePresent = $newExists" in INSPECTOR
    assert "Remove-Item" not in INSPECTOR
    assert "Copy-Item" not in INSPECTOR
    assert "Move-Item" not in INSPECTOR


def test_inspector_validates_journal_schema_and_windows_path_safety():
    for token in (
        "ITVIP_RESTORE_JOURNAL_V1",
        "PREPARED|APPLYING|APPLIED|ROLLING_BACK|COMMITTED",
        "invalid UTF-8 path",
        "OrdinalIgnoreCase",
        "..",
        "reserved device-name component",
        "approved application roots",
    ):
        assert token in INSPECTOR


def test_windows_ci_runs_recovery_inspector_fixture_for_both_powershell_editions():
    assert "Test-RestoreRecoveryInspector.ps1" in WORKFLOW
    assert "powershell-runtime-tests" in WORKFLOW
    assert "Windows PowerShell 5.1" in WORKFLOW
    assert "PowerShell 7" in WORKFLOW
    assert "invalid phase" in FIXTURE
    assert "Restore recovery inspector fixture: PASS" in FIXTURE
