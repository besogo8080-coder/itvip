from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = (ROOT / ".github/workflows/windows-build.yml").read_text(encoding="utf-8")
RUNTIME_TEST = (ROOT / "tests/windows/Test-ProcessExitPropagation.ps1").read_text(encoding="utf-8")


def test_windows_ci_runs_process_exit_tests_on_both_powershell_editions():
    assert "Process exit propagation (${{ matrix.edition }})" in WORKFLOW
    assert "Windows PowerShell 5.1" in WORKFLOW
    assert "PowerShell 7" in WORKFLOW
    assert "Test-ProcessExitPropagation.ps1" in WORKFLOW


def test_runtime_fixture_checks_success_and_nonzero_exit_codes():
    assert "foreach ($expected in @(0, 23))" in RUNTIME_TEST
    assert 'set "RC=%ERRORLEVEL%"' in RUNTIME_TEST
    assert "endlocal & exit /b %RC%" in RUNTIME_TEST
    assert "-NonInteractive" in RUNTIME_TEST


def test_runtime_fixture_uses_temporary_isolated_files_and_cleans_them():
    assert "[guid]::NewGuid()" in RUNTIME_TEST
    assert "Remove-Item -LiteralPath $tempRoot -Recurse -Force" in RUNTIME_TEST
