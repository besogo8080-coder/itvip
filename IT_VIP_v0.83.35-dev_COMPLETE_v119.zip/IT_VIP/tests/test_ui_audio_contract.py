from pathlib import Path
import struct
import wave

ROOT = Path(__file__).resolve().parents[1]


def test_shared_audio_helper_and_optional_winmm_playback():
    header = (ROOT / "src/app/itvip_ui_audio.hpp").read_text(encoding="utf-8")
    assert "PlaySoundW" in header
    assert "SND_FILENAME | SND_NODEFAULT" in header
    assert "synchronous ? SND_SYNC : SND_ASYNC" in header
    assert 'L"Audio", L"Enabled", 1' in header
    assert "MessageBeep" in header


def test_click_and_back_hooks_are_present_in_primary_windows():
    dashboard = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    branded = (ROOT / "src/app/branded_tool_gui.cpp").read_text(encoding="utf-8")
    monitor = (ROOT / "src/modules/system_monitor_gui.cpp").read_text(encoding="utf-8")
    for source in (dashboard, branded, monitor):
        assert "itvip::audio::click()" in source
        assert "itvip::audio::back()" in source
    for module in (ROOT / "src/modules").glob("*.cpp"):
        text = module.read_text(encoding="utf-8")
        if "case WM_COMMAND:" in text:
            assert "itvip_ui_audio.hpp" in text, module.name
            assert "itvip::audio::click()" in text, module.name
            assert "itvip::audio::back()" in text, module.name
    assert "ID_AUDIO_TOGGLE" in dashboard
    assert "WritePrivateProfileStringW(L\"Audio\",L\"Enabled\"" in dashboard


def test_audio_assets_are_valid_short_pcm_waves():
    for name, max_seconds in (("ui_click.wav", 0.10), ("ui_back.wav", 0.20)):
        path = ROOT / "assets/audio" / name
        assert path.is_file()
        with wave.open(str(path), "rb") as audio:
            assert audio.getnchannels() == 1
            assert audio.getsampwidth() == 2
            assert audio.getframerate() == 22050
            assert 0 < audio.getnframes() / audio.getframerate() <= max_seconds
            assert audio.getcomptype() == "NONE"


def test_gui_build_targets_link_windows_multimedia_library():
    build = (ROOT / "build.bat").read_text(encoding="utf-8")
    assert "gdiplus.lib winmm.lib" in build
    assert "-lgdiplus -lwinmm" in build
    assert "iphlpapi.lib winmm.lib" in build
    assert "-liphlpapi -lwinmm" in build
    assert "ole32.lib winmm.lib" in build
    assert "-lole32 -lwinmm" in build


def test_extended_event_cues_and_individual_preferences():
    header = (ROOT / "src/app/itvip_ui_audio.hpp").read_text(encoding="utf-8")
    for cue in ("Success", "Warning", "Complete", "Notification"):
        assert f"Cue::{cue}" in header
        assert f"{cue.lower()}()" in header
    assert "SuccessEnabled" in header and "WarningEnabled" in header
    assert "CompleteEnabled" in header and "NotificationEnabled" in header
    dashboard = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    for control in ("ID_AUDIO_TEST_SUCCESS", "ID_AUDIO_TEST_WARNING", "ID_AUDIO_TEST_COMPLETE", "ID_AUDIO_TEST_NOTIFICATION"):
        assert control in dashboard
    branded = (ROOT / "src/app/branded_tool_gui.cpp").read_text(encoding="utf-8")
    assert "itvip::audio::success()" in branded
    assert "itvip::audio::warning()" in branded
    assert "itvip::audio::complete()" in branded


def test_extended_audio_assets_are_valid_short_pcm_waves():
    for name, max_seconds in (("ui_success.wav", 0.30), ("ui_warning.wav", 0.35), ("ui_complete.wav", 0.35), ("ui_notification.wav", 0.25)):
        path = ROOT / "assets/audio" / name
        assert path.is_file()
        with wave.open(str(path), "rb") as audio:
            assert audio.getnchannels() == 1
            assert audio.getsampwidth() == 2
            assert audio.getframerate() == 22050
            assert 0 < audio.getnframes() / audio.getframerate() <= max_seconds
            assert audio.getcomptype() == "NONE"


def test_custom_wav_import_controls_and_runtime_overrides():
    header = (ROOT / "src/app/itvip_ui_audio.hpp").read_text(encoding="utf-8")
    for key in ("ClickFile", "BackFile", "SuccessFile", "WarningFile", "CompleteFile", "NotificationFile"):
        assert key in header
    assert "configured.is_absolute()" in header
    assert 'if (file.empty()) file = root / L"assets" / L"audio"' in header
    dashboard = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    for control in range(385, 391):
        assert f"{control}" in dashboard
    assert "importCustomAudio" in dashboard
    assert 'std::string(signature,4)!="RIFF"' in dashboard
    assert 'std::string(signature+8,4)!="WAVE"' in dashboard
    assert "assets" in dashboard and "audio" in dashboard and "custom" in dashboard


def test_optional_startup_and_shutdown_audio_cues():
    header = (ROOT / "src/app/itvip_ui_audio.hpp").read_text(encoding="utf-8")
    assert "Cue::Startup" in header and "Cue::Shutdown" in header
    assert 'L"StartupEnabled"' in header and 'L"ShutdownEnabled"' in header
    assert 'L"ui_startup.wav"' in header and 'L"ui_shutdown.wav"' in header
    assert "inline void startup()" in header and "inline void shutdown()" in header
    assert "defaultCueEnabled" in header and "SND_SYNC" in header
    assert "play(Cue::Shutdown, true)" in header
    dashboard = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    assert "itvip::audio::startup()" in dashboard
    assert "itvip::audio::shutdown()" in dashboard
    assert "ID_AUDIO_STARTUP_TOGGLE" in dashboard and "ID_AUDIO_SHUTDOWN_TOGGLE" in dashboard
    assert "ID_AUDIO_TEST_STARTUP" in dashboard and "ID_AUDIO_TEST_SHUTDOWN" in dashboard
    for name in ("ui_startup.wav", "ui_shutdown.wav"):
        path = ROOT / "assets/audio" / name
        assert path.is_file()
        with wave.open(str(path), "rb") as audio:
            assert audio.getnchannels() == 1
            assert audio.getsampwidth() == 2
            assert audio.getframerate() == 22050
            assert 0 < audio.getnframes() / audio.getframerate() <= 0.75
            assert audio.getcomptype() == "NONE"


def test_dashboard_button_hover_and_pressed_theme_feedback():
    dashboard = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    assert "dashboardButtonProc" in dashboard
    assert "WM_MOUSEMOVE" in dashboard and "WM_MOUSELEAVE" in dashboard
    assert "WM_LBUTTONDOWN" in dashboard and "WM_LBUTTONUP" in dashboard
    assert "TrackMouseEvent" in dashboard and "SetWindowSubclass" in dashboard
    assert "DefSubclassProc" in dashboard and "RemoveWindowSubclass" in dashboard
    assert "EnumChildWindows(w,installDashboardButtonEffects,0)" in dashboard
    assert "themes[themeIndex].accent2" in dashboard


def test_native_startup_splash_is_centered_timed_and_bilingual():
    source = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8")
    assert 'L"ITVIPSplashWindow"' in source
    assert 'SetTimer(w,1,850,nullptr)' in source
    assert 'Preparing your workspace' in source
    assert 'جارٍ تجهيز بيئة العمل' in source
    assert 'GetSystemMetrics(SM_CXSCREEN)' in source
    assert 'loadSettings();' in source
    assert source.index('CreateWindowExW(WS_EX_TOPMOST,splash.lpszClassName') < source.index('L"ITVIPMainWindow"')
