# IT VIP — Execution History

The Execution History window lists local text reports from the `reports` directory. The current allowlist includes `workflow_run_`, `team_run_`, and `project_validation_` filename prefixes.

Features:
- Refresh the report list.
- Preview a selected report (up to 4 MiB).
- Export a copy through a Save dialog.
- Delete a selected report only after explicit confirmation.

Privacy: reports may contain prompts, AI responses, system details, or other sensitive content. Review before exporting or sharing. Deleting a report removes only that report file. This module does not upload report contents.

Scope: this is a report browser, not a persistent per-Agent chat memory database. Provider Runtime and Workflow Runner are not yet automatically unified into a shared conversation-history store.
