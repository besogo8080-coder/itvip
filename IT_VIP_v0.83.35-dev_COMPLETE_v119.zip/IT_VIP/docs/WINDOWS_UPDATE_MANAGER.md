# IT VIP Windows Update Manager

## Purpose
A read-only inventory of software updates exposed by the Windows Update Agent (WUA) on the current Windows installation, plus recent WUA history and the Windows Update service status.

## Launch
Use `deployment/WindowsUpdate-ITVIP.cmd` or the dashboard button. The launcher explains that an available-update search may contact the machine's configured Microsoft Update or organization WSUS source and asks for consent before proceeding.

## Data collected
- WUA available software updates: title, update identity/revision, KB article IDs, downloaded flag, mandatory flag, reboot-required flag, and maximum download size when supplied.
- Recent WUA history: date, title, operation, result code, HRESULT, update identity, and client application ID.
- Windows Update service status when readable.
- Timestamped JSON, TXT, and CSV reports under `reports/`.

## Safety boundaries
- Read-only query only. No update download, install, hide, decline, scheduling, EULA acceptance, or reboot.
- Does not start/stop/reconfigure `wuauserv`, modify Windows Update policy, or write Registry settings.
- The search can contact the configured update source. Do not run it on metered or restricted networks unless appropriate.
- A listed update is not proof that it is applicable or advisable for every device. Check release notes, compatibility, backups, and organizational policy before installing through Windows Settings or the organization's approved management system.
- Reports can disclose installed update history, device management details, and software titles. Review before sharing.

## Limitations
- Results depend on Windows Update Agent, configured update source, network access, policy, and permissions.
- Only software updates returned by the configured source are listed; drivers and other update classes are not queried.
- Search and history results are capped (100 available updates and 100 history entries by default in the launcher/script unless parameters are changed).
- Windows PowerShell 5.1 / Windows 10 / Windows 11 runtime validation is still required. Static source checks do not prove WUA COM behavior on a live device.
