# IT VIP Software & Installed Apps Manager

## Purpose
A read-only inventory of conventional desktop applications registered in the Windows Uninstall registry locations.

## Launch
Use **Software & Installed Apps Manager** from the IT VIP dashboard, or run `deployment/Software-ITVIP.cmd`.

## Inventory scope
- Machine-wide native uninstall registry entries.
- Machine-wide 32-bit uninstall registry entries (WOW6432Node).
- Current-user uninstall registry entries.
- Optional scope selection and display-name substring filter.
- Bounded result count (1–5000; default 2000).
- Fields: display name, version, publisher, install date metadata, estimated size metadata, install location, registry scope/view, and registry key path.

## Reports
Timestamped JSON, TXT, and CSV reports are written to `reports/`.

## Safety
The module only reads registry uninstall metadata. It does not retrieve or execute uninstall strings, launch installers, update software, remove applications, modify registry values, or contact vendor websites. No elevation is requested.

## Limitations
This is not a complete inventory of every Windows application. Microsoft Store/MSIX packages and portable applications may be missing or represented differently. `EstimatedSize` is optional publisher-provided metadata and may be inaccurate; the total is not a verified disk-usage measurement. Registry key paths can reveal local configuration details, so review reports before sharing them.

## Validation status
Static source checks can verify files, integration, bounded parameters, read-only design, and report generation. Runtime behavior requires testing on Windows PowerShell 5.1 or a compatible PowerShell version on Windows; this environment has not executed that Windows runtime.
