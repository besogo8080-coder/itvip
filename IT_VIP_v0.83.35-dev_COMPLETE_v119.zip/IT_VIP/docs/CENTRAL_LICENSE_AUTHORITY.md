# IT VIP Central License Authority — v0.60 reference service

## Scope

`server/license_authority.py` is a small Python-standard-library control-plane reference. It stores EditionId revocations and restorations in SQLite, emits an `ITVIP-REVOCATIONS-1` JSON snapshot with a monotonically increasing `Revision`, and keeps a bounded audit response over an append-only audit table. It does **not** issue or sign licenses and does not push policy to clients. The existing offline RSA authority remains the trust root: download/export the snapshot from this service, then pass it to `Sign-ITVIPUserEdition.ps1 -RevocationFile <file>` while signing/reissuing the edition. The resulting snapshot is RSA-signed by the owner key and checked by the offline verifier.

## Run locally

From the project root (Python 3.10+ recommended):

```powershell
$env:ITVIP_ADMIN_TOKEN = '<random secret, at least 32 characters>'
python server/license_authority.py --host 127.0.0.1 --port 8765 --database data/license_authority.sqlite3
```

The `/health` endpoint is unauthenticated and returns service health only. All `/v1/*` routes require `Authorization: Bearer <token>`.

## API

- `POST /v1/revoke` JSON: `{"EditionId":"123e4567-e89b-42d3-a456-426614174000","Reason":"license cancelled"}`
- `POST /v1/restore` JSON: same fields; removes the ID from the current central set and records an audit event.
- `GET /v1/revocations`: returns `ITVIP-REVOCATIONS-1` JSON with `Revision`, save the response as a file and use it as `-RevocationFile` during offline signing. Revision increments only when revoke/restore changes state; repeated no-op requests do not increment it. The owner signing script embeds the revision in the signed snapshot.
- `GET /v1/audit`: returns the most recent 500 audit events for interactive review.
- `GET /v1/audit/export`: returns the complete ordered audit history plus a chain-integrity result. This is intended for offline retention/review; it is not signed and the unkeyed SHA-256 chain is tamper-evident, not tamper-proof. See `docs/LICENSE_AUDIT_EXPORT_v116.md`.

Example request:

```powershell
$h = @{ Authorization = "Bearer $env:ITVIP_ADMIN_TOKEN" }
Invoke-RestMethod http://127.0.0.1:8765/v1/revocations -Headers $h |
  ConvertTo-Json -Depth 5 | Set-Content .\revocations.json -Encoding UTF8
```

Then, on the owner signing workstation:

```powershell
.\deployment\Sign-ITVIPUserEdition.ps1 -EditionDirectory <edition> `
  -PrivateKeyFile <owner-private-key-dpapi-file> `
  -PublicKeyFile <owner-public-key-xml> -RevocationFile .\revocations.json
```

## Security and operational limits

- The service binds to loopback by default and refuses non-loopback binds unless `--allow-remote` is explicitly supplied.
- It has no built-in TLS, user directory, MFA, rate limiting, HA, backup scheduler, or remote client updater. For remote use, put it behind a correctly configured TLS reverse proxy, restrict network access, rotate the bearer token, and protect the SQLite database and host.
- The bearer token is supplied through the process environment; do not place it in source control, command history, or logs. Use a secrets manager in a production deployment.
- The snapshot returned by the server is **not signed by the server**. It is untrusted transport data until the owner signs it with the separate offline RSA private key. Never copy that private key onto the service host.
- Restoring an EditionId only removes it from the next central snapshot. It does not remotely reactivate already distributed copies: a newly signed snapshot/reissued edition must be delivered, and the client must run the verifier.
- Existing client enforcement remains launcher/PowerShell-based, not native in-process enforcement. A user with local administrator rights can tamper with the host environment. Authenticode, native C++ enforcement, and a production service are still release gates.
- SQLite is a single-host reference store. Back up the database securely and test restore procedures before operational use. Revision is an audit/order indicator, not an anti-rollback guarantee: clients do not persist a trusted highest-seen revision, so an older but correctly owner-signed snapshot could still be replayed.

## Tests

Run `python -m unittest discover -s tests -v`. These tests exercise SQLite revoke/restore, snapshot contents, audit behavior, idempotency, and input validation. They do not prove network security or Windows runtime behavior.

## Client anti-rollback state (v0.62)

The edition verifier now stores the highest accepted signed revocation `Revision`
per EditionId under `%LOCALAPPDATA%\\ITVIP\\LicenseState`. The state is protected
with Windows DPAPI `CurrentUser` scope and written via a temporary file followed
by replacement. A lower revision is rejected; equal revisions are accepted; a
higher revision advances the local high-water mark. This makes casual replay of
an older signed snapshot detectable for that Windows user profile.

This is deliberately a **local anti-rollback measure, not an absolute security
boundary**. A local administrator, a user who deletes the protected state, a
restored old profile backup, or a different Windows profile can reset/avoid the
high-water mark. Offline clients cannot learn about a newer server revision until
a newer signed snapshot is delivered. Stronger guarantees require a trusted
online service plus server-authenticated freshness, or hardware-backed monotonic
state. The verifier fails closed if an existing DPAPI state cannot be decrypted
or parsed.

## v0.63 — operator separation and direct TLS option

The reference service now supports two independent bearer credentials:

- `ITVIP_ADMIN_TOKEN` (required, at least 32 characters): may read and mutate.
- `ITVIP_READ_TOKEN` (optional, at least 32 characters and distinct when set): read-only access to `/v1/revocations` and `/v1/audit`. If omitted, it inherits the admin token for backwards-compatible local use.

Mutation routes require the admin credential. An optional `X-ITVIP-Actor` header is normalized to a bounded audit label; it is an server-configured service principal, **not a human identity**. Never put personal secrets in it.

For remote binding, `--allow-remote` now requires both `--tls-cert` and `--tls-key`. Direct TLS uses Python's `ssl` server context and enforces TLS 1.2 minimum. Example:

```powershell
$env:ITVIP_ADMIN_TOKEN = '<unique random secret, 32+ chars>'
$env:ITVIP_READ_TOKEN = '<different unique random secret, 32+ chars>'
python server/license_authority.py --host 0.0.0.0 --port 8765 `
  --allow-remote --tls-cert C:\ITVIP\tls\server-chain.pem `
  --tls-key C:\ITVIP\tls\server-key.pem `
  --database D:\ITVIPData\license_authority.sqlite3
```

Use a certificate whose SAN matches the DNS name clients use. Protect the private TLS key with OS ACLs; rotate both bearer tokens. TLS certificate provisioning/renewal, firewall policy, operator identity, MFA, rate limiting, HA, monitoring, and backup/restore drills remain deployment responsibilities. The actor header is not authentication. SQLite uses WAL and FULL synchronous mode for the local reference store; this does not replace tested backups or a production database strategy.

The built-in TLS path and HTTP authorization behavior are covered by source tests where practical, but no external TLS certificate handshake or Windows service deployment was exercised in this environment.


## v0.64 — tamper-evident audit chain

Each audit event now stores `prev_hash` and `audit_hash`. The digest is SHA-256 over a canonical JSON representation of the event fields (including its database ID, revision, and previous hash). New events link to the previous event in the same SQLite transaction. On startup, legacy rows with empty chain fields are backfilled in ID order; existing non-empty hashes are preserved rather than silently rewritten.

Authenticated `GET /v1/audit/verify` checks the full chain and returns `valid`, number of checked rows, first bad row ID, and the last verified head. A failed check indicates an altered, missing, or inconsistent row. This is **tamper-evident, not tamper-proof**: an attacker who can rewrite the database can also recompute the unkeyed SHA-256 chain. For stronger evidence, periodically export and digitally sign the chain head or forward audit events to a separately administered append-only/WORM logging system.

SQLite connection handling now commits/rolls back explicitly and closes every connection. Tests cover normal chaining, legacy schema migration, direct row tampering, and the authenticated verification endpoint.


## v0.65 — strict mutation request parsing and serialized writers (v115)

Mutation endpoints now accept only a bounded `application/json` request body with an explicit decimal `Content-Length`. Transfer-Encoding request bodies are rejected; the body must be complete, valid UTF-8, and a JSON object. Duplicate object properties are rejected rather than silently taking the last value, and non-standard JSON constants (`NaN`, `Infinity`, `-Infinity`) are rejected. The existing 8 KiB body limit remains in force.

Revoke and restore now issue `BEGIN IMMEDIATE` before changing the revocation set, revision metadata, or audit-chain head. This reserves the SQLite writer slot before the state transition, serializing concurrent mutations so revisions and audit links are committed in one ordered transaction. Regression tests exercise concurrent independent revocations and verify that revisions remain contiguous and the audit chain remains valid.

These changes harden request interpretation and concurrent state updates; they do not turn the reference service into a production identity platform. Continue to use distinct high-entropy bearer tokens, TLS, network restrictions, protected database backups, separately administered audit export, and an offline owner signing workstation. The actor header remains an server-configured service principal, not a human identity. The unkeyed SHA-256 audit chain remains tamper-evident rather than tamper-proof.


## v117 audit attribution boundary

Audit events now use the server-configured `ITVIP_ADMIN_ACTOR` value (default `license-authority-admin`) instead of trusting the caller-controlled `X-ITVIP-Actor` request header. This labels the configured service principal only; it does not identify an individual human when a shared bearer token is used. See `docs/LICENSE_AUDIT_IDENTITY_v117.md`.
