# Storage safety hardening — v109

## Fast Copy

- The copy worker records whether it successfully created the destination root.
- A failed/cancelled operation removes a partial destination only when that root was
  created by the current worker. If another process creates the path between preflight
  and worker startup, the worker fails without deleting that other process's directory.
- Existing destination-name rejection and no-overwrite file copying remain in place.
- Cancellation and cleanup are still best-effort Windows filesystem operations; removal
  can fail when files are held open, permissions change, or a removable device disconnects.

## Backup Center

- Backup creation now fails closed on directory enumeration, metadata, copy, hash,
  manifest-write, and flush errors rather than silently skipping inaccessible entries.
- A failed backup removes only the uniquely-created backup directory for that attempt.
- Backup files use no-overwrite creation inside the new backup tree.
- Restore continues to validate relative paths, allowed top-level folders, file sizes,
  containment, and SHA-256 before copying files.

## Scope and remaining qualification

These changes are source-level hardening. They do not prove behavior on Windows or real
USB media. Still required: Windows 10/11 runtime tests on NTFS, exFAT, and FAT32 where
supported; low-space and disconnect tests; large-file tests; cancellation under load;
and restore failure/rollback tests. Restore is not yet an all-or-nothing transaction:
a failure after some files have been restored can leave a partially restored application.
Credential Manager secrets are not included in backups.
