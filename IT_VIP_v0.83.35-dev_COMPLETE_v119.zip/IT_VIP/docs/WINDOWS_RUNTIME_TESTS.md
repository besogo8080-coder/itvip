# Windows runtime test gates

The Windows build workflow now includes a dedicated process-exit propagation test
on both Windows PowerShell 5.1 and PowerShell 7. The test creates an isolated
CMD wrapper and temporary PowerShell fixture under a unique directory, runs
success and non-zero exit cases (0 and 23), and asserts that `cmd.exe` returns
exactly the PowerShell process exit code after `ENDLOCAL`.

This validates the CMD-to-PowerShell exit-code transport used by the deployment
launchers. It does **not** prove that every PowerShell tool completed its
business operation successfully, validate privileged actions, or replace
Windows 10/11 GUI and hardware testing. Tool-specific semantic checks remain
separate and must be safe, bounded, and consent-gated.

Run locally from a Windows PowerShell or PowerShell 7 prompt:

```powershell
./tests/windows/Test-ProcessExitPropagation.ps1 -PowerShellExe (Get-Process -Id $PID).Path
```

The GitHub Actions workflow runs this fixture once with Windows PowerShell 5.1
and once with PowerShell 7. No local Windows runtime execution is claimed by a
Linux-only validation run.
