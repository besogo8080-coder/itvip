# Native JSON parser fuzzing

## Scope

The target `tests/native/fuzz_strict_json.cpp` feeds arbitrary byte sequences into the dependency-free parser in `src/app/strict_json.hpp`. Parser exceptions are expected for malformed input; crashes, sanitizer findings, hangs, and abnormal termination are failures.

## Reproducible smoke test

Run `tests/native/run_strict_json_fuzz_smoke.sh`. It compiles with C++17, warnings-as-errors, AddressSanitizer, and UndefinedBehaviorSanitizer, then executes 50,000 deterministic mutations plus 15 seed inputs. The PRNG seed is fixed so the same mutation stream can be reproduced.

## Coverage-guided fuzzing

With LLVM Clang/libFuzzer installed, run:

```bash
CXX=clang++ RUNS=20000 tests/native/run_libfuzzer.sh
```

The included corpus contains representative edition manifest, revocation snapshot, and inventory inputs. Increase `RUNS` for longer campaigns. libFuzzer may add minimized corpus entries to the corpus directory; review and commit useful regression cases deliberately rather than blindly committing all generated files.

## Recorded run for Package v72

- Strict parser unit groups: 12 passed.
- Deterministic ASan/UBSan mutation smoke: 50,000 mutations plus 15 seeds passed.
- Clang libFuzzer with ASan/UBSan: 20,000 executions completed, 109 new coverage corpus units, no crash or sanitizer finding.
- The libFuzzer run reached 20,000 executions in approximately 21 seconds in the packaging environment.

## Limits

These are parser-level tests on the available Linux toolchain. They do not exercise Windows CNG, DPAPI, SID binding, file-system reparse-point behavior, PowerShell, or the complete signed-edition verification flow. Fuzzing is evidence from a bounded run, not proof of parser correctness. Continue longer fuzz campaigns and run Windows-specific integration tests before production use.
