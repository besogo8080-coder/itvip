# Native License Schema Hardening — v0.72.0-dev

This update tightens semantic validation after RSA signature verification and typed JSON parsing.

## Revocation snapshot

The native verifier now requires exactly four top-level fields: `Schema`, `Revision`, `GeneratedUtc`, and `RevokedEditionIds`. Revision must be a non-negative integer; `GeneratedUtc` must be a valid UTC ISO-8601 timestamp; the revocation list is capped at 100,000 canonical GUID-shaped values and duplicate IDs are rejected case-insensitively. The current EditionId membership check still occurs before DPAPI anti-rollback state mutation.

## Timestamp syntax

UTC timestamps must match the complete accepted form `YYYY-MM-DDTHH:MM:SS[.fraction]Z` or `YYYY-MM-DDTHH:MM:SS[.fraction]+00:00` with up to seven fractional digits. Trailing text and non-UTC offsets are rejected. Calendar validity is checked by the Windows `SystemTimeToFileTime` conversion.

## Inventory resource policy

The signed inventory is limited to 100,000 entries. Each file is limited to 512 MiB and aggregate inventoried payload size to 4 GiB. These checks are applied before file contents are read for hashing. This bounds ordinary package verification resource use but does not replace OS-level resource controls.

## Validation status

Portable parser tests and Python authority tests can be run on Linux. The changed verifier is Windows-specific and has **not** been compiled or executed with MSVC/MinGW, CNG, DPAPI, or Windows filesystem APIs in this environment. Static source validation is not a substitute for Windows integration testing.
