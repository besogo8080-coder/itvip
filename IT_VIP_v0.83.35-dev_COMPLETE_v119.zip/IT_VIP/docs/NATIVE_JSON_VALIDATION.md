# Native JSON validation — v0.69.0-dev

The native CNG verifier now runs a bounded strict JSON syntax pass over the signed edition manifest, file inventory, and revocation snapshot before applying policy fields. The pass rejects malformed strings/escapes, invalid number grammar, trailing data, duplicate object keys, documents larger than 16 MiB, strings larger than 1 MiB, and nesting deeper than 64 levels.

**Historical note for v0.69.0-dev:** that release used a strict syntax gate followed by regex-based field extraction. This limitation was addressed in v0.70.0-dev below by replacing signed JSON extraction with a typed DOM parser. The custom parser still requires independent security review and broader fuzzing before production use.

The verifier also checks whether the current EditionId is present in the signed `RevokedEditionIds` array **before** mutating the DPAPI anti-rollback high-water mark. This avoids persisting a newer revision for an edition that is already revoked.

## Limits and verification status

- The source has not been compiled with MSVC or MinGW in this environment.
- The strict parser has not been fuzzed under Windows; static checks do not prove parser correctness.
- CNG, DPAPI, SID binding, filesystem reparse-point handling, and bootstrap execution still require Windows 10/11 x86/x64 runtime qualification.

## v0.70.0-dev — typed JSON DOM

The native verifier now uses the dependency-free `src/app/strict_json.hpp` parser and a typed JSON DOM for all signed JSON inputs and the protected anti-rollback state. The regex-based JSON field extraction and inventory iteration have been removed. The public-key XML reader remains separate and is not a JSON parser.

The typed parser adds:
- Correct decoding of `\\uXXXX` escapes, including paired UTF-16 surrogates, into UTF-8.
- Validation of raw UTF-8 sequences (rejects overlong encodings, surrogate code points, invalid continuation bytes, and code points above U+10FFFF).
- Duplicate-key rejection at every object nesting level.
- Explicit node-count, document-size, string-size, and nesting limits.
- Typed accessors: required strings, nullable expiry strings, integer-only revisions, arrays, and objects.
- Exact inventory-entry shape (`Path` and `SHA256` only), SHA-256 format validation, and GUID-shape validation for edition/revocation IDs.

Portable parser tests are in `tests/native/test_strict_json.cpp`; run `tests/native/run_strict_json_tests.sh` with a C++17 compiler. The test harness was compiled with GCC using `-Wall -Wextra -Wpedantic -Werror` and passed 12 test groups in the development environment. This tests the portable parser only, not the Windows verifier, CNG, DPAPI, filesystem checks, or bootstrapper.
