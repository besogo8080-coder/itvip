# IT VIP Provider Runtime — v0.29.0-dev

This release adds a first operational chat path for enabled provider profiles that expose an OpenAI-compatible Chat Completions endpoint.

## Configuration flow
1. Create/save an API connection in Universal API Manager. Its display name is the API profile reference used by the provider profile.
2. Save its token in Windows Credential Manager through Universal API Manager.
3. In Provider Hub, configure an enabled provider with an HTTPS Base URL, model, protocol label, and the same API profile display name.
4. Open Multi-Provider Chat, select the provider, and send a prompt.

The runtime derives the API credential target using the same FNV-1a section naming rule as Universal API Manager. It reads the token directly from Windows Credential Manager and does not copy it into provider configuration files.

## Scope and limitations
- Supports `POST {BaseURL}/chat/completions` with JSON `{model,messages,stream:false}`.
- Intended for OpenAI-compatible Chat Completions services only. The protocol label is descriptive; it does not implement provider-specific protocols.
- Uses configured AuthHeader/AuthPrefix from the selected API connection.
- Requires HTTPS and limits response reading to approximately 1 MiB.
- Does not stream, maintain conversation history, invoke tools, execute local commands, or run Agents/workflows.
- Some services require extra headers, request signing, different payloads, or response schemas and will not work with this generic adapter.
- Network/API behavior must be tested on Windows with real provider credentials. No live API request is performed by static checks.
