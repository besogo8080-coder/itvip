# IT VIP Event Viewer & Log Analyzer

## Scope
A bounded, read-only Windows Event Log inventory implemented by `deployment/EventLogs-ITVIP.ps1` and launched manually through `deployment/EventLogs-ITVIP.cmd` or the dashboard. It queries only the **System** and **Application** logs. It does not clear logs, subscribe persistently, change audit policy, or access Security/Setup/custom channels.

## Filters and limits
- Log: `All` (System + Application), `System`, or `Application`.
- Level: Critical, Error, Warning, Information, or All. `All` means Critical/Error/Warning in this release; it intentionally excludes verbose/debug events.
- Time window: 1–90 days; default 7.
- Maximum returned events: 1–5,000; default 1,000.
- Optional Event ID: `0` means any ID.
- Message text is truncated at 12,000 characters per event; TXT displays at most 100 recent entries while JSON/CSV contain the bounded query result.

## Reports
Timestamped JSON, TXT, and CSV files are written to `reports/`.

## Privacy and interpretation
Event messages can include usernames, machine names, local paths, software details, device identifiers, and other private information. Inspect reports before sharing them. A failed query may mean access restrictions, a missing log, or provider/OS differences; it is not proof that the system has no events. Counts describe only the events returned by the bounded query, not the complete historical log. Event severity is supplied by the event provider and does not by itself establish root cause.

## Safety
Read-only. No logs or Windows settings are changed. The tool does not automatically remediate events, disable services, delete files, or contact external services. Standard Windows permissions apply; elevated access may reveal additional records but is not requested automatically.

## Validation status
Static source/launcher/documentation checks can be run with `python tools/validate_project.py --report`. PowerShell 5.1 runtime behavior and live Windows 10/11 event-log results still require testing on Windows.
