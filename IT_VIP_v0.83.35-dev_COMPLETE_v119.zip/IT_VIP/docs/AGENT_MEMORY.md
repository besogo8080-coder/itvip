# IT VIP Agent Memory Vault

## Scope
The Memory Center is a local, user-managed memory vault. It is not yet an automatic chat-history capture system and is not wired into provider prompts or Agent execution. Users explicitly create records and choose an Agent ID and project/context tag.

## Storage
- File: `data/memory/memory.v1` relative to the portable project root.
- Format: version header `ITVIPMEM1`, followed by tab-separated hexadecimal UTF-8 fields (timestamp, Agent ID, project tag, body).
- Hex encoding keeps tabs and newlines inside content from corrupting record boundaries.
- Content limit: 256 KiB per record; Agent ID and project tag: 256 bytes each.
- The application writes a temporary file and replaces the store when saving.

## Privacy and controls
- Records stay on the local project drive; no network request is made by Memory Center.
- Nothing is automatically sent to an AI provider.
- Users can inspect, export, refresh, and delete records. Deletion requires confirmation.
- Exported records may contain private or confidential material; review them before sharing.
- The store is not encrypted. Use Windows device encryption/BitLocker and protect the USB/device. Do not store passwords, API keys, recovery codes, or other secrets here.

## Current limitations
- No automatic capture from Provider Runtime, Team Runner, or Workflow Runner.
- No semantic search, retention policy, encryption, or per-record access control yet.
- Future prompt integration must be explicit, size-limited, scoped to the selected Agent/project, and disclose exactly which records will be sent before transmission.
