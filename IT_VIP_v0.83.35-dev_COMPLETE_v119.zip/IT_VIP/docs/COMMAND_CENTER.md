# IT VIP Command Center

The dashboard's **Command Center** is a native Win32 view of processes launched through the dashboard's tracked launch paths.

## Live processes

While a native module or deployment `.cmd` wrapper is running, the center displays its filename, PID, and elapsed seconds. The list refreshes once per second. The process watcher removes the live row after completion and posts a UI refresh.

## Completed process history

Completed records are stored locally in `reports/tool_execution_history.tsv`. New records contain six tab-separated fields:

1. Local completion timestamp.
2. Executable or CMD launcher filename.
3. Numeric process exit code.
4. `SUCCESS` or `NONZERO_EXIT`.
5. Elapsed process duration in milliseconds.
6. Windows process ID.

The reader remains compatible with the earlier four-field v104 rows; unavailable duration and PID values are shown as `—`. Existing retention remains bounded to the newest 2,000 rows after the file exceeds 512 KiB.

## Search, filters, export

The window provides live text search, All/Running/Success/Failed filters, refresh, open-log, and CSV export. Export includes the recorded process metadata; it does not include command-line arguments, standard output/error, environment variables, or credentials.

## Interpretation and safety boundary

A running row means the tracked process handle has not signaled completion. `SUCCESS` means only that Windows reported exit code zero. It does not prove that the requested operation achieved its intended result. Nested commands must explicitly propagate their own exit codes. The center does not terminate, restart, elevate, or otherwise control processes; it is observational only.

## Verification boundary

Host-side source-contract tests verify the dashboard integration, process tracking, history compatibility, list/search/filter/export hooks, and common-control initialization. A Windows MSVC/MinGW build and interactive Windows 10/11 validation are still required for actual Win32 behavior.
