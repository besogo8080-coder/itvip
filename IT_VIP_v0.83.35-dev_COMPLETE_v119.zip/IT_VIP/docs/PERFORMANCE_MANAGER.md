# IT VIP Process & Performance Manager

## Scope
The PowerShell utility inventories CPU model/load snapshot, OS memory, the top 100 processes by working set, running Windows services, and fixed logical-disk usage. It writes timestamped JSON and TXT reports plus a process CSV under `reports/`.

## Optional process stop
The launcher offers an explicit process-stop path. The script rejects PID 0–4 and a conservative list of protected Windows process names, displays the target, warns about unsaved work, and requires the exact text `STOP <PID>`. This is not a guarantee that every remaining process is safe to stop; users should close applications normally first. Administrative elevation is not requested automatically.

## Limitations and safety
- Inventory does not change services, startup entries, power settings, disk settings, or process priority.
- Process `CPU` is cumulative CPU seconds, not a live percentage. `LoadPercentage` is a CIM snapshot and may be unavailable.
- Process inventory is limited to 100 entries by working set.
- Service inventory is limited to 100 running services.
- Some process fields may be unavailable due to permissions or process exit races; warnings are recorded.
- No automatic optimization, process killing, service disabling, or remote monitoring occurs.
- PowerShell 5.1/CIM behavior and live Windows runtime have not yet been validated in this environment.

## Run
Use `deployment/Performance-ITVIP.cmd`, or run `Performance-ITVIP.ps1 -Action Inventory` from Windows PowerShell.
