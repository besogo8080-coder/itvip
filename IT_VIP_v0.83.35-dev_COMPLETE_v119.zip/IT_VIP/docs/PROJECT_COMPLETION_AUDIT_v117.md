# IT VIP Project Completion Audit — v117

Date: 2026-11-25  
Baseline: `IT_VIP_v0.83.32-dev_COMPLETE_v116.zip`  
Candidate: `IT_VIP_v0.83.33-dev_COMPLETE_v117.zip`

## v117 implementation

- Removed caller-controlled `X-ITVIP-Actor` from audit attribution.
- Revoke/restore events now use the server-side `ITVIP_ADMIN_ACTOR` configuration, defaulting to `license-authority-admin`.
- Validate the configured principal at startup (1–64 ASCII letters, digits, `.`, `_`, `@`, `-`); invalid values stop startup.
- Added an HTTP regression test that attempts to impersonate `ceo@example.test` and confirms the database stores only `configured-license-admin`.
- Updated English/Arabic project summaries, authority documentation, roadmap, build status, and security-boundary documentation.

## Verification performed in this environment

- `python -m pytest -q -p no:cacheprovider`: **111 passed**.
- `python -m compileall -q server tests tools`: passed.
- `python tools/validate_project.py`: **466 PASS / 0 FAIL**.
- `bash tests/native/run_strict_json_tests.sh`: **12 groups passed**.
- `bash tests/native/run_strict_json_fuzz_smoke.sh`: **50,000 deterministic mutations + 15 seeds passed**.
- Source continuity: all regular files from v116 retained; v117 adds documentation/report files.
- ZIP CRC integrity and SHA-256 checksum: verified in the release report.

## Security interpretation

The audit label now represents the configured service principal, not a human identity. A shared admin bearer token still cannot distinguish individual operators. Person-level accountability requires individually provisioned credentials with a server-side identity map or a trusted identity-aware gateway. The SHA-256 audit chain remains unkeyed and can be recomputed by an administrator able to rewrite the database. No production tamper-proof audit claim is made.

## Release gates still open

1. Execute MSVC x86 and x64 builds and MinGW x64 build on Windows; inspect compiler/linker logs and produced PE files.
2. Execute Windows PowerShell 5.1 and PowerShell 7 runtime tests.
3. Run RSA signing/verifying, DPAPI/CNG, native license verifier, and Authenticode tests on Windows.
4. Perform a real TLS certificate handshake and remote deployment/security review, including identity federation if human attribution is required.
5. Qualify GUI behavior on Windows 10/11, including RTL, mixed DPI, notifications, and audio.
6. Exercise backup/restore and recovery on NTFS, exFAT, FAT32, and USB media, including interruption and rollback failure.
7. Decide whether Boot Manager remains read-only preflight or receives a separately scoped, safety-reviewed boot-media implementation.

## Explicit non-claims

No Windows executable was built or run in this Linux environment. No Windows CI workflow was executed. The tests above establish host-side Python behavior, source contracts, native portable JSON test behavior, and package integrity only. v117 remains a cumulative development source package, not a Windows-qualified production release.
