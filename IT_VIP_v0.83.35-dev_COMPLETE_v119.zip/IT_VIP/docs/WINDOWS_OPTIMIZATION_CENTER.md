# IT VIP Windows Optimization Center

## Scope
The PowerShell assessment is read-only and can inventory fixed-disk capacity, estimate the size of files in selected temporary folders, and list Windows startup entries. It emits timestamped JSON and TXT reports, plus a storage CSV when storage data is available.

## Run
Use `deployment/Optimize-ITVIP.cmd`, or run `deployment/Optimize-ITVIP.ps1` with `-Action All`, `Storage`, `TemporaryFiles`, or `StartupImpact`. `-MaxFiles` caps the number of temporary files inspected per location (default 5000).

## Safety and limitations
- No file is deleted, moved, compressed, or modified.
- No registry, service, power, firewall, or network setting is changed.
- Temporary-file totals are bounded estimates and may omit files beyond the scan cap or inaccessible files.
- Startup entries are inventoried; boot impact is not benchmarked.
- The tool provides recommendations only. Review files manually and use Windows controls for any cleanup or configuration change.
- PowerShell runtime behavior must be tested on supported Windows versions; static project validation is not a runtime test.
