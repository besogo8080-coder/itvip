# Tool Execution History

IT VIP records completed dashboard-launched native modules and deployment CMD utilities in `reports/tool_execution_history.tsv`.

Each new row contains six tab-separated fields:

1. Local completion timestamp.
2. Executable or CMD launcher filename.
3. Numeric process exit code returned by Windows.
4. `SUCCESS` for exit code 0, otherwise `NONZERO_EXIT`.
5. Process duration in milliseconds.
6. Windows process ID (PID).

The reader also accepts legacy four-field v104 rows; duration and PID are displayed as unavailable for those entries.

The file remains on the local machine and is not transmitted. The writer serializes concurrent completions and trims the file when it reaches 512 KiB, retaining the newest 2,000 lines. This is an execution-status log only: it does not capture console output, PowerShell error text, command arguments, or credentials. A zero exit code means only that the process reported success; it is not independent proof that every requested operation achieved its intended result.

PowerShell-backed CMD launchers capture `$LASTEXITCODE` as exposed through `%ERRORLEVEL%` immediately after PowerShell returns, then return that code from the wrapper after the interactive pause. Batch scripts that launch nested processes must continue to propagate their own child exit codes explicitly.

## Verification boundary

Source-contract tests validate the logging hook, bounded retention, synchronization, and wrapper exit-code patterns. Runtime behavior must still be confirmed on Windows with CMD, Windows PowerShell 5.1, and PowerShell 7. This package does not claim those runtime tests or a native Windows build.

The dashboard Command Center provides live process rows, search, status filters, manual refresh, open-log, and CSV export. See `COMMAND_CENTER.md`.
