# Windows Build Qualification Pipeline

## v0.83.22-dev / package v106

The Windows CI workflow now covers the full native application build through:

- MSVC x64 and x86 jobs on Windows Server 2022.
- MinGW-w64 x64 job using the MSYS2 MINGW64 environment.
- Post-build verification that every declared executable exists and has the requested PE architecture.
- Native strict-JSON executable tests in each compiler job.
- CI artifacts retained for 14 days for inspection.

`tools/verify_windows_build.ps1` supports `dumpbin` for MSVC and `objdump` for MinGW. Its target list includes console tools, standalone GUI tools, dashboard, native verifier, and bootstrapper. The source contract test checks that the verifier list matches the build outputs and that stale executables are removed before each build.

## Qualification boundary

The workflow definition and source contracts are checked in this package, but GitHub Actions has not been run from this local environment. A successful workflow run is still required before claiming compiler qualification. MinGW x86 remains an open matrix item; MSVC x86 is covered by the existing matrix. Windows 10/11 interactive runtime qualification, PowerShell 5.1/7 wrapper tests, DPI transitions, licensing tamper tests, and Authenticode signing remain separate release gates.
