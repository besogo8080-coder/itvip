# IT VIP — App Card Studio

## Current source features
- Add an EXE by browsing to its location.
- Set a display name independent of the EXE filename.
- Choose a built-in symbol or import an ICO file.
- Imported ICO files are copied into `assets/icons` for portable use.
- Preview the imported ICO in the editor and render it in the app list.
- Choose one of five per-card background palettes: Violet, Cyan, Gold, Matrix, Neutral.
- Move a selected card up or down, or drag a card with the mouse to a new position; ordering is saved in the portable app database.
- Run a selected application manually, edit its card, or remove only its list entry.
- Data is stored in `config/portable_apps.tsv`; older four-column records remain readable.

## Drag-and-drop behavior
- Drag starts when the left mouse button is pressed on a list item.
- Releasing over another item moves the source card to that target position and immediately saves the order.
- Releasing outside the list does not change the order. Keyboard up/down controls remain available.

## Data and safety notes
- The manager does not install applications or execute them during import.
- Removing an entry does not delete its EXE or imported icon asset.
- Applications outside the IT VIP folder are stored as absolute paths and may need relinking if moved.
- The TSV format is a simple UTF-8 tab-separated format. Names and paths containing tab/newline characters are not supported yet.
- The Windows GUI source has not yet been compiled or runtime-tested in this environment.

## Card size controls (v0.10.0-dev)
Each app card can now be set to Compact, Standard, or Large in the card editor. The list uses variable-height owner-drawn rows and scales the icon with the selected size. Existing database rows without the new size column are loaded as Standard; new saves append the size index as column six.


## Relink moved applications (v0.11.0-dev)
Select an app card and choose **إعادة ربط EXE** to browse to its new executable. This is useful after moving an app folder or reconnecting a USB drive under a different drive letter. The new path is saved using the existing relative-path rule when it is inside the IT VIP folder; otherwise it is stored as an absolute path. Relinking only updates metadata and never starts the selected program.


## Per-card typography (v0.12.0-dev)
The editor now provides four label-color presets (Ice White, Soft Cyan, Warm Gold, Neon Violet) and three label-size presets (Small, Medium, Large). These values are saved per app in TSV columns seven and eight. Records from older releases that do not contain these columns load with Ice White and Medium defaults. The executable path subtitle remains muted and is not independently configurable in this iteration. Arbitrary RGB colors and font-family selection are not implemented yet.
