# IT VIP Driver & Hardware Manager

Launch from the dashboard or `deployment/Hardware-ITVIP.cmd`. This is a **read-only inventory and diagnostics** tool.

## Inventory
- Windows edition/build and process architecture.
- CPU model, display adapters and reported display driver versions.
- Disk model/interface/status and physical network adapters.
- Plug and Play device name, class, manufacturer, status, service, device ID and Configuration Manager problem code.
- Audio-related device count based on Plug and Play class/name matching.
- Optional signed-driver inventory with `-IncludeSignedDriverInventory` (provider, version, date, INF, signature flag and device ID).

## Reports
Creates timestamped JSON and TXT reports under `reports/`, and a CSV of Plug and Play devices. The JSON report contains device IDs and other machine details; review before sharing.

## Safety and limitations
- No driver installation, removal, update, disablement, registry change, or device reset is performed.
- A nonzero Configuration Manager code is a diagnostic signal, not proof that a driver is malicious or that a particular fix is appropriate.
- CIM/WMI inventory can be incomplete on restricted systems or when providers fail. Missing data is not interpreted as a healthy device.
- Driver dates/versions are reported as Windows exposes them; this tool does not decide whether a newer driver is compatible.
- Use Windows Update or the hardware manufacturer's official support channel to obtain drivers. Do not use third-party driver packs or automated driver-updater utilities.
- Run without elevation first; elevation is not required by design.
