# IT VIP Deployment Manager (v0.41.0-dev)

This release adds PowerShell deployment tooling; it is **not** a signed Windows installer.

## Requirements
- Windows 10/11 with Windows PowerShell 5.1 or newer.
- A complete successful build produced by `build.bat` in the project's `build` directory.
- Run PowerShell as a normal user. The scripts do not request elevation.

## Preflight
From the project root:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\deployment\Deploy-ITVIP.ps1 -Action Preflight
```

Preflight reports OS version, OS architecture, and every required executable. It does not build the application or prove runtime compatibility.

## Create a portable folder
Choose a destination outside the source project tree:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\deployment\Deploy-ITVIP.ps1 -Action PackagePortable -OutputPath E:\IT_VIP_Portable
```

The script refuses to package when any required executable is missing and refuses to overwrite an existing destination. It copies all required EXEs plus `assets`, `config`, `docs`, and `portable`, creates empty `data`, `reports`, and `logs` folders, includes bilingual READMEs and a launcher, then writes SHA-256 hashes.

## Verify a portable folder

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\deployment\Deploy-ITVIP.ps1 -Action VerifyPackage -PackagePath E:\IT_VIP_Portable
```

## Scope and limitations
- This is a portable-folder packager and integrity checker, not an MSI/MSIX installer or uninstaller.
- No registry entries, services, scheduled tasks, firewall rules, or shortcuts are created.
- No automatic elevation or application auto-run occurs; the user starts `Start-ITVIP.cmd` manually.
- The package copies configuration files as they exist in the source tree. Review them before distribution and never place API secrets in plain-text config files.
- x86/x64 executable selection is not performed by this script; it packages the binaries produced by the selected compiler/toolchain. Build separate output trees for separate architectures.
- PowerShell execution and package round-trip were not run in this non-Windows environment.


## Update Manager integration
The portable package includes the `deployment` folder, which now contains the manual local Update Manager. It is not an online updater and does not replace the portable packaging workflow. See `docs/UPDATE_MANAGER.md`.
