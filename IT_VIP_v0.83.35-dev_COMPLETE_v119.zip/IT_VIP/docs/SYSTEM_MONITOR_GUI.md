# IT VIP Native Live System Monitor

## Launch
Use the **Live System Monitor / مراقبة النظام المباشرة** action in the main Dashboard. The action starts `build/system_monitor_gui.exe` from the packaged installation.

## Data sources (read-only)
- CPU: `GetSystemTimes` deltas. The first sample establishes the baseline.
- Memory: `GlobalMemoryStatusEx`.
- Network: `GetIfTable2` counters for active non-loopback interfaces. The first sample establishes the baseline; displayed rates are local adapter throughput, not an internet speed test.
- Storage: `GetDiskFreeSpaceExW` for the Windows system volume.

## Controls
Start begins a new session, Pause/Resume suspends/resumes sampling, Stop ends the session, and the duration selector limits a session to 1, 5, 10, 30, or 60 minutes. Graph history is capped at 90 samples. CSV samples are appended to `reports/system_monitor_live.csv`.

## Scope and limitations
The monitor performs read-only queries and does not modify settings, services, processes, drivers, disks, or network configuration. Network graph values are scaled relative to 1 MB/s for visualization. This native UI does not currently expose temperature sensors. MSVC/MinGW compilation and Windows 10/11 runtime testing remain required; Linux source checks do not prove Windows runtime correctness.

The monitor is also represented as the `system_monitor` capability in owner-created user-edition profiles. User-edition and portable-package builders require and include its executable when the capability is granted.
