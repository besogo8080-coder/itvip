# IT VIP Universal AI / API / Agent Architecture — Design Contract

The platform is provider-neutral. OpenAI is one adapter, not the controller of IT VIP.

## Planned layers
1. **Provider adapters:** OpenAI-compatible chat/responses, Anthropic, Gemini, Azure-hosted models, local Ollama/LM Studio, and custom HTTPS REST endpoints. Each adapter declares endpoint, authentication, model discovery support, request/response mapping, rate limits, and data-handling notes.
2. **API catalog:** named connections, encrypted credential references, configurable headers/query parameters, REST methods, JSON validation, OpenAPI import, health checks, and per-connection permission scopes.
3. **Agent runtime:** explicit goals, bounded steps/time/token budgets, tool allowlists, cancellation, state snapshots, and human approval gates.
4. **Tool adapters:** native IT VIP modules, GitHub read-only connector, MCP clients, file/report readers, and optional external integrations.
5. **Workflow engine:** typed inputs/outputs, visible node graph, retries with limits, approval nodes, and audit trail.
6. **Security boundary:** Windows Credential Manager for secrets; no secrets in logs/config/prompts; least privilege; network allowlists where practical; local sandbox for generated code; backups and rollback for edits; no silent elevation.

## Execution policy
- Model output is untrusted data, never a shell command to execute directly.
- Agents may only call registered tools with schema-validated arguments.
- Read-only actions can run within the configured allowlist.
- File writes, repository writes, system changes, software installation, and privileged actions require a human confirmation showing the exact diff/action and target.
- Destructive actions require a second confirmation and recoverability check; unsafe actions are denied.
- Every action records timestamp, connector, capability, target, approval, and result, without recording secrets.
- No provider receives local files or reports unless the user explicitly selects them for that request.

## Compatibility note
"Support every API" cannot mean one universal protocol: providers differ in authentication, payloads, streaming, tool calling, and policy. IT VIP therefore uses a documented adapter/plugin interface and a generic REST connector, with provider-specific adapters where needed. MCP and agent-to-agent protocols are optional connectors, not assumed capabilities of every provider.

## Status
Architecture specification only. The current executable implementation is the OpenAI assistant plus the read-only GitHub Hub; the generic API catalog, MCP manager, multi-agent orchestration, and workflow runtime are not yet implemented.


## Implemented first slice — v0.24.0-dev
`src/modules/api_manager.cpp` provides a generic HTTPS REST client with GET/POST, JSON POST body, configurable auth header and prefix, Credential Manager secret storage, saved endpoint/method settings, bounded response display, and explicit confirmation for POST. The dashboard launches `build/api_manager.exe`.

### Deliberate limitations
This is not a claim of universal protocol compatibility. OAuth2 flows, request signing, multipart uploads, GraphQL, WebSocket, gRPC, provider-specific SDKs, OpenAPI import, pagination helpers, multiple named profiles, and API schema generation remain future work. Arbitrary endpoint calls can disclose data to the endpoint owner; users must verify the host and payload before sending.

## Implemented slice — v0.26.0-dev
The generic HTTPS REST client now exposes GET, POST, PUT, PATCH, and DELETE. Mutating methods require a confirmation dialog; POST/PUT/PATCH send the JSON body editor contents, and GET omits the body. This remains a generic REST transport and does not imply compatibility with OAuth2-only services, signed requests, GraphQL, WebSocket, gRPC, or provider-specific AI payloads.
