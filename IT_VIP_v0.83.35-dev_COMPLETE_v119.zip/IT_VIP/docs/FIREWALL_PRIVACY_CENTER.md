# IT VIP Firewall & Privacy Center

## Scope
This is a read-only Windows assessment launched by `deployment/FirewallPrivacy-ITVIP.cmd`.

- Reads Windows Defender Firewall profile state and summarizes enabled inbound/outbound allow/block rules.
- Lists Windows network profiles.
- Reads selected UAC, SmartScreen, advertising, content-suggestion, app-privacy policy, and telemetry policy registry values when present.
- Optionally lists up to 250 established TCP connections visible to the current account, with process names when permitted.
- Writes timestamped JSON and TXT reports under `reports/`.

## Safety and interpretation
No firewall rules are added, removed, enabled, or disabled. No privacy setting, registry value, service, or network configuration is changed. No traffic is captured or intercepted, no remote hosts are scanned, and no application is blocked.

Missing registry values are reported as absent, not as proof that a feature is enabled or disabled. Firewall rule counts are summaries and do not establish application safety. Connection visibility depends on Windows permissions and timing. Review reports locally before sharing because they can contain local addresses, remote endpoints, process names, and policy details.

## Actions
- `All`: firewall, privacy, network profile, and established connection inventory.
- `Firewall`: firewall profiles and enabled-rule summaries.
- `Privacy`: selected registry policy snapshots.
- `Connections`: established TCP connection inventory only.

## Verification status
Static project checks can validate file presence and integration. PowerShell 5.1 execution and live Windows 10/11 behavior must be tested on target machines before production use.
