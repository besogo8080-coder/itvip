# VIP Studio — Responsive Customization Window (v0.83.3-dev)

The main dashboard's Customization Center now adapts its initial window height to the available desktop height, with a 600 px minimum and a 900 px maximum (subject to the display's reported height).

When the customization content is taller than the available client area, the window exposes a vertical scrollbar. Users can navigate the full set of controls using the scrollbar, line/page scrolling, or the mouse wheel. Resizing the window recalculates the scroll range while preserving the current scroll position.

The change does not alter the stored appearance schema, themes, backgrounds, imported assets, tool visibility, or profile format. All appearance settings continue to be stored in `config/appearance.ini`.

## Validation scope

Static integration checks verify the adaptive-height, vertical-scroll, mouse-wheel, and scroll-range code paths are present. Python authority tests, strict JSON tests, and deterministic parser fuzz smoke are regression checks unrelated to native Win32 window behavior. No Windows compiler or Windows GUI runtime is available in the current Linux environment; actual DPI, scrollbar, mouse-wheel, Arabic RTL, and multi-monitor behavior still require Windows 10/11 testing.
