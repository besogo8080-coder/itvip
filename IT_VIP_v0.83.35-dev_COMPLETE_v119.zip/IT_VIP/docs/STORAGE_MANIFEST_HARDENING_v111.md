# Backup manifest path hardening — v111

Before restore, each manifest path is validated as a Windows-safe relative file path. The parser rejects rooted/absolute paths, `.` and `..`, backslash aliases, colon/ADS syntax, control and reserved filename characters, trailing dots/spaces, and reserved DOS device names.

Each segment is folded using `LCMapStringEx(LOCALE_NAME_INVARIANT, LCMAP_LOWERCASE, ...)` to detect target collisions that Windows would treat as case-insensitive duplicates. Duplicate file targets and duplicate/unexpected folder records are rejected. Manifest line length, total record count, and file count are bounded to avoid unbounded parser resource use.

These checks supplement—not replace—the v110 SHA-256, staging, reparse-point, and rollback checks. The parser has not yet been exercised on Windows in this environment; Windows build/runtime qualification remains required.
