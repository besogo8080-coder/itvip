# IT VIP Roadmap

## Delivered in source (not yet Windows-tested)
- Initial Win32 dashboard with Arabic-first/English toggle.
- Core module launch integration and package-root path resolution.
- Theme and basic animated accent setting; tool visibility preferences.
- Portable Apps Manager with add/run/remove, editable card names, built-in symbol catalog,
  custom ICO import/preview/rendering, per-card color palettes, persistent move-up/down ordering, and mouse drag-and-drop ordering.
- Security Center initial read-only status checks.

## Next
1. Replace simple TSV app metadata with robust escaped JSON and validation.
2. Add relink/browse action for moved applications and missing icon recovery.
3. Add card size/label controls and richer layout presets.
4. Add bundled raster/vector icon packs and image backgrounds.
5. Add optional animated/video backgrounds with performance controls.
6. Add Shredder with dry-run, explicit confirmation, and storage-media limitations.
7. Refine dashboard layout, responsive resizing, DPI handling, and RTL/LTR behavior.
8. Design and validate the independent IT VIP Boot Manager architecture.

## Release gates
- Build and test on Windows 10/11, x86/x64.
- Verify portable operation after USB drive-letter changes.
- Test malformed settings, missing files, and moved application paths safely.
- No claims of antivirus detection or Secure Boot compatibility without actual engine/signing and firmware tests.

## v0.10.0-dev — Per-app card sizing
- Added per-application Compact, Standard, and Large card size selection in the app-card editor.
- Switched the owner-drawn list to variable-height rows so each card can use its saved size.
- Icon rendering scales with the selected card size.
- Extended the TSV record with a sixth size field; older five-column records remain readable and default to Standard.

## Next
- Add a dedicated relink action for moved EXE files and missing icons.
- Add an in-app icon gallery with bundled original assets and image backgrounds.
- Add font and text-size controls, then layout presets and a full VIP Studio preview.


## v0.11.0-dev — Portable app relinking
- Added a dedicated **Relink EXE** action for a selected app card.
- Users can browse to the application's new executable location after it has moved or a USB drive letter has changed.
- The selected app path is normalized through the existing portable-path helper, then saved without changing its display name, icon, palette, or card size.
- The relink action validates that the selected path exists and is a regular file; it does not launch the executable.

## Next
- Add missing-icon recovery and a safe path validation report.
- Add editable font family/size and label color settings to the card editor.
- Add an export/import workflow for app-card profiles.


## v0.12.0-dev — Per-card typography
- Added editable label color presets (Ice White, Soft Cyan, Warm Gold, Neon Violet).
- Added Small, Medium, and Large label font-size presets.
- Persisted both values as optional TSV columns seven and eight; older rows retain default values.
- These are preset controls, not arbitrary RGB/font-family pickers yet.

## Next
- Add a full visual preview and arbitrary color/font selection with safe fallbacks.
- Add app-card profile export/import and icon recovery.
- Continue VIP Studio background gallery and layout editor work.

## v0.13.0-dev progress
- [x] Custom static image background picker (PNG/JPG/JPEG/BMP)
- [x] Copy background into project assets and persist a relative path
- [x] Clear configured background without deleting the asset
- [ ] Animated video backgrounds
- [ ] Live preview in VIP Studio
- [ ] Windows build and runtime verification


## Completed in 0.14.0-dev
- Added a live background overlay/dimming slider (0–255) to the Customization Center.
- Added percentage feedback and persisted the selected opacity in `config/appearance.ini`.
- The image overlay now uses the selected alpha value; this is a dimming overlay, not image transparency editing.

## Next UI work
- Per-theme background assignments and a browsable built-in background gallery.
- A proper scrollable customization workspace and richer preview.
- Video backgrounds remain unsupported until a real playback backend is implemented.

## v0.15.0-dev completed at source level
- Separate static image backgrounds per visual theme.
- Live theme switching preview in the customization window.
- Theme-specific image copies and independent clear operation.
- Next: add a real preset gallery with bundled, licensed assets; improve preview/layout; then validate on Windows. Video backgrounds remain unsupported.


## v0.17.0-dev
- Visual preset gallery with image thumbnails and labels.
- Next: gallery import/manage/delete workflow and a larger preview pane; then Windows build/runtime validation.


## v0.18.0-dev — Imported wallpaper library
- [x] Multi-file image import into project assets
- [x] Imported-image list and large preview
- [x] Explicit apply and remove actions
- [ ] Windows build and interactive validation
- [ ] Thumbnail grid, search/filter, and per-item metadata

## v0.19.0-dev — VIP Studio card sizing
- [x] Add live dashboard card-size slider (80%–115%).
- [x] Persist CardScale in appearance.ini.
- [x] Adapt horizontal spacing for the supported size range.
- [x] Restore saved scale on cancel/close.
- [ ] Free-form drag-and-drop dashboard layout.
- [ ] Per-card font/color controls and layout profile import/export.
- [ ] Windows build, DPI, and runtime validation.


## VIP Studio follow-up — v0.21.0-dev
Completed at source level: dashboard font-size control (14–26), live preview, persistence, and cancel rollback.
Next: add a selectable font family with safe fallback, then per-card appearance and layout profiles. Arbitrary drag-and-drop positioning is still not implemented.


## Completed in v0.22.0-dev
- Added IT VIP AI Assistant using OpenAI Platform Responses API over WinHTTP HTTPS.
- Added Windows Credential Manager storage for the user-provided API key.
- Added explicit send workflow, editable model, manual prompt/report paste, and dashboard launcher.
- Added build targets for MSVC and MinGW.
- Remaining: report-file import, streaming, conversation history, model discovery, cancellation/retries, and Windows/live-API validation.

## v0.23.0-dev — VIP Studio appearance profiles
- Added Export profile to save the current `config/appearance.ini` as a portable INI profile.
- Added Import profile to back up the current settings to `config/appearance.before-import.ini`, load a selected profile, and apply its theme, visibility, opacity, card scale, font size, and accent settings immediately.
- Import refreshes the dashboard and the customization controls. Existing image assets are not bundled into the INI profile; referenced relative asset paths must exist in the destination project.
- Profiles are settings-only. They do not contain executable files, API credentials, or application-card databases.
- Windows compilation and interactive import/export testing remain required.

## Next
- Bundle referenced background assets alongside profiles or provide missing-asset relinking.
- Add profile preview and validation before applying imported settings.
- Continue per-card dashboard positioning and a scrollable VIP Studio workspace.

## v0.23.0-dev — GitHub & Developer Hub
- Added a separate read-only GitHub Hub executable using WinHTTP.
- Added token storage via Windows Credential Manager and a dashboard launcher.
- Added authenticated account check and recent repository listing (up to 50).
- Scope is intentionally read-only; no repository writes, Actions, pull requests, or AI upload.
- Next: generic provider adapters/API catalog, OpenAPI import, MCP connection manager, and a permissioned Agent/Workflow runtime. Each connector must declare capabilities and scopes; write actions require confirmation and audit records.
- Windows build and live API validation remain release gates.


## Universal API platform
- [x] Generic HTTPS REST GET/POST client with configurable auth header.
- [x] Credential Manager storage for one active API secret.
- [x] Dashboard entry point and build integration.
- [ ] Multiple named connection profiles and per-profile secrets.
- [ ] OAuth2 authorization-code/device flows and refresh tokens.
- [ ] OpenAPI import, endpoint explorer, and schema validation.
- [ ] Provider adapters for signed APIs, GraphQL, WebSocket, and SDK-based services.
- [ ] Agent tool permission layer with per-host allowlists and user approval.


## v0.35.0-dev update
- [x] Sequential Workflow Runner with previous-output hand-off, approval gate, stop-on-failure policy, and timestamped reports.
- [ ] Add retry/backoff and cancellation.
- [ ] Add structured conditional branches and workflow graph editor.
- [ ] Add Windows build/runtime tests and provider integration tests.


## Newly delivered — v0.36.0-dev
- Execution History desktop module: browse, preview, export, and confirmed deletion of approved local report types.
- Next: shared persistent chat/session storage integrated into Provider Runtime and workflow/team runners; cancellation/retry controls; Windows build and live-provider validation.

## v0.37.0-dev — Agent Memory Vault
- Added a manual local memory vault scoped by Agent ID and project tag.
- Added browse, export, delete-with-confirmation, and versioned portable storage.
- Not yet connected to chat capture or provider prompt context; encryption and search remain future work.


## v0.38.0-dev — Chat Session History
- Persist successful Provider Runtime exchanges locally.
- Browse, filter, preview, export, and confirmed-delete saved turns.
- Keep history isolated from provider requests unless a future explicit context-sharing feature is approved.


## v0.38.0-dev — Persistent Chat Session History
- [x] Keep an active local conversation scoped to one provider.
- [x] Include up to 12 completed turns from the active session in subsequent requests.
- [x] Append successful turns to the shared archive consumed by Session Center.
- [x] New Session clears active context without deleting archived history.
- [x] Document plaintext storage and explicit provider-context behavior.
- [ ] Windows build, runtime, and live-provider validation.
- [ ] Encryption at rest and named/multiple resumable sessions.

## Cumulative integration update v0.38.0-dev
- Added Backup & Restore Center for application data/configuration portability.
- Backed up folders: config, data, assets, portable, reports.
- Versioned manifest required for restore; explicit confirmation before overwrite.
- Credential Manager secrets are excluded by design.
- Remaining verification: compile and runtime test on Windows 10/11 with MSVC and MinGW.

## Cumulative integration update v0.38.0-dev
- Added Backup & Integrity Center with timestamped project backups and per-file SHA-256 manifest verification.
- Included folders: src, docs, config, data, assets, portable, reports. Build outputs and Windows Credential Manager secrets are excluded.
- Backup restore is not implemented in this release.
- Remaining verification: compile and runtime test on Windows 10/11 with MSVC and MinGW.


## v0.39.0-dev — Cumulative Backup & Restore
- [x] Back up approved portable data/config folders to a user-selected external destination.
- [x] Versioned manifest with per-file SHA-256 and size verification.
- [x] Validate manifest and file hashes before restore.
- [x] Require explicit confirmation before overwriting existing files.
- [x] Exclude Credential Manager secrets and symbolic links.
- [ ] Add transactional restore staging/rollback.
- [ ] Encrypt backup archives with a user-managed key.
- [ ] Run Windows build and backup/restore round-trip tests.


## v0.39.0-dev — Cumulative integration and Backup & Restore
- [x] Integrate provider-scoped active chat context with the shared Session Center archive.
- [x] Keep previous archived chat turns separate from the active context; include only the latest 12 active turns for the same provider.
- [x] Add Backup & Restore Center with an external destination, approved-folder allowlist, versioned manifest, path validation, file-size and SHA-256 verification, and explicit restore confirmation.
- [x] Repair cumulative MSVC/MinGW build dispatch for all modules, including Backup Center and Session Center.
- [ ] Windows MSVC/MinGW compile and GUI runtime validation.
- [ ] Test backup/restore on disposable sample folders and USB media.


## v0.40.0-dev — Universal Settings Center
- Central local folder/config validation, safe folder creation, selected settings export, and confirmed appearance-default reset with backup.
- Next: consolidate shared configuration schemas and add integration tests/build verification on Windows.


## v0.41.0-dev — Deployment tooling
- Added Windows PowerShell preflight for OS architecture and required build outputs.
- Added portable-folder packaging with strict missing-binary checks and no-overwrite behavior.
- Added SHA-256 package manifest verification and manual launcher.
- Signed installer/uninstaller and separate x86/x64 build pipelines remain future work.


## v0.42.0-dev — Manual Update Manager
- [x] Versioned local update manifest with file sizes and SHA-256 digests.
- [x] Approved runtime path allowlist; user config/data/reports/logs are not update targets.
- [x] Verify and stage package separately from apply.
- [x] Explicit typed confirmation, pre-update file backups, and latest-update rollback action.
- [x] Dashboard launcher and portable deployment inclusion.
- [ ] Authenticode/pinned publisher certificate validation.
- [ ] Signed release manifest and trusted release distribution channel.
- [ ] Windows PowerShell 5.1 execution tests, update/rollback fault-injection tests, and x86/x64 package tests.

## v0.43.0-dev — Security & Diagnostics Center
- [x] Add read-only PowerShell diagnostics for project structure and source/build-output presence.
- [x] Collect Windows, architecture, storage, Defender, Firewall, Secure Boot, and UAC status when available.
- [x] Export timestamped TXT and JSON reports locally.
- [x] Add bilingual dashboard entry and portable deployment script inclusion via deployment folder.
- [ ] Add Windows PowerShell 5.1 execution and Windows 10/11 verification.
- [ ] Add signed binary/publisher verification and optional controlled repair workflows (separate approval-gated design).

## v0.44.0-dev — Driver & Hardware Manager
- [x] Add read-only Plug and Play device inventory with Configuration Manager problem codes.
- [x] Collect CPU, display, disk, physical network adapter, and audio-device summary.
- [x] Add optional signed-driver inventory and timestamped JSON/TXT/CSV reports.
- [x] Add bilingual dashboard entry and portable PowerShell/CMD launchers.
- [ ] Validate PowerShell 5.1/CIM behavior on Windows 10 and Windows 11 hardware.
- [ ] Add vendor-signed driver metadata verification and curated official-vendor lookup (no automatic installation).

## v0.45.0-dev — Network Manager
- [x] Add read-only network adapter, IP/DNS, gateway, and adapter-statistics inventory.
- [x] List local TCP listening sockets and owning process names where permitted; no remote port scanning.
- [x] Add optional gateway/public-IP ICMP checks and DNS resolution test.
- [x] Export timestamped JSON/TXT reports and CSV adapter inventory.
- [x] Add bilingual dashboard launcher and safety/limitations documentation.
- [ ] Validate PowerShell 5.1 cmdlet compatibility and live results on Windows 10/11.
- [ ] Add optional user-selected bandwidth test with explicit endpoint and privacy disclosure.

## v0.46.0-dev — Process & Performance Manager
- [x] Add CPU/OS memory, top-process, running-service, and fixed-disk inventory.
- [x] Export timestamped JSON/TXT/CSV reports.
- [x] Add optional process stop with PID guard, protected-name denylist, warning, and exact typed confirmation.
- [x] Add bilingual dashboard entry and manual CMD/PowerShell launcher.
- [ ] Validate PowerShell 5.1/CIM behavior on Windows 10/11 and test against disposable processes.
- [ ] Add sampled performance history and more robust process protection policy.

## v0.47.0-dev — Startup & Services Manager
- Added read-only inventory for Windows startup command registrations and service state/start mode.
- Added timestamped JSON/TXT/CSV reporting and dashboard launcher.
- No service/startup mutations are supported in this release.
- Windows runtime validation remains pending.

## v0.48.0-dev — Windows Optimization Center
- [x] Add read-only fixed-drive capacity and free-space inventory.
- [x] Add bounded temporary-folder file inventory (default 5,000 files per location).
- [x] List registered startup entries without claiming measured boot impact.
- [x] Export timestamped JSON/TXT and storage CSV reports.
- [x] Add bilingual dashboard entry, manual launcher, and safety documentation.
- [ ] Validate PowerShell 5.1 behavior and scan performance on Windows 10/11.
- [ ] Consider a separately consented cleanup workflow only after preview, exclusion rules, backup strategy, and rollback tests are designed.


## v0.49.0-dev — Windows Repair Center (read-only)
- Added OS/update-service/disk inventory and optional SFC verify-only, DISM ScanHealth, and CHKDSK online scan actions.
- No repair, update reset, cache deletion, service mutation, registry write, or reboot is automated.
- Windows runtime validation remains pending.


## v0.50.0-dev — Firewall & Privacy Center
- [x] Add read-only Windows Firewall profile inventory and enabled allow/block rule summaries.
- [x] Add selected UAC, SmartScreen, advertising, app-privacy, and telemetry policy snapshots.
- [x] Add bounded established TCP connection inventory and network profile details.
- [x] Export timestamped JSON/TXT reports and integrate a bilingual dashboard launcher.
- [ ] Validate PowerShell 5.1 and Windows 10/11 behavior on real systems; review report privacy before sharing.
- [ ] Consider a separately designed, approval-gated rule review workflow; no rule mutation is included now.


## v0.51.0-dev — Event Viewer & Log Analyzer
- [x] Add read-only System/Application event-log queries with bounded severity/date/ID/count filters.
- [x] Export timestamped JSON/TXT/CSV and add bilingual dashboard launcher.
- [x] Document event-message privacy, query limits, and interpretation cautions.
- [ ] Validate PowerShell 5.1 behavior and live event retrieval on Windows 10/11.
- [ ] Consider optional provider-specific grouping only after Windows runtime tests.


## v0.52.0-dev — Software & Installed Apps Manager
- [x] Inventory standard native, 32-bit, and current-user Windows Uninstall registry entries.
- [x] Add scope and display-name filtering with bounded results.
- [x] Export timestamped JSON/TXT/CSV reports.
- [x] Integrate dashboard launcher and bilingual safety documentation.
- [x] Include deployment scripts in portable package output.
- [ ] Validate PowerShell 5.1 registry behavior and inventory accuracy on Windows 10/11.
- [ ] Evaluate a future approval-gated uninstall workflow separately; this release is inventory-only.

## v0.53.0-dev — Windows Update Manager
- [x] Add consent-gated read-only Windows Update Agent software-update search.
- [x] Add bounded recent update history and Windows Update service status.
- [x] Export timestamped JSON/TXT/CSV and integrate dashboard launcher.
- [ ] Validate WUA COM search/history on Windows 10/11 with Microsoft Update and WSUS policies.
- [ ] No automatic download/install or update-policy changes are in scope for this release.


## v0.54.0-dev — Owner Permissions & User Edition Builder
- [x] Add native owner console with named user/edition labels and per-capability checkboxes.
- [x] Save reusable profiles under `profiles/` without changing the owner's active policy.
- [x] Add dashboard feature gating and owner-console visibility for exported editions.
- [x] Export separate runtime folders containing only granted module executables and launchers.
- [x] Add edition manifest and SHA-256 inventory.
- [ ] Build and run both MSVC and MinGW targets on Windows 10/11.
- [ ] Validate PowerShell 5.1 package export and test profile round-trip.
- [ ] Add signed policy verification, Authenticode signing, and tested NTFS ACL deployment before claiming tamper resistance.


## v0.55.0-dev — User Profile Lifecycle
- [x] List, load, edit, revoke, and delete owner-managed profiles.
- [x] Create a new recipient profile without restarting the owner console.
- [x] Track Active/Revoked status, revision, UTC update time, and local audit events.
- [x] Block future exports from revoked/inactive profiles and include profile revision in edition manifest.
- [ ] Test owner GUI and profile lifecycle on Windows 10/11.
- [ ] Validate PowerShell 5.1 export and revoked-profile rejection.
- [ ] Implement signed policy verification and Authenticode before tamper-resistance claims.
- [ ] Evaluate central policy validation only if remote revocation is required.

## v0.56.0-dev — License & Security Authority foundation
- [x] Separate owner-side RSA-3072 keypair generation; private key protected using Windows DPAPI.
- [x] User-edition manifest schema 2 with EditionId, profile revision, issue time, optional expiry, and explicit no-binding mode.
- [x] Detached RSA/SHA-256 signing of manifest + SHA-256 file inventory.
- [x] Offline verifier checks signature, inventory hashes, path containment, and optional expiry.
- [ ] Windows PowerShell 5.1 key generation/sign/verify integration tests.
- [ ] Native startup signature enforcement and trusted public-key provisioning.
- [ ] Authenticode signing and certificate-chain validation.
- [ ] Owner-selectable device/account binding with privacy disclosure and robust rebind workflow.
- [ ] Central license service, authenticated check-in, policy distribution, and remote revocation.
- [ ] Boot Manager, independent bootloader, ISO chainloading, UEFI/BIOS and Secure Boot implementation/testing.
- [ ] Complete polished GUI redesign, true animated/video backgrounds, and full native module integration testing.
- [ ] Windows x86/x64 MSVC/MinGW builds, PowerShell runtime, USB hardware tests, and release qualification.

These unchecked items are genuine outstanding engineering work; they are not represented as completed by this source-only increment.


## v0.57.0-dev — Signed Edition Launch Gate
- [x] Include the public verification key in the issued edition before generating its signed inventory.
- [x] Include the verifier in exported editions and verify the detached signature, expiry, inventory, and file hashes before the launcher starts the dashboard.
- [x] Reject duplicate inventory paths and unlisted files.
- [ ] Replace launcher-level trust with a native signed bootstrapper / pinned trust anchor.
- [ ] Execute PowerShell 5.1 end-to-end tests on Windows 10/11, including tamper, expiry, missing-file, and path traversal cases.
- [ ] Add Authenticode signing and trusted certificate-chain validation.

The launcher gate is defense-in-depth only; it is not resistant to a local administrator who can replace the launcher, verifier, or bundled public key.


## v0.58.0-dev — Optional Account Binding & Boot Preflight
- [x] Optional Windows account SID binding using a SHA-256 SID hash in the signed manifest.
- [x] Verifier rejects unsupported binding modes, future issue timestamps, revoked manifest state, and reparse points.
- [x] Read-only Boot Manager preflight for firmware mode and disk inventory.
- [ ] Native in-process license verification / protected bootstrapper.
- [ ] Authenticode publisher certificate and signing pipeline.
- [ ] Central license issuance, heartbeat policy, signed revocation distribution, and offline grace design.
- [ ] Independent bootloader, ISO compatibility/chainloading, media writer, Secure Boot trust chain, and hardware qualification.
- [ ] Final polished GUI and Windows 10/11 x86/x64 qualification.

The v0.58 Boot Manager work is inventory-only; it does not create bootable media or modify disks.


## v0.59.0-dev — Offline signed revocation snapshots
- Edition signing emits a revocation snapshot and detached RSA/SHA-256 signature.
- Verification validates the snapshot signature and blocks revoked EditionId values.
- Owner may supply a JSON RevokedEditionIds GUID list when signing.
- This is offline snapshot enforcement only; live remote revocation and central service remain future work.
- Windows PowerShell 5.1 cryptographic runtime validation remains outstanding.

## v0.60.0-dev — Central License Authority reference service
- Added a loopback-first Python/SQLite control-plane reference for EditionId revoke/restore, authenticated snapshot retrieval, and audit history.
- Snapshot output is intentionally unsigned; the owner must sign it offline with the existing RSA authority before distributing it.
- Added unit tests for revoke/restore, snapshot, audit, idempotency, and input validation.
- Not production-ready: no built-in TLS/MFA/HA/remote updater; native in-process enforcement and Authenticode remain pending.


## v0.61.0-dev — Central Authority Revisioning
- [x] Persist a monotonically increasing revision for each actual revoke/restore state transition.
- [x] Include the revision in the central snapshot and audit events.
- [x] Preserve the revision in the owner-signed offline revocation artifact and validate its format.
- [ ] Add a trusted client-side high-water mark with rollback-resistant storage; simple portable-file storage is not sufficient against a local administrator.
- [ ] Add authenticated operator identities, MFA, TLS deployment, backups, and production operations.
- [ ] Native C++ enforcement, Authenticode, independent bootloader, GUI redesign, and Windows qualification remain release gates.

## v0.62.0-dev — Local revocation anti-rollback
- [x] Verifier stores the highest accepted signed revocation revision per EditionId under the current Windows user's LocalAppData.
- [x] Protect local high-water state with DPAPI CurrentUser and atomic temp-file replacement.
- [x] Reject a signed snapshot whose revision is lower than the previously accepted revision; accept equal and advance on higher.
- [x] Document limits: local administrators/profile rollback/state deletion can bypass local state; offline clients still require snapshot delivery.
- [ ] Windows PowerShell 5.1 DPAPI execution and rollback fault-injection tests.
- [ ] Hardware-backed monotonic state or authenticated online freshness service for stronger rollback resistance.

## v0.63.0-dev — Central Authority Access Hardening
- [x] Split read-only and mutation bearer credentials (`ITVIP_READ_TOKEN` / `ITVIP_ADMIN_TOKEN`).
- [x] Require administrator authorization for revoke/restore routes.
- [x] Add bounded operator audit labels via `X-ITVIP-Actor` (label only; not identity proof).
- [x] Add optional direct TLS listener; remote bind requires TLS certificate and private key, TLS 1.2 minimum.
- [x] Enable SQLite WAL and FULL synchronous mode for the reference store.
- [x] Add HTTP-level tests for health/auth boundaries, read-only role, mutation role, and audit actor normalization.
- [ ] Provision/rotate real TLS certificates and test external HTTPS clients.
- [ ] Add real operator identity, MFA, rate limiting, operational monitoring, backup/restore drills, and HA before production deployment.
- [ ] Native C++ license enforcement, Authenticode, independent bootloader, final GUI and Windows qualification remain open release gates.


## v0.64.0-dev — Tamper-evident central audit
- [x] Chain audit rows using canonical SHA-256 hashes and previous-event pointers.
- [x] Verify chain integrity through authenticated `/v1/audit/verify`.
- [x] Migrate legacy rows and close SQLite connections deterministically.
- [x] Test tamper detection, migration, and HTTP verification.
- [ ] Add signed external checkpoints or WORM log forwarding; the local unkeyed hash chain is recomputable by a database administrator.
- [ ] Verified operator identities/MFA, rate limiting, monitoring, tested backup/restore, production deployment, native C++ license enforcement, Authenticode, independent bootloader, polished GUI, and Windows qualification remain open.


## v0.65.0-dev — Native license launch orchestrator
- Added a native Win32 bootstrapper target for MSVC and MinGW.
- User edition packaging requires the bootstrapper; the compatibility CMD launcher delegates to it.
- Bootstrapper waits for the existing PowerShell verifier and launches the dashboard only on success.
- This is orchestration, not native cryptographic enforcement; PowerShell remains the verifier and Authenticode/trusted bootstrap chain remain future release gates.


## v0.67.0-dev — Native license policy enforcement
- [x] Add source implementation for native UTC expiry/issue checks, optional Windows SID binding, and DPAPI CurrentUser anti-rollback state.
- [ ] Compile and test CNG/DPAPI/SID paths on Windows 10/11 x86/x64 with signed test editions.
- [ ] Add Authenticode signing and a trusted publisher verification chain.
- [ ] Complete independent review of native JSON parsing and trust-chain hardening.

## v0.68.0-dev — Native edition-tree hardening
- [x] Reject reparse points/junctions in inventory path components and the full edition tree.
- [x] Reject unlisted files and case-insensitive duplicate paths in the native verifier.
- [x] Validate the signed revocation schema before mutating DPAPI anti-rollback state.
- [ ] Replace regex-based JSON field extraction with a vetted JSON parser and fuzz malformed manifests/inventories.
- [ ] Compile and run native CNG/DPAPI tests on Windows 10/11 x86/x64; add signed fixture editions.
- [ ] Authenticode-sign and verify the bootstrapper/verifier chain.

## v0.69.0-dev — Native JSON syntax gate and revocation ordering
- [x] Add bounded strict JSON syntax validation for signed manifest, inventory, and revocation documents.
- [x] Reject duplicate object keys, malformed escapes/numbers, trailing bytes, oversized documents/strings, and excessive nesting.
- [x] Check current EditionId revocation membership before mutating the DPAPI anti-rollback high-water mark.
- [ ] Replace regex field accessors with a vetted typed JSON parser and strict schema validation.
- [ ] Fuzz malformed and adversarial signed fixtures; compile and run CNG/DPAPI/SID and filesystem tests on Windows 10/11 x86/x64.
- [ ] Authenticode, independent bootloader, production license service, final GUI, and full Windows qualification remain open.

## Native license verifier progress — v0.70.0-dev
- Replaced regex-based JSON policy extraction with a typed, dependency-free JSON DOM parser.
- Added UTF-8 and Unicode-surrogate validation, duplicate-key rejection, bounded node/depth/string/document sizes, and strict typed schema access.
- Added portable C++17 parser tests; Windows API integration still requires MSVC/MinGW and Windows 10/11 runtime qualification.


## v0.71.0-dev — Native JSON fuzzing
- Added deterministic mutation testing and a libFuzzer target for the native JSON parser.
- Bounded ASan/UBSan libFuzzer campaign completed 20,000 executions without a crash or sanitizer finding.
- Remaining release gates: longer fuzzing, Windows C++ build/runtime, CNG/DPAPI/SID integration, Authenticode, and Windows 10/11 x86/x64 qualification.

### v0.72.0-dev — Native license schema hardening
- Enforce exact revocation snapshot schema, strict UTC timestamp syntax, bounded unique revocation IDs, and inventory size ceilings.
- Remaining qualification: Windows compiler/runtime integration, cryptographic API tests, filesystem race analysis, and signed-package end-to-end tests.

## v0.73.0-dev — Windows CI readiness
- [x] Add GitHub Actions Windows 2022 MSVC matrix for x64 and x86.
- [x] Add Linux parser, deterministic sanitizer smoke, license authority, and Python syntax jobs.
- [ ] Execute hosted CI on GitHub and resolve compiler diagnostics from actual MSVC output.
- [ ] Run native verifier and bootstrapper on Windows with CNG, DPAPI, SID binding, and rollback cases.
- [ ] Add signed release pipeline only after trusted certificate and key-handling policy are established.


## v0.74.0-dev — Windows build output qualification
- [x] Remove stale EXE outputs before each build.
- [x] Verify all expected native EXEs exist after build.
- [x] Verify PE machine type matches x86/x64 CI matrix.
- [x] Compile and run portable JSON tests with MSVC in the Windows workflow.
- [ ] Execute GitHub-hosted Windows matrix and resolve actual compiler/runtime failures.
- [ ] Run CNG/DPAPI/SID and signed-edition end-to-end tests on Windows 10/11.

## v0.75.0-dev — Native verifier bounded file I/O
- [x] Check file size before allocating buffers in the native verifier; reject files that exceed the configured read cap.
- [x] Apply tighter independent limits to the signed manifest (4 MiB), inventory (64 MiB), revocation snapshot (16 MiB), and DPAPI anti-rollback state (64 KiB).
- [x] Detect short reads or files changed during the read operation and fail closed.
- [ ] Compile with MSVC x86/x64 and execute signed-fixture tests on Windows; the CNG/DPAPI paths are not exercised by Linux tests.
- [ ] Add a Windows fixture harness for oversized metadata, inventory file changes, junction/reparse-point cases, signature tampering, and rollback.

### v0.76 — Portable Apps large-folder import
- [x] Add recursive application-folder import into portable/apps.
- [x] Stream/copy large files with CopyFileExW; do not load full files into RAM.
- [x] Preflight total size and free space; confirm before copying; show progress.
- [x] Preserve source and skip symbolic links.
- [ ] Windows x86/x64 compile and runtime validation.
- [ ] Physical USB tests on exFAT and NTFS, including >4 GB single files, interrupted copies, and low-space conditions.


## v0.77.0-dev — Portable import reliability
- Stage imports under a temporary sibling directory and publish by same-volume rename only after all files copy and size/count checks pass.
- Fail closed on unreadable entries rather than skipping permission-denied paths.
- Validate per-file copied size and aggregate file count/bytes; use overflow-safe progress math.
- Remaining: Windows/MSVC build, USB filesystem matrix tests (FAT32/exFAT/NTFS), interruption/cancellation, free-space races, and optional SHA-256 verification.


### Portable storage follow-up
- [x] Compare imported source/destination content using streaming SHA-256 after each file copy.
- [ ] Move the synchronous import workflow to a cancellable worker thread with safe UI progress messaging.
- [ ] Add a portable storage dashboard (volume, filesystem, free/used space, imported app sizes).
- [ ] Add guarded rename/move/delete operations and per-app re-verification.
- [ ] Validate large-file imports on Windows 10/11 and real exFAT/NTFS USB media.

- [x] v0.79: Add informational Portable Apps storage overview (file count, total bytes, free space, filesystem type, FAT32 warning, open folder).
- [ ] Next: implement safe imported-folder rename/move/delete with strict path containment, confirmation, and rollback-aware behavior.
- [ ] Move long import and inventory operations off the Win32 UI thread with cancellation and safe progress messaging.


### Portable Apps follow-up (v0.80)
- [x] Source-level rename of an imported application folder using its card display name, with collision refusal and registered path updates.
- [x] Source-level confirmed deletion of an imported top-level folder, constrained to portable/apps.
- [ ] MSVC x86/x64 build and Windows/physical-USB tests for rename/delete failure cases.
- [ ] Background/resumable copy and move workflow; not implemented in v0.80.

- v0.81: Fast Copy utility for folder transfers in either direction between PC and USB; background copy, progress, cancellation, destination capacity preflight, no-overwrite. Pending Windows runtime and real-device throughput tests.

## v0.82 visual identity follow-up
- [x] Shared crowned-V icon and common Win32 dark cyberpunk styling for existing GUI windows.
- [x] Embed shared icon in MSVC/MinGW build outputs and apply a Windows GUI subsystem to Portable Apps Manager and Fast Copy.
- [ ] Validate visual behavior on Windows 10/11 at multiple DPI settings and both x86/x64.
- [ ] Migrate the six console utilities to dedicated graphical interfaces using the same shared visual layer.
- [ ] Replace stock Win32 buttons with a polished custom control set after Windows runtime qualification.


## v0.83 GUI localization and branded front-ends
- Delivered source-level branded GUI entry points for the six remaining core console tools.
- Shared language preference is stored in `config/appearance.ini` (`Language=ar|en`); Arabic is the default.
- Existing CLI engines are retained as separate backends to avoid rewriting security-sensitive operations during a UI pass.
- Next: migrate backend output into an in-window asynchronous job console, unify localization across every existing standalone GUI, and validate RTL layout under Windows 10/11.


## v0.83.1-dev — Branded front-end reliability
- [x] Fix localized module heading so it appears in the GUI content area.
- [x] Quote Windows process arguments safely for selected paths, report destinations, and account names.
- [x] Reject engine paths that are not regular files.
- [x] Capture engine stdout/stderr inside the GUI with a background process worker, Stop action, indeterminate activity indicator, and exit-code reporting (v0.83.2-dev source implementation).
- [ ] Complete shared Arabic/English persistence and RTL audit across remaining standalone modules.
- [ ] Build and exercise all six front-ends on Windows 10/11, x86/x64.


## v0.83.2-dev — Embedded asynchronous tool console
- [x] Redirect legacy engine stdout/stderr to a GUI-owned pipe and display output in a read-only panel.
- [x] Consume output on a background worker so the Win32 UI remains responsive.
- [x] Add process cancellation request, indeterminate activity indicator, and exit-code reporting.
- [ ] Compile all six GUI targets with MSVC and MinGW on Windows x86/x64.
- [ ] Exercise cancellation, long output, non-ASCII output, process failures, and window-close behavior on Windows 10/11.
- [ ] Add structured progress reporting only after the CLI engines expose a stable progress protocol.

## v0.83.3-dev — VIP Studio responsive window
- [x] Make the full Customization Center reachable on shorter displays using adaptive window sizing, a vertical scrollbar, and mouse-wheel navigation.
- [x] Preserve the existing appearance settings and profile format.
- Remaining validation: Windows 10/11 runtime, high-DPI, RTL, and multi-monitor testing.


## v0.83.4-dev — Boot Manager preflight inventory detail
- [x] Extend read-only disk inventory with available hardware identity and offline/read-only state.
- [x] Add read-only partition and volume/filesystem details to JSON and TXT reports.
- [x] Record partial inventory failures as explicit warnings.
- [x] Keep candidate hints informational; no disk selection or destructive operation is authorized.
- [ ] Run PowerShell 5.1 checks and storage-provider tests on Windows 10/11 with removable and fixed disks.
- [ ] Design and review a separately gated, signed bootloader architecture before any media-writing implementation.


## v0.83.5-dev — shareable Boot Manager reports
- [x] Add optional redaction of computer name, disk serial number, and UniqueId in JSON/TXT preflight reports.
- [x] Record redaction state and forward launcher arguments.
- [x] Add static contract tests and document remaining visible inventory fields.
- [ ] Execute PowerShell 5.1 and Windows Storage tests on Windows 10/11.


## v0.83.6-dev / Package v90 — System Diagnostics Center
- Added a read-only Windows system diagnostics workflow with bounded CPU/memory sampling, fixed-volume capacity, active physical network adapter counters, and optional ACPI thermal-zone readings.
- Exports timestamped JSON, TXT, HTML, and CSV reports; unavailable providers are reported as warnings rather than fabricated values.
- Thermal readings are conditional on firmware/driver exposure. Network byte counters are cumulative, not throughput or an internet speed test.
- PowerShell 5.1 execution and Windows 10/11 provider behavior remain pending real Windows validation.


## v0.83.7-dev — Diagnostics thresholds and history (Package v91)
- [x] Add configurable, bounded CPU, memory, and disk-free warning thresholds.
- [x] Include threshold alerts in JSON, TXT, and HTML reports.
- [x] Persist CPU/memory samples to a local CSV history capped at 1,000 rows.
- [x] Add a dark HTML status summary and contract tests.
- [ ] Validate PowerShell 5.1 parsing/execution and threshold behavior on Windows 10/11.
- [ ] Validate long-running history maintenance and localized display on Windows.


## v0.83.8-dev — bounded live diagnostics (Package v92)
- [x] Add optional live console sampling for CPU and memory with bounded duration and sample count.
- [x] Estimate physical network adapter receive/send rates from counter deltas; label rates as approximate and not internet speed.
- [x] Include rates in timestamped sample/report outputs and add contract tests.
- [ ] Validate PowerShell 5.1 parsing and live execution on Windows 10/11 across Ethernet, Wi-Fi, disconnected, and changing-adapter scenarios.
- [ ] Integrate live status into the native Dashboard only after Windows UI and threading tests.


## v0.83.9-dev / Package v93 — Native Live System Monitor
- [x] Add a dedicated native Win32 live-monitor executable with bilingual labels.
- [x] Integrate a Dashboard action and capability key for the monitor.
- [x] Sample CPU, RAM, active non-loopback network counters, and Windows system-volume capacity using read-only APIs.
- [x] Add start, pause/resume, stop, bounded session duration, and rolling graphs.
- [x] Append session samples to a local CSV report.
- [ ] Compile MSVC and MinGW targets on Windows x86/x64.
- [ ] Test CPU/network counter accuracy, pause/resume, session timeout, DPI, and RTL on Windows 10/11.

## v0.83.10-dev / Package v94 — Shared UI Audio Feedback

- Added short, non-blocking click and descending back cues using bundled WAV assets.
- Added a persisted mute toggle in VIP Studio (`[Audio] Enabled=0|1`).
- Routed button-click and window-close feedback through the shared native audio helper in the dashboard, native modules, branded tool windows, and Live System Monitor.
- Added WinMM link dependencies for MSVC and MinGW GUI targets.
- Actual playback and sound-level validation remain pending on Windows 10/11.

## v0.83.12-dev / Package v96 — Custom UI Audio
- [x] Add six per-event custom WAV import controls to VIP Studio.
- [x] Copy imported WAV assets into the project and persist relative paths per cue.
- [x] Enforce a 20 MiB import limit and RIFF/WAVE signature check.
- [x] Fall back to bundled cue assets when a custom path is missing.
- [ ] Validate custom WAV decoding, audible playback, and UI flow on Windows 10/11.
- [ ] Evaluate custom hover/press animations after native Windows rendering and DPI tests.

## أصوات الواجهة المخصصة (v0.83.12-dev / الحزمة v96)
- [x] إضافة عناصر استيراد WAV مستقلة للنغمات الست داخل VIP Studio.
- [x] نسخ الأصوات إلى مجلد المشروع وحفظ المسار النسبي لكل نغمة.
- [x] فرض حد 20 ميجابايت والتحقق من توقيع RIFF/WAVE.
- [x] الرجوع إلى ملفات الصوت المرفقة إذا فُقد الملف المخصص.
- [ ] اختبار فك الترميز والتشغيل المسموع وتفاعل الواجهة على Windows 10/11.
- [ ] تقييم تأثيرات Hover/Press بعد اختبارات الرسم وDPI الفعلية على Windows.


## v0.83.13-dev / Package v97 — Optional Lifecycle Audio
- Added dedicated startup and shutdown WinMM cues with short bundled PCM WAV assets.
- Added separate VIP Studio enable switches and preview controls.
- Lifecycle cues are opt-in and default to disabled for backward-compatible, non-surprising startup behavior.
- Existing six cue imports, custom path fallback, and master mute remain unchanged.
- Windows audio playback and MSVC/MinGW compilation remain pending native Windows validation.


## v0.83.14-dev / Package v98 — Dashboard Button Feedback
- [x] Add theme-colored hover outline to dashboard native buttons.
- [x] Add stronger alternate-accent outline while the mouse button is held.
- [x] Preserve standard BUTTON input/keyboard/accessibility handling via subclass delegation.
- [ ] Extend visual treatment to VIP Studio and individual tool windows after native Windows DPI/runtime verification.
- [ ] Validate MSVC/MinGW builds and Windows 10/11 hover, press, capture-loss, keyboard, and high-DPI behavior.


## v0.83.15-dev / Package v99 — Native Startup Splash
- [x] Add a centered, lightweight native Win32 startup splash before the dashboard.
- [x] Use the saved UI language and selected theme accent; Arabic remains the first-run default.
- [x] Automatically dismiss the splash after 850 ms without adding a dependency or changing module launch behavior.
- [ ] Validate appearance, timing, DPI scaling, and startup behavior on Windows 10/11.
- [ ] Build with MSVC and MinGW; neither toolchain is available in this Linux validation environment.

## v0.83.16-dev — Notification Center and desktop polish (v100)
- Added a lightweight native Win32 toast window with themed border, bilingual heading/body, slide-in and fade-out animation, non-activating display, and click-to-open notification history.
- Added append-only local notification history at `reports/ui_notifications.log`; records use local timestamps and contain UI event messages only.
- Dashboard module launch success/failure and missing-module feedback now use the toast notification path; notification sounds use the existing user-configurable notification cue.
- Added per-monitor-v2 DPI awareness through a dynamically resolved Windows API with legacy system-DPI fallback. This establishes process awareness; every child layout has not yet been independently validated at mixed monitor scales.
- Remaining: full per-monitor child-control relayout, toast queue/deduplication, notification-center filtering/retention controls, and Windows MSVC/MinGW build plus interactive runtime verification.

v0.83.17-dev — Package v101
- Added an in-app bilingual Notification Center opened from the dashboard and toast popups.
- Added live text search, refresh, explicit-confirmation clear, and open-log actions.
- Added a bounded FIFO toast queue (maximum 50 waiting entries) so new events no longer replace the active toast.
- Added notification-log retention: when the log exceeds 512 KiB it is compacted to the newest 1,000 lines.
- Extended the existing dashboard button hover/pressed accent effect to VIP Studio child buttons.
- Windows native build and interactive GUI behavior remain pending until verified on Windows with MSVC or MinGW.



## v103+ follow-up
- Extend completion notifications to `.cmd` and PowerShell-launched utilities with explicit wrapper exit-code propagation.
- Complete DPI-aware text rendering, minimum-size behavior, and responsive layouts in VIP Studio and secondary dialogs.
- Test MSVC and MinGW builds plus Windows 10/11 multi-monitor runtime behavior.


v0.83.18-dev — Package v102
- Added responsive dashboard reflow for top commands, core tools, and standalone module launchers.
- Added DPI-scaled control placement and a minimum tracking size.
- Added process-exit notifications with numeric exit status for standalone modules started through the dashboard process API.
- Remaining: responsive secondary windows, DPI-aware text rendering, script-launch exit-code propagation, and native Windows verification.

## v103 — Script process tracking and secondary tool DPI groundwork
- [x] Launch dashboard deployment CMD utilities through tracked `CreateProcessW` processes and report their process exit code through the existing notification queue.
- [x] Enable per-monitor DPI awareness in branded tool executables with a legacy fallback.
- [x] Handle `WM_DPICHANGED` and resize the output, progress, and status regions with the client area.
- [ ] Audit each deployment batch wrapper for explicit `exit /b` propagation so inner PowerShell/native failures are reflected reliably.
- [ ] Reflow every branded tool input/action control and all secondary dialogs at narrow widths and mixed-DPI monitor transitions.
- [ ] Build with MSVC/MinGW and test on Windows 10/11.

## v0.83.20-dev — Tool execution audit and exit-code propagation (v104)
- Added a local bounded local TSV execution history for launched native modules and deployment CMD tools. Each completed process records local timestamp, executable/script filename, numeric process exit code, and SUCCESS/NONZERO_EXIT classification.
- Normalized PowerShell-backed CMD launchers to capture the PowerShell process exit code and return it from the wrapper after the interactive pause, so the dashboard process watcher can report failures accurately.
- History is stored locally at `reports/tool_execution_history.tsv`; it is not uploaded or shared.
- Remaining: run CMD/PowerShell integration tests on Windows PowerShell 5.1 and PowerShell 7; confirm console close behavior and nonzero propagation on Windows 10/11.


## v0.83.21-dev / Package v105 — Command Center
- [x] Add a native dashboard Command Center with live process rows for dashboard-launched native modules and deployment CMD wrappers.
- [x] Show PID, elapsed time, completion timestamp, exit code, and outcome classification.
- [x] Add live text search, Running/Success/Failed filters, manual refresh, open-log, and CSV export.
- [x] Extend new TSV records with duration and PID while retaining compatibility with legacy four-column v104 records.
- [x] Keep the view observational: it does not terminate, restart, or elevate processes.
- [ ] Build with MSVC and MinGW and test the list view, DPI, filters, export, and process lifecycle on Windows 10/11.
- [ ] Add capture of stdout/stderr and structured operation-level results only where individual tools can safely and consistently provide them.


## v0.83.22-dev / Package v106 — Windows Build CI hardening
- [x] Extend the native output verifier to check every executable emitted by the build dispatch, including copy manager and all standalone tool GUIs.
- [x] Support PE architecture inspection with MSVC `dumpbin` and MinGW `objdump`.
- [x] Add a MinGW-w64 x64 GitHub Actions build, architecture verification, native JSON test, and artifact upload.
- [x] Add source-contract tests tying build outputs, cleanup targets, verifier coverage, and CI configuration together.
- [ ] Run the GitHub Actions MSVC x86/x64 and MinGW x64 jobs and resolve any real compiler diagnostics.
- [ ] Add a maintained MinGW x86 toolchain job when a supported runner/toolchain is available.
- [ ] Complete Windows 10/11 GUI and PowerShell runtime qualification; signing and production licensing remain separate gates.

## v0.83.23-dev / Package v107 — PowerShell process runtime gate
- [x] Add an isolated Windows CMD/PowerShell integration fixture for exit codes 0 and 23.
- [x] Add Windows CI execution under Windows PowerShell 5.1 and PowerShell 7.
- [x] Add host-side source-contract tests and document the fixture's exact scope.
- [ ] Execute the workflow and retain passing logs for both PowerShell editions.
- [ ] Test each deployment script's semantic output and failure modes on Windows; process exit propagation alone is not semantic validation.
- [ ] Complete Windows 10/11 GUI, mixed-DPI, storage/USB, signing, licensing, and bootable Boot Manager gates listed in the v107 audit.

## v0.83.24-dev / Package v108 — Secondary tool responsive layout
- [x] Reflow branded secondary-tool headings, path/account inputs, browse control, action buttons, status, stop control, progress bar, and output pane when the window is resized.
- [x] Wrap the second action button onto a separate row when the client width is insufficient, avoiding horizontal clipping.
- [x] Add a minimum tracking size and rerun the same layout after `WM_DPICHANGED` using the current window DPI.
- [ ] Verify actual mixed-DPI movement, Arabic/English text clipping, and keyboard navigation on Windows 10/11.
- [ ] Apply the same per-control responsive audit to the remaining specialist windows that do not use the shared branded-tool front end.
- [ ] Complete native MSVC/MinGW builds and retain Windows CI execution logs.

## v0.83.25-dev / Package v109 — Storage safety hardening
- [x] Restrict Fast Copy partial-tree cleanup to a destination root successfully created by the current worker.
- [x] Make Backup Center fail closed on enumeration, metadata, copy, hashing, and manifest-write errors instead of silently skipping files.
- [x] Remove only the newly-created incomplete backup directory after a failed attempt; retain no-overwrite copy behavior.
- [x] Stage all restore files and snapshot existing destinations before commit; roll back committed files in reverse order on handled commit errors.
- [ ] Add Windows fault-injection tests for commit and rollback failures, forced termination, power loss, and filesystem-specific behavior; current rollback is not crash-consistent.
- [ ] Execute Windows/USB tests for NTFS, exFAT, FAT32 where supported, >4 GB files, low-space, disconnect, and cancellation cases.


v0.83.26-dev / Package v110 — Staged restore and rollback
- [x] Retain manifest sizes and SHA-256 digests in the restore plan and revalidate staged copies before commit.
- [x] Reject reparse-point components in backup and destination paths to reduce junction/symlink redirection risk.
- [x] Stage every incoming file and snapshot every existing destination before changing application files.
- [x] Commit staged files with same-volume MoveFileExW and roll back committed entries in reverse order after handled errors.
- [x] Preserve the transaction directory when rollback fails so recovery material is not deleted.
- [ ] Add Windows runtime fault-injection and crash-recovery tests; this is not a crash-consistent multi-file transaction.
- [ ] Complete native builds, Windows 10/11 GUI qualification, physical storage tests, signing/licensing, and bootable Boot Manager scope.


## v0.83.27-dev / Package v111 — Restore manifest path hardening
- [x] Reject non-canonical separators, absolute/rooted paths, traversal components, Windows ADS syntax, control characters, invalid filename characters, and trailing dot/space aliases in manifest paths.
- [x] Reject Windows reserved device-name segments (CON, PRN, AUX, NUL, COM1-9, LPT1-9).
- [x] Reject case-insensitive duplicate restore targets using invariant Windows case mapping.
- [x] Reject duplicate or unexpected FOLDER records and bound manifest line size, total records, and file count.
- [ ] Execute native Windows builds and runtime tests; validate the path policy against real NTFS/exFAT/FAT32 media and Windows path edge cases.
- [ ] Continue the existing Windows crash-recovery, signing/licensing, GUI qualification, and bootable Boot Manager release gates.


## v0.83.28-dev / Package v112 — Restore recovery journal
- [x] Persist restore transaction phases and target metadata in a flushed, write-through journal before/after commit boundaries.
- [x] Detect journal-bearing restore transaction directories on Backup Center startup and offer operator inspection.
- [x] Preserve interrupted transaction folders; do not automatically delete or replay potentially unsafe recovery state.
- [ ] Run Windows fault injection at each journal boundary, including forced termination and storage interruption.
- [ ] Complete Windows builds, filesystem/USB tests, GUI qualification, signing/licensing, and Boot Manager scope decisions.


## v0.83.29-dev / Package v113 — Read-only recovery inspector
- [x] Add a PowerShell 5.1-compatible, read-only inspector for retained restore transaction journals.
- [x] Validate journal schema, phases, UTF-8 paths, approved roots, duplicate paths, traversal aliases, and reserved Windows names.
- [x] Report target/original/staged file presence without performing recovery or cleanup.
- [x] Add isolated Windows CI fixture for valid and malformed journal cases to the PowerShell 5.1/7 matrix.
- [ ] Execute Windows CI and review logs on both PowerShell editions.
- [ ] Add true native fault injection for forced termination and rollback/storage failures; complete filesystem qualification and production signing/licensing gates.


## v0.83.30-dev / Package v114 — Restore crash-boundary model
- [x] Add deterministic protocol-model stops after PREPARED, before/after each replacement, after APPLIED checkpoints, before COMMITTED, and after COMMITTED before cleanup.
- [x] Assert pending transaction evidence remains inspectable, including original snapshots and staged/destination file presence.
- [x] Cover the ambiguous move-completed/journal-still-APPLYING boundary.
- [x] Keep fault injection test-only; no environment-controlled production failpoint was introduced.
- [x] Remove the duplicate PowerShell recovery-inspector CI step.
- [ ] Run native Windows process-termination and storage-fault injection; the Python model is not a Windows crash-consistency test.
- [ ] Complete Windows builds, filesystem/USB qualification, GUI, signing/licensing, and Boot Manager release gates.


## v0.83.31-dev / Package v115 — License authority request and transaction hardening
- [x] Reject duplicate JSON object properties and non-standard JSON constants in authority mutation requests.
- [x] Require strict UTF-8, explicit `Content-Length`, bounded request bodies, and `application/json`; reject transfer-encoding request bodies.
- [x] Serialize revoke/restore write transactions with SQLite `BEGIN IMMEDIATE` before revision and audit-chain updates.
- [x] Add regression tests for ambiguous JSON, content-type errors, and concurrent writers preserving monotonic revisions and the audit chain.
- [ ] Execute authenticated TLS handshake and remote deployment tests with real certificates and hardened host/network policy.
- [ ] Perform Windows PowerShell 5.1/7 signing/verifying, Authenticode, DPAPI/CNG, and native verifier runtime qualification.
- [ ] Complete Windows builds, GUI/storage qualification, and Boot Manager scope decisions.


## v0.83.32-dev / Package v116 — Complete license audit export
- [x] Add authenticated `/v1/audit/export` returning all audit events in ascending ID order, beyond the 500-event interactive view.
- [x] Include an integrity summary (validity, checked count, first bad row, verified head) with the exported events.
- [x] Add regression coverage for a 505-event export and tampered-row detection.
- [ ] Forward exports to separately administered append-only/WORM storage and sign export manifests offline; the current chain is unkeyed SHA-256 and not tamper-proof.
- [ ] Execute real TLS/remote deployment tests, Windows builds/runtime qualification, filesystem tests, and remaining release gates.


## v0.83.33-dev / Package v117 — Server-controlled audit attribution
- [x] Stop trusting caller-controlled `X-ITVIP-Actor` for privileged audit events.
- [x] Attribute revoke/restore events using validated server-side `ITVIP_ADMIN_ACTOR` configuration.
- [x] Add a regression test proving a caller cannot spoof the stored audit principal.
- [ ] For person-level accountability, integrate individually authenticated identities or a trusted identity-aware gateway; a shared bearer token cannot identify a human.
- [ ] Execute Windows builds/runtime, TLS deployment, native signing/verifying, GUI/storage qualification, and remaining release gates.

## v118 — User-edition signing hardening
- [x] Reject reparse-point roots and entries during owner-side signing.
- [x] Validate and normalize signed inventory paths; reject ambiguous/reserved/duplicate paths.
- [x] Require RSA-3072 and verify the private/public authority key pair matches before signing.
- [x] Add Windows PowerShell 5.1/7 signing fixture to CI.
- [ ] Run the Windows fixture and native CNG verifier in successful CI.
- [ ] Complete Authenticode signing and production certificate lifecycle qualification.
