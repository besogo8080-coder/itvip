# IT VIP License Authority Security Review — v115

Date: 2026-11-25  
Baseline: `IT_VIP_v0.83.30-dev_COMPLETE_v114.zip`  
Candidate: `IT_VIP_v0.83.31-dev_COMPLETE_v115.zip`

## Scope reviewed

- `server/license_authority.py`
- `tests/test_license_authority.py`
- `deployment/Sign-ITVIPUserEdition.ps1`
- `src/app/license_native_verifier.cpp`
- `docs/CENTRAL_LICENSE_AUTHORITY.md`

## Changes implemented

1. Strict UTF-8 decoding for mutation request bodies.
2. Duplicate JSON object property rejection, preventing ambiguous `EditionId`/`Reason` interpretation.
3. Rejection of non-standard JSON constants such as `NaN` and `Infinity`.
4. Explicit `application/json` content type and decimal `Content-Length` validation, with the existing 8 KiB limit and rejection of `Transfer-Encoding`.
5. Exact body-length check before parsing.
6. SQLite `BEGIN IMMEDIATE` in revoke and restore before mutation, revision allocation, and audit-chain append.
7. Regression tests for malformed/ambiguous JSON, content type, non-standard constants, and concurrent writers.

## Findings and boundaries

- The central service does not sign licenses and does not hold the owner's RSA private key. The owner still signs exported revocation snapshots offline.
- The audit hash chain is unkeyed SHA-256. It detects accidental or unsophisticated row edits but is not tamper-proof against an administrator able to rewrite and recompute the database.
- `X-ITVIP-Actor` is caller-supplied and is not authenticated identity.
- The service has no built-in MFA, operator directory, rate limiting, HA, remote updater, or managed certificate lifecycle.
- The offline signing PowerShell workflow and native verifier were source-reviewed only in this environment. DPAPI, RSA-3072 signing/verification, CNG, Authenticode, and anti-rollback behavior require actual Windows execution.
- Existing local anti-rollback state is not an absolute boundary against local administrators, profile replacement, or state deletion.

## Validation boundary

Host-side Python tests, compileall, source validator, native JSON tests/fuzz, and archive checks are run for v115. No MSVC/MinGW build, Windows PowerShell runtime, real TLS handshake, Windows GUI test, Authenticode signature, or production deployment qualification is claimed.

**Status: cumulative development source package v115; not a production license service or Windows-qualified final release.**
