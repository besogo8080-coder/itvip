# IT VIP GitHub & Developer Hub — v0.23.0-dev

## Implemented in this source package
- Separate native Win32 executable: `src/modules/github_hub.cpp`.
- GitHub REST API over HTTPS using Windows WinHTTP.
- Personal Access Token saved in Windows Credential Manager under `ITVIP_GITHUB_TOKEN`; masked in the UI.
- Explicit user-triggered connection and repository listing (`GET /user`, `GET /user/repos?per_page=50&sort=updated`).
- Shows up to 50 repositories returned by GitHub, newest updated first.
- Clear saved credential action.
- Dashboard button launches `build/github_hub.exe`.
- Runs network calls on a worker thread to keep the UI responsive.

## Least-privilege setup
Use a GitHub fine-grained Personal Access Token limited to the intended owner/repositories. For public repository metadata, select only the minimum read-only metadata permission required by GitHub. Private repository visibility requires granting access to those selected repositories. Do not use classic broad `repo` scope unless the user understands and explicitly needs it.

## Deliberate limitations
This first GitHub integration is read-only repository listing. It does not read source files, create issues, write commits, open/merge pull requests, delete repositories, trigger Actions, or modify account settings. Those features require separate permission scopes, explicit per-action confirmation, audit logging, and additional testing. No repository content is uploaded to an AI provider by this module.

## Validation
Static source/packaging checks only. A Windows build, OAuth flow, and live GitHub API request have not been performed in this environment.
