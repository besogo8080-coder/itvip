# IT VIP Network Manager

The Network Manager is a manually launched, read-only Windows PowerShell inventory and diagnostics utility.

## Features
- Network adapter inventory: status, MAC address, link speed, media type, and virtual adapter flag.
- IPv4/IPv6 addresses, default gateways, and configured DNS servers.
- Adapter byte/packet counters and packet errors.
- Local TCP listening sockets with owning process names where accessible.
- Optional connectivity checks: gateway ICMP, two public IP ICMP checks, and DNS resolution for `example.com`.
- Timestamped JSON and TXT reports; CSV adapter inventory.

## Run
Double-click `deployment/Network-ITVIP.cmd`, or run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\Network-ITVIP.ps1 -Action All
```

Reports are written to `reports/`.

## Safety and limitations
- Read-only: does not change IP/DNS settings, routes, adapters, firewall rules, or services.
- The port list contains local TCP listeners only. It is not a remote port scanner.
- ICMP may be blocked; a failed ping does not prove internet access is unavailable.
- Link speed and counters depend on Windows driver/provider reporting.
- No bandwidth benchmark, packet capture, Wi-Fi password extraction, or remote host scanning is performed.
- Some fields may be unavailable on older Windows versions or under restricted accounts.
- PowerShell runtime behavior must be tested on Windows; static project validation is not a runtime test.
