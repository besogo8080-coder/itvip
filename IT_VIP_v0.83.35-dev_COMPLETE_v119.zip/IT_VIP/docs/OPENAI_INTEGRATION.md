# IT VIP AI Assistant — OpenAI Platform

## Current implementation
- Separate native Win32 GUI executable: `src/modules/ai_assistant.cpp`.
- OpenAI Responses API: `POST https://api.openai.com/v1/responses`.
- HTTPS transport through Windows WinHTTP.
- Bearer authentication.
- Default model field: `gpt-5.5`; users can change it to a model enabled for their API project.
- `store:false` is included in requests.
- API key is stored with Windows Credential Manager (`ITVIP_OPENAI_API_KEY`) and never written to project config/log files. The key edit control masks the value.
- User explicitly initiates every request. Reports are not collected or uploaded automatically.
- A background worker performs network I/O so the window remains responsive. The window cannot close while a request is in flight.
- API response text is displayed in the assistant window. HTTP errors are reported with status code.

## Build
`build.bat` builds `build\\ai_assistant.exe` and links `winhttp.lib` + `advapi32.lib` (MSVC) or `-lwinhttp -ladvapi32` (MinGW).

## Security and cost notes
- API requests may incur charges according to the user's OpenAI API account and model pricing/limits.
- Never share the key or paste it into prompts. Do not submit passwords, personal secrets, or sensitive data.
- The application sends only the prompt text the user entered, plus model metadata; it does not upload local files or scan reports automatically.
- Credential Manager protects the saved credential within the Windows user environment. The key is still available to the local app process while a request is made.
- `store:false` is a request setting and is not a blanket guarantee about all retention or abuse-monitoring policies; consult current OpenAI API data controls.

## Not yet implemented
- Direct import of IT VIP JSON/TXT reports; current workflow is manual paste.
- Streaming tokens, conversation history, model picker populated from API, cancellation, retry/backoff, detailed API error JSON parsing.
- A bundled server-side proxy. A desktop app cannot make an embedded API key secret from the machine's owner; each user should use their own key.

## Validation status
Static source and packaging checks only. A Windows/MSVC or MinGW build and live API call have not been performed in this environment.
