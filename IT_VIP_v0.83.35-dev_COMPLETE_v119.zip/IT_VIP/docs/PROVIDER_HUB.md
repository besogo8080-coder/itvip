# IT VIP Universal AI Provider Hub — v0.28.0-dev

The Provider Hub is a configuration catalog for AI provider endpoints. It stores provider name, protocol label, HTTPS base URL, default model, an API Manager profile ID reference, and enabled state in `config/providers.ini`.

## Security boundary
- API secrets are not stored in `providers.ini`; keep them in Universal API Manager / Windows Credential Manager.
- The provider entry stores only the API profile ID reference.
- Only HTTPS base URLs are accepted by this UI.
- Deleting a provider entry does not delete API credentials.

## Current scope
This release is a provider catalog and configuration foundation. It does not send chat prompts, perform provider-specific request signing, implement OAuth2, or execute agents. Protocol label is descriptive and does not imply compatibility. The next integration step is a shared HTTP transport and provider adapters with explicit request/response schemas, bounded response sizes, timeouts, and secret retrieval by API profile reference.

## Initial suggested entries
OpenAI-compatible endpoints can be represented with protocol `OpenAI-compatible`; other providers may require custom adapters even when they expose REST APIs.
