# IT VIP Backup & Restore Center

## Implemented
- Creates a timestamped backup in a user-selected destination outside the IT VIP application folder.
- Copies only `config`, `data`, `assets`, `portable`, and `reports`. Source, docs, build outputs, and Windows Credential Manager secrets are excluded.
- Writes `ITVIP_BACKUP.manifest` with version marker `ITVIP_BACKUP_V1`, approved folder entries, relative file paths, byte sizes, and SHA-256 digests.
- Before restore, validates the manifest, restricts paths to the approved top-level folders, rejects reparse-point path components, and verifies file sizes and SHA-256 digests.
- Restore stages every incoming file and snapshots every existing destination before changing application files.
- Staged files are rechecked against manifest size and SHA-256 values. Commit uses same-volume `MoveFileExW` operations.
- If a handled commit error occurs, already committed files are rolled back in reverse order. Newly created files are removed and overwritten files are restored from snapshots.
- If rollback itself fails, the private `.itvip_restore_txn_*` directory is retained for manual recovery.
- Requires explicit confirmation before applying a restore.

## Restore behavior and limits
- Restore copies validated backup files into matching folders under the application root. It does not delete extra files absent from the backup.
- The staged rollback protects against handled runtime errors; it is **not crash-consistent**. Power loss, forced process termination, or storage failure during commit/rollback can still require manual recovery.
- This is not a single atomic directory swap. Create a fresh backup before restoring.
- No cloud backup, encryption, scheduled backup, or differential backup is implemented.

## Privacy
Backups may contain configuration, local memory, chat history, and reports. They are not encrypted. Store them on a trusted drive. SHA-256 detects file changes relative to the manifest but is not a digital signature.

## Build and qualification
`build.bat msvc` or `build.bat mingw` builds `backup_center.exe`, launched from the main dashboard. The target links Windows CNG (`bcrypt`), Shell, and OLE APIs.
Source-contract checks do not replace MSVC/MinGW compilation or Windows restore/rollback fault-injection tests on NTFS/exFAT/FAT32.
