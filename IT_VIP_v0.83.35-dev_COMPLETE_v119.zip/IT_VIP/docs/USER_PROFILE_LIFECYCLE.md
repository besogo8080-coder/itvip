# IT VIP — User Profile Lifecycle (v0.55.0-dev)

## Owner controls
The Owner Permissions Console now supports multiple named profiles and a separate profile manager window. The owner can create a new profile, load an existing profile for editing, save a revision, export a separate edition, revoke a profile, or delete the local profile.

## Profile lifecycle
1. **Create:** choose **New profile**, enter an edition name and user label, then select the 36 capability bits.
2. **Save/update:** save writes the INI under `profiles/`, sets `Status=Active`, increments `Revision`, records `UpdatedUtc`, and appends a `PROFILE_SAVED` event to `data/permissions_audit.csv`.
3. **Edit:** open Manage users, select a profile, choose Load to edit, change permissions, then Save. Saving a revoked profile explicitly reactivates it by setting `Status=Active`.
4. **Export:** export creates a new output directory. The builder validates the profile and refuses any non-Active status. The edition manifest records the source profile revision.
5. **Revoke:** Manage users → Revoke access. This marks the profile `Revoked`, increments the revision, updates the timestamp, sets all 36 capability bits to `0`, and records `PROFILE_REVOKED`. New exports from that profile are blocked.
6. **Delete:** removes the local profile file after confirmation and records `PROFILE_DELETED`. It does not erase already exported folders.

## Audit log
`data/permissions_audit.csv` is a local UTF-8 CSV file recording UTC time, action, profile filename, and a short detail. It is not cryptographically protected; a local administrator can modify or delete it. Export audit entries mean the owner requested an export, not that the PowerShell builder completed successfully.

## Important revocation boundary
Revocation is local to the owner profile and blocks future exports. It cannot remotely disable or retract an edition already copied to another computer or USB. To update a recipient's permissions, edit/reactivate the profile and export a new edition, then manually replace the recipient's old folder after backing up their data. For immediate central revocation, the application would need an authenticated online licensing/policy service; this release intentionally has no such service.

## Security limits
Profiles remain unsigned INI files. The edition manifest and SHA-256 file detect accidental changes only; they are not publisher signatures. A recipient with local administrator rights or write access to the package can alter the files. Use separate standard Windows accounts, owner-only storage for the master project, and carefully tested NTFS ACLs for shared computers. Authenticode and public-key policy signatures are not implemented.

## Validation status
Static source checks cover lifecycle controls and builder gating. Native GUI operation, PowerShell 5.1 export/revoke behavior, audit-file behavior, and Windows ACLs have not been runtime-tested in this environment.
