# IT VIP v116 — Complete License Audit Export

The authority now exposes authenticated `GET /v1/audit/export` for a complete audit-history export. Unlike `GET /v1/audit`, which intentionally returns only the latest 500 events for interactive review, this endpoint returns every audit row in ascending database-ID order.

The response schema is `ITVIP-AUDIT-EXPORT-1` and contains:

- `GeneratedUtc`: export generation timestamp.
- `Integrity.valid`: whether every exported row matches the SHA-256 chain and previous-hash link.
- `Integrity.checked`: number of rows examined.
- `Integrity.first_bad_id`: first detected invalid row, or null.
- `Integrity.head`: last successfully verified hash (or empty string when the first row fails / the chain is empty).
- `Events`: the complete ordered event array, including IDs, revisions, actor labels, previous hashes, and row hashes.

The export is intended for controlled offline retention and independent review. It is **not** a cryptographically authenticated export: the chain is unkeyed SHA-256, the service does not sign it, and an administrator able to rewrite the database can recompute the chain. Export files should be transferred to separately administered, append-only storage and signed offline if stronger provenance is required. The endpoint requires the read bearer token (or admin token).

## Verification

Host-side regression tests verify that the endpoint returns more than the 500-event interactive window, reports valid integrity for a complete chain, and flags a modified row. These tests do not qualify a remote deployment, TLS certificate handshake, or Windows runtime.
