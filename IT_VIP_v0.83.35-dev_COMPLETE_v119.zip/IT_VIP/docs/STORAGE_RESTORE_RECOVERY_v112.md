# Backup Center restore recovery journal — v112

## Implemented
- Backup Center writes `restore.journal` in each staged transaction directory.
- Journal updates are written to a temporary file, flushed with `FlushFileBuffers`, then replaced using `MoveFileExW` with write-through semantics.
- Journal phases are `PREPARED`, `APPLYING`, `APPLIED`, `ROLLING_BACK`, and `COMMITTED`.
- Each journal includes the current item index, each relative target path (UTF-8 hex encoded), and whether the destination existed before restore.
- Before each target move, the journal records `APPLYING` including the possibly interrupted item. After a successful move it records `APPLIED`.
- Backup Center scans for transaction directories containing a journal on startup. It warns the operator and can open the first transaction folder for inspection; it never automatically deletes or replays an interrupted transaction.
- If journal finalization fails after all files have been applied, the transaction folder is retained and the UI warns the operator.

## Recovery procedure
1. Stop IT VIP modules before manual recovery.
2. Do not delete the `.itvip_restore_txn_*` directory.
3. Read `restore.journal` and inspect its phase and index.
4. Use `old/` as the pre-restore snapshot and `new/` as the staged incoming files. Compare the journal's item list with the actual target files before taking action.
5. If unsure, preserve the entire transaction directory and make a separate copy before manual intervention.

## Limits
- This is durable recovery metadata and next-launch detection, not automatic crash recovery or a multi-file atomic transaction.
- A power failure may still interrupt filesystem metadata updates; `FlushFileBuffers` and write-through flags improve durability but do not guarantee hardware-level persistence on every storage device.
- Recovery is intentionally operator-confirmed. The software does not automatically roll back a transaction after restart because the exact crash point and external changes cannot always be proven safe.
- Windows runtime crash/fault-injection tests, MSVC/MinGW builds, and NTFS/exFAT/FAT32 qualification remain required.
