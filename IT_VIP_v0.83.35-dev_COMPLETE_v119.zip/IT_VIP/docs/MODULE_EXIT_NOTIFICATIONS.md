
# Module exit notifications — v102

When the dashboard starts a standalone native module with `CreateProcessW`, it now retains the process handle and starts a small Win32 watcher thread. The watcher waits for process termination, reads the exit code, closes the process handle, and posts a private `WM_APP` message to the dashboard. The UI thread converts that event into the existing queued notification/toast and log path.

Exit code 0 is reported as successful completion; nonzero exit codes are reported with their numeric value. This reports process termination, not detailed internal task success. Modules launched through external `.cmd`/PowerShell scripts or via `ShellExecuteW` are not covered by this watcher yet.
