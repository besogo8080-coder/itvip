# IT VIP Workflow Studio

Workflow Studio (v0.34.0-dev foundation) creates and maintains ordered workflow definitions for enabled Agent profiles.

## Current capabilities
- Create, edit, and delete workflow definitions.
- Store definitions in `config/workflows.ini`.
- Set a display name and an ordered sequence of 1–16 enabled Agent IDs.
- Validate IDs against enabled sections in `config/agents.ini` and reject duplicates.
- Select Sequential or Round-robin dispatch metadata.
- Store `RequireApproval` and `StopOnFailure` policy flags.
- Launch from the main IT VIP dashboard.

## Important limitations
This is a **definition editor only**. It does not execute workflows, dispatch agents, implement conditional branches, pass outputs between agents, retry requests, or perform file/system actions. The mode and policy values are saved for a future execution engine; they do not currently alter runtime behavior. No live API or Windows runtime test has been performed in this environment.

## Build
Run `build.bat msvc` from a Visual Studio 2022 Developer Command Prompt, or `build.bat mingw` with MinGW-w64 and windres available. The output target is `build/workflow_studio.exe`.
