# IT VIP Notification Toast — v100

## Delivered
- A native Win32 popup toast is displayed without activating itself or stealing keyboard focus.
- The toast uses the active theme accent (or custom accent), a bilingual heading, and the current UI language for its body.
- Entry animation slides the toast upward while fading it in; it remains visible briefly and then fades away.
- Clicking the toast opens `reports/ui_notifications.log` in the user's default text editor.
- Dashboard module launch success, missing executable, and process-start failure are recorded as local UI events.
- The existing Notification sound cue is played subject to the user's global audio setting and per-cue setting.

## Local data and privacy
The log is append-only UTF text written beneath the project `reports` directory. Entries contain a local timestamp and short UI status message. The notification path does not record API keys, passwords, request bodies, or process output. Users can remove the log file manually while the application is closed.

## Current boundaries
- A single toast is displayed at a time; a new toast replaces the currently visible toast. A queue and deduplication are not implemented.
- The log currently has no in-app search, filtering, retention policy, or clear-history button.
- Only dashboard module launches and the initial ready message use this toast path. Other modules have not yet been migrated to a shared notification API.
- Per-monitor-v2 process awareness is requested dynamically with a legacy system-DPI fallback. Full child-control relayout and mixed-DPI interactive testing remain outstanding.
- Windows MSVC/MinGW compilation and Windows 10/11 runtime tests are not claimed by the host-side checks in this release.
