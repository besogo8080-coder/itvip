# IT VIP Customization Center

The dashboard now includes a first native Win32 customization window.

## Current controls
- Four built-in appearance themes: Neon Violet, Ocean Cyan, Golden Chrome, Matrix Green.
- Experimental animated accent-line background; it can be disabled.
- Show/hide toggles for the seven current tool buttons.
- Settings persist in `config/appearance.ini` using Windows profile APIs.
- The default theme is Neon Violet and all tool buttons are visible when no preference exists.

## Scope and limitations
- This is a first functional customization layer, not a full visual editor.
- Arbitrary image/video backgrounds, drag-and-drop button placement, user-defined buttons, custom icons, and per-button renaming are not implemented yet.
- Animated background is a lightweight GDI accent animation, not a video wallpaper; it can be disabled for lower resource use.
- Button visibility only hides/shows existing tools. It does not remove modules or change their permissions.

## Portable Apps Studio — v0.5.0-dev
The Portable Apps Manager now supports per-card display names and icon selection. Users can choose from a built-in symbol catalog (general, browser, security, system, files, network, media, games, terminal, backup, folder, VIP) or select a custom `.ico` file. Metadata is stored in `config/portable_apps.tsv` with backward-compatible loading of the previous two-column format. Editing a card never renames or modifies the target executable. Removing a card only removes its registry entry; it does not delete the executable or icon file.

Note: the selected custom `.ico` path is recorded as metadata in this development iteration; rendering custom image assets directly inside the list is a follow-up UI task. Built-in symbols are rendered as text glyphs in the list.
