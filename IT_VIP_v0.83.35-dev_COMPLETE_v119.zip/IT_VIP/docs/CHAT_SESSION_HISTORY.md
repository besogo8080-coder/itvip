# IT VIP Chat Session History

## Integrated behavior
- Provider Runtime keeps the active conversation in `data/sessions/current.session` using the `ITVIPACTIVE2` format.
- The active context is scoped to the selected provider. Switching providers while a conversation is active prompts before clearing that active context.
- Up to the latest 12 completed turns from the active conversation are included in the next request to the same provider.
- Starting a new session clears only the active context; it does not erase the archive.
- Each successful turn is appended to `data/sessions/chat.v1` using the `ITVIPCHAT1` four-field format: timestamp, provider, prompt, and answer.
- Session Center reads that shared archive and supports filtering, preview, export, and confirmed deletion of archived turns.
- Failed requests are not archived. API credentials are never written to either session file.

## Privacy and storage
- Both session files are local plaintext in the portable project folder; they are not encrypted.
- Active-session context is sent to the selected provider with subsequent messages. Older archived turns are not automatically sent.
- Deleting an archived turn in Session Center does not currently remove a matching turn from the active context file. Use **New Session** to clear active context.
- Protect the USB/device and exported files. Do not store passwords, API keys, recovery codes, or other secrets in prompts.

## Build
`build.bat msvc` or `build.bat mingw` builds `session_center.exe` and the updated Provider Runtime. The dashboard launcher is wired to Session Center.

## Limitations
- This is local text history, not provider-side thread/session state.
- No encryption, semantic search, session labels, or automatic memory-vault retrieval is implemented.
- Provider compatibility remains limited to HTTPS Chat Completions-compatible endpoints.
- Windows compilation, UI runtime, and live provider tests must be performed on Windows.
