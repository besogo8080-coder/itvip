# IT VIP Windows Repair Center

## Purpose
A read-only Windows health assessment utility. It gathers OS, fixed-disk, selected Windows Update service, and pending-reboot information, with optional built-in diagnostic scans.

## Launch
Run `deployment/Repair-ITVIP.cmd` and select an assessment. Reports are written to `reports/` as timestamped JSON and TXT files.

## Actions
- `Inventory`: quick inventory only (default).
- `SystemFiles`: runs `sfc /verifyonly` (verification; does not repair).
- `ImageHealth`: runs `DISM /Online /Cleanup-Image /ScanHealth` (scan only; does not restore/repair).
- `DiskOnline`: runs `chkdsk <system-drive> /scan` (online scan; no `/f` or `/r`).
- `All`: runs all three scans and may take a long time.

## Safety boundaries
- No SFC `/scannow`, DISM `/RestoreHealth`, CHKDSK `/f` or `/r`, Windows Update reset, cache deletion, service changes, registry writes, or reboot is performed.
- The utility does not automatically elevate. Some diagnostics may provide incomplete results without an elevated PowerShell session.
- Tool output and exit codes are recorded; non-zero exit codes require human review and are not interpreted as a definitive diagnosis.
- Suggested repair paths are informational only. Back up important data and obtain explicit approval before running any repair command manually.

## Limitations
This is a PowerShell-based Windows feature, not a native C++ repair engine. Runtime behavior must be tested on supported Windows 10/11 systems. The current source package has not been validated by executing these commands on a Windows host.
