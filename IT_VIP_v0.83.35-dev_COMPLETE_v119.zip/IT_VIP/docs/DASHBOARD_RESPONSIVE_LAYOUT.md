
# Dashboard responsive layout — v102

The main dashboard now recalculates control positions on `WM_SIZE`. The top command strip, core tools, and standalone module launchers are arranged from the current client width rather than relying only on their initial hard-coded positions. A three-column fallback is used for narrower supported widths; four columns are used when the logical client width is at least 1040 px.

Control coordinates are scaled against the window DPI using `GetDpiForWindow` when available, with a 96-DPI fallback. The dashboard also supplies a minimum tracking size to avoid compressing controls below their intended usable width. This is a first responsive pass: text painting and every secondary dialog have not yet been fully converted to a DPI-aware layout system, and mixed-monitor runtime behavior still requires Windows testing.
