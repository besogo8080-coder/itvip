# IT VIP UI Audio Feedback — v97

The shared native audio helper supports eight optional, asynchronous WinMM cues: click, back, success, warning, completion, notification, startup, and shutdown. Startup and shutdown cues are opt-in (disabled by default) to avoid surprising users. VIP Studio provides preview buttons, six custom-WAV import controls for the original six cues, and separate startup/shutdown enable toggles and preview buttons.

Custom sounds are copied into `assets/audio/custom/` and their project-relative paths are stored in `config/appearance.ini` under `[Audio]` using `ClickFile`, `BackFile`, `SuccessFile`, `WarningFile`, `CompleteFile`, and `NotificationFile`. If a custom path is empty or unavailable, the corresponding bundled WAV asset is used. The importer checks the `.wav` extension and RIFF/WAVE container signature; it does not transcode audio. Windows/WinMM remains responsible for decoding and playback compatibility, so PCM WAV is recommended.

`[Audio] Enabled=0` disables all cues. Per-cue `*Enabled=0` settings remain supported. Startup and shutdown are controlled by `[Audio] StartupEnabled=1` and `[Audio] ShutdownEnabled=1`; both default to `0` when absent. Existing v96 settings remain backward-compatible. Imported custom audio files are part of the project package and should not be moved independently from the project root.

Validation covers source contracts and host-side tests. Audible playback, codec compatibility, and the complete VIP Studio interaction still require Windows 10/11 runtime testing with an audio device.

## Notification delivery
Dashboard module launch feedback is shown through a non-activating animated toast. When enabled, the toast uses the configured Notification cue. Clicking the toast opens `reports/ui_notifications.log`. The log is local and append-only; it records timestamped UI messages, not credentials or API payloads.
