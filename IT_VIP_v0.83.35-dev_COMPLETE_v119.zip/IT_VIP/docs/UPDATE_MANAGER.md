# IT VIP Update Manager

The Update Manager is a **manual, local-package updater**. It does not contact a server, download code, elevate privileges, stop processes, or install services.

## Actions

Run `deployment\Update-ITVIP.cmd` from the project root, or invoke `deployment\Update-ITVIP.ps1` directly:

- `Preflight`: displays the installation root and update/rollback locations.
- `CreateManifest -PackagePath <folder> -Version <version>`: creates `ITVIP_UPDATE.json` for approved files under `build`, `assets`, `docs`, `deployment`, plus the two README files.
- `VerifyPackage -PackagePath <folder>`: checks manifest schema, approved paths, file sizes, and SHA-256.
- `StageUpdate -PackagePath <folder>`: copies a verified package into `.update-staging\<version>`; it does not alter installed files.
- `ApplyUpdate -Version <version>`: requires ITVIP.exe to be closed and the user to type `APPLY`; copies old target files to `data\update-backups`, verifies staged hashes again, and then replaces files.
- `RollbackLatest`: requires ITVIP.exe to be closed and the user to type `ROLLBACK`; restores files from the most recent rollback record.

## Package layout

An update package mirrors the application folder layout. `ITVIP_UPDATE.json` contains schema `ITVIP-UPDATE-1`, version, and a list of relative paths, sizes, and SHA-256 hashes. Only the approved runtime roots are accepted. `config`, `data`, `reports`, `logs`, and arbitrary root files are not update targets, preserving user settings and data.

## Security limits

- SHA-256 detects corruption or mismatch; **it does not authenticate the publisher**. Obtain the package and its manifest from a trusted release channel and compare a separately published manifest digest. This implementation does not yet enforce Authenticode or a pinned signing certificate.
- There is no automatic internet update check or download.
- Update application is a sequence of per-file replacements, not a filesystem-wide atomic transaction. The script attempts rollback if a replacement fails, but power loss or storage failure can interrupt it. Keep a separate backup before updating.
- Do not run the update from an untrusted package. Review the package contents and manifest before staging.
- The script uses PowerShell and is not executed automatically by the application.
