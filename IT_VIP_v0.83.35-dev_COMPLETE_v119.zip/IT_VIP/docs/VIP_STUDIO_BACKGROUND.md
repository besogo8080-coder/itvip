# VIP Studio — Custom Image Background

## Implemented in v0.13.0-dev

The main-window Customization Center can now select or clear a custom image background.

- Supported formats: PNG, JPG, JPEG, BMP (decoded by Windows GDI+).
- The selected image is copied into `assets/backgrounds/` inside the project folder.
- `config/appearance.ini` stores a project-relative path, so the image remains portable when the whole folder is moved.
- The main window paints the image with high-quality interpolation and a dark translucent overlay to preserve text contrast.
- Clearing the image removes the configured reference; it does not delete the copied image file.

## Build dependency

The GUI now links against `gdiplus.lib` (MSVC) or `-lgdiplus` (MinGW), and uses the common file dialog library.

## Limitations

- This is a static image background, not a video background.
- Very large images may use substantial memory; resize images before use for best performance.
- The selected image is copied using a stable filename (`custom_background` plus its extension), replacing a previous custom background with the same extension.
- Windows build/runtime testing is still required.
