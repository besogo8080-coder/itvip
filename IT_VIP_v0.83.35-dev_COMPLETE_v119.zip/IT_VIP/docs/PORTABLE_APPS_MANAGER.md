# IT VIP Portable Apps Manager

## Folder import

The Windows Portable Apps Manager can import a complete application folder into `portable/apps/<app-name>`. It first scans the source tree, refuses to proceed when an entry cannot be inspected, checks available destination space, asks for confirmation, and copies into a uniquely named staging directory on the same volume. The staging directory is published under its final name only after all files have been copied and checked.

Files are copied by Windows `CopyFileExW`; the application does not load an entire large file into memory. After each copy, the source and destination sizes are checked and their SHA-256 digests are computed incrementally with Windows CNG using a fixed 1 MiB buffer. A mismatch or hash/read error fails the import and triggers best-effort staging cleanup. The original source is not deleted or modified.

The SHA-256 comparison verifies content at the time each side is read; it is not a guarantee against a source file changing after verification, filesystem hardware faults, or malicious concurrent changes during the operation. The final folder rename is intended as a same-volume publication step. Cleanup can fail if Windows or another process holds files open; in that case a hidden staging folder may remain and should be inspected manually.

## Large files and USB formats

The import path uses bounded memory and 64-bit size accounting, so it has no intentional 512 MiB per-file cap. Actual limits depend on the destination filesystem, free space, device health, and Windows API behavior. FAT32 cannot store an individual file larger than 4 GiB; exFAT or NTFS is required for larger individual files.

## Current limitations

- The manager is Win32 code and must be built and exercised on Windows.
- The import workflow has not yet been validated on physical USB devices in this environment.
- The manager currently imports folders; it does not yet provide a full storage dashboard, application folder rename/move/delete UI, or background/resumable transfer.
- The progress UI is synchronous; a slow or very large import temporarily occupies the manager's UI thread.

## Storage overview (v0.79)

The manager now reports the number of regular files and total bytes under `portable/apps`, free space on the volume containing the toolkit, and the detected filesystem name. A dedicated storage-information action also warns when the detected filesystem is FAT32, because a single file larger than 4 GiB cannot be stored there. The manager can open the portable-apps folder in Explorer. Inventory traversal does not follow symbolic links and treats traversal/metadata errors as an incomplete scan rather than silently claiming a complete result.

This is an informational overview only: it does not move, rename, or delete imported application folders. It is synchronous and may take time on very large or slow USB devices. The storage counters describe files currently visible during the scan and are not a transactional snapshot.

## Imported folder management (v0.80)

The manager now offers two actions for an imported application selected in the list:

- **Rename imported folder:** edits the folder name to the selected card's current display name. If a different folder already uses that name, the operation is refused; no existing folder is overwritten. Registered EXE and custom-icon paths located inside the renamed folder are updated in the local app list.
- **Delete imported folder:** after a second, explicit destructive confirmation, removes the selected application's entire top-level folder under `portable/apps` and removes list records whose EXE paths were inside it; custom-icon references into that folder are cleared. This is a permanent deletion; it does not use the Recycle Bin.

Both actions reject external EXE paths, symbolic-link roots, and paths that do not resolve to a direct child folder of `portable/apps`. They do not operate on arbitrary folders elsewhere on the computer. The existing **Remove from list** action remains separate and only removes the list record.

These are source-level Win32 features. They still require MSVC build and Windows/USB runtime testing, including paths containing non-ASCII characters, locked files, removable-drive removal, and filesystem permission failures. A failed recursive delete may leave some files behind; the UI reports that condition for manual inspection.


## Fast Copy utility (v0.81)

A separate Win32 utility, `copy_manager.exe`, is launched from the Portable Apps Manager. It supports folder-to-folder copying in either direction: select a folder on a USB drive as the source and a folder on the PC as the destination, or reverse those choices to copy from the PC to USB. It scans the source first, totals regular-file sizes with 64-bit accounting, checks destination free space, and refuses a destination folder that already exists. It does not overwrite existing content.

The transfer runs on a worker thread so the window remains responsive. Windows `CopyFileExW` performs the file transfers and reports progress; the user can request cancellation. Symbolic links are not followed. On failure or cancellation, the tool attempts to remove the partial destination tree. The source is never deleted or modified. The tool checks copied file sizes but intentionally does not compute SHA-256 during ordinary transfers, avoiding the additional full read that would reduce copy throughput. Use the import workflow when you specifically want per-file SHA-256 verification.

Transfer speed is not guaranteed by software: it depends on USB generation, port, flash-drive/controller write speed, destination disk, file sizes/count, filesystem, and thermal throttling. Many tiny files can copy much slower than a few large files. FAT32 cannot store an individual file larger than 4 GiB; exFAT or NTFS is needed for such files. The first implementation copies complete folders (including empty subfolders), does not merge into an existing destination folder, and is not resumable after cancellation or device removal. It requires Windows build and physical-device testing; Linux static checks do not establish real transfer throughput or Windows runtime correctness.

## Shared IT VIP visual identity (v0.82)
Portable Apps Manager and Fast Copy use the common IT VIP crowned-V icon and dark navy/violet/cyan window styling. The icon is embedded by the MSVC and MinGW build paths; runtime window/taskbar icon loading uses the adjacent `assets/itvip.ico` when present. See `docs/ITVIP_VISUAL_IDENTITY.md` for the complete GUI coverage and limitations.
