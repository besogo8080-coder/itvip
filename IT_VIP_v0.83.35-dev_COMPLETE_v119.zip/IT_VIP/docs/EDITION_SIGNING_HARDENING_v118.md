# Edition Signing Hardening — v118

The user-edition signer now fails closed before producing RSA signatures when the
edition root is missing or is a reparse point. It performs an initial tree-wide reparse-point preflight before copying the public key, and repeats the check while building the inventory. During inventory creation it rejects
reparse-point entries, empty inventories, unsafe/ambiguous relative paths, Windows
reserved device names, trailing-dot/trailing-space components, and duplicate paths
under Windows case-insensitive comparison. Nested paths are normalized to `/` in the
signed JSON inventory.

The signer also requires both imported authority keys to be RSA-3072 and compares
the public modulus and exponent derived from the private key against the supplied
public authority key before signing. This prevents an operator from accidentally
signing an edition with a private key that does not correspond to the public key
bundled into the edition.

The native CNG verifier remains the runtime trust gate: it verifies the RSA
signatures, validates the signed inventory, and checks every inventoried file. The
new Python tests are source-contract checks only. PowerShell 5.1/7 execution, actual
RSA key-pair signing, native CNG verification, and Windows reparse-point behavior
must still be exercised by Windows CI before production qualification.

The signing private key remains an offline owner secret. Do not place it in the
source archive, repository, CI artifacts, or a distributed edition. This change
does not add Authenticode signing and does not claim that the audit or package is
protected against a local administrator who can replace the trust anchor.
