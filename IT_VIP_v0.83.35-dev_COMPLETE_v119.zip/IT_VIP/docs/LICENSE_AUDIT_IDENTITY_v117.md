# IT VIP v117 — Audit Actor Identity Boundary

## Change

The license-authority service no longer accepts `X-ITVIP-Actor` as the audit
principal. That header is caller-controlled and therefore cannot establish who
performed a privileged action. Revoke/restore events now use the service-side
`ITVIP_ADMIN_ACTOR` setting (default: `license-authority-admin`).

The value is validated at startup and must be 1–64 ASCII characters from
`A-Z`, `a-z`, `0-9`, `.`, `_`, `@`, and `-`. Invalid values prevent startup.

Example (PowerShell):

```powershell
$env:ITVIP_ADMIN_TOKEN = '<random secret, at least 32 characters>'
$env:ITVIP_READ_TOKEN = '<different random secret, at least 32 characters>'
$env:ITVIP_ADMIN_ACTOR = 'license-authority-prod'
python server/license_authority.py --host 127.0.0.1
```

## Security meaning and limits

- This prevents a request from forging an arbitrary actor string in the audit log.
- It identifies the configured service credential/principal, **not a human operator**.
- With one shared admin bearer token, individual human attribution is not possible.
  A production deployment needing person-level accountability must put a trusted
  identity-aware gateway in front of the service and pass authenticated identity
  through a separately verified mechanism, or use individually provisioned
  credentials with a server-side identity map.
- `ITVIP_ADMIN_ACTOR` is an operator-controlled deployment setting. It is not
  cryptographically bound to the bearer token and does not make the audit chain
  tamper-proof.
- The existing `X-ITVIP-Actor` header is ignored for attribution.

## Tests

The authority HTTP regression test supplies `X-ITVIP-Actor: ceo@example.test`
while the server is configured as `configured-license-admin`; the stored audit
row must contain only the server-configured principal. Existing concurrent
writer, audit-chain, export, and request-parsing tests remain in place.

## Qualification

Host-side tests and static checks can verify this source behavior. They do not
qualify remote identity federation, TLS deployment, Windows runtime, or
production authorization policy.
