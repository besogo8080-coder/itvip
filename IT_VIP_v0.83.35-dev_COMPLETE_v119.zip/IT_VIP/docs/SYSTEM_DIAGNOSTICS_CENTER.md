# IT VIP System Diagnostics Center

Package v90 adds a read-only Windows system snapshot and short sampling workflow.

## Launch

Run `deployment/System-Diagnostics-ITVIP.cmd` or invoke PowerShell directly:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\System-Diagnostics-ITVIP.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\System-Diagnostics-ITVIP.ps1 -Samples 10 -IntervalSeconds 3
```

`Samples` is bounded to 1–30 and `IntervalSeconds` to 1–10. The default is five samples two seconds apart.

## Collected information

- Windows caption and processor architecture.
- Processor model and sampled `Win32_Processor.LoadPercentage` values.
- Total/free physical memory and calculated used percentage.
- Fixed logical volumes, capacity, free space, and used percentage.
- Active physical network adapter link speed and cumulative received/sent byte counters.
- ACPI thermal-zone readings only when `root/wmi:MSAcpi_ThermalZoneTemperature` is exposed by the platform.
- Per-query warnings when a provider or permission is unavailable.

## Reports

Timestamped JSON, TXT, HTML, and sample CSV files are written under `reports/`.

## Interpretation and limitations

- CPU load is based on the CIM `LoadPercentage` property; it is coarse and may be unavailable. It is not a high-frequency performance-counter graph.
- Network byte counts are cumulative adapter counters, not current throughput and not an internet speed test.
- Many modern PCs do not expose usable thermal readings through the standard ACPI WMI class. Missing readings are reported as unavailable; no temperature is fabricated.
- Disk values describe fixed logical volumes, not physical-drive health or SMART diagnostics.
- This workflow is read-only. It does not stop processes, change services, modify power plans, install drivers, repair Windows, or write to disks.
- PowerShell 5.1 execution and Windows 10/11 hardware-provider behavior must be validated on Windows. Static contract tests on Linux do not prove runtime compatibility.

## Threshold alerts and local history (v91)

The workflow supports configurable warning thresholds and records crossed thresholds in JSON/TXT/HTML output:

```powershell
.\deployment\System-Diagnostics-ITVIP.ps1 -Samples 10 -IntervalSeconds 2 -CpuAlertPercent 85 -MemoryAlertPercent 90 -DiskFreeAlertPercent 10
```

Thresholds are bounded: CPU and memory 1–100%; disk free 1–50%. The default thresholds are 85%, 90%, and 10% respectively. A persistent `reports/system_diagnostics_history.csv` stores CPU/memory samples and alert text, retaining at most the latest 1,000 rows. The HTML report includes a dark status summary. Alerts are informational only; no automatic remediation or throttling occurs.


## Live monitoring and network rates (v92)

An optional bounded live mode prints CPU, memory, and estimated active-adapter receive/send rates in bytes per second while sampling. Example:

```powershell
.\deployment\System-Diagnostics-ITVIP.ps1 -LiveMonitoring -DurationMinutes 5 -IntervalSeconds 2
```

`DurationMinutes` is bounded to 1–60 minutes; `IntervalSeconds` remains bounded to 1–10 seconds. The resulting sample count is capped at 3,601. Network rates are calculated from differences between cumulative adapter byte counters and are approximate (sampling and provider latency affect the interval); the first sample has no rate because no prior counter exists. Rates are local adapter traffic, not internet speed. The regular short sampling mode remains the default.
