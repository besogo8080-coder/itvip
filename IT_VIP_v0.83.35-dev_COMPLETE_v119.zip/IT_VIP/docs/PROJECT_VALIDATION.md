# IT VIP Project Validation

Run from any directory with Python 3:

```bat
py tools\validate_project.py
py tools\validate_project.py --report
```

The validator checks that expected C++ sources, build entries, dashboard launch references, core directories, documentation, and primary branding are present. `--report` writes a timestamped text report under `reports/`.

This is a **static source-tree check only**. It does not compile C++, execute Windows binaries, test live API credentials/network calls, verify Windows Credential Manager behavior, or validate boot media. A PASS is not a substitute for Windows build and runtime testing.
