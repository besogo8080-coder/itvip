# IT VIP Multi-Agent Team Studio — v0.30.0-dev

Team Studio is a configuration editor for named teams of existing Agent Studio profiles.

## Current capabilities
- Create, edit, list, and delete team definitions in `config/teams.ini`.
- Choose a coordinator Agent ID and up to 16 member Agent IDs.
- Validate that referenced agents exist in `config/agents.ini` and are enabled.
- Store dispatch preference (`sequential` or `round_robin`) and an approval-required flag.
- Deleting a team does not delete its Agent profiles.

## Configuration format
Each team is stored in a `[Team_<id>]` INI section with `Name`, `CoordinatorAgent`, `Members`, `Mode`, `RequireApproval`, and `Enabled` keys. Agent references use the suffix of `[Agent_<id>]` sections in `agents.ini`.

## Important limitation
This is a team-definition editor only. It does not execute agents, dispatch prompts, call providers, invoke tools, or implement multi-agent orchestration. The dispatch mode and approval flag are stored policy metadata for a future runtime. Create and enable individual Agent profiles first in Agent Studio.
