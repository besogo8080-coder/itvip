# IT VIP Startup & Services Manager

The read-only inventory is launched from `deployment/Startup-ITVIP.cmd`.

## Inventory
- Startup commands registered through Windows startup-command providers (`Win32_StartupCommand`).
- Windows services: display name, service name, state, startup mode, service account, and process ID.
- JSON and TXT reports; separate CSV exports for startup entries and services when results exist.

## Safety boundary
This version is inventory-only. It does not enable, disable, stop, start, delete, or reconfigure startup entries, scheduled tasks, services, or registry values. It does not claim that a listed startup command successfully ran. Changes should be made only after review using Windows Settings or the Services console. Some details may require elevated permissions and may be unavailable on some Windows editions.

## Run
Double-click `deployment/Startup-ITVIP.cmd`, or run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\Startup-ITVIP.ps1 -Action All
```

Reports are written to `reports/`. PowerShell execution and Windows runtime behavior must be tested on a Windows machine; static project validation is not a substitute.
