# IT VIP shared visual identity — v0.82.0-dev

The Windows GUI suite now uses a shared identity layer from
`src/app/itvip_branding.hpp`.

## Shared assets

- `assets/itvip.ico`: crowned V / IT VIP icon, embedded into the Windows
  executables by the MSVC and MinGW build paths.
- `assets/branding/itvip_app_icon_512.png`: high-resolution master icon.
- `assets/branding/itvip_dark_cyber_background.png`: reusable dark cyber
  background artwork for future customizer/gallery use.

## Shared runtime styling

The following GUI entry points call `itvip::applyBranding`:

- Main IT VIP dashboard.
- Portable Apps Manager and Fast Copy.
- AI Assistant, GitHub Hub, Universal API Manager.
- Agent Studio, Provider Hub, Provider Runtime.
- Team Studio/Runner and Workflow Studio/Runner.
- Run History, Memory Center, Session Center.
- Backup Center, Settings Center, Owner Permissions Console.

The common layer sets the window/taskbar icon, requests a dark DWM title bar
where Windows supports it, and applies a deep navy surface with subtle circuit
traces and violet/cyan accent rules. Static text and standard edit/list controls
receive a shared dark palette. Existing tool-specific layouts and workflows
remain intact.

## Scope and honest limitations

The six command-line utilities (Scanner, USB Guard, Temp Cleaner, Activation
Manager, Password Recovery, and Security Center) are still console programs;
they do not yet have standalone graphical windows to theme. Their dashboard
launch points remain branded by the main IT VIP application. A later UI
migration can give those utilities the same full visual treatment.

The shared styling is a consistent Win32 foundation, not a final custom-drawn
Cyberpunk widget toolkit. Standard Win32 buttons and dialogs may retain some
Windows-native visual behavior. Windows/MSVC and physical-device runtime tests
are still required; this Linux environment cannot execute those GUI binaries.
