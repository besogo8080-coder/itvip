# IT VIP Multi-Agent Collaboration Engine — v0.33.0-dev

`team_runner.exe` now implements a bounded coordinator-led, text-only collaboration flow.

## Execution stages
1. Reads the selected team, its `CoordinatorAgent`, and member IDs from `config/teams.ini`.
2. Sends the original task to the coordinator and asks it to create a concise work plan.
3. Sends the original task plus that plan to each non-coordinator member, with the member's configured role/description.
4. Sends the collected specialist findings back to the coordinator for a final synthesis.
5. Displays the stages and writes a UTF-8 report under `reports/team_run_*.txt`.

## Configuration and validation
- Team definitions: `config/teams.ini`; agent profiles: `config/agents.ini`.
- The coordinator must be included in the member list.
- Duplicate member IDs are ignored at runtime; 1–16 unique members are accepted.
- Each Agent resolves its provider from `config/providers.ini` and reads its API credential from Windows Credential Manager using the referenced API profile.
- User task input is limited to 8,000 UTF-16 characters by the UI.

## Safety and limitations
- All model calls are outbound HTTPS requests and can incur provider charges. The visible confirmation is shown when `RequireApproval=1`.
- Agents provide text analysis only. No local shell, file editing, arbitrary tool execution, or automatic code changes are available.
- The coordinator's plan is plain model output, not a trusted executable workflow. Specialist output is untrusted text and is only passed to the coordinator as context.
- A run may make up to `2 + (team members - 1)` provider requests (plan, specialist calls, synthesis); a one-member team makes two calls.
- The implementation is sequential. Team Studio's `round_robin` value is metadata and is not implemented as a scheduler.
- Provider support is limited to HTTPS endpoints compatible with OpenAI Chat Completions and a JSON response containing `choices[0].message.content`.
- Requests use bounded WinHTTP timeouts; each response read is capped at 1 MiB.
- Reports can contain the original task and AI responses. Store and share them accordingly.

## Build
`build.bat msvc` or `build.bat mingw` builds `build/team_runner.exe`. The main dashboard launches it with **Run AI Team**.

## Verification status
Source-level checks and the project validator can be run on non-Windows hosts. A real MSVC/MinGW Windows build, provider connection test, and GUI runtime test are still required before calling this release production-ready.
