# IT VIP License & Security Authority — v0.56 foundation

## What is implemented
- A separate owner-side RSA-3072 keypair generator.
- The private RSA XML is protected with Windows DPAPI through `ConvertFrom-SecureString`; it is bound to the creating Windows user/profile and machine context. Keep an offline protected backup. A lost DPAPI context can make the key unrecoverable.
- A public XML key suitable for distribution to verifiers.
- User Edition manifest schema 2 with a fresh EditionId, profile revision, issue timestamp, optional expiry, explicit `BindingMode=None`, and signature algorithm state.
- An explicit signing command that signs the exact manifest and SHA-256 inventory bytes with RSA/SHA-256.
- A verifier that checks the detached signature, every inventoried file hash, path containment, and optional expiry.
- Private key material is not copied by the user-edition builder; the authority scripts and owner console are not packaged as user-edition components.

## Owner workflow (Windows PowerShell 5.1)
1. Create the authority directory OUTSIDE the project and outside any user-edition output, preferably on encrypted offline storage:
   `powershell -NoProfile -ExecutionPolicy RemoteSigned -File deployment\New-ITVIPAuthorityKey.ps1 -AuthorityDirectory E:\ITVIP-Authority`
2. Build a user edition using the existing owner console / `Build-UserEdition.ps1`.
3. Sign it from the owner environment:
   `powershell -NoProfile -ExecutionPolicy RemoteSigned -File deployment\Sign-ITVIPUserEdition.ps1 -EditionDirectory E:\Issued\UserA -PrivateKeyFile E:\ITVIP-Authority\authority.private.dpapi.txt -ExpiresUtc 2027-11-25T00:00:00Z`
   Omit `-ExpiresUtc` for no expiry.
4. The signing step copies `authority.public.xml` into the edition before the inventory is generated, so the verification key itself is covered by the signed inventory.
5. Verify it using the public key:
   `powershell -NoProfile -ExecutionPolicy RemoteSigned -File deployment\Test-ITVIPUserEdition.ps1 -EditionDirectory E:\Issued\UserA -PublicKeyFile E:\ITVIP-Authority\authority.public.xml`

## Launcher verification added in v0.57
- `Build-UserEdition.ps1` now includes the verifier script and generates a launcher that refuses to start the dashboard unless the detached signature, expiry, inventory, and file hashes verify.
- The signer places the public key in `deployment/authority.public.xml` before generating the inventory; the verifier rejects duplicate paths and files not represented in the inventory.
- This is launcher-level enforcement, not an immutable native trust boundary. A local administrator can replace the launcher, verifier, public key, or binaries. For strong publisher trust, pin a public-key fingerprint in a separately signed/native bootstrapper or use Authenticode with a trusted certificate and OS policy.

## Security boundaries / not yet implemented
- `BindingMode=None`: no hardware fingerprint, Windows SID, TPM, or account binding is collected or enforced. This is deliberate until the owner explicitly chooses a binding policy and privacy behavior.
- Signature verification is performed by the generated PowerShell launcher before it starts the native dashboard. The native dashboard itself does NOT yet verify the signature. A user with write access to the package or local administrator rights can bypass or replace the launcher and verifier. Do not represent this as tamper-proof runtime enforcement.
- Expiry is checked by the verification script, not by the native application at launch.
- There is no central server, online activation, remote revocation, license telemetry, or automatic reissue. Previously issued offline copies remain valid until expiry or manual replacement; a local revocation list is not globally distributed.
- The signature authenticates the manifest and file inventory. The verifier checks the inventory against actual files. It does not establish publisher identity unless the public key is distributed through a trusted channel.
- RSA key generation, DPAPI behavior, PowerShell 5.1 compatibility, and signing/verifying have not been executed on Windows in this build environment.
- This is not Authenticode and does not sign each EXE. Authenticode requires a properly managed code-signing certificate and Windows signing/verification tests.

## Reissue and revoke procedure
- Edit or revoke the source profile in Owner Permissions Console; revoked profiles are blocked from new exports.
- Build a fresh edition into a new empty output directory, then sign it.
- Replace/remove the old distributed copy manually. Remote revocation is impossible without a central service and an online check-in policy.
- Keep audit records and securely back up the authority private key. Never place the private key under the project tree or in any user-edition folder.

## v0.58 additions — optional Windows account binding and safer inventory checks
- The signer accepts `-BindingMode None` (default) or `-BindingMode WindowsSid`.
- WindowsSid mode hashes the current Windows account SID with SHA-256 and stores only the hash in the signed manifest. The owner explicitly supplies the target account SID with `-BindingSid`; the private signing key does not need to be moved to the target account.
- Example: `deployment\Sign-ITVIPUserEdition.ps1 -EditionDirectory E:\Issued\UserA -PrivateKeyFile E:\ITVIP-Authority\authority.private.dpapi.txt -BindingMode WindowsSid -BindingSid 'S-1-5-21-...'`. The owner supplies the intended target SID; the owner signing key remains usable in the owner's DPAPI context.
- The verifier checks the current account SID hash when WindowsSid is selected, rejects unsupported binding modes, future issue timestamps, revoked manifest status, and reparse points/symbolic links in the edition tree.
- Binding is account-scoped, not hardware/TPM binding. It does not stop a local administrator, SID spoofing through a compromised OS, or replacement of the launcher/verifier. `None` remains the default to avoid collecting account identifiers without an explicit owner choice.
- These PowerShell changes are static-reviewed only here; Windows PowerShell 5.1 execution remains required.


## v0.59 offline revocation snapshot

The signing workflow now emits `EDITION_REVOCATIONS.json` and a detached
`EDITION_REVOCATIONS.sha256rsa` signature using the owner authority key. The
verifier validates that signature before trusting the snapshot and blocks an
`EditionId` present in `RevokedEditionIds`. The optional signer parameter
`-RevocationFile` accepts a JSON document with a `RevokedEditionIds` array of
GUIDs. If omitted, an empty signed snapshot is created.

This is **offline snapshot revocation**, not live or central revocation. An
existing installation does not learn about a later revocation until its owner
receives a newly signed/reissued edition or updated signed snapshot through a
controlled release process. The owner must protect the private key and retain
its revocation source file. This workflow has source/static validation only;
PowerShell 5.1 cryptographic runtime testing remains outstanding.
