# Restore Recovery Inspector — v113

`tools/Inspect-RestoreRecovery.ps1` is a read-only diagnostic tool for a retained `.itvip_restore_txn_*` directory.

## Usage

Run from Windows PowerShell 5.1 or PowerShell 7:

```powershell
.\tools\Inspect-RestoreRecovery.ps1 -TransactionPath 'C:\Path\To\IT VIP\.itvip_restore_txn_...' -AppRoot 'C:\Path\To\IT VIP' -AsJson
```

The inspector validates the journal header, phase, index, item record shape, UTF-8 path encoding, approved application roots, duplicate paths, traversal/alias syntax, and reserved Windows device names. It reports whether each destination, original snapshot, and staged new file is present.

The tool is deliberately diagnostic only. It does not copy, move, restore, roll back, delete, or modify any file. A report is not a recovery decision: compare the journal phase/index with the actual files and make a separate verified backup before any manual intervention.

## CI fixture

`tests/windows/Test-RestoreRecoveryInspector.ps1` creates an isolated transaction fixture, verifies a valid `APPLYING` journal report, and confirms an invalid phase is rejected. The Windows PowerShell runtime matrix runs this fixture under Windows PowerShell 5.1 and PowerShell 7.

This CI addition is configured but has not been executed from the current Linux development environment. It does not qualify power-loss durability, filesystem semantics, or automatic recovery.
