# IT VIP Backup & Restore Center

## Implemented
- Creates a timestamped backup in a user-selected destination outside the IT VIP application folder.
- Copies only `config`, `data`, `assets`, `portable`, and `reports`. Source, docs, build outputs, and Windows Credential Manager secrets are excluded.
- Writes `ITVIP_BACKUP.manifest` with version marker `ITVIP_BACKUP_V1`, approved folder entries, relative file paths, byte sizes, and SHA-256 digests.
- Before restore, validates the manifest, restricts paths to the approved top-level folders, and verifies file sizes and SHA-256 digests.
- Requires explicit confirmation before overwriting matching files.

## Restore behavior and limits
- Restore copies validated backup files into matching folders under the application root. It does not delete extra files absent from the backup.
- Create a fresh backup before restoring. If restore is interrupted, some files may already have been restored; this version does not provide transactional rollback.
- No cloud backup, encryption, scheduled backup, or differential backup is implemented.

## Privacy
Backups may contain configuration, local memory, chat history, and reports. They are not encrypted. Store them on a trusted drive. SHA-256 detects file changes relative to the manifest but is not a digital signature.

## Build
`build.bat msvc` or `build.bat mingw` builds `backup_center.exe`, launched from the main dashboard. The target links Windows CNG (`bcrypt`), Shell, and OLE APIs.

Static integration checks do not replace Windows compilation or a real backup/restore round-trip test.
