# IT VIP Workflow Runner

Version: v0.35.0-dev

## What it does
- Loads enabled workflow definitions from `config/workflows.ini`.
- Validates that each ordered Agent ID exists and is enabled in `config/agents.ini`.
- Requests explicit user approval when `RequireApproval=1` (default).
- Executes configured Agents sequentially using each Agent's assigned provider and API profile.
- Passes the original request plus the previous successful Agent response to the next Agent.
- Honors `StopOnFailure=1`; when disabled, a failure is recorded and the next Agent receives a failure note as context.
- Saves a text report in `reports/workflow_run_*.txt`.

## Safety and limits
- Text-only AI workflow. It does not run shell commands, invoke local tools, edit files, or change Windows settings.
- Every Agent request is an external API disclosure. Review the task and approve dispatch before sending it.
- HTTPS endpoints only; credentials are read from Windows Credential Manager via the linked API profile.
- Maximum 16 unique Agent IDs per workflow and 8,000 characters per initial task.
- Current execution is sequential. The saved Round-robin metadata is not used by this runner.
- No retries, cancellation, branching, or live progress streaming yet.
- Provider compatibility remains limited to the existing Chat Completions-compatible request format.

## Build and launch
- `build.bat msvc` or `build.bat mingw`
- Output: `build/workflow_runner.exe`
- Launch from the main dashboard using **Run Workflow**.

## Validation status
Static source/configuration checks only. Build and live API execution must be verified on Windows with valid provider credentials.
