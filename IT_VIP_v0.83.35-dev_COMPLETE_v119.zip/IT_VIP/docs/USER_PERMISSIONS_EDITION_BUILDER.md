# IT VIP — Owner Permissions & User Edition Builder

## Purpose
The Owner Permissions Console lets the package owner create named capability profiles for individual recipients and export a separate IT VIP runtime edition for each recipient. The owner chooses each capability explicitly. The exported edition contains only the executables and deployment launchers granted by that profile.

## Owner workflow
1. Build the complete owner application with `build.bat msvc` from a Visual Studio 2022 Developer Command Prompt, or `build.bat mingw` from a configured MinGW environment.
2. Start `build\ITVIP.exe` and open **User Permissions Console**.
3. Enter an edition name and a user label. These are labels, not Windows account authentication credentials.
4. Select only the capabilities that this recipient should receive. **Select all** and **Clear all** are available.
5. Use **Load profile** to reopen and edit an existing profile. Choose **Save permissions**. The named profile is stored under `profiles\<edition-name>.ini`; it does not alter the owner's current installation policy.
6. Choose **Export user edition** and select a new destination folder outside the source project. The builder refuses an existing destination and validates every permission bit.
7. Deliver the generated folder to the intended recipient. Each recipient should receive a separately generated folder.

## Capability catalog
The profile controls the core tools, AI/provider tools, team/workflow tools, memory/session/backup/settings tools, and the Windows diagnostics/deployment tools. Profiles carry a revision number, UTC update timestamp, and Active/Revoked status. Revoked profiles have all 36 capabilities cleared and cannot be used for new exports. The dashboard reads `config\user_permissions.ini`, hides disabled entries, and blocks disabled dashboard commands. The export builder also omits ungranted EXEs and corresponding CMD/PowerShell launchers. If a granted binary or launcher is missing, export fails and removes the incomplete output.

## Export contents and integrity
The generated edition includes the main dashboard, only the granted module executables and launchers, required shared assets/config/docs/portable data, `EDITION_MANIFEST.json`, and `EDITION_SHA256.json`. The SHA-256 manifest covers files present when it is generated; it is an integrity aid, not a publisher signature. Owner profile actions are appended to `data/permissions_audit.csv`; this local log is not tamper-proof. The export-request event is recorded before launching PowerShell and does not prove the export completed.

## Security model and important limits
- This is **application-level feature gating and package minimization**, not a Windows security boundary.
- A recipient who has local administrator rights, can modify the files, can replace the dashboard, or can obtain another full build may bypass application-level restrictions.
- Revocation blocks future exports from the profile only; previously delivered editions are not remotely disabled and must be manually replaced or removed.
- Profiles are editable INI files. They are not cryptographically signed, and this release does not authenticate a person by their Windows SID or password.
- For enforceable per-user restrictions on a shared PC, create separate standard Windows accounts and apply NTFS ACLs to each user's edition folder. Keep the owner console and master build in an owner-only folder.
- For commercial distribution or hostile-user resistance, the next hardening stage must add signed policy manifests (public-key verification in the app), Authenticode-signed binaries, protected installation directories/ACLs, and a tested update/signing pipeline. Do not represent this release as tamper-proof or DRM.
- A profile's `UserLabel` is descriptive only; it does not prevent another person from running a copied edition.
- The edition builder requires already-built EXEs. It does not compile binaries, download components, or elevate privileges.

## Compatibility
The owner console and dashboard target Windows 10/11 and C++17. The edition builder uses Windows PowerShell 5.1-compatible syntax and local file operations only. No network request is made. Runtime behavior still requires validation on Windows 10/11 after building.

See `docs/USER_PROFILE_LIFECYCLE.md` for create/edit/revoke/delete and reissue details.

## Current verification status
Static source checks and ZIP integrity can be run in the packaging environment. MSVC/MinGW compilation, PowerShell 5.1 parsing, the native GUI, profile round-trip, and actual per-user NTFS ACL behavior have not been tested here.
