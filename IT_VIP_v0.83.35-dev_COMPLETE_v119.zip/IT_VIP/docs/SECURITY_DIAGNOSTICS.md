# IT VIP Security & Diagnostics Center

The Diagnostics Center is a **read-only** PowerShell assessment launched from the dashboard or `deployment/Diagnostics-ITVIP.cmd`.

## Checks
- Required project structure and module source presence.
- Presence of expected build outputs (presence only; binaries are never executed).
- Windows version/architecture and application-drive free space.
- When available: Microsoft Defender status, Windows Firewall profiles, Secure Boot state, and UAC policy.
- Timestamped TXT and JSON reports under `reports/`.

## Safety and limits
- No repairs, policy changes, service changes, registry writes, downloads, or process execution are performed.
- Security cmdlets may be unavailable on older Windows versions, non-Windows hosts, or restricted sessions. Such results are reported as WARN/INFO rather than treated as proof of compromise.
- Secure Boot may be unavailable on Legacy BIOS or without suitable permissions.
- The module checks project source and executable presence; it does not prove that binaries are trustworthy or malware-free. Use a reputable endpoint protection product for malware scanning.
- Reports can contain local system details. Review them before sharing.
- Run without elevation first. Elevation is not required by design and is not requested.

Optional: run with `-SkipWindowsSecurityChecks` to perform project-only checks.
