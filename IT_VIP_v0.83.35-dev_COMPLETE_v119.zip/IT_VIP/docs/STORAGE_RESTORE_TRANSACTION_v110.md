# IT VIP Storage Restore — staged rollback (v110)

## Implemented
- Manifest validation now retains each relative path, expected byte size, and SHA-256 digest.
- Restore rejects reparse-point path components in the backup and application destination paths.
- Every incoming file is copied into a private transaction staging tree before application files are changed.
- Every existing destination file is copied into a private rollback tree before commit begins.
- Staged files are checked again for expected size and SHA-256 before commit.
- Commit uses same-volume `MoveFileExW` replacement semantics from the transaction directory.
- If a commit operation fails, already committed files are rolled back in reverse order. Newly created targets are removed; overwritten targets are restored from their snapshots.
- If rollback itself fails, the transaction directory is deliberately retained for manual recovery rather than deleted.

## Important limits
- This is staged rollback for handled runtime errors, not a crash-consistent database transaction. Power loss, forced termination, or storage failure during commit/rollback can still require manual recovery.
- No directory-wide atomic swap is claimed. Windows does not provide a single atomic operation for replacing this multi-folder restore set.
- Windows runtime tests on NTFS/exFAT/FAT32, permission failures, read-only files, low disk space, disconnects, and forced termination remain required.
- Create a fresh backup before restore. Credential Manager secrets remain excluded.

## Qualification status
Source-contract tests and Linux-host static checks do not replace MSVC/MinGW builds or a Windows restore/rollback fault-injection test.
