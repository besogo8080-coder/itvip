# IT VIP Native License Verification

## v0.67.0-dev — Native policy enforcement with CNG and DPAPI

Added `src/app/license_native_verifier.cpp`, built as `build/ITVIPNativeVerify.exe` with MSVC and MinGW. The native bootstrapper now runs this verifier before invoking the existing PowerShell policy verifier and before launching the dashboard.

The CNG verification stage:

1. Imports the RSA-3072 public key from the authority XML into Windows CNG.
2. Verifies the edition signature over the exact manifest bytes concatenated with the exact inventory bytes using RSA PKCS#1 v1.5 / SHA-256.
3. Verifies the detached signature over the exact offline revocation snapshot bytes.
4. Parses the signed inventory and recalculates SHA-256 for every listed file.
5. Rejects duplicate, absolute, parent-traversal, escaping, missing, linked, or hash-mismatched inventory paths.
6. Checks the edition and revocation schema markers and rejects the EditionId if it appears in the signed revoked-ID list.
7. Enforces manifest issue time and optional expiry natively; timestamps must be UTC ISO-8601.
8. Enforces the optional `WindowsSid` binding natively by hashing the current token SID with SHA-256; `BindingMode=None` does not collect the SID.
9. Stores the highest accepted signed revocation revision under `%LOCALAPPDATA%\ITVIP\LicenseState`, protected with DPAPI `CurrentUser` and application entropy; older signed snapshots are rejected.
10. Uses a temporary file, flush, and atomic replacement for state updates; inability to read or update protected state fails closed.

The PowerShell verifier remains as a second independent policy layer, including full-tree reparse-point and unlisted-file checks. Local administrators can still delete/restore user-profile state or replace the portable package and trust anchor; DPAPI is not hardware-backed anti-rollback.

## Security boundaries

- The native verifier and bootstrapper are not Authenticode-signed by this source package. A trusted publisher certificate and signing operation are still required to establish a trusted executable chain.
- A local administrator or attacker able to replace the entire package and its trust anchor can still defeat a portable package. Protect deployment directories with Windows ACLs and distribute the public key through a trusted channel.
- The CNG, SID, and DPAPI implementation is source-level only until compiled and tested on supported Windows toolchains. No Windows CNG/DPAPI runtime result is claimed in this package.
- Native inventory parsing is deliberately strict and supports the current PowerShell JSON inventory shape (`Path`, then `SHA256`). A schema change requires synchronized verifier updates and compatibility tests.

## Build

Run `build.bat msvc` from a Visual Studio 2022 Developer Command Prompt, or `build.bat mingw` with a Windows MinGW toolchain. The build creates both `ITVIPNativeVerify.exe` and `ITVIPBootstrap.exe`. User-edition export now requires both binaries and places the verifier under `build/`.

## Verification status

Python syntax, central-authority unit/HTTP tests, static source integration checks, and ZIP integrity are run in the packaging environment. Native C++ compilation, CNG signature verification, Windows SID token lookup, DPAPI state persistence, PowerShell 5.1, Authenticode, and Windows 10/11 runtime tests remain NOT RUN here.

## v0.68.0-dev — Native exact-tree hardening

The native C++ verifier now mirrors the PowerShell edition-tree policy more closely:

- Rejects Windows reparse points (including junctions) in each inventory path component and during a recursive walk of the entire edition tree.
- Rejects unlisted files; only inventory-listed payload files plus the defined inventory/signature metadata are accepted.
- Detects duplicate inventory paths using case-insensitive Windows path semantics.
- Rejects empty/NUL-containing paths, rooted paths, `.` and `..` components, and paths escaping the edition root.
- Validates the revocation schema before changing the DPAPI anti-rollback high-water mark, avoiding state mutation for an unsupported signed schema.

This remains source-level hardening. The C++ source has not been compiled with MSVC/MinGW or run on Windows in this environment. The lightweight JSON extraction still supports the current signer-produced JSON shape rather than a general-purpose JSON grammar; a vetted JSON library and fuzz testing remain recommended before production release.
