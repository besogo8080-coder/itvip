# Bilingual Branded Core Tool Front-Ends — v0.83.0-dev

## Delivered
Six standalone Win32 GUI front-ends are built from `src/app/branded_tool_gui.cpp`:

| Executable | Engine | GUI scope |
|---|---|---|
| `scanner_gui.exe` | `scanner.exe` | Choose a folder and run a SHA-256 scan/report |
| `usb_guard_gui.exe` | `usb_guard.exe` | Scan a selected USB root; optional immunization requires confirmation |
| `tempclean_gui.exe` | `tempclean.exe` | Preview is the default; apply requires confirmation |
| `activator_gui.exe` | `activator.exe` | Read-only Windows and Office licensing status |
| `pwrecover_gui.exe` | `pwrecover.exe` | Launches the existing secure local-account reset workflow; no password extraction |
| `security_center_gui.exe` | `security_center.exe` | Opens the existing read-only security inventory |

The front-ends share the IT VIP branding helper, icon loader, dark window treatment, and language preference. The dashboard persists the language under `[Appearance] Language=ar|en` in `config/appearance.ini`. Arabic is the first-run default. The six new front-ends read the same value on startup.

## Safety and current limitations

- Existing CLI engines remain separate and are invoked with explicit arguments. This minimizes changes to security-sensitive logic.
- Engine stdout and stderr are redirected into a read-only output panel inside the GUI. A background worker reads the pipe so the Win32 message loop remains responsive.
- The output panel reports process completion and its exit code. An indeterminate progress bar indicates active work, and a Stop button requests termination of the active engine process.
- Progress is indeterminate because the existing CLI engines do not expose a shared structured progress protocol; the GUI does not invent percentage values.
- Temp Cleaner opens in preview mode. Deletion requires a separate confirmation.
- USB immunization requires a separate confirmation. The GUI does not expose USB block/unblock controls.
- Activation GUI requests status only; it does not expose activation or KMS mutation actions.
- Password reset remains the existing interactive local-account workflow and may request elevation.
- These six front-ends have Arabic/English labels, but the remaining standalone GUI modules have not yet all been migrated to the shared persisted language setting. A complete app-wide localization pass and RTL layout audit remain future work.
- Windows MSVC/MinGW compilation and Windows 10/11 runtime testing were not available in this Linux environment.


## v0.83.1-dev / Package v85 — front-end reliability polish

- Corrected the module-title target: the localized module name now updates its dedicated visible heading control and no longer overwrites the top-level window caption.
- Added Windows command-line argument quoting for engine paths, selected folder paths, report paths, and local account names. Embedded quotes and trailing backslashes are escaped according to Windows argv parsing rules.
- Engine launch now rejects a path that exists but is not a regular file.
- These are source-level changes. MSVC/MinGW compilation and Windows GUI interaction tests remain pending.


## v0.83.2-dev / Package v86 — embedded asynchronous engine console

- Replaced the separate engine console window with redirected stdout/stderr captured inside a read-only GUI output panel.
- Engine execution and pipe reading run on a background worker; the GUI message loop remains available while work is active.
- Added an indeterminate progress indicator, a Stop action that requests termination of the active process, and completion reporting with the process exit code.
- A percentage progress value is intentionally not shown because the legacy CLI engines do not share a structured progress protocol.
- Source/static validation only in the current Linux environment; Windows compiler and runtime qualification remain required.


## v0.83.3-dev / Package v87 — responsive VIP Studio customizer

- The main Customization Center chooses a window height based on the available display height, bounded to a practical range.
- A vertical scrollbar and mouse-wheel handling expose controls that would otherwise fall below the visible area on shorter displays.
- Scroll range is recalculated after window resizing while preserving the current scroll position.
- Appearance settings, wallpaper assets, and profile compatibility are unchanged.
- Static source checks pass; actual Win32 behavior on Windows 10/11, high-DPI, RTL, and multi-monitor configurations remains untested.
