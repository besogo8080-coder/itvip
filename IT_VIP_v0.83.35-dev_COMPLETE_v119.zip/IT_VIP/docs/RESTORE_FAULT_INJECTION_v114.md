# Restore fault-injection model — v114

## Purpose

v114 adds a deterministic, host-runnable **filesystem model** for abrupt-stop
boundaries in the Backup Center restore protocol. It exercises stops after the
`PREPARED` journal, before and after each `MoveFileExW`-equivalent replacement,
after each `APPLIED` journal, before `COMMITTED`, and after `COMMITTED` but
before transaction cleanup.

The tests verify that a pending transaction retains a parseable journal,
original snapshots for destinations that existed before restore, and either a
staged incoming file or a corresponding destination for every item. A separate
case checks the important ambiguous boundary: the destination move may have
completed while the last durable journal still says `APPLYING`.

## Critical limitation

This is a **Python protocol model**, not fault injection into the C++ executable.
It does not emulate Windows cache manager behavior, NTFS metadata ordering,
`FlushFileBuffers`, `MoveFileExW`, storage-controller caches, sudden power loss,
process termination at instruction-level boundaries, or removable-media
failures. It must not be described as proving crash consistency. No production
fault-injection environment variable or unsafe runtime switch was added.

The existing implementation remains a staged best-effort multi-file restore.
The v113 PowerShell inspector remains read-only. Interrupted transaction
folders must be preserved for operator review; this version does not add
automatic replay or rollback of uncertain state.

## Run

```powershell
python -m pytest -q tests/test_restore_fault_injection_v114.py
```

The same test is included in the normal pytest suite and portable CI job.
Windows-native fault injection and real NTFS/exFAT/FAT32 qualification remain
release gates.
