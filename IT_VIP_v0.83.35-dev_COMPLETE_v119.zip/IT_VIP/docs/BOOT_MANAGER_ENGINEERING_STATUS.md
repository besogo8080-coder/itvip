# IT VIP Boot Manager — Engineering Status

## Implemented in v0.58 (preflight foundation only)
- Read-only firmware-mode snapshot (Legacy BIOS / UEFI where Windows exposes the registry value).
- Read-only disk inventory using the Windows Storage cmdlets when available.
- Informational USB candidate hints; boot/system disks are explicitly flagged.
- Timestamped JSON and TXT reports.
- No partitioning, formatting, filesystem changes, boot-sector writes, ISO extraction, or bootloader installation.

## Not implemented
- There is no bootloader in this project yet. This script is not a bootable USB creator and must not be advertised as one.
- No ISO compatibility database, chainloader, GRUB/systemd-boot integration, Windows boot files, WinPE deployment, or Linux boot test.
- No UEFI Secure Boot signing chain or Microsoft third-party UEFI CA validation.
- No Legacy BIOS/UEFI/GPT/MBR destructive-media workflow.

## Required implementation sequence
1. Define supported bootloader architecture and licenses; select a maintained upstream bootloader or implement a genuinely independent loader with clear attribution. Never rename or misrepresent Ventoy.
2. Build a non-destructive image/ISO inspection layer and compatibility metadata. Treat each ISO family separately; do not assume generic chainloading.
3. Implement media preparation behind a separate explicit confirmation workflow, exact device identity confirmation, backup warning, and read-back verification.
4. Add signed UEFI binaries and document Secure Boot enrollment/trust requirements. Never claim Secure Boot support based only on a menu entry.
5. Test on disposable USB media across UEFI/GPT, UEFI/MBR where supported, Legacy BIOS, Secure Boot on/off, and real hardware/VM matrices.

## Safety
The preflight script is read-only. CandidateHint is not a device selection authorization. Any future media writer must require the user to select a physical disk by number, model, capacity, and serial where available, then type a destructive confirmation phrase. It must refuse Windows boot/system disks.


## v0.83.4-dev / Package v88 — read-only inventory detail
- Preflight schema advanced to `ITVIP-BOOT-PREFLIGHT-2`.
- Disk inventory now includes available model/manufacturer, serial number, UniqueId, location, offline/read-only state, partition count, and boot/system flags.
- Partition and volume details are collected read-only, including partition type/GPT type, drive letter, filesystem, capacity, and remaining space.
- Partial firmware, partition, or volume query failures are preserved as report warnings.
- Candidate hints remain informational and explicitly require manual physical-device identity verification.
- No disk mutation cmdlets, partitioning, formatting, or bootloader writes were added.
- PowerShell execution and Windows storage-provider behavior must still be validated on Windows; Linux static checks do not prove Windows runtime behavior.


## v0.83.5-dev / Package v89 — shareable report privacy
- Preflight schema advanced to `ITVIP-BOOT-PREFLIGHT-3`.
- Added optional `-RedactHardwareIdentifiers` mode; it redacts computer name, disk serial number, and disk UniqueId in both JSON and TXT output.
- Reports explicitly record whether redaction was enabled.
- The CMD launcher forwards arguments so the option can be used from the launcher: `BootManager-Preflight.cmd -RedactHardwareIdentifiers`.
- Default behavior remains backward-compatible and retains identifiers for local diagnostics. Review reports before sharing; model, capacity, bus type, and partition details remain visible.
- Added static contract tests. PowerShell and Windows Storage runtime behavior still require Windows verification.
