# IT VIP Universal Settings & Control Center

The Settings Center is a local maintenance utility for the portable project tree.

## Included actions
- Validate the presence of core project folders and known configuration files.
- Create missing standard folders (`config`, `data`, `assets`, `portable`, `reports`, `build`, `logs`, memory and session storage).
- Export known settings files to a timestamped folder under `reports`.
- Restore dashboard appearance defaults only, after making a timestamped backup and asking for confirmation.
- Open the local `config`, `data`, and `reports` folders.

## Boundaries
- This module does not read Windows Credential Manager secrets and does not export API keys.
- It does not rewrite agent/provider/team/workflow configuration.
- Export is a copy of selected config files, not a full backup; use Backup & Restore for project data backups.
- The tool uses paths relative to the portable application root.
- Restart the main application after restoring appearance defaults.

## Build
`build.bat msvc` or `build.bat mingw` builds `build/settings_center.exe` as part of the complete build.
