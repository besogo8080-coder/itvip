# IT VIP Agent Studio — Foundation

Version: 0.27.0-dev

Agent Studio is a Windows GUI profile manager. It stores profiles in `config/agents.ini` and supports:

- Agent display name and description.
- Provider label and a reference to an existing API profile ID/name.
- A comma-separated tool allowlist policy.
- Maximum step count (1–50) and timeout (5–3600 seconds).
- Enabled/disabled and approval-required flags.
- Create, select, edit, save, and delete profile operations.

## Security and scope

This release does **not** execute agents, call providers, orchestrate workflows, or invoke tools. Provider and API profile values are labels/references only. API credentials are not read, copied, or stored by Agent Studio. The tool allowlist is a policy field only; it is not an executable tool registry. No shell or arbitrary-command tool is provided. Profiles default to requiring approval.

Build with `build.bat msvc` from a Visual Studio 2022 Developer Command Prompt, or `build.bat mingw` with MinGW-w64. The target is `build/agent_studio.exe`. Windows compilation and runtime testing have not been performed in this environment.
