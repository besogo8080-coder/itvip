IT VIP Portable Apps Manager

The Portable Apps Manager stores its app catalogue in config\portable_apps.tsv.
Applications located inside the IT VIP folder are stored using relative paths so
that the catalogue can survive a USB drive-letter change. Applications outside
the IT VIP folder are stored with absolute paths and therefore are not guaranteed
portable. Removing an entry only removes it from the catalogue; it never deletes
the EXE. Launching is always a manual user action.

The catalogue is UTF-8 tab-separated text. Back it up with the rest of config.

Large application-folder import (v0.76):
Use Portable Apps Manager > Import complete folder to USB. The folder is copied
under portable\apps using CopyFileExW, which avoids loading an entire large file
into memory. The source is never deleted. Check available free space first.
FAT32 cannot store a single file above 4 GB; use exFAT or NTFS for such files.
After import, add the app's main EXE from the copied folder to the catalogue.
A failed import can leave a partial destination folder for manual review.
