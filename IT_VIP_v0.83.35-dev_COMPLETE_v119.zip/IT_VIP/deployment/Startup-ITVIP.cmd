@echo off
setlocal
set "SCRIPT=%~dp0Startup-ITVIP.ps1"
if not exist "%SCRIPT%" (
  echo IT VIP Startup Manager script was not found.
  pause
  exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Action All
set "RC=%ERRORLEVEL%"
echo.
echo IT VIP Startup Manager finished with exit code %RC%.
pause
exit /b %RC%
