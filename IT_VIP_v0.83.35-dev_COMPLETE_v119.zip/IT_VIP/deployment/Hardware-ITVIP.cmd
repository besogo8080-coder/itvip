@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Hardware-ITVIP.ps1" %*
set "RC=!ERRORLEVEL!"
if errorlevel 1 echo Hardware inventory completed with a PowerShell error.
pause
endlocal & exit /b %RC%
