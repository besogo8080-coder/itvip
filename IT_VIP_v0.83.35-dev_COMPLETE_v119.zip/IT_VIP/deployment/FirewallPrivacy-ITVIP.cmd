@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo IT VIP - Firewall & Privacy Center (READ-ONLY)
echo 1. Full audit
echo 2. Firewall only
echo 3. Privacy settings only
echo 4. Established connections only
set /p choice=Select action [1-4]:
if "%choice%"=="2" (set action=Firewall) else if "%choice%"=="3" (set action=Privacy) else if "%choice%"=="4" (set action=Connections) else (set action=All)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0FirewallPrivacy-ITVIP.ps1" -Action "%action%"
set "RC=!ERRORLEVEL!"
echo.
echo Reports are saved in the reports folder.
pause
endlocal & exit /b %RC%
