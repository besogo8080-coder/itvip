[CmdletBinding()]
param([switch]$SkipWindowsSecurityChecks)
$ErrorActionPreference = 'Continue'
$AppRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$ReportDir = Join-Path $AppRoot 'reports'
New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$checks = [Collections.Generic.List[object]]::new()
function Add-Check([string]$Area,[string]$Name,[string]$Status,[string]$Details) {
    $checks.Add([pscustomobject]@{Area=$Area;Check=$Name;Status=$Status;Details=$Details})
}
function Test-PathItem([string]$Relative,[string]$Label) {
    $p = Join-Path $AppRoot $Relative
    if (Test-Path -LiteralPath $p) { Add-Check 'Project' $Label 'PASS' $Relative }
    else { Add-Check 'Project' $Label 'FAIL' "Missing: $Relative" }
}
# Project structure checks are read-only and limited to known application paths.
foreach ($item in @(@('src/app/main.cpp','Main GUI source'),@('build.bat','Build script'),@('config','Configuration folder'),@('assets','Assets folder'),@('docs','Documentation folder'),@('deployment/Update-ITVIP.ps1','Update Manager'),@('deployment/Deploy-ITVIP.ps1','Deployment Manager'))) { Test-PathItem $item[0] $item[1] }
$requiredModules = @('scanner','usb_guard','tempclean','activator','pwrecover','portable_manager','copy_manager','security_center','ai_assistant','github_hub','api_manager','agent_studio','provider_hub','provider_runtime','team_studio','team_runner','workflow_studio','workflow_runner','run_history','memory_center','session_center','backup_center','settings_center')
foreach ($module in $requiredModules) {
    $src = Join-Path $AppRoot "src/modules/$module.cpp"
    if (Test-Path -LiteralPath $src -PathType Leaf) { Add-Check 'Source' $module 'PASS' 'Source file exists' }
    else { Add-Check 'Source' $module 'FAIL' 'Source file missing' }
    $exe = Join-Path $AppRoot "build/$module.exe"
    if (Test-Path -LiteralPath $exe -PathType Leaf) { Add-Check 'Build output' "$module.exe" 'PASS' 'Executable present; not executed' }
    else { Add-Check 'Build output' "$module.exe" 'WARN' 'Executable not found; source may still require a Windows build' }
}
try {
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    Add-Check 'System' 'Windows version' 'INFO' "$($os.Caption) | Build $($os.BuildNumber) | $env:PROCESSOR_ARCHITECTURE"
} catch { Add-Check 'System' 'Windows version' 'WARN' $_.Exception.Message }
try {
    $drive = Get-PSDrive -Name ([IO.Path]::GetPathRoot($AppRoot).Substring(0,1)) -ErrorAction Stop
    Add-Check 'Storage' 'Application drive free space' 'INFO' ("{0:N2} GB free" -f ($drive.Free/1GB))
} catch { Add-Check 'Storage' 'Application drive free space' 'WARN' $_.Exception.Message }
if (-not $SkipWindowsSecurityChecks) {
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        Add-Check 'Security' 'Microsoft Defender real-time protection' $(if ($mp.RealTimeProtectionEnabled) {'PASS'} else {'WARN'}) ([string]$mp.RealTimeProtectionEnabled)
        Add-Check 'Security' 'Defender antivirus enabled' $(if ($mp.AntivirusEnabled) {'PASS'} else {'WARN'}) ([string]$mp.AntivirusEnabled)
    } catch { Add-Check 'Security' 'Microsoft Defender status' 'WARN' 'Unavailable or access denied; verify in Windows Security.' }
    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($profile in $profiles) { Add-Check 'Security' "Firewall $($profile.Name)" $(if ($profile.Enabled) {'PASS'} else {'WARN'}) ([string]$profile.Enabled) }
    } catch { Add-Check 'Security' 'Windows Firewall status' 'WARN' 'Unavailable; verify in Windows Security.' }
    try {
        $sb = Confirm-SecureBootUEFI -ErrorAction Stop
        Add-Check 'Security' 'Secure Boot' $(if ($sb) {'PASS'} else {'WARN'}) ([string]$sb)
    } catch { Add-Check 'Security' 'Secure Boot' 'INFO' 'Not available on this firmware/boot mode or permission level.' }
    try {
        $uac = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA -ErrorAction Stop
        Add-Check 'Security' 'UAC policy' $(if ($uac.EnableLUA -eq 1) {'PASS'} else {'WARN'}) ([string]$uac.EnableLUA)
    } catch { Add-Check 'Security' 'UAC policy' 'WARN' 'Could not read UAC policy.' }
}
$summary = [ordered]@{ Product='IT VIP Security & Diagnostics Center'; GeneratedAt=(Get-Date).ToString('o'); AppRoot=$AppRoot; ReadOnly=$true; Checks=$checks }
$jsonPath = Join-Path $ReportDir "itvip_diagnostics_$stamp.json"
$txtPath = Join-Path $ReportDir "itvip_diagnostics_$stamp.txt"
$summary | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
$lines = @('IT VIP — Security & Diagnostics Report',"Generated: $($summary.GeneratedAt)","Application: $AppRoot",'Mode: READ-ONLY','')
foreach ($c in $checks) { $lines += "[$($c.Status)] [$($c.Area)] $($c.Check) — $($c.Details)" }
$lines += ''; $lines += "Summary: $(@($checks | Where-Object Status -eq 'PASS').Count) PASS | $(@($checks | Where-Object Status -eq 'WARN').Count) WARN | $(@($checks | Where-Object Status -eq 'FAIL').Count) FAIL | $(@($checks | Where-Object Status -eq 'INFO').Count) INFO"
$lines | Set-Content -LiteralPath $txtPath -Encoding UTF8
Write-Host ($lines -join [Environment]::NewLine)
Write-Host "`nReports saved:`n$jsonPath`n$txtPath"
Write-Host 'No settings were changed. No repair actions were performed.'
