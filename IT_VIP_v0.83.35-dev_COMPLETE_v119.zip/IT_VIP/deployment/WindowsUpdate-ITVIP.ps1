[CmdletBinding()]
param(
  [ValidateRange(1,500)][int]$MaxUpdates=100,
  [ValidateRange(1,500)][int]$HistoryCount=100,
  [switch]$SkipAvailableSearch,
  [switch]$SkipHistory
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$warnings=New-Object System.Collections.Generic.List[string]
$available=New-Object System.Collections.Generic.List[object]
$history=New-Object System.Collections.Generic.List[object]
$searchStatus='NotRun'
$historyStatus='NotRun'
$serviceInfo=$null

# This module only queries the Windows Update Agent API. It never downloads,
# installs, hides, accepts EULAs, changes services, or changes update policies.
try {
  $svc=Get-Service -Name wuauserv -ErrorAction Stop
  $startType='Unknown'; try { $startType=[string]$svc.StartType } catch {}
  $serviceInfo=[pscustomobject]@{Name=$svc.Name;Status=[string]$svc.Status;StartType=$startType}
} catch { $warnings.Add("Windows Update service status unavailable: $($_.Exception.Message)") }

$session=$null
$searcher=$null
try {
  $session=New-Object -ComObject Microsoft.Update.Session -ErrorAction Stop
  $searcher=$session.CreateUpdateSearcher()
  if(-not $SkipAvailableSearch){
    try {
      # Uses the machine's configured Windows Update / WSUS source. Search may
      # contact that source; the CMD launcher asks before invoking this script.
      $result=$searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
      $searchStatus='Completed'
      $limit=[Math]::Min([int]$result.Updates.Count,$MaxUpdates)
      for($i=0;$i -lt $limit;$i++){
        $u=$result.Updates.Item($i)
        $kb=@(); try { foreach($k in $u.KBArticleIDs){$kb+=[string]$k} } catch {}
        $maxDownload=$null; try { $maxDownload=[int64]$u.MaxDownloadSize } catch {}
        $available.Add([pscustomobject]@{
          Title=[string]$u.Title;UpdateID=[string]$u.Identity.UpdateID
          RevisionNumber=[int]$u.Identity.RevisionNumber;KBArticleIDs=$kb
          Type=[string]$u.Type;IsDownloaded=[bool]$u.IsDownloaded
          IsMandatory=[bool]$u.IsMandatory;RebootRequired=[bool]$u.RebootRequired
          MaxDownloadSizeBytes=$maxDownload
        })
      }
      if($result.Updates.Count -gt $MaxUpdates){$warnings.Add("Available update list capped at $MaxUpdates of $($result.Updates.Count).")}
    } catch { $searchStatus='Failed'; $warnings.Add("Available update search failed: $($_.Exception.Message)") }
  }
  if(-not $SkipHistory){
    try {
      $count=[Math]::Min([int]$searcher.GetTotalHistoryCount(),$HistoryCount)
      if($count -gt 0){
        $items=$searcher.QueryHistory(0,$count)
        foreach($h in $items){
          $historyDate=$null; if($h.Date){$historyDate=$h.Date.ToString('o')}
          $history.Add([pscustomobject]@{
            Date=$historyDate;Title=[string]$h.Title
            Operation=[int]$h.Operation;ResultCode=[int]$h.ResultCode
            HResult=('{0:X8}' -f ([uint32]$h.HResult));UpdateID=[string]$h.UpdateIdentity.UpdateID
            ClientApplicationID=[string]$h.ClientApplicationID
          })
        }
      }
      $historyStatus='Completed'
    } catch { $historyStatus='Failed'; $warnings.Add("Update history query failed: $($_.Exception.Message)") }
  }
} catch {
  $searchStatus=if($SkipAvailableSearch){'Skipped'}else{'Failed'}
  if(-not $SkipAvailableSearch){$warnings.Add("Windows Update Agent API unavailable: $($_.Exception.Message)")}
} finally {
  if($searcher){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($searcher)}catch{}}
  if($session){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($session)}catch{}}
}

$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$result=[ordered]@{
 Product='IT VIP Windows Update Manager';Schema='ITVIP-WINDOWSUPDATE-1';Timestamp=(Get-Date).ToString('o')
 ReadOnly=$true;SearchStatus=$searchStatus;HistoryStatus=$historyStatus;UpdateService=$serviceInfo
 AvailableUpdateCount=$available.Count;AvailableUpdates=@($available);HistoryCount=$history.Count;History=@($history);Warnings=@($warnings)
 Safety=@('Queries the configured Windows Update Agent source; an available-update search may contact Microsoft Update or an organization WSUS server.','No update is downloaded, installed, hidden, declined, or scheduled.','No Windows Update service, policy, registry, or restart setting is changed.','A listed update is not a recommendation that it is safe or appropriate for every device; review applicability and vendor guidance.','The result is limited to software updates returned by the configured update source and the requested result caps.')
}
$json=Join-Path $reportDir "itvip_windows_update_$stamp.json"
$txt=Join-Path $reportDir "itvip_windows_update_$stamp.txt"
$csv=Join-Path $reportDir "itvip_windows_update_$stamp.csv"
$result|ConvertTo-Json -Depth 8|Set-Content -Encoding UTF8 $json
$available|Select-Object Title,UpdateID,RevisionNumber,KBArticleIDs,IsDownloaded,IsMandatory,RebootRequired,MaxDownloadSizeBytes|Export-Csv -NoTypeInformation -Encoding UTF8 $csv
$lines=@('IT VIP Windows Update Manager',"Timestamp: $($result.Timestamp)",'READ-ONLY WINDOWS UPDATE INVENTORY',"Update service: $(if($serviceInfo){$serviceInfo.Status}else{'Unavailable'})","Available search: $searchStatus | History: $historyStatus","Available updates returned: $($available.Count) | History entries: $($history.Count)",'','AVAILABLE UPDATES')
foreach($u in $available){$lines+=@("$($u.Title)","Update ID: $($u.UpdateID) | Revision: $($u.RevisionNumber) | KB: $($u.KBArticleIDs -join ', ')","Downloaded: $($u.IsDownloaded) | Mandatory: $($u.IsMandatory) | Reboot required: $($u.RebootRequired)",'')}
$lines+=@('RECENT UPDATE HISTORY')
foreach($h in ($history|Select-Object -First 100)){$lines+=@("$($h.Date) | $($h.Title) | Operation: $($h.Operation) | Result: $($h.ResultCode) | HRESULT: $($h.HResult)")}
$lines+=@('','WARNINGS')+$warnings+@('','READ-ONLY: no update was downloaded or installed and no Windows settings were changed. Review update applicability before taking action.')
$lines|Set-Content -Encoding UTF8 $txt
Write-Host 'Windows Update inventory completed (read-only).' -ForegroundColor Cyan
Write-Host "Available: $($available.Count) | History: $($history.Count) | Search: $searchStatus | History query: $historyStatus"
Write-Host "JSON: $json`nTXT: $txt`nCSV: $csv"
