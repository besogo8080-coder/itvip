@echo off
setlocal
pushd "%~dp0.." || exit /b 1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BootManager-Preflight.ps1" %*
set "RC=%ERRORLEVEL%"
echo.
echo Read-only preflight finished. No USB device was modified.
pause
popd
exit /b %RC%
