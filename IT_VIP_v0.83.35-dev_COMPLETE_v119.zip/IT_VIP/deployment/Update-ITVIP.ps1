[CmdletBinding()]
param(
    [ValidateSet('Preflight','CreateManifest','VerifyPackage','StageUpdate','ApplyUpdate','RollbackLatest')]
    [string]$Action = 'Preflight',
    [string]$PackagePath = '',
    [string]$Version = '',
    [string]$ManifestPath = ''
)
$ErrorActionPreference = 'Stop'
$AppRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$ManifestName = 'ITVIP_UPDATE.json'
$AllowedRoots = @('build','assets','docs','deployment')
$AllowedRootFiles = @('README.md','README_AR.md')

function Get-SafeRelativePath([string]$RelativePath) {
    if ([string]::IsNullOrWhiteSpace($RelativePath)) { throw 'Empty update path is not allowed.' }
    $p = $RelativePath.Replace('/','\')
    if ([IO.Path]::IsPathRooted($p) -or $p -match '(^|\\)\.\.(\\|$)' -or $p.Contains(':')) { throw "Unsafe update path: $RelativePath" }
    $parts = $p -split '\\'
    $first = $parts[0]
    if (($AllowedRoots -notcontains $first) -and ($AllowedRootFiles -notcontains $p)) { throw "Update path is outside the approved runtime allowlist: $RelativePath" }
    if ($first -eq 'build' -and ($parts.Count -ne 2 -or [IO.Path]::GetExtension($p) -ine '.exe')) { throw "Only top-level build\*.exe files may be updated: $RelativePath" }
    return $p
}
function Get-Manifest([string]$Root) {
    $manifest = Join-Path $Root $ManifestName
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw "$ManifestName is missing." }
    $m = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($m.Schema -ne 'ITVIP-UPDATE-1' -or [string]::IsNullOrWhiteSpace([string]$m.Version) -or -not $m.Files) { throw 'Unsupported or incomplete update manifest.' }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $m.Files) {
        $rel = Get-SafeRelativePath ([string]$entry.Path)
        if (-not $seen.Add($rel)) { throw "Duplicate manifest path: $rel" }
        if ([string]$entry.SHA256 -notmatch '^[A-Fa-f0-9]{64}$') { throw "Invalid SHA-256 for $rel" }
        if ([long]$entry.Size -lt 0) { throw "Invalid size for $rel" }
    }
    return $m
}
function Test-UpdatePackage([string]$Root) {
    $rootFull = [IO.Path]::GetFullPath($Root)
    $m = Get-Manifest $rootFull
    $issues = [Collections.Generic.List[string]]::new()
    foreach ($entry in $m.Files) {
        $rel = Get-SafeRelativePath ([string]$entry.Path)
        $file = Join-Path $rootFull $rel
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { $issues.Add("Missing: $rel"); continue }
        $item = Get-Item -LiteralPath $file -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { $issues.Add("Reparse point rejected: $rel"); continue }
        if ($item.Length -ne [long]$entry.Size) { $issues.Add("Size mismatch: $rel"); continue }
        $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($actual -ne ([string]$entry.SHA256).ToUpperInvariant()) { $issues.Add("SHA-256 mismatch: $rel") }
    }
    if ($issues.Count) { throw ($issues -join [Environment]::NewLine) }
    return $m
}
function New-UpdateManifest([string]$Root,[string]$ReleaseVersion) {
    if ([string]::IsNullOrWhiteSpace($ReleaseVersion)) { throw 'Supply -Version when creating a manifest.' }
    $rootFull = [IO.Path]::GetFullPath($Root)
    if (-not (Test-Path -LiteralPath $rootFull -PathType Container)) { throw 'Package directory does not exist.' }
    $files = @()
    foreach ($folder in $AllowedRoots) {
        $dir = Join-Path $rootFull $folder
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { continue }
        Get-ChildItem -LiteralPath $dir -File -Recurse -Force | ForEach-Object {
            if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse point rejected: $($_.FullName)" }
            $rel = $_.FullName.Substring($rootFull.Length).TrimStart('\','/')
            $rel = Get-SafeRelativePath $rel
            $files += [pscustomobject]@{ Path=$rel; Size=[long]$_.Length; SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash }
        }
    }
    foreach ($name in $AllowedRootFiles) {
        $f = Join-Path $rootFull $name
        if (Test-Path -LiteralPath $f -PathType Leaf) { $i=Get-Item -LiteralPath $f; $files += [pscustomobject]@{Path=$name;Size=[long]$i.Length;SHA256=(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash} }
    }
    if ($files.Count -eq 0) { throw 'No approved update payload files were found.' }
    $manifest = [ordered]@{ Schema='ITVIP-UPDATE-1'; Product='IT VIP – ULTIMATE WINDOWS TOOLKIT'; Version=$ReleaseVersion; CreatedUtc=[DateTime]::UtcNow.ToString('o'); Files=$files }
    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $rootFull $ManifestName) -Encoding UTF8
    Write-Host "Manifest created for $($files.Count) files, version $ReleaseVersion."
}
function Get-StageRoot([string]$ReleaseVersion) {
    $safe = ($ReleaseVersion -replace '[^A-Za-z0-9._-]','_')
    if ([string]::IsNullOrWhiteSpace($safe)) { throw 'Invalid version.' }
    return Join-Path $AppRoot (Join-Path '.update-staging' $safe)
}
function Invoke-Stage([string]$Package) {
    $source = (Resolve-Path -LiteralPath $Package).Path
    $m = Test-UpdatePackage $source
    $stage = Get-StageRoot ([string]$m.Version)
    if (Test-Path -LiteralPath $stage) { throw "Staging folder already exists: $stage. Remove it manually after reviewing it." }
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    try {
        foreach ($entry in $m.Files) {
            $rel = Get-SafeRelativePath ([string]$entry.Path)
            $src = Join-Path $source $rel; $dst = Join-Path $stage $rel
            $parent = Split-Path -Parent $dst
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
            Copy-Item -LiteralPath $src -Destination $dst
        }
        Copy-Item -LiteralPath (Join-Path $source $ManifestName) -Destination (Join-Path $stage $ManifestName)
        $null = Test-UpdatePackage $stage
        Write-Host "Update verified and staged: $stage" -ForegroundColor Green
        Write-Host 'No application files have been changed yet.'
    } catch { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue; throw }
}
function Invoke-Apply([string]$ReleaseVersion) {
    $stage = Get-StageRoot $ReleaseVersion
    if (-not (Test-Path -LiteralPath $stage -PathType Container)) { throw "No staged update found for version $ReleaseVersion." }
    $m = Test-UpdatePackage $stage
    $running = Get-Process -Name 'ITVIP' -ErrorAction SilentlyContinue
    if ($running) { throw 'Close IT VIP before applying an update. No process was stopped automatically.' }
    Write-Host "Target version: $($m.Version)" -ForegroundColor Cyan
    Write-Host "Files to update: $($m.Files.Count)"
    $answer = Read-Host 'Type APPLY to continue (anything else cancels)'
    if ($answer -cne 'APPLY') { Write-Host 'Cancelled. Existing installation unchanged.'; return }
    $backupRoot = Join-Path $AppRoot (Join-Path 'data\update-backups' ([DateTime]::UtcNow.ToString('yyyyMMdd_HHmmss_fff')))
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $state = [ordered]@{ Schema='ITVIP-ROLLBACK-1'; Version=[string]$m.Version; CreatedUtc=[DateTime]::UtcNow.ToString('o'); Files=@() }
    $applied = [Collections.Generic.List[object]]::new()
    try {
        foreach ($entry in $m.Files) {
            $rel = Get-SafeRelativePath ([string]$entry.Path)
            $target = Join-Path $AppRoot $rel
            $staged = Join-Path $stage $rel
            $targetParent = Split-Path -Parent $target
            New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
            $existed = Test-Path -LiteralPath $target -PathType Leaf
            if ($existed) { $targetItem=Get-Item -LiteralPath $target -Force; if (($targetItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Refusing to replace reparse point: $rel" } }
            $backupRel = $null
            if ($existed) {
                $backupRel = $rel
                $backupFile = Join-Path $backupRoot $backupRel
                New-Item -ItemType Directory -Path (Split-Path -Parent $backupFile) -Force | Out-Null
                Copy-Item -LiteralPath $target -Destination $backupFile
            }
            $temp = "$target.itvip-new"
            Copy-Item -LiteralPath $staged -Destination $temp -Force
            $stagedHash = (Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash
            if ($stagedHash -ne ([string]$entry.SHA256).ToUpperInvariant()) { throw "Staged file changed during apply: $rel" }
            Move-Item -LiteralPath $temp -Destination $target -Force
            $applied.Add([pscustomobject]@{Path=$rel;Existed=$existed;BackupPath=$backupRel})
        }
        $state.Files = @($applied)
        $state | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $backupRoot 'ROLLBACK.json') -Encoding UTF8
        Write-Host "Update $($m.Version) applied. Rollback data: $backupRoot" -ForegroundColor Green
    } catch {
        for ($idx = $applied.Count - 1; $idx -ge 0; $idx--) {
            $item = $applied[$idx]
            $target = Join-Path $AppRoot (Get-SafeRelativePath $item.Path)
            if ($item.Existed) { Copy-Item -LiteralPath (Join-Path $backupRoot $item.BackupPath) -Destination $target -Force }
            else { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
        }
        throw "Update failed; attempted automatic rollback. Original error: $_"
    }
}
function Invoke-Rollback {
    $base = Join-Path $AppRoot 'data\update-backups'
    if (-not (Test-Path -LiteralPath $base -PathType Container)) { throw 'No update rollback backups exist.' }
    $latest = Get-ChildItem -LiteralPath $base -Directory | Sort-Object Name -Descending | Select-Object -First 1
    if (-not $latest) { throw 'No update rollback backup exists.' }
    $stateFile = Join-Path $latest.FullName 'ROLLBACK.json'
    if (-not (Test-Path -LiteralPath $stateFile -PathType Leaf)) { throw 'Latest backup has no valid ROLLBACK.json.' }
    $state = Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($state.Schema -ne 'ITVIP-ROLLBACK-1' -or -not $state.Files) { throw 'Unsupported rollback manifest.' }
    if (Get-Process -Name 'ITVIP' -ErrorAction SilentlyContinue) { throw 'Close IT VIP before rollback.' }
    $confirm = Read-Host "Type ROLLBACK to restore the previous files from $($latest.Name)"
    if ($confirm -cne 'ROLLBACK') { Write-Host 'Rollback cancelled.'; return }
    foreach ($item in $state.Files) {
        $rel = Get-SafeRelativePath ([string]$item.Path)
        $target = Join-Path $AppRoot $rel
        if ($item.Existed) {
            $backupRel = Get-SafeRelativePath ([string]$item.BackupPath)
            $backup = Join-Path $latest.FullName $backupRel
            if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw "Rollback file missing: $backupRel" }
            New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
            Copy-Item -LiteralPath $backup -Destination $target -Force
        } else { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
    }
    Write-Host 'Rollback completed.' -ForegroundColor Green
}
switch ($Action) {
    'Preflight' {
        $version = 'unknown'; $readme = Join-Path $AppRoot 'docs\BUILD_STATUS.txt'
        if (Test-Path -LiteralPath $readme) { $line = Select-String -LiteralPath $readme -Pattern '^Version:' | Select-Object -First 1; if ($line) { $version = ($line.Line -split ':',2)[1].Trim() } }
        [pscustomobject]@{ Product='IT VIP'; InstalledVersion=$version; AppRoot=$AppRoot; StagingRoot=(Join-Path $AppRoot '.update-staging'); RollbackRoot=(Join-Path $AppRoot 'data\update-backups'); NetworkDownload='Disabled'; AutomaticElevation='Disabled' } | Format-List
    }
    'CreateManifest' { New-UpdateManifest -Root $PackagePath -ReleaseVersion $Version }
    'VerifyPackage' { $resolved=(Resolve-Path -LiteralPath $PackagePath).Path; $m=Test-UpdatePackage $resolved; Write-Host "PASS: $($m.Version) — $($m.Files.Count) files verified." -ForegroundColor Green }
    'StageUpdate' { Invoke-Stage -Package $PackagePath }
    'ApplyUpdate' { Invoke-Apply -ReleaseVersion $Version }
    'RollbackLatest' { Invoke-Rollback }
}
