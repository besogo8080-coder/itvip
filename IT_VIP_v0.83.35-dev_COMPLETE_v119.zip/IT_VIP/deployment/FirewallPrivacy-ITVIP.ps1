[CmdletBinding()]
param([ValidateSet('All','Firewall','Privacy','Connections')][string]$Action='All')
$ErrorActionPreference='SilentlyContinue'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings=New-Object System.Collections.Generic.List[string]
function Get-RegistryValueSnapshot([string]$Path,[string[]]$Names) {
  $out=[ordered]@{Path=$Path;Exists=$false;Values=@()}
  try {
    if(Test-Path -LiteralPath $Path) {
      $out.Exists=$true; $item=Get-ItemProperty -LiteralPath $Path
      $values=@()
      foreach($name in $Names) {
        $prop=$item.PSObject.Properties[$name]
        if($null -ne $prop) { $values += [pscustomobject]@{Name=$name;Value=$prop.Value} }
      }
      $out.Values=$values
    }
  } catch { $warnings.Add("Registry read failed for $Path") }
  [pscustomobject]$out
}
$firewallProfiles=@(); $firewallRules=[ordered]@{}; $networkProfiles=@()
$privacy=[ordered]@{}
$connections=@()
if($Action -in @('All','Firewall')) {
  try { $firewallProfiles=@(Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowInboundRules,NotifyOnListen,LogAllowed,LogBlocked,LogFileName) }
  catch { $warnings.Add('Get-NetFirewallProfile is unavailable; firewall profile inventory was skipped.') }
  try {
    $rules=@(Get-NetFirewallRule -PolicyStore ActiveStore -Enabled True)
    foreach($profile in @('Domain','Private','Public')) {
      $subset=@($rules | Where-Object {$_.Profile -eq $profile -or $_.Profile -eq 'Any' -or $_.Profile -eq 'Domain, Private, Public'})
      $firewallRules[$profile]=[ordered]@{
        EnabledRules=$subset.Count
        InboundAllow=@($subset | Where-Object {$_.Direction -eq 'Inbound' -and $_.Action -eq 'Allow'}).Count
        InboundBlock=@($subset | Where-Object {$_.Direction -eq 'Inbound' -and $_.Action -eq 'Block'}).Count
        OutboundAllow=@($subset | Where-Object {$_.Direction -eq 'Outbound' -and $_.Action -eq 'Allow'}).Count
        OutboundBlock=@($subset | Where-Object {$_.Direction -eq 'Outbound' -and $_.Action -eq 'Block'}).Count
      }
    }
  } catch { $warnings.Add('Firewall rule summary could not be collected.') }
  try { $networkProfiles=@(Get-NetConnectionProfile | Select-Object Name,InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity) }
  catch { $warnings.Add('Network profile inventory is unavailable.') }
}
if($Action -in @('All','Privacy')) {
  $privacy['UAC'] = Get-RegistryValueSnapshot 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' @('EnableLUA','ConsentPromptBehaviorAdmin','PromptOnSecureDesktop')
  $privacy['SmartScreen'] = Get-RegistryValueSnapshot 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' @('SmartScreenEnabled')
  $privacy['Advertising'] = Get-RegistryValueSnapshot 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' @('Enabled')
  $privacy['ContentDelivery'] = Get-RegistryValueSnapshot 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' @('SubscribedContent-338393Enabled','SubscribedContent-353694Enabled','SystemPaneSuggestionsEnabled')
  $privacy['AppPrivacy'] = Get-RegistryValueSnapshot 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' @('LetAppsAccessCamera','LetAppsAccessMicrophone','LetAppsAccessLocation','LetAppsAccessContacts')
  $privacy['TelemetryPolicy'] = Get-RegistryValueSnapshot 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' @('AllowTelemetry')
}
if($Action -in @('All','Connections')) {
  try {
    $connections=@(Get-NetTCPConnection -State Established | Select-Object -First 250 LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess,@{n='ProcessName';e={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName}})
  } catch { $warnings.Add('Established TCP connection inventory is unavailable.') }
}
$result=[ordered]@{
  Product='IT VIP Firewall & Privacy Center'; Schema='ITVIP-FIREWALL-PRIVACY-1'
  Timestamp=(Get-Date).ToString('o'); Action=$Action; ReadOnly=$true
  FirewallProfiles=@($firewallProfiles); EnabledFirewallRuleSummary=$firewallRules
  NetworkProfiles=@($networkProfiles); PrivacySettings=$privacy
  EstablishedTcpConnections=@($connections); Warnings=@($warnings)
  Limits=@('Read-only inventory only: no firewall rules, privacy settings, registry values, services, or network configuration are changed.','Firewall rule counts are summaries; they do not prove that a specific application is safe or unsafe.','Privacy registry values may be absent because Windows defaults, policy scope, or edition differ. Absence is not interpreted as enabled or disabled.','Connection inventory is limited to the first 250 established TCP connections visible to the current account.','No packet capture, remote scan, traffic interception, or application blocking is performed.')
}
$json=Join-Path $reportDir "itvip_firewall_privacy_$stamp.json"
$txt=Join-Path $reportDir "itvip_firewall_privacy_$stamp.txt"
$result | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $json
@('IT VIP Firewall & Privacy Center',"Timestamp: $($result.Timestamp)","Action: $Action",'READ-ONLY AUDIT','', 'FIREWALL PROFILES',(@($firewallProfiles) | Format-Table -AutoSize | Out-String),'ENABLED RULE SUMMARY',($firewallRules | ConvertTo-Json -Depth 5),'NETWORK PROFILES',(@($networkProfiles) | Format-Table -AutoSize | Out-String),'PRIVACY SETTINGS',($privacy | ConvertTo-Json -Depth 8),'ESTABLISHED TCP CONNECTIONS',(@($connections) | Select-Object -First 50 | Format-Table -AutoSize | Out-String),'WARNINGS',($warnings -join "`r`n"),'No firewall or privacy settings were modified.') | Set-Content -Encoding UTF8 $txt
Write-Host 'Firewall & Privacy assessment completed. No settings were changed.' -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt"
