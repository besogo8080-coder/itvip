@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo IT VIP - Software & Installed Apps Manager (READ-ONLY)
echo 1. All registered desktop applications
echo 2. Machine-wide applications
echo 3. Current-user applications
echo 4. Search by display name
set /p choice=Select action [1-4]:
if "%choice%"=="2" (set scope=Machine&set filter=) else if "%choice%"=="3" (set scope=CurrentUser&set filter=) else if "%choice%"=="4" (set scope=All&set /p filter=Name contains:) else (set scope=All&set filter=)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Software-ITVIP.ps1" -Scope "%scope%" -NameLike "%filter%"
set "RC=!ERRORLEVEL!"
echo.
echo Reports are saved in the reports folder. Inventory is read-only.
pause
endlocal & exit /b %RC%
