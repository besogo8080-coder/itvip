@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0.."
echo IT VIP Process & Performance Manager
echo 1. Inventory only (safe, read-only)
echo 2. Stop a process by PID (requires typed confirmation)
set /p choice=Choose 1 or 2: 
if "%choice%"=="2" goto stopproc
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Performance-ITVIP.ps1" -Action Inventory
set "RC=!ERRORLEVEL!"
goto done
:stopproc
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Performance-ITVIP.ps1" -Action StopProcess
set "RC=!ERRORLEVEL!"
:done
echo.
pause
endlocal & exit /b %RC%
