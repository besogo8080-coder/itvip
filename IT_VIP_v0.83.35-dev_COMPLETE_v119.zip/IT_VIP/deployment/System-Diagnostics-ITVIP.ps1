[CmdletBinding()]
param(
    [ValidateRange(1,30)][int]$Samples = 5,
    [ValidateRange(1,10)][int]$IntervalSeconds = 2,
    [ValidateRange(1,100)][int]$CpuAlertPercent = 85,
    [ValidateRange(1,100)][int]$MemoryAlertPercent = 90,
    [ValidateRange(1,50)][int]$DiskFreeAlertPercent = 10,
    [switch]$LiveMonitoring,
    [ValidateRange(1,60)][int]$DurationMinutes = 5
)
$ErrorActionPreference = 'Continue'
$AppRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$ReportDir = Join-Path $AppRoot 'reports'
New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings = [Collections.Generic.List[string]]::new()
$sampleRows = [Collections.Generic.List[object]]::new()
$alerts = [Collections.Generic.List[string]]::new()
$previousNetworkCounters = @{}
$liveNetworkRows = @()
$effectiveSamples = $Samples
if ($LiveMonitoring) { $effectiveSamples = [math]::Min(3601, [math]::Max(1, [int][math]::Ceiling(($DurationMinutes * 60) / $IntervalSeconds) + 1)) }
function Read-CimSafe([string]$Class, [string]$Label) {
    try { return @(Get-CimInstance -ClassName $Class -ErrorAction Stop) }
    catch { $warnings.Add("$Label unavailable: $($_.Exception.Message)"); return @() }
}
$os = Read-CimSafe 'Win32_OperatingSystem' 'Operating system'
$cpuInfo = Read-CimSafe 'Win32_Processor' 'CPU information'
$diskInfo = Read-CimSafe 'Win32_LogicalDisk' 'Logical disks' | Where-Object { $_.DriveType -eq 3 }
$adapterInfo = @()
try { $adapterInfo = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object Status -eq 'Up') }
catch { $warnings.Add("Network adapter inventory unavailable: $($_.Exception.Message)") }
$thermalInfo = @()
try {
    $thermalInfo = @(Get-CimInstance -Namespace 'root/wmi' -ClassName 'MSAcpi_ThermalZoneTemperature' -ErrorAction Stop | ForEach-Object {
        $celsius = [math]::Round(($_.CurrentTemperature / 10) - 273.15, 1)
        [pscustomobject]@{ InstanceName=[string]$_.InstanceName; Celsius=$celsius }
    })
} catch { $warnings.Add('Thermal sensors unavailable through the standard ACPI WMI provider; this is common on many systems.') }
for ($i = 1; $i -le $effectiveSamples; $i++) {
    $cpuLoad = $null; $totalMemoryMb = $null; $freeMemoryMb = $null; $usedMemoryPercent = $null
    try {
        $cpuRows = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
        if ($cpuRows.Count) { $cpuLoad = [math]::Round((($cpuRows | Measure-Object -Property LoadPercentage -Average).Average), 1) }
    } catch { $warnings.Add("CPU sample $i unavailable: $($_.Exception.Message)") }
    if ($os.Count) {
        $freshOs = $os[0]
        try { $freshOs = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
        $totalMemoryMb = [math]::Round(([double]$freshOs.TotalVisibleMemorySize / 1024), 1)
        $freeMemoryMb = [math]::Round(([double]$freshOs.FreePhysicalMemory / 1024), 1)
        if ($totalMemoryMb -gt 0) { $usedMemoryPercent = [math]::Round((($totalMemoryMb - $freeMemoryMb) / $totalMemoryMb) * 100, 1) }
    }
    $networkReceiveBytesPerSec = $null; $networkSendBytesPerSec = $null
    $currentNetworkRows = @()
    foreach ($adapter in $adapterInfo) {
        try {
            $stats = Get-NetAdapterStatistics -Name $adapter.Name -ErrorAction Stop
            $rx = [double]$stats.ReceivedBytes; $tx = [double]$stats.SentBytes
            if ($previousNetworkCounters.ContainsKey([string]$adapter.Name)) {
                $prior = $previousNetworkCounters[[string]$adapter.Name]
                $elapsed = [math]::Max(1, $IntervalSeconds)
                $rxRate = [math]::Round([math]::Max(0, ($rx - $prior.Rx) / $elapsed), 1)
                $txRate = [math]::Round([math]::Max(0, ($tx - $prior.Tx) / $elapsed), 1)
                $currentNetworkRows += [pscustomobject]@{ Name=[string]$adapter.Name; ReceiveBytesPerSec=$rxRate; SendBytesPerSec=$txRate }
            }
            $previousNetworkCounters[[string]$adapter.Name] = @{ Rx=$rx; Tx=$tx }
        } catch { $warnings.Add("Network rate sample $i unavailable for $($adapter.Name): $($_.Exception.Message)") }
    }
    if ($currentNetworkRows.Count) {
        $networkReceiveBytesPerSec = [math]::Round((($currentNetworkRows | Measure-Object -Property ReceiveBytesPerSec -Sum).Sum), 1)
        $networkSendBytesPerSec = [math]::Round((($currentNetworkRows | Measure-Object -Property SendBytesPerSec -Sum).Sum), 1)
        $liveNetworkRows = @($currentNetworkRows)
    }
    $sampleAlerts = [Collections.Generic.List[string]]::new()
    if ($null -ne $cpuLoad -and $cpuLoad -ge $CpuAlertPercent) { $sampleAlerts.Add("CPU load $cpuLoad% reached threshold $CpuAlertPercent%") }
    if ($null -ne $usedMemoryPercent -and $usedMemoryPercent -ge $MemoryAlertPercent) { $sampleAlerts.Add("Memory use $usedMemoryPercent% reached threshold $MemoryAlertPercent%") }
    foreach ($alert in $sampleAlerts) { $alerts.Add("Sample ${i}: $alert") }
    $sampleRows.Add([pscustomobject]@{ Sample=$i; Timestamp=(Get-Date).ToString('o'); CpuLoadPercent=$cpuLoad; MemoryUsedPercent=$usedMemoryPercent; MemoryTotalMB=$totalMemoryMb; MemoryFreeMB=$freeMemoryMb; NetworkReceiveBytesPerSec=$networkReceiveBytesPerSec; NetworkSendBytesPerSec=$networkSendBytesPerSec; Alerts=(@($sampleAlerts) -join '; ') })
    if ($LiveMonitoring) {
        $cpuText = if ($null -eq $cpuLoad) { 'n/a' } else { "$cpuLoad%" }
        $ramText = if ($null -eq $usedMemoryPercent) { 'n/a' } else { "$usedMemoryPercent%" }
        $rxText = if ($null -eq $networkReceiveBytesPerSec) { 'n/a' } else { "$networkReceiveBytesPerSec B/s" }
        $txText = if ($null -eq $networkSendBytesPerSec) { 'n/a' } else { "$networkSendBytesPerSec B/s" }
        Write-Host ("LIVE {0}/{1} | CPU {2} | RAM {3} | NET RX {4} | TX {5}" -f $i,$effectiveSamples,$cpuText,$ramText,$rxText,$txText)
    }
    if ($i -lt $effectiveSamples) { Start-Sleep -Seconds $IntervalSeconds }
}
$diskRows = @($diskInfo | ForEach-Object {
    $used = $null; if ([double]$_.Size -gt 0) { $used = [math]::Round(((([double]$_.Size - [double]$_.FreeSpace) / [double]$_.Size) * 100), 1) }
    [pscustomobject]@{ Drive=[string]$_.DeviceID; Volume=[string]$_.VolumeName; FileSystem=[string]$_.FileSystem; SizeGB=[math]::Round(([double]$_.Size / 1GB), 2); FreeGB=[math]::Round(([double]$_.FreeSpace / 1GB), 2); UsedPercent=$used }
})
foreach ($disk in $diskRows) {
    if ($disk.SizeGB -gt 0) {
        $freePercent = [math]::Round(($disk.FreeGB / $disk.SizeGB) * 100, 1)
        if ($freePercent -le $DiskFreeAlertPercent) { $alerts.Add("Disk $($disk.Drive) free space $freePercent% is at/below threshold $DiskFreeAlertPercent%") }
    }
}
$networkRows = @()
foreach ($adapter in $adapterInfo) {
    try {
        $stats = Get-NetAdapterStatistics -Name $adapter.Name -ErrorAction Stop
        $networkRows += [pscustomobject]@{ Name=[string]$adapter.Name; LinkSpeed=[string]$adapter.LinkSpeed; ReceivedBytes=[double]$stats.ReceivedBytes; SentBytes=[double]$stats.SentBytes }
    } catch { $warnings.Add("Network statistics unavailable for $($adapter.Name): $($_.Exception.Message)") }
}
$cpuName = if ($cpuInfo.Count) { [string]$cpuInfo[0].Name } else { 'Unavailable' }
$osName = if ($os.Count) { [string]$os[0].Caption } else { 'Unavailable' }
$liveDurationValue = $null
if ($LiveMonitoring) { $liveDurationValue = $DurationMinutes }
$summary = [ordered]@{
    Product='IT VIP System Diagnostics Center'; Schema='ITVIP-SYSTEM-DIAGNOSTICS-1'; GeneratedAt=(Get-Date).ToString('o')
    ReadOnly=$true; Sampling=[pscustomobject]@{ Count=$effectiveSamples; IntervalSeconds=$IntervalSeconds; LiveMonitoring=[bool]$LiveMonitoring; DurationMinutes=$liveDurationValue }
    AlertThresholds=[pscustomobject]@{ CpuPercent=$CpuAlertPercent; MemoryPercent=$MemoryAlertPercent; DiskFreePercent=$DiskFreeAlertPercent }
    Alerts=@($alerts)
    OperatingSystem=$osName; Architecture=$env:PROCESSOR_ARCHITECTURE; CPU=$cpuName
    Samples=@($sampleRows); LogicalDisks=$diskRows; ActivePhysicalNetworkAdapters=$networkRows
    ThermalZones=$thermalInfo; Warnings=@($warnings)
    Notes=@('CPU load uses the Win32_Processor LoadPercentage property and may be coarse or unavailable.','Network byte totals are cumulative adapter counters, not internet throughput or a speed test.','Thermal readings are included only when the standard ACPI WMI provider exposes them.','No settings, services, processes, drivers, disks, or network configuration were changed.')
}
$jsonPath = Join-Path $ReportDir "itvip_system_diagnostics_$stamp.json"
$txtPath = Join-Path $ReportDir "itvip_system_diagnostics_$stamp.txt"
$htmlPath = Join-Path $ReportDir "itvip_system_diagnostics_$stamp.html"
$csvPath = Join-Path $ReportDir "itvip_system_samples_$stamp.csv"
$historyPath = Join-Path $ReportDir 'system_diagnostics_history.csv'
$summary | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
if ($sampleRows.Count) {
    $sampleRows | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
    $historyRows = @($sampleRows | ForEach-Object { [pscustomobject]@{ Timestamp=$_.Timestamp; CpuLoadPercent=$_.CpuLoadPercent; MemoryUsedPercent=$_.MemoryUsedPercent; Alert=$_.Alerts } })
    if (Test-Path -LiteralPath $historyPath) { $historyRows | Export-Csv -LiteralPath $historyPath -NoTypeInformation -Append -Encoding UTF8 }
    else { $historyRows | Export-Csv -LiteralPath $historyPath -NoTypeInformation -Encoding UTF8 }
    try { $allHistory = @(Import-Csv -LiteralPath $historyPath); if ($allHistory.Count -gt 1000) { $allHistory | Select-Object -Last 1000 | Export-Csv -LiteralPath $historyPath -NoTypeInformation -Encoding UTF8 } } catch { $warnings.Add("Performance history maintenance warning: $($_.Exception.Message)") }
}
$lines = @('IT VIP — System Diagnostics Report',"Generated: $($summary.GeneratedAt)","OS: $osName", "CPU: $cpuName", "Architecture: $($summary.Architecture)", "Samples: $effectiveSamples every $IntervalSeconds second(s) | Live: $([bool]$LiveMonitoring)",'','PERFORMANCE SAMPLES')
foreach ($row in $sampleRows) { $lines += "#$($row.Sample) CPU=$($row.CpuLoadPercent)% RAM=$($row.MemoryUsedPercent)% ($($row.MemoryFreeMB) MB free / $($row.MemoryTotalMB) MB) NET RX=$($row.NetworkReceiveBytesPerSec) B/s TX=$($row.NetworkSendBytesPerSec) B/s" }
$lines += ''; $lines += "ALERT THRESHOLDS: CPU $CpuAlertPercent% | RAM $MemoryAlertPercent% | Disk free $DiskFreeAlertPercent%"; $lines += 'ALERTS'; foreach ($alert in $alerts) { $lines += "! $alert" }; if ($alerts.Count -eq 0) { $lines += 'No thresholds were crossed during this run.' }; $lines += ''; $lines += 'LOGICAL DISKS'; foreach ($d in $diskRows) { $lines += "$($d.Drive) $($d.Volume) | $($d.UsedPercent)% used | $($d.FreeGB) GB free / $($d.SizeGB) GB" }
$lines += ''; $lines += 'ACTIVE PHYSICAL NETWORK ADAPTERS'; foreach ($n in $networkRows) { $lines += "$($n.Name) | $($n.LinkSpeed) | RX $($n.ReceivedBytes) bytes | TX $($n.SentBytes) bytes" }
$lines += ''; $lines += 'THERMAL ZONES (IF EXPOSED)'; foreach ($t in $thermalInfo) { $lines += "$($t.InstanceName) | $($t.Celsius) C" }
$lines += ''; $lines += 'WARNINGS'; foreach ($w in $warnings) { $lines += "- $w" }
$lines += ''; $lines += 'READ-ONLY: no system configuration was changed.'
$lines | Set-Content -LiteralPath $txtPath -Encoding UTF8
$htmlSections = @()
$htmlSections += $sampleRows | ConvertTo-Html -Fragment -PreContent '<h2>Performance samples</h2>'
$htmlSections += $diskRows | ConvertTo-Html -Fragment -PreContent '<h2>Logical disks</h2>'
$htmlSections += $sampleRows | Select-Object Timestamp,CpuLoadPercent,MemoryUsedPercent,NetworkReceiveBytesPerSec,NetworkSendBytesPerSec | ConvertTo-Html -Fragment -PreContent '<h2>Live network throughput (bytes/second)</h2>'
$htmlSections += $networkRows | ConvertTo-Html -Fragment -PreContent '<h2>Active network adapters</h2>'
$htmlSections += $thermalInfo | ConvertTo-Html -Fragment -PreContent '<h2>Thermal zones (when exposed)</h2>'
$htmlSections += @($warnings | ForEach-Object { [pscustomobject]@{ Warning=$_ } }) | ConvertTo-Html -Fragment -PreContent '<h2>Warnings</h2>'
$alertHtml = if ($alerts.Count) { '<div class="alert"><h2>Alerts</h2><ul>' + (($alerts | ForEach-Object { '<li>' + [System.Net.WebUtility]::HtmlEncode($_) + '</li>' }) -join '') + '</ul></div>' } else { '<div class="ok">No alert thresholds crossed.</div>' }
$style = '<style>body{font-family:Segoe UI,Arial,sans-serif;background:#101522;color:#e8edf7;margin:2rem}h1,h2{color:#63d7ff}table{border-collapse:collapse;width:100%;margin:1rem 0}th,td{padding:.55rem;border:1px solid #344158;text-align:left}th{background:#1d2a40}.alert{border:1px solid #d98b39;padding:1rem;background:#382819}.ok{border:1px solid #3c9b70;padding:1rem;background:#17352b}p{color:#c5d0e0}.metric{display:inline-block;padding:.7rem 1rem;margin:.3rem;border:1px solid #34516d;border-radius:8px}</style>'
$html = ConvertTo-Html -Title 'IT VIP System Diagnostics' -Head $style -PreContent "<h1>IT VIP System Diagnostics</h1><p>Generated: $($summary.GeneratedAt)</p><p>OS: $osName | CPU: $cpuName | Architecture: $($summary.Architecture)</p><p>Thresholds: CPU $CpuAlertPercent% | RAM $MemoryAlertPercent% | Disk free $DiskFreeAlertPercent%</p><p class='metric'>Live monitoring: $([bool]$LiveMonitoring)</p><p class='metric'>Interval: $IntervalSeconds second(s)</p><p>READ-ONLY report</p>$alertHtml" -PostContent ($htmlSections -join "`n")
$html | Set-Content -LiteralPath $htmlPath -Encoding UTF8
Write-Host ($lines -join [Environment]::NewLine)
Write-Host "`nReports saved:`n$jsonPath`n$txtPath`n$htmlPath`n$csvPath`n$historyPath"
Write-Host 'No system settings were changed; this diagnostic is read-only.'
