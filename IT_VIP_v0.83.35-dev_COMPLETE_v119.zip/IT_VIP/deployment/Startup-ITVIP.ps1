[CmdletBinding()]
param([ValidateSet('All','StartupApps','Services')][string]$Action='All')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings=New-Object System.Collections.Generic.List[string]
function Safe-Query([scriptblock]$Query,[string]$Label) { try { @(& $Query) } catch { $warnings.Add("$Label : $($_.Exception.Message)"); @() } }
$startup=@(); $services=@()
if($Action -in @('All','StartupApps')) {
  $startup=Safe-Query { Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User } 'Startup applications'
}
if($Action -in @('All','Services')) {
  $services=Safe-Query { Get-CimInstance Win32_Service | Select-Object Name,DisplayName,State,StartMode,StartName,ProcessId } 'Windows services'
}
$result=[ordered]@{
  Product='IT VIP Startup & Services Manager'; Schema='ITVIP-STARTUP-1'; Timestamp=(Get-Date).ToString('o')
  Action=$Action; ReadOnly=$true; StartupApplications=$startup; Services=$services; Warnings=@($warnings)
  Notes=@('Inventory is read-only.','Startup command entries are reported as registered by Windows; their execution success is not verified.','Service StartMode is reported, not changed.','No startup entries, services, tasks, registry values, or system settings were modified.','Use Windows Settings or the Services console for changes after reviewing the impact.')
}
$json=Join-Path $reportDir "itvip_startup_$stamp.json"
$txt=Join-Path $reportDir "itvip_startup_$stamp.txt"
$csv=Join-Path $reportDir "itvip_startup_apps_$stamp.csv"
$svcCsv=Join-Path $reportDir "itvip_services_$stamp.csv"
$result | ConvertTo-Json -Depth 7 | Set-Content -Encoding UTF8 $json
@('IT VIP Startup & Services Manager',"Timestamp: $($result.Timestamp)",'','STARTUP APPLICATIONS',($startup | Format-Table -Wrap -AutoSize | Out-String),'WINDOWS SERVICES',($services | Format-Table -AutoSize | Out-String),'WARNINGS',($warnings -join "`r`n"),$result.Notes) | Set-Content -Encoding UTF8 $txt
if($startup.Count -gt 0) { $startup | Export-Csv -NoTypeInformation -Encoding UTF8 $csv }
if($services.Count -gt 0) { $services | Export-Csv -NoTypeInformation -Encoding UTF8 $svcCsv }
Write-Host 'Startup and services inventory completed (read-only).' -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt"
if($startup.Count -gt 0) { Write-Host "Startup CSV: $csv" }
if($services.Count -gt 0) { Write-Host "Services CSV: $svcCsv" }
