@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo IT VIP - Windows Update Manager (READ-ONLY)
echo This checks the configured Windows Update or organization WSUS source.
echo It may contact that source to search for available updates.
echo It will NOT download, install, hide, or schedule updates.
choice /C YN /N /M "Continue with read-only update search? [Y/N] "
if errorlevel 2 goto cancelled
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0WindowsUpdate-ITVIP.ps1"
set "RC=!ERRORLEVEL!"
echo.
echo Reports are saved in the reports folder. No updates were installed.
goto end
:cancelled
echo Cancelled. No update search was performed.
:end
pause
endlocal & exit /b %RC%
