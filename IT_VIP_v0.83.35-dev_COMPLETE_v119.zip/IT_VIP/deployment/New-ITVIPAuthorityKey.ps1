[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$AuthorityDirectory)
$ErrorActionPreference='Stop'
$dir=[IO.Path]::GetFullPath($AuthorityDirectory)
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$privatePath=Join-Path $dir 'authority.private.dpapi.txt'
$publicPath=Join-Path $dir 'authority.public.xml'
if((Test-Path $privatePath) -or (Test-Path $publicPath)){throw 'Authority key files already exist. Back them up securely or choose a new directory.'}
$rsa=New-Object System.Security.Cryptography.RSACryptoServiceProvider(3072)
try {
 $p=$rsa.ExportParameters($true)
 function B64($b){[Convert]::ToBase64String($b)}
 $privateXml='<RSAKeyValue><Modulus>'+ (B64 $p.Modulus) +'</Modulus><Exponent>'+ (B64 $p.Exponent) +'</Exponent><P>'+ (B64 $p.P) +'</P><Q>'+ (B64 $p.Q) +'</Q><DP>'+ (B64 $p.DP) +'</DP><DQ>'+ (B64 $p.DQ) +'</DQ><InverseQ>'+ (B64 $p.InverseQ) +'</InverseQ><D>'+ (B64 $p.D) +'</D></RSAKeyValue>'
 $publicXml='<RSAKeyValue><Modulus>'+ (B64 $p.Modulus) +'</Modulus><Exponent>'+ (B64 $p.Exponent) +'</Exponent></RSAKeyValue>'
 $secure=ConvertTo-SecureString $privateXml -AsPlainText -Force
 $protected=ConvertFrom-SecureString $secure
 [IO.File]::WriteAllText($privatePath,$protected,[Text.Encoding]::ASCII)
 [IO.File]::WriteAllText($publicPath,$publicXml,[Text.Encoding]::UTF8)
 Write-Host "Created DPAPI-protected private key: $privatePath" -ForegroundColor Green
 Write-Host "Created public verification key: $publicPath" -ForegroundColor Cyan
 Write-Warning 'Private key is decryptable only by this Windows user on this Windows installation. Keep an offline protected backup; never ship it with user editions.'
} finally {$rsa.Dispose()}
