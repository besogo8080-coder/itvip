@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0.."
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Network-ITVIP.ps1" -Action All
set "RC=!ERRORLEVEL!"
if errorlevel 1 echo Network Manager reported an error.
echo.
pause
endlocal & exit /b %RC%
