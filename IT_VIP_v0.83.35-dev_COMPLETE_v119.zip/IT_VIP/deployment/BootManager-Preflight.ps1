[CmdletBinding()]
param([string]$OutputDirectory='', [switch]$RedactHardwareIdentifiers)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
function Protect-HardwareIdentifier([object]$Value) {
    if($RedactHardwareIdentifiers -and -not [string]::IsNullOrWhiteSpace([string]$Value)) { return '[REDACTED]' }
    return [string]$Value
}
if([string]::IsNullOrWhiteSpace($OutputDirectory)){$OutputDirectory=Join-Path $root 'reports'}
$out=[IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $out -Force | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$warnings=[System.Collections.Generic.List[string]]::new()
$firmware='Unknown'
try {
    $reg=Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name PEFirmwareType -ErrorAction Stop
    $firmware=switch([int]$reg.PEFirmwareType){1{'Legacy BIOS'} 2{'UEFI'} default{'Unknown'}}
} catch { $warnings.Add("Firmware mode unavailable: $($_.Exception.Message)") }
$disks=@()
try {
    foreach($d in @(Get-Disk -ErrorAction Stop)) {
        $parts=@()
        try {
            foreach($part in @(Get-Partition -DiskNumber $d.Number -ErrorAction Stop)) {
                $volumes=@()
                try {
                    foreach($v in @(Get-Volume -Partition $part -ErrorAction Stop)) {
                        $volumes += [pscustomobject]@{
                            DriveLetter=[string]$v.DriveLetter
                            FileSystem=[string]$v.FileSystem
                            FileSystemLabel=[string]$v.FileSystemLabel
                            HealthStatus=[string]$v.HealthStatus
                            SizeBytes=[UInt64]$v.Size
                            SizeRemainingBytes=[UInt64]$v.SizeRemaining
                        }
                    }
                } catch { $warnings.Add("Volume details unavailable for disk $($d.Number), partition $($part.PartitionNumber): $($_.Exception.Message)") }
                $parts += [pscustomobject]@{
                    PartitionNumber=[int]$part.PartitionNumber
                    DriveLetter=[string]$part.DriveLetter
                    Type=[string]$part.Type
                    GptType=[string]$part.GptType
                    IsBoot=[bool]$part.IsBoot
                    IsSystem=[bool]$part.IsSystem
                    IsHidden=[bool]$part.IsHidden
                    SizeBytes=[UInt64]$part.Size
                    OffsetBytes=[UInt64]$part.Offset
                    Volumes=$volumes
                }
            }
        } catch { $warnings.Add("Partition inventory unavailable for disk $($d.Number): $($_.Exception.Message)") }
        $isUsb=([string]$d.BusType -eq 'USB')
        $protected=([bool]$d.IsBoot -or [bool]$d.IsSystem)
        $disks += [pscustomobject]@{
            Number=[int]$d.Number
            FriendlyName=[string]$d.FriendlyName
            Manufacturer=[string]$d.Manufacturer
            Model=[string]$d.Model
            SerialNumber=(Protect-HardwareIdentifier $d.SerialNumber)
            UniqueId=(Protect-HardwareIdentifier $d.UniqueId)
            BusType=[string]$d.BusType
            Location=[string]$d.Location
            PartitionStyle=[string]$d.PartitionStyle
            NumberOfPartitions=[int]$d.NumberOfPartitions
            OperationalStatus=(@($d.OperationalStatus) -join ',')
            HealthStatus=[string]$d.HealthStatus
            IsBoot=[bool]$d.IsBoot
            IsSystem=[bool]$d.IsSystem
            IsReadOnly=[bool]$d.IsReadOnly
            IsOffline=[bool]$d.IsOffline
            SizeBytes=[UInt64]$d.Size
            CandidateHint=($isUsb -and -not $protected)
            CandidateHintRequiresManualIdentityCheck=$true
            Partitions=$parts
        }
    }
} catch { $warnings.Add("Storage disk inventory unavailable: $($_.Exception.Message)") }
$report=[ordered]@{
    Schema='ITVIP-BOOT-PREFLIGHT-3'
    GeneratedUtc=[DateTime]::UtcNow.ToString('o')
    ComputerName=(Protect-HardwareIdentifier $env:COMPUTERNAME)
    HardwareIdentifiersRedacted=[bool]$RedactHardwareIdentifiers
    WindowsVersion=[Environment]::OSVersion.VersionString
    PowerShellVersion=$PSVersionTable.PSVersion.ToString()
    FirmwareMode=$firmware
    ReadOnly=$true
    DestructiveOperationsPerformed=$false
    DiskCount=$disks.Count
    DiskInventory=$disks
    Warnings=@($warnings.ToArray())
    SafetyNotes=@(
        'CandidateHint is informational only and never authorizes a disk operation.',
        'SerialNumber and UniqueId may be unavailable, duplicated by USB bridges, or masked by virtualization.',
        'Use -RedactHardwareIdentifiers when sharing reports; it redacts computer name, disk serial number, and UniqueId.',
        'Verify the physical device by number, model, capacity, and hardware identity before any future preparation.',
        'This preflight does not create partitions, format disks, install bootloaders, or write to USB devices.',
        'UEFI Secure Boot compatibility and ISO chainloading are not validated by this inventory.'
    )
    NextEngineeringStage='Implement signed bootloader integration and disposable-media test matrix.'
}
$json=Join-Path $out "itvip_boot_preflight_$stamp.json"
$txt=Join-Path $out "itvip_boot_preflight_$stamp.txt"
$report | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath $json -Encoding UTF8
$lines=@(
    'IT VIP Boot Manager — Read-only Preflight v3',
    "Hardware identifiers redacted: $([bool]$RedactHardwareIdentifiers)",
    "Generated UTC: $($report.GeneratedUtc)",
    "Computer: $($report.ComputerName)",
    "Firmware: $firmware",
    "Disk count: $($disks.Count)",
    '', 'DISK INVENTORY:'
)
foreach($d in $disks) {
    $lines += "Disk #$($d.Number) | $($d.FriendlyName) | Model=$($d.Model) | Bus=$($d.BusType) | Style=$($d.PartitionStyle) | $([Math]::Round($d.SizeBytes/1GB,2)) GB | Serial=$($d.SerialNumber) | UniqueId=$($d.UniqueId) | CandidateHint=$($d.CandidateHint) | Boot=$($d.IsBoot) | System=$($d.IsSystem)"
    foreach($part in $d.Partitions) {
        $lines += "  Partition #$($part.PartitionNumber) | $($part.Type) | $([Math]::Round($part.SizeBytes/1GB,2)) GB | Drive=$($part.DriveLetter) | Boot=$($part.IsBoot) | System=$($part.IsSystem)"
        foreach($v in $part.Volumes) { $lines += "    Volume | $($v.DriveLetter): | $($v.FileSystem) | $($v.FileSystemLabel) | $([Math]::Round($v.SizeBytes/1GB,2)) GB" }
    }
}
$lines += @('', 'WARNINGS:')
if($warnings.Count -eq 0){$lines += 'None'} else {$lines += @($warnings | ForEach-Object {"- $_"})}
$lines += @('', 'No disk was modified. This is not a bootable USB creator.')
$lines | Set-Content -LiteralPath $txt -Encoding UTF8
Write-Host "Read-only boot preflight complete: $json" -ForegroundColor Green
Write-Host "Disk inventory count: $($disks.Count)" -ForegroundColor Cyan
Write-Host 'No partitions, filesystems, boot sectors, or USB contents were changed.' -ForegroundColor Cyan
