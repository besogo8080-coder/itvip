[CmdletBinding()]
param([ValidateSet('All','Storage','TemporaryFiles','StartupImpact')][string]$Action='All',[int]$MaxFiles=5000)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings=New-Object System.Collections.Generic.List[string]
function Safe-Query([scriptblock]$Query,[string]$Label) { try { @(& $Query) } catch { $warnings.Add("$Label : $($_.Exception.Message)"); @() } }
$drives=@(); $tempSummary=@(); $startup=@(); $recommendations=New-Object System.Collections.Generic.List[string]
if($Action -in @('All','Storage')) {
  $drives=Safe-Query { Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID,VolumeName,FileSystem,Size,FreeSpace,@{N='UsedBytes';E={$_.Size-$_.FreeSpace}},@{N='FreePercent';E={if($_.Size -gt 0){[math]::Round(100*$_.FreeSpace/$_.Size,2)}else{$null}}} } 'Storage inventory'
  foreach($d in $drives){ if($null -ne $d.FreePercent -and $d.FreePercent -lt 10){$recommendations.Add("Drive $($d.DeviceID) has less than 10% free space. Review large files and backups manually.")} }
}
if($Action -in @('All','TemporaryFiles')) {
  $locations=@($env:TEMP,(Join-Path $env:WINDIR 'Temp')) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } | Select-Object -Unique
  foreach($location in $locations){
    $files=Safe-Query { Get-ChildItem -LiteralPath $location -File -Force -Recurse -ErrorAction SilentlyContinue | Select-Object -First $MaxFiles FullName,Length,LastWriteTime } "Temporary inventory $location"
    $bytes=0L; foreach($f in $files){$bytes += [int64]$f.Length}
    $tempSummary += [pscustomobject]@{Location=$location;FilesScanned=$files.Count;BytesScanned=$bytes;ApproxMiB=[math]::Round($bytes/1MB,2);ScanLimit=$MaxFiles}
  }
  $recommendations.Add('Temporary-file results are an inventory estimate only. Review files in Explorer before deleting anything.')
}
if($Action -in @('All','StartupImpact')) {
  $startup=Safe-Query { Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User } 'Startup inventory'
  $recommendations.Add('Review startup entries in Windows Settings. This report does not measure boot-time impact or disable entries.')
}
$result=[ordered]@{Product='IT VIP Windows Optimization Center';Schema='ITVIP-OPTIMIZE-1';Timestamp=(Get-Date).ToString('o');Action=$Action;ReadOnly=$true;Storage=$drives;TemporaryFileInventory=$tempSummary;StartupEntries=$startup;Recommendations=@($recommendations);Warnings=@($warnings);Limits=@('No files were deleted, moved, compressed, or modified.','Temporary-file scan is capped per location and can omit files beyond the limit.','Startup impact is not benchmarked; entries are listed only.','No registry, service, power, or network settings were changed.')}
$json=Join-Path $reportDir "itvip_optimization_$stamp.json"; $txt=Join-Path $reportDir "itvip_optimization_$stamp.txt"; $csv=Join-Path $reportDir "itvip_storage_$stamp.csv"
$result | ConvertTo-Json -Depth 7 | Set-Content -Encoding UTF8 $json
@('IT VIP Windows Optimization Center',"Timestamp: $($result.Timestamp)","Action: $Action",'','STORAGE',($drives | Format-Table -AutoSize | Out-String),'TEMPORARY FILE INVENTORY',($tempSummary | Format-Table -AutoSize | Out-String),'STARTUP ENTRIES',($startup | Format-Table -Wrap -AutoSize | Out-String),'RECOMMENDATIONS',($recommendations -join "`r`n"),'WARNINGS',($warnings -join "`r`n"),'READ-ONLY: no cleanup or settings changes were performed.') | Set-Content -Encoding UTF8 $txt
if($drives.Count -gt 0){$drives | Export-Csv -NoTypeInformation -Encoding UTF8 $csv}
Write-Host 'Optimization assessment completed (read-only; no cleanup performed).' -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt"
if($drives.Count -gt 0){Write-Host "Storage CSV: $csv"}
