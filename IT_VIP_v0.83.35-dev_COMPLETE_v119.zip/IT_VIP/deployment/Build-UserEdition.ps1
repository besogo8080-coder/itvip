[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$Profile,
 [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$profilePath=[IO.Path]::GetFullPath($Profile)
$out=[IO.Path]::GetFullPath($OutputDirectory)
if(-not (Test-Path -LiteralPath $profilePath -PathType Leaf)){throw 'Permission profile was not found.'}
if(Test-Path -LiteralPath $out){throw "Output already exists; choose a new empty destination: $out"}
$rootPrefix=$root.TrimEnd('\')+'\'
if($out.Equals($root,[StringComparison]::OrdinalIgnoreCase) -or $out.StartsWith($rootPrefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must be outside the source project tree.'}
function Get-IniValue([string]$Path,[string]$Section,[string]$Key){
 $inside=$false
 foreach($line in Get-Content -LiteralPath $Path){$t=$line.Trim();if($t -match '^\[(.+)\]$'){$inside=($Matches[1] -eq $Section);continue};if($inside -and $t -match ('^'+[regex]::Escape($Key)+'\s*=\s*(.*)$')){return $Matches[1].Trim()}}
 return $null
}
$schema=Get-IniValue $profilePath 'Edition' 'Schema'
if($schema -ne '1'){throw 'Unsupported permission profile schema.'}
if((Get-IniValue $profilePath 'Edition' 'OwnerMode') -ne '1'){throw 'Only owner-created profiles can be exported by this builder.'}
$status=Get-IniValue $profilePath 'Edition' 'Status'
if($status -and $status -ne 'Active'){throw 'This permission profile is revoked or inactive; reactivate it in the owner console before exporting.'}
if([string]::IsNullOrWhiteSpace((Get-IniValue $profilePath 'Edition' 'Name')) -or [string]::IsNullOrWhiteSpace((Get-IniValue $profilePath 'Edition' 'UserLabel'))){throw 'Edition name and user label are required.'}

$features=@{
 scanner=@{Exe='scanner.exe'};usb_guard=@{Exe='usb_guard.exe'};tempclean=@{Exe='tempclean.exe'};activator=@{Exe='activator.exe'};pwrecover=@{Exe='pwrecover.exe'};portable_manager=@{Exe='portable_manager.exe';Extra=@('copy_manager.exe')};security_center=@{Exe='security_center.exe'}
 ai_assistant=@{Exe='ai_assistant.exe'};github_hub=@{Exe='github_hub.exe'};api_manager=@{Exe='api_manager.exe'};agent_studio=@{Exe='agent_studio.exe'};provider_hub=@{Exe='provider_hub.exe'};provider_runtime=@{Exe='provider_runtime.exe'};team_studio=@{Exe='team_studio.exe'};team_runner=@{Exe='team_runner.exe'};workflow_studio=@{Exe='workflow_studio.exe'};workflow_runner=@{Exe='workflow_runner.exe'};run_history=@{Exe='run_history.exe'};memory_center=@{Exe='memory_center.exe'};session_center=@{Exe='session_center.exe'};backup_center=@{Exe='backup_center.exe'};settings_center=@{Exe='settings_center.exe'}
 update_manager=@{Cmd='Update-ITVIP.cmd';Ps='Update-ITVIP.ps1'};diagnostics=@{Cmd='Diagnostics-ITVIP.cmd';Ps='Diagnostics-ITVIP.ps1'};hardware_manager=@{Cmd='Hardware-ITVIP.cmd';Ps='Hardware-ITVIP.ps1'};network_manager=@{Cmd='Network-ITVIP.cmd';Ps='Network-ITVIP.ps1'};performance_manager=@{Cmd='Performance-ITVIP.cmd';Ps='Performance-ITVIP.ps1'};startup_manager=@{Cmd='Startup-ITVIP.cmd';Ps='Startup-ITVIP.ps1'};optimization_center=@{Cmd='Optimize-ITVIP.cmd';Ps='Optimize-ITVIP.ps1'};repair_center=@{Cmd='Repair-ITVIP.cmd';Ps='Repair-ITVIP.ps1'};firewall_privacy=@{Cmd='FirewallPrivacy-ITVIP.cmd';Ps='FirewallPrivacy-ITVIP.ps1'};event_logs=@{Cmd='EventLogs-ITVIP.cmd';Ps='EventLogs-ITVIP.ps1'};software_manager=@{Cmd='Software-ITVIP.cmd';Ps='Software-ITVIP.ps1'};windows_update=@{Cmd='WindowsUpdate-ITVIP.cmd';Ps='WindowsUpdate-ITVIP.ps1'};system_monitor=@{Exe='system_monitor_gui.exe'};command_center=@{}
}
$selected=@{}
foreach($key in $features.Keys){$value=Get-IniValue $profilePath 'Permissions' $key;if($key -eq 'command_center' -and $null -eq $value){$value='0'};if($value -notin @('0','1')){throw "Missing or invalid permission value: $key"};$selected[$key]=($value -eq '1')}
$hasAny=$selected.Values | Where-Object {$_} | Select-Object -First 1
if(-not $hasAny){throw 'The profile grants no capabilities; refusing to create an unusable edition.'}
New-Item -ItemType Directory -Path $out | Out-Null
try {
 foreach($dir in @('assets','config','data','portable','reports','deployment','build','docs')){if(Test-Path (Join-Path $root $dir)){New-Item -ItemType Directory -Path (Join-Path $out $dir) -Force | Out-Null}}
 foreach($file in @('README.md','README_AR.md')){if(Test-Path (Join-Path $root $file)){Copy-Item (Join-Path $root $file) (Join-Path $out $file)}}
 foreach($dir in @('assets','portable','docs')){if(Test-Path (Join-Path $root $dir)){Copy-Item -Path (Join-Path $root ($dir+'\*')) -Destination (Join-Path $out $dir) -Recurse -Force}}
 foreach($file in @('config/settings.json','config/appearance.ini.example')){if(Test-Path (Join-Path $root $file)){Copy-Item (Join-Path $root $file) (Join-Path $out $file) -Force}}
 Copy-Item $profilePath (Join-Path $out 'config/user_permissions.ini') -Force
 $policyText=Get-Content -LiteralPath (Join-Path $out 'config/user_permissions.ini') -Raw
 $policyText=[regex]::Replace($policyText,'(?m)^OwnerMode\s*=\s*1\s*$','OwnerMode=0')
 if($policyText -notmatch '(?im)^\s*command_center\s*='){if($policyText -match '(?im)^\[Permissions\]\s*$'){$policyText=([regex]::new('(?im)^\[Permissions\]\s*$')).Replace($policyText,"[Permissions]`r`ncommand_center=0",1)}else{$policyText+="`r`n[Permissions]`r`ncommand_center=0`r`n"}}
 [IO.File]::WriteAllText((Join-Path $out 'config/user_permissions.ini'),$policyText,[Text.Encoding]::Unicode)
 $mainExe=Join-Path $root 'build/ITVIP.exe';if(-not (Test-Path $mainExe)){throw 'Main dashboard build/ITVIP.exe is missing. Build the project before exporting editions.'};Copy-Item $mainExe (Join-Path $out 'build/ITVIP.exe')
 $bootstrapper=Join-Path $root 'build/ITVIPBootstrap.exe';$nativeVerifier=Join-Path $root 'build/ITVIPNativeVerify.exe';if(-not (Test-Path -LiteralPath $bootstrapper -PathType Leaf) -or -not (Test-Path -LiteralPath $nativeVerifier -PathType Leaf)){throw 'Native bootstrapper or CNG verifier is missing. Build all native security targets before exporting editions.'};Copy-Item -LiteralPath $bootstrapper -Destination (Join-Path $out 'ITVIPBootstrap.exe') -Force;Copy-Item -LiteralPath $nativeVerifier -Destination (Join-Path $out 'build/ITVIPNativeVerify.exe') -Force
 foreach($key in $features.Keys){if(-not $selected[$key]){continue};$spec=$features[$key]
  if($spec.Exe){$src=Join-Path $root ('build/'+$spec.Exe);if(-not (Test-Path $src)){throw "Required executable for granted capability '$key' is missing: $src"};Copy-Item $src (Join-Path $out ('build/'+$spec.Exe))};foreach($extra in @($spec.Extra)){if($extra){$extraSrc=Join-Path $root ('build/'+$extra);if(-not (Test-Path $extraSrc)){throw "Required companion executable for '$key' is missing: $extraSrc"};Copy-Item $extraSrc (Join-Path $out ('build/'+$extra))}}
  if($spec.Cmd){foreach($leaf in @($spec.Cmd,$spec.Ps)){$src=Join-Path $root ('deployment/'+$leaf);if(-not (Test-Path $src)){throw "Required deployment component for '$key' is missing: $leaf"};Copy-Item $src (Join-Path $out ('deployment/'+$leaf))}}
 }
 $verifyScript=Join-Path $root 'deployment/Test-ITVIPUserEdition.ps1'
if(-not (Test-Path -LiteralPath $verifyScript -PathType Leaf)){throw 'Edition verifier script is missing.'}
Copy-Item -LiteralPath $verifyScript -Destination (Join-Path $out 'deployment/Test-ITVIPUserEdition.ps1') -Force
$launcher = @'
@echo off
setlocal
set "ROOT=%~dp0"
if not exist "%ROOT%ITVIPBootstrap.exe" (echo Native IT VIP bootstrapper is missing. Launch blocked. & exit /b 20)
"%ROOT%ITVIPBootstrap.exe"
exit /b %errorlevel%
'@
 [IO.File]::WriteAllText((Join-Path $out 'Start-ITVIP.cmd'),$launcher,[Text.Encoding]::ASCII)
 $manifest=[ordered]@{Schema='ITVIP-USER-EDITION-2';EditionId=([guid]::NewGuid().ToString());Edition=(Get-IniValue $profilePath 'Edition' 'Name');UserLabel=(Get-IniValue $profilePath 'Edition' 'UserLabel');ProfileRevision=(Get-IniValue $profilePath 'Edition' 'Revision');IssuedUtc=[DateTime]::UtcNow.ToString('o');CreatedUtc=[DateTime]::UtcNow.ToString('o');ExpiresUtc=$null;BindingMode='None';SignatureAlgorithm='Unsigned';GrantedCapabilities=@($selected.Keys | Where-Object {$selected[$_] } | Sort-Object);ExcludedCapabilities=@($selected.Keys | Where-Object {-not $selected[$_] } | Sort-Object);SecurityNote='Unsigned until explicitly signed with the owner authority key. Application-level feature gating and component omission are not a security boundary against a local administrator or a user who can modify package files.'}
 $manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $out 'EDITION_MANIFEST.json') -Encoding UTF8
 $hashes=Get-ChildItem -LiteralPath $out -File -Recurse | Sort-Object FullName | ForEach-Object {$rel=$_.FullName.Substring($out.Length).TrimStart('\','/');$hash=Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256;[pscustomobject]@{Path=$rel;SHA256=$hash.Hash}}
 $hashes | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $out 'EDITION_SHA256.json') -Encoding UTF8
 Write-Host "Edition created: $out" -ForegroundColor Green
 Write-Host "Granted capabilities: $(@($manifest.GrantedCapabilities).Count)" -ForegroundColor Cyan
} catch {Remove-Item -LiteralPath $out -Recurse -Force -ErrorAction SilentlyContinue;throw}
