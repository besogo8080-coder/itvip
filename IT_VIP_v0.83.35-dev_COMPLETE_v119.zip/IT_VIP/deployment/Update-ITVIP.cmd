@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo ================================================
echo IT VIP - UPDATE MANAGER
echo ================================================
echo 1. Installation preflight
echo 2. Verify an update package
echo 3. Stage a verified update
echo 4. Apply a staged update
echo 5. Roll back the latest update
echo 0. Exit
set /p choice=Select: 
if "%choice%"=="1" (
  powershell.exe -NoProfile -File "%~dp0Update-ITVIP.ps1" -Action Preflight
set "RC=!ERRORLEVEL!"
  goto end
)
if "%choice%"=="2" goto verify
if "%choice%"=="3" goto stage
if "%choice%"=="4" goto apply
if "%choice%"=="5" (
  powershell.exe -NoProfile -File "%~dp0Update-ITVIP.ps1" -Action RollbackLatest
set "RC=!ERRORLEVEL!"
  goto end
)
goto end
:verify
set /p package=Enter update package folder path: 
powershell.exe -NoProfile -File "%~dp0Update-ITVIP.ps1" -Action VerifyPackage -PackagePath "%package%"
set "RC=!ERRORLEVEL!"
goto end
:stage
set /p package=Enter update package folder path: 
powershell.exe -NoProfile -File "%~dp0Update-ITVIP.ps1" -Action StageUpdate -PackagePath "%package%"
set "RC=!ERRORLEVEL!"
goto end
:apply
set /p version=Enter staged version: 
powershell.exe -NoProfile -File "%~dp0Update-ITVIP.ps1" -Action ApplyUpdate -Version "%version%"
set "RC=!ERRORLEVEL!"
:end
echo.
pause
endlocal & exit /b %RC%
