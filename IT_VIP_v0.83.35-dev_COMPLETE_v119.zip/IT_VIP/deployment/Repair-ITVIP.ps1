[CmdletBinding()]
param([ValidateSet('Inventory','SystemFiles','ImageHealth','DiskOnline','All')][string]$Action='Inventory')
$ErrorActionPreference='Continue'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings=New-Object System.Collections.Generic.List[string]
$checks=New-Object System.Collections.Generic.List[object]
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
function Invoke-ReadOnlyCheck([string]$Name,[string]$File,[string[]]$Arguments,[int]$TimeoutSeconds=2400) {
  $started=Get-Date; $output=''; $exitCode=$null; $status='NotRun'
  try {
    $psi=New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName=$File; $psi.Arguments=($Arguments -join ' '); $psi.UseShellExecute=$false
    $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true; $psi.CreateNoWindow=$true
    $p=New-Object System.Diagnostics.Process; $p.StartInfo=$psi
    [void]$p.Start(); $stdoutTask=$p.StandardOutput.ReadToEndAsync(); $stderrTask=$p.StandardError.ReadToEndAsync()
    if(-not $p.WaitForExit($TimeoutSeconds*1000)){ try{$p.Kill()}catch{}; $status='TimedOut'; $warnings.Add("$Name timed out after $TimeoutSeconds seconds") }
    else { $p.WaitForExit(); $exitCode=$p.ExitCode; $output=($stdoutTask.Result+"`r`n"+$stderrTask.Result).Trim(); $status=if($exitCode -eq 0){'Completed'}else{'CompletedWithNonZeroExit'} }
  } catch { $status='Unavailable'; $output=$_.Exception.Message; $warnings.Add("$Name : $output") }
  $checks.Add([pscustomobject]@{Name=$Name;Status=$status;ExitCode=$exitCode;Started=$started.ToString('o');DurationSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,1);Output=$output})
}
$os=Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue | Select-Object Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime
$services=@(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object {$_.Name -in @('wuauserv','BITS','cryptsvc','TrustedInstaller')} | Select-Object Name,DisplayName,State,StartMode,StartName)
$disks=@(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -ErrorAction SilentlyContinue | Select-Object DeviceID,FileSystem,Size,FreeSpace)
$pendingReboot=$false
try { $pendingReboot=Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' } catch { $warnings.Add('Could not read pending reboot indicator.') }
if($Action -in @('SystemFiles','All')) { Invoke-ReadOnlyCheck 'System File Checker verification' (Join-Path $env:WINDIR 'System32\sfc.exe') @('/verifyonly') }
if($Action -in @('ImageHealth','All')) { Invoke-ReadOnlyCheck 'DISM component store ScanHealth' (Join-Path $env:WINDIR 'System32\Dism.exe') @('/Online','/Cleanup-Image','/ScanHealth') }
if($Action -in @('DiskOnline','All')) { Invoke-ReadOnlyCheck 'Online disk scan (system drive)' (Join-Path $env:WINDIR 'System32\chkdsk.exe') @($env:SystemDrive,'/scan') }
$suggestions=@('If SFC reports integrity violations, review the log and consider the documented Microsoft repair sequence after backup and approval.','If DISM reports component-store corruption, review Microsoft guidance before running RestoreHealth.','If CHKDSK reports errors, back up important data and review the report before scheduling repairs.','For Windows Update issues, review service states and Windows Update history; no reset or cache deletion is performed.')
$result=[ordered]@{Product='IT VIP Windows Repair Center';Schema='ITVIP-REPAIR-1';Timestamp=(Get-Date).ToString('o');Action=$Action;ReadOnly=$true;IsAdministrator=$isAdmin;OperatingSystem=$os;UpdateServices=$services;FixedDisks=$disks;PendingRebootIndicator=$pendingReboot;Checks=@($checks);Suggestions=$suggestions;Warnings=@($warnings);Limits=@('No repair, restore, reset, cleanup, service change, registry write, or reboot is performed.','SFC uses /verifyonly; DISM uses /ScanHealth; CHKDSK uses /scan.','Some checks may require an elevated PowerShell window and can take substantial time.','A non-zero tool exit code requires reviewing its output; it is not automatically a definitive diagnosis.')}
$json=Join-Path $reportDir "itvip_repair_$stamp.json"; $txt=Join-Path $reportDir "itvip_repair_$stamp.txt"
$result | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $json
@('IT VIP Windows Repair Center',"Timestamp: $($result.Timestamp)","Action: $Action","Administrator: $isAdmin",'', 'WINDOWS',($os | Format-List | Out-String),'UPDATE SERVICES',($services | Format-Table -AutoSize | Out-String),'DISKS',($disks | Format-Table -AutoSize | Out-String),'CHECK RESULTS',(@($checks) | ForEach-Object {"$($_.Name): $($_.Status) (ExitCode=$($_.ExitCode))`r`n$($_.Output)"} | Out-String),'SUGGESTIONS',($suggestions -join "`r`n"),'WARNINGS',($warnings -join "`r`n"),'READ-ONLY: no repair or configuration changes were performed.') | Set-Content -Encoding UTF8 $txt
Write-Host 'Repair assessment completed. No repairs or settings changes were performed.' -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt"
