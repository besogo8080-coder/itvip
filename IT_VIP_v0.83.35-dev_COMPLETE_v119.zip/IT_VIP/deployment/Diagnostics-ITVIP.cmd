@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnostics-ITVIP.ps1" %*
set "RC=!ERRORLEVEL!"
if errorlevel 1 echo Diagnostics completed with a PowerShell error.
pause
endlocal & exit /b %RC%
