[CmdletBinding()]
param([switch]$IncludeSignedDriverInventory)
$ErrorActionPreference = 'Continue'
$AppRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$ReportDir = Join-Path $AppRoot 'reports'
New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$devices = [Collections.Generic.List[object]]::new()
$drivers = [Collections.Generic.List[object]]::new()
$warnings = [Collections.Generic.List[string]]::new()
function Read-Cim([string]$Class,[string]$Area) {
    try { return @(Get-CimInstance -ClassName $Class -ErrorAction Stop) }
    catch { $warnings.Add("$Area unavailable: $($_.Exception.Message)"); return @() }
}
# PnP inventory: status and problem code are observational only.
foreach ($d in (Read-Cim 'Win32_PnPEntity' 'Plug and Play inventory')) {
    $devices.Add([pscustomobject]@{
        Name=[string]$d.Name; Class=[string]$d.PNPClass; Manufacturer=[string]$d.Manufacturer
        Status=[string]$d.Status; ConfigManagerErrorCode=$d.ConfigManagerErrorCode
        DeviceID=[string]$d.PNPDeviceID; Service=[string]$d.Service
        Problem=$(if ($null -ne $d.ConfigManagerErrorCode -and $d.ConfigManagerErrorCode -ne 0) {'Yes'} else {'No/Unknown'})
    })
}
$os = Read-Cim 'Win32_OperatingSystem' 'Operating system' | Select-Object -First 1
$cpu = Read-Cim 'Win32_Processor' 'CPU inventory' | Select-Object -First 1
$video = Read-Cim 'Win32_VideoController' 'Display inventory'
$disk = Read-Cim 'Win32_DiskDrive' 'Disk inventory'
$net = Read-Cim 'Win32_NetworkAdapter' 'Network inventory' | Where-Object { $_.PhysicalAdapter -eq $true }
$audio = @($devices | Where-Object { $_.Class -match 'MEDIA|Audio' -or $_.Name -match 'Audio|Sound' })
if ($IncludeSignedDriverInventory) {
    foreach ($dr in (Read-Cim 'Win32_PnPSignedDriver' 'Signed driver inventory')) {
        $drivers.Add([pscustomobject]@{ DeviceName=[string]$dr.DeviceName; Manufacturer=[string]$dr.Manufacturer; DriverProvider=[string]$dr.DriverProviderName; DriverVersion=[string]$dr.DriverVersion; DriverDate=[string]$dr.DriverDate; InfName=[string]$dr.InfName; IsSigned=[bool]$dr.IsSigned; DeviceID=[string]$dr.DeviceID })
    }
}
$problemDevices = @($devices | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0 })
$summary = [ordered]@{
    Product='IT VIP Driver & Hardware Manager'; GeneratedAt=(Get-Date).ToString('o'); AppRoot=$AppRoot; ReadOnly=$true
    OperatingSystem=$(if ($os) { [string]$os.Caption + ' | Build ' + [string]$os.BuildNumber } else { 'Unavailable' })
    Architecture=$env:PROCESSOR_ARCHITECTURE
    CPU=$(if ($cpu) { [string]$cpu.Name } else { 'Unavailable' })
    DisplayAdapters=@($video | ForEach-Object { [pscustomobject]@{Name=$_.Name; DriverVersion=$_.DriverVersion; DriverDate=$_.DriverDate; Status=$_.Status; AdapterRAM=$_.AdapterRAM} })
    Disks=@($disk | ForEach-Object { [pscustomobject]@{Model=$_.Model; InterfaceType=$_.InterfaceType; MediaType=$_.MediaType; SizeBytes=$_.Size; Status=$_.Status} })
    PhysicalNetworkAdapters=@($net | ForEach-Object { [pscustomobject]@{Name=$_.Name; Manufacturer=$_.Manufacturer; MACAddress=$_.MACAddress; NetEnabled=$_.NetEnabled; Speed=$_.Speed} })
    AudioDeviceCount=$audio.Count; DeviceCount=$devices.Count; DevicesWithProblemCode=$problemDevices.Count
    Devices=$devices; SignedDrivers=$drivers; Warnings=$warnings
}
$jsonPath=Join-Path $ReportDir "itvip_hardware_$stamp.json"
$txtPath=Join-Path $ReportDir "itvip_hardware_$stamp.txt"
$csvPath=Join-Path $ReportDir "itvip_devices_$stamp.csv"
$summary | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
if ($devices.Count) { $devices | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8 }
$lines=@('IT VIP — Driver & Hardware Inventory',"Generated: $($summary.GeneratedAt)","OS: $($summary.OperatingSystem)","Architecture: $($summary.Architecture)","CPU: $($summary.CPU)","PnP devices: $($devices.Count)","Devices reporting a problem code: $($problemDevices.Count)","Signed driver records collected: $($drivers.Count)",'','DISPLAY ADAPTERS')
foreach($v in $video){$lines += "- $($v.Name) | Driver $($v.DriverVersion) | $($v.Status)"}
$lines += ''; $lines += 'DISKS'; foreach($x in $disk){$lines += "- $($x.Model) | $($x.InterfaceType) | $($x.Status)"}
$lines += ''; $lines += 'DEVICES WITH NONZERO PROBLEM CODE'; foreach($x in $problemDevices){$lines += "- $($x.Name) | Code $($x.ConfigManagerErrorCode) | $($x.DeviceID)"}
$lines += ''; $lines += 'WARNINGS'; foreach($w in $warnings){$lines += "- $w"}
$lines += ''; $lines += 'READ-ONLY: no drivers installed, removed, updated, or disabled.'
$lines | Set-Content -LiteralPath $txtPath -Encoding UTF8
Write-Host ($lines -join [Environment]::NewLine)
Write-Host "`nReports saved:`n$jsonPath`n$txtPath"
if($devices.Count){Write-Host $csvPath}
Write-Host 'No driver changes were made. Use Windows Update or the hardware manufacturer official support page for driver updates.'
