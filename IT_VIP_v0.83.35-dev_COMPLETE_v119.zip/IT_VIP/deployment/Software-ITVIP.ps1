[CmdletBinding()]
param(
  [ValidateRange(1,5000)][int]$MaxApps=2000,
  [ValidateSet('All','Machine','CurrentUser')][string]$Scope='All',
  [string]$NameLike=''
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$warnings=New-Object System.Collections.Generic.List[string]
$apps=New-Object System.Collections.Generic.List[object]
$locations=@(
  [pscustomobject]@{Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*';Scope='Machine';View='64-bit/native'},
  [pscustomobject]@{Path='HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*';Scope='Machine';View='32-bit'},
  [pscustomobject]@{Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*';Scope='CurrentUser';View='Current user'}
)
foreach($loc in $locations){
  if($Scope -ne 'All' -and $Scope -ne $loc.Scope){continue}
  try {
    foreach($item in @(Get-ItemProperty -Path $loc.Path -ErrorAction SilentlyContinue)){
      $display=[string]$item.DisplayName
      if([string]::IsNullOrWhiteSpace($display)){continue}
      if($item.SystemComponent -eq 1){continue}
      if($item.ParentKeyName){continue}
      if($NameLike -and $display -notlike "*$NameLike*"){continue}
      $size=$null
      if($null -ne $item.EstimatedSize){try{$sizeMB=[math]::Round(([double]$item.EstimatedSize)/1024,2)}catch{$sizeMB=$null}}else{$sizeMB=$null}
      $installDate=$null
      if($item.InstallDate -match '^\d{8}$'){$installDate=[string]$item.InstallDate}
      $apps.Add([pscustomobject]@{
        DisplayName=$display;DisplayVersion=[string]$item.DisplayVersion;Publisher=[string]$item.Publisher
        InstallDate=$installDate;EstimatedSizeMB=$sizeMB;InstallLocation=[string]$item.InstallLocation
        RegistryScope=$loc.Scope;RegistryView=$loc.View;RegistryKey=[string]$item.PSPath
      })
      if($apps.Count -ge $MaxApps){$warnings.Add("Result cap reached ($MaxApps); inventory may be incomplete.");break}
    }
  }catch{$warnings.Add("Could not read $($loc.Path): $($_.Exception.Message)")}
  if($apps.Count -ge $MaxApps){break}
}
$unique=@($apps | Sort-Object DisplayName,DisplayVersion,RegistryKey -Unique | Sort-Object DisplayName)
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$totalMB=($unique|Where-Object {$null -ne $_.EstimatedSizeMB}|Measure-Object EstimatedSizeMB -Sum).Sum
$result=[ordered]@{
 Product='IT VIP Software & Installed Apps Manager';Schema='ITVIP-SOFTWARE-1';Timestamp=(Get-Date).ToString('o')
 ReadOnly=$true;Scope=$Scope;NameFilter=$NameLike;RetrievedCount=$unique.Count
 EstimatedTotalSizeMB=$totalMB;Apps=$unique;Warnings=@($warnings)
 Limitations=@('Inventory is based on standard Windows Uninstall registry entries; Store/MSIX and portable apps may be absent or represented differently.','EstimatedSize is publisher-supplied registry metadata and may be missing or inaccurate.','No uninstall command is read, displayed, or executed. No software is installed, updated, or removed.','Registry key paths are included for diagnostics; review reports before sharing.')
}
$json=Join-Path $reportDir "itvip_software_$stamp.json"
$txt=Join-Path $reportDir "itvip_software_$stamp.txt"
$csv=Join-Path $reportDir "itvip_software_$stamp.csv"
$result|ConvertTo-Json -Depth 6|Set-Content -Encoding UTF8 $json
$unique|Select-Object DisplayName,DisplayVersion,Publisher,InstallDate,EstimatedSizeMB,InstallLocation,RegistryScope,RegistryView|Export-Csv -NoTypeInformation -Encoding UTF8 $csv
$lines=@('IT VIP Software & Installed Apps Manager',"Timestamp: $($result.Timestamp)",'READ-ONLY SOFTWARE INVENTORY',"Scope: $Scope | Name filter: $NameLike","Applications: $($unique.Count)","Estimated size total (publisher metadata): $totalMB MB",'','APPLICATIONS')
foreach($app in $unique){$lines+=@("$($app.DisplayName) | Version: $($app.DisplayVersion) | Publisher: $($app.Publisher) | Size MB: $($app.EstimatedSizeMB)")}
$lines+=@('','WARNINGS')+$warnings+@('','Read-only: no applications were installed, updated, or removed. Estimated sizes may be missing or inaccurate.')
$lines|Set-Content -Encoding UTF8 $txt
Write-Host 'Software inventory completed (read-only).' -ForegroundColor Cyan
Write-Host "Applications: $($unique.Count)"
Write-Host "JSON: $json`nTXT: $txt`nCSV: $csv"
