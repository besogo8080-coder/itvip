@echo off
setlocal
pushd "%~dp0" || exit /b 1
if not exist "build\ITVIP.exe" (
  echo IT VIP executable was not found.
  echo Build the complete project with build.bat before launching.
  pause
  popd
  exit /b 2
)
start "IT VIP" "%~dp0build\ITVIP.exe"
popd
endlocal
