[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$EditionDirectory,
 [Parameter(Mandatory=$true)][string]$PrivateKeyFile,
 [string]$ExpiresUtc='',
 [string]$PublicKeyFile='',
 [ValidateSet('None','WindowsSid')][string]$BindingMode='None',
 [string]$BindingSid='',
 [string]$RevocationFile=''
)
$ErrorActionPreference='Stop'
$edition=[IO.Path]::GetFullPath($EditionDirectory);$keyPath=[IO.Path]::GetFullPath($PrivateKeyFile)
if(-not (Test-Path -LiteralPath $edition -PathType Container)){throw 'EditionDirectory must be an existing directory.'}
$editionItem=Get-Item -LiteralPath $edition -Force
if(($editionItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Edition root must not be a reparse point.'}
$manifestPath=Join-Path $edition 'EDITION_MANIFEST.json';$inventoryPath=Join-Path $edition 'EDITION_SHA256.json'
if([string]::IsNullOrWhiteSpace($PublicKeyFile)){$PublicKeyFile=[IO.Path]::ChangeExtension($keyPath,'.public.xml')}
$publicPath=[IO.Path]::GetFullPath($PublicKeyFile)
foreach($p in @($manifestPath,$inventoryPath,$keyPath,$publicPath)){if(-not(Test-Path -LiteralPath $p -PathType Leaf)){throw "Required file missing: $p"}}
if(Test-Path (Join-Path $edition 'EDITION_SIGNATURE.sha256rsa')){throw 'Edition already has a signature. Rebuild/reissue into a fresh output directory.'}
foreach($entry in @(Get-ChildItem -LiteralPath $edition -Recurse -Force)){if(($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw "Reparse points are not allowed in a signed edition: $($entry.FullName)"}}
Copy-Item -LiteralPath $publicPath -Destination (Join-Path $edition 'deployment/authority.public.xml') -Force
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if($manifest.Schema -ne 'ITVIP-USER-EDITION-2'){throw 'Unsupported edition manifest schema. Rebuild with the matching current builder.'}
if($ExpiresUtc){$expiry=[DateTime]::Parse($ExpiresUtc).ToUniversalTime();if($expiry -le [DateTime]::UtcNow){throw 'Expiry must be in the future.'};$manifest | Add-Member -NotePropertyName ExpiresUtc -NotePropertyValue $expiry.ToString('o') -Force}
$manifest | Add-Member -NotePropertyName IssuedUtc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
$manifest | Add-Member -NotePropertyName SignatureAlgorithm -NotePropertyValue 'RSA-3072-SHA256' -Force
$manifest | Add-Member -NotePropertyName BindingMode -NotePropertyValue $BindingMode -Force
if($BindingMode -eq 'WindowsSid'){if([string]::IsNullOrWhiteSpace($BindingSid)){throw 'WindowsSid binding requires -BindingSid with the target account SID. The owner can obtain it from the target account using WindowsIdentity.'};try{[void](New-Object Security.Principal.SecurityIdentifier($BindingSid))}catch{throw 'BindingSid is not a valid Windows SID.'};$sid=$BindingSid;$sidHash=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sid))).Replace('-',''));$manifest | Add-Member -NotePropertyName BindingValue -NotePropertyValue $sidHash -Force;$manifest | Add-Member -NotePropertyName BindingNote -NotePropertyValue 'Bound to the Windows account SID hash present on the signing workstation. Issue from the target account context.' -Force}else{$manifest | Add-Member -NotePropertyName BindingValue -NotePropertyValue $null -Force;$manifest | Add-Member -NotePropertyName BindingNote -NotePropertyValue 'No Windows account or device binding is applied.' -Force}
$json=$manifest | ConvertTo-Json -Depth 8
[IO.File]::WriteAllText($manifestPath,$json,[Text.UTF8Encoding]::new($false))
# Create an authority-signed offline revocation snapshot. The owner may supply a JSON
# file containing { RevokedEditionIds: [ GUID, ... ] }; absence means an empty snapshot.
$revokedIds=@();$revocationRevision=0
if($RevocationFile){
 if(-not(Test-Path -LiteralPath $RevocationFile -PathType Leaf)){throw 'RevocationFile does not exist.'}
 $source=Get-Content -LiteralPath $RevocationFile -Raw | ConvertFrom-Json
 if($null -eq $source.RevokedEditionIds){throw 'Revocation file must contain RevokedEditionIds.'}
 if($null -ne $source.Revision){$parsedRevision=0;if(-not [int]::TryParse([string]$source.Revision,[ref]$parsedRevision) -or $parsedRevision -lt 0){throw 'Revocation Revision must be a non-negative integer.'};$revocationRevision=$parsedRevision}
 foreach($id in @($source.RevokedEditionIds)){$parsed=[guid]::Empty;if(-not[guid]::TryParse([string]$id,[ref]$parsed)){throw "Invalid revoked EditionId: $id"};$revokedIds+= $parsed.ToString('D')}
}
$revocation=[ordered]@{Schema='ITVIP-REVOCATIONS-1';Revision=$revocationRevision;GeneratedUtc=[DateTime]::UtcNow.ToString('o');RevokedEditionIds=@($revokedIds | Sort-Object -Unique)}
$revocationPath=Join-Path $edition 'EDITION_REVOCATIONS.json'
[IO.File]::WriteAllText($revocationPath,($revocation | ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
# Rebuild the file inventory after the final manifest is written; exclude inventory and signature artifacts themselves.
# Refuse reparse points and ambiguous Windows paths before creating the signed inventory.
$items=@();$seenPaths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach($file in @(Get-ChildItem -LiteralPath $edition -Recurse -Force | Sort-Object FullName)){
 if(($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw "Reparse points are not allowed in a signed edition: $($file.FullName)"}
 if($file.PSIsContainer){continue}
 if($file.FullName.Equals($inventoryPath,[StringComparison]::OrdinalIgnoreCase) -or $file.FullName.Equals((Join-Path $edition 'EDITION_SIGNATURE.sha256rsa'),[StringComparison]::OrdinalIgnoreCase)){continue}
 $rel=($file.FullName.Substring($edition.Length).TrimStart('\','/')) -replace '\\','/'
 if([string]::IsNullOrWhiteSpace($rel) -or $rel.Contains(':') -or $rel.Contains('\') -or $rel.StartsWith('/') -or $rel -match '(^|/)\.\.?(/|$)' -or $rel -match '[<>"|?*]'){throw "Unsafe signed inventory path: $rel"}
 foreach($part in $rel.Split('/')){if($part.EndsWith('.') -or $part.EndsWith(' ') -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$'){throw "Windows-reserved inventory path: $rel"}}
 if(-not $seenPaths.Add($rel)){throw "Duplicate case-insensitive inventory path: $rel"}
 $items+= [pscustomobject]@{Path=$rel;SHA256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash}
}
if($items.Count -lt 1){throw 'Refusing to sign an edition with an empty file inventory.'}
$items | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $inventoryPath -Encoding UTF8
$secure=ConvertTo-SecureString (Get-Content -LiteralPath $keyPath -Raw)
$ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$privateXml=$null
try {$privateXml=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
$rsa=New-Object System.Security.Cryptography.RSACryptoServiceProvider
$publicRsa=New-Object System.Security.Cryptography.RSACryptoServiceProvider
try {
 $rsa.FromXmlString($privateXml)
 $publicXml=Get-Content -LiteralPath $publicPath -Raw
 $publicRsa.FromXmlString($publicXml)
 if($rsa.KeySize -ne 3072 -or $publicRsa.KeySize -ne 3072){throw 'The edition authority key must be RSA-3072.'}
 $privatePublic=$rsa.ExportParameters($false);$expectedPublic=$publicRsa.ExportParameters($false)
 if([Convert]::ToBase64String($privatePublic.Modulus) -cne [Convert]::ToBase64String($expectedPublic.Modulus) -or [Convert]::ToBase64String($privatePublic.Exponent) -cne [Convert]::ToBase64String($expectedPublic.Exponent)){throw 'Private key does not match the supplied authority public key.'}
 $m=[IO.File]::ReadAllBytes($manifestPath);$i=[IO.File]::ReadAllBytes($inventoryPath)
 $payload=New-Object byte[] ($m.Length+$i.Length);[Array]::Copy($m,0,$payload,0,$m.Length);[Array]::Copy($i,0,$payload,$m.Length,$i.Length)
 $sig=$rsa.SignData($payload,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'))
 [IO.File]::WriteAllText((Join-Path $edition 'EDITION_SIGNATURE.sha256rsa'),[Convert]::ToBase64String($sig),[Text.Encoding]::ASCII)
 $revBytes=[IO.File]::ReadAllBytes($revocationPath)
 $revSig=$rsa.SignData($revBytes,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'))
 [IO.File]::WriteAllText((Join-Path $edition 'EDITION_REVOCATIONS.sha256rsa'),[Convert]::ToBase64String($revSig),[Text.Encoding]::ASCII)
 Write-Host 'Edition and offline revocation snapshot signed. Revocation updates require a newly signed/reissued edition.' -ForegroundColor Green
} finally {$rsa.Dispose();$publicRsa.Dispose();$privateXml=$null}
