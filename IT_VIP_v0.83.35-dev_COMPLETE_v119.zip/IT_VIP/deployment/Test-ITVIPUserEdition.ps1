[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$EditionDirectory,[Parameter(Mandatory=$true)][string]$PublicKeyFile)
$ErrorActionPreference='Stop'
$edition=[IO.Path]::GetFullPath($EditionDirectory);$pub=[IO.Path]::GetFullPath($PublicKeyFile)
$mp=Join-Path $edition 'EDITION_MANIFEST.json';$ip=Join-Path $edition 'EDITION_SHA256.json';$sp=Join-Path $edition 'EDITION_SIGNATURE.sha256rsa';$rp=Join-Path $edition 'EDITION_REVOCATIONS.json';$rsp=Join-Path $edition 'EDITION_REVOCATIONS.sha256rsa'
foreach($p in @($mp,$ip,$sp,$rp,$rsp,$pub)){if(-not(Test-Path -LiteralPath $p -PathType Leaf)){throw "Required verification file missing: $p"}}
$manifest=Get-Content -LiteralPath $mp -Raw | ConvertFrom-Json
if($manifest.Schema -ne 'ITVIP-USER-EDITION-2' -or $manifest.SignatureAlgorithm -ne 'RSA-3072-SHA256'){throw 'Unsupported or unsigned edition manifest.'}
$inventory=Get-Content -LiteralPath $ip -Raw | ConvertFrom-Json
$bad=@();$listed=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase);foreach($entry in $inventory){if(-not $listed.Add([string]$entry.Path)){throw "Duplicate inventory path: $($entry.Path)"};$candidate=[IO.Path]::GetFullPath((Join-Path $edition $entry.Path));$prefix=$edition.TrimEnd('\')+'\';if(-not $candidate.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw "Unsafe path in inventory: $($entry.Path)"};if(-not(Test-Path -LiteralPath $candidate -PathType Leaf)){$bad+="MISSING $($entry.Path)";continue};$actual=(Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash;if($actual -ne $entry.SHA256){$bad+="HASH_MISMATCH $($entry.Path)"}}
if($bad.Count){$bad | ForEach-Object {Write-Error $_};throw 'Edition file integrity check failed.'}
$tree=Get-ChildItem -LiteralPath $edition -Force -Recurse; if(@($tree | Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0}).Count){throw 'Reparse points / symbolic links are not allowed in a signed edition.'}; $actualFiles=@($tree | Where-Object {-not $_.PSIsContainer} | ForEach-Object {$_.FullName.Substring($edition.TrimEnd('\').Length).TrimStart('\','/')})
$allowed=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach($path in $listed){[void]$allowed.Add($path)}
[void]$allowed.Add('EDITION_SHA256.json');[void]$allowed.Add('EDITION_SIGNATURE.sha256rsa');[void]$allowed.Add('EDITION_REVOCATIONS.sha256rsa')
$extras=@($actualFiles | Where-Object {-not $allowed.Contains($_)})
if($extras.Count){throw ('Unlisted files detected: '+($extras -join ', '))}
$signature=[Convert]::FromBase64String((Get-Content -LiteralPath $sp -Raw).Trim());$m=[IO.File]::ReadAllBytes($mp);$i=[IO.File]::ReadAllBytes($ip);$payload=New-Object byte[] ($m.Length+$i.Length);[Array]::Copy($m,0,$payload,0,$m.Length);[Array]::Copy($i,0,$payload,$m.Length,$i.Length)
$rsa=New-Object System.Security.Cryptography.RSACryptoServiceProvider
try {
 $rsa.FromXmlString((Get-Content -LiteralPath $pub -Raw))
 if(-not $rsa.VerifyData($payload,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'),$signature)){throw 'Digital signature is invalid.'}
 $revBytes=[IO.File]::ReadAllBytes($rp);$revSig=[Convert]::FromBase64String((Get-Content -LiteralPath $rsp -Raw).Trim())
 if(-not $rsa.VerifyData($revBytes,[Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'),$revSig)){throw 'Revocation snapshot signature is invalid.'}
} finally {$rsa.Dispose()}
$revocations=Get-Content -LiteralPath $rp -Raw | ConvertFrom-Json
if($revocations.Schema -ne 'ITVIP-REVOCATIONS-1'){throw 'Unsupported revocation snapshot schema.'}
if($null -ne $revocations.Revision){$rev=0;if(-not [int]::TryParse([string]$revocations.Revision,[ref]$rev) -or $rev -lt 0){throw 'Invalid revocation snapshot revision.'}}else{$rev=0}
# Per-Windows-user high-water mark: reject older signed snapshots after a newer
# revision has been accepted. DPAPI CurrentUser prevents another Windows account
# from silently reusing this state; this is not tamper-proof against local admins.
$stateRoot=Join-Path $env:LOCALAPPDATA 'ITVIP\LicenseState'
$statePath=Join-Path $stateRoot ($manifest.EditionId.ToString().ToLowerInvariant()+'.bin')
$entropy=[Text.Encoding]::UTF8.GetBytes('ITVIP-LicenseState-v1')
$state=[ordered]@{EditionId=[string]$manifest.EditionId;HighestRevision=0}
if(Test-Path -LiteralPath $statePath -PathType Leaf){
 try {
  $protected=[IO.File]::ReadAllBytes($statePath)
  $plain=[Security.Cryptography.ProtectedData]::Unprotect($protected,$entropy,[Security.Cryptography.DataProtectionScope]::CurrentUser)
  $prior=([Text.Encoding]::UTF8.GetString($plain) | ConvertFrom-Json)
  if(([string]$prior.EditionId) -ne ([string]$manifest.EditionId)){throw 'License state identity mismatch.'}
  $priorRevision=0;if(-not [int]::TryParse([string]$prior.HighestRevision,[ref]$priorRevision) -or $priorRevision -lt 0){throw 'Stored license revision state is invalid.'}
  $state.HighestRevision=$priorRevision
 } catch { throw ('Cannot validate protected anti-rollback state: '+$_.Exception.Message) }
}
if($rev -lt [int]$state.HighestRevision){throw "Rollback detected: signed revocation revision $rev is older than accepted revision $($state.HighestRevision)."}
if($rev -gt [int]$state.HighestRevision){
 New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
 $state.HighestRevision=$rev
 $json=ConvertTo-Json -InputObject $state -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($json)
 $protected=[Security.Cryptography.ProtectedData]::Protect($bytes,$entropy,[Security.Cryptography.DataProtectionScope]::CurrentUser)
 $tmp=$statePath+'.tmp.'+[Guid]::NewGuid().ToString('N')
 try {[IO.File]::WriteAllBytes($tmp,$protected);Move-Item -LiteralPath $tmp -Destination $statePath -Force}
 finally {if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
if(@($revocations.RevokedEditionIds | Where-Object {([string]$_).Equals([string]$manifest.EditionId,[StringComparison]::OrdinalIgnoreCase)}).Count){throw 'This EditionId appears in the signed offline revocation list.'}
if([string]::IsNullOrWhiteSpace([string]$manifest.EditionId) -or [string]::IsNullOrWhiteSpace([string]$manifest.ProfileRevision)){throw 'Edition identity or profile revision is missing.'};if($manifest.Status -eq 'Revoked'){throw 'Edition has been revoked.'};if($manifest.IssuedUtc){$issued=[DateTime]::Parse($manifest.IssuedUtc).ToUniversalTime();if($issued -gt [DateTime]::UtcNow.AddMinutes(5)){throw 'Edition issue timestamp is in the future.'}}
if($manifest.BindingMode -eq 'WindowsSid'){$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;$sha=[Security.Cryptography.SHA256]::Create();try{$currentHash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($sid))).Replace('-',''))}finally{$sha.Dispose()};if([string]::IsNullOrWhiteSpace([string]$manifest.BindingValue) -or $currentHash -ne $manifest.BindingValue){throw 'This edition is bound to a different Windows account.'}}elseif($manifest.BindingMode -ne 'None'){throw 'Unsupported license binding mode.'}
if($manifest.ExpiresUtc){$expiry=[DateTime]::Parse($manifest.ExpiresUtc).ToUniversalTime();if([DateTime]::UtcNow -ge $expiry){throw 'Edition has expired.'}}
Write-Host 'PASS: RSA signature, manifest, inventory, file hashes, and anti-rollback state verified.' -ForegroundColor Green
Write-Host "EditionId: $($manifest.EditionId) | ProfileRevision: $($manifest.ProfileRevision) | RevocationRevision: $rev | Binding: $($manifest.BindingMode)"
