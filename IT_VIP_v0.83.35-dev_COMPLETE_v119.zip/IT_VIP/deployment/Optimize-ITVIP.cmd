@echo off
setlocal
set "SCRIPT=%~dp0Optimize-ITVIP.ps1"
if not exist "%SCRIPT%" (
  echo IT VIP Optimization Center script was not found.
  pause
  exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Action All
set "RC=%ERRORLEVEL%"
echo.
echo IT VIP Optimization Center finished with exit code %RC%.
pause
exit /b %RC%
