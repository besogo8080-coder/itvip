[CmdletBinding()]
param(
  [ValidateSet('Inventory','StopProcess','All')][string]$Action='All',
  [int]$ProcessId=0
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings=New-Object System.Collections.Generic.List[string]
function Safe-Query([scriptblock]$Query,[string]$Label) { try { @(& $Query) } catch { $warnings.Add("$Label : $($_.Exception.Message)"); @() } }
$os=Safe-Query { Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime,TotalVisibleMemorySize,FreePhysicalMemory } 'OS memory'
$cpu=Safe-Query { Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,LoadPercentage,MaxClockSpeed } 'CPU'
$processes=Safe-Query { Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 100 Id,ProcessName,CPU, @{n='MemoryMB';e={[math]::Round($_.WorkingSet64/1MB,1)}}, @{n='PrivateMemoryMB';e={[math]::Round($_.PrivateMemorySize64/1MB,1)}},Threads,Handles,StartTime } 'Processes'
$services=Safe-Query { Get-CimInstance Win32_Service | Where-Object {$_.State -eq 'Running'} | Select-Object -First 100 Name,DisplayName,StartMode,State,ProcessId } 'Running services'
$logicalDisks=Safe-Query { Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID,VolumeName,FileSystem,Size,FreeSpace,@{n='UsedPercent';e={if($_.Size){[math]::Round((($_.Size-$_.FreeSpace)/$_.Size)*100,1)}else{$null}}} } 'Disk usage'
$stopResult=$null
if($Action -eq 'StopProcess') {
  if($ProcessId -le 0) { $rawPid=Read-Host 'Enter process PID'; if($rawPid -notmatch '^\d+$') { throw 'PID must contain digits only.' }; $ProcessId=[int]$rawPid }
  if($ProcessId -le 4) { throw 'Refusing to stop PID 0-4. Supply a normal user-process PID.' }
  $target=Get-Process -Id $ProcessId -ErrorAction Stop
  $protected=@('System','Idle','Registry','smss','csrss','wininit','services','lsass','winlogon','svchost')
  if($protected -contains $target.ProcessName) { throw "Refusing to stop protected process: $($target.ProcessName)" }
  Write-Host "Target: $($target.ProcessName) (PID $ProcessId)" -ForegroundColor Yellow
  Write-Host 'This can cause unsaved work loss or application instability.' -ForegroundColor Yellow
  $confirm=Read-Host "Type STOP $ProcessId to continue"
  if($confirm -cne "STOP $ProcessId") { $stopResult='Cancelled by user' }
  else { Stop-Process -Id $ProcessId -ErrorAction Stop; $stopResult="Stop requested for PID $ProcessId" }
}
$result=[ordered]@{Product='IT VIP Process & Performance Manager';Schema='ITVIP-PERFORMANCE-1';Timestamp=(Get-Date).ToString('o');Action=$Action;ReadOnly=($Action -ne 'StopProcess');OS=$os;CPU=$cpu;TopProcesses=$processes;RunningServices=$services;LogicalDisks=$logicalDisks;StopProcessResult=$stopResult;Warnings=@($warnings);Notes=@('Inventory is read-only.','CPU time is cumulative process CPU time, not an instantaneous percentage.','Top process list is limited to 100 processes sorted by working set.','Stopping a process is optional, interactive, and may lose unsaved work.','No service, startup setting, power plan, or disk configuration is changed.')}
$json=Join-Path $reportDir "itvip_performance_$stamp.json"; $txt=Join-Path $reportDir "itvip_performance_$stamp.txt"; $csv=Join-Path $reportDir "itvip_processes_$stamp.csv"
$result | ConvertTo-Json -Depth 7 | Set-Content -Encoding UTF8 $json
@('IT VIP Process & Performance Manager',"Timestamp: $($result.Timestamp)",'', 'CPU',($cpu | Format-List | Out-String),'OS MEMORY',($os | Format-List | Out-String),'TOP PROCESSES',($processes | Format-Table -AutoSize | Out-String),'RUNNING SERVICES',($services | Format-Table -AutoSize | Out-String),'LOGICAL DISKS',($logicalDisks | Format-Table -AutoSize | Out-String),'WARNINGS',($warnings -join "`r`n"),$result.Notes) | Set-Content -Encoding UTF8 $txt
if($processes.Count -gt 0) { $processes | Export-Csv -NoTypeInformation -Encoding UTF8 $csv }
Write-Host 'Performance inventory completed.' -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt`nCSV: $csv"
if($Action -eq 'StopProcess' -and $stopResult) { Write-Host $stopResult }
