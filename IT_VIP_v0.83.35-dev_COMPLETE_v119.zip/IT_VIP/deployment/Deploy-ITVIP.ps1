[CmdletBinding()]
param(
    [ValidateSet('Preflight','PackagePortable','VerifyPackage')]
    [string]$Action = 'Preflight',
    [string]$OutputPath = '',
    [string]$PackagePath = ''
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$RequiredBins = @(
    'ITVIP.exe','scanner.exe','usb_guard.exe','tempclean.exe','activator.exe',
    'pwrecover.exe','portable_manager.exe','copy_manager.exe','security_center.exe','ai_assistant.exe',
    'github_hub.exe','api_manager.exe','agent_studio.exe','provider_hub.exe',
    'provider_runtime.exe','team_studio.exe','team_runner.exe','workflow_studio.exe',
    'workflow_runner.exe','run_history.exe','memory_center.exe','session_center.exe',
    'backup_center.exe','settings_center.exe','permissions_center.exe','system_monitor_gui.exe'
)
function Get-Preflight {
    $os = Get-CimInstance Win32_OperatingSystem
    $arch = if ([Environment]::Is64BitOperatingSystem) { 'x64' } else { 'x86' }
    $missing = @($RequiredBins | Where-Object { -not (Test-Path -LiteralPath (Join-Path $Root "build\$_") -PathType Leaf) })
    [pscustomobject]@{
        Product = 'IT VIP – ULTIMATE WINDOWS TOOLKIT'
        Version = '0.54.0-dev'
        Windows = $os.Caption
        WindowsVersion = $os.Version
        Architecture = $arch
        PowerShell = $PSVersionTable.PSVersion.ToString()
        BuildDirectory = Join-Path $Root 'build'
        RequiredExecutables = $RequiredBins.Count
        MissingExecutables = $missing
        ReadyForPortablePackage = ($missing.Count -eq 0)
    }
}
function New-PortablePackage {
    param([string]$Destination)
    $check = Get-Preflight
    if (-not $check.ReadyForPortablePackage) {
        throw "Portable packaging stopped. Missing build outputs: $($check.MissingExecutables -join ', '). Run build.bat first."
    }
    if ([string]::IsNullOrWhiteSpace($Destination)) {
        $Destination = Join-Path (Split-Path $Root -Parent) 'IT_VIP_Portable'
    }
    $destFull = [IO.Path]::GetFullPath($Destination)
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    if ($destFull.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose an output directory outside the source project folder.'
    }
    if (Test-Path -LiteralPath $destFull) { throw "Output already exists; choose a new empty destination: $destFull" }
    New-Item -ItemType Directory -Path $destFull -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $destFull 'build') -Force | Out-Null
    foreach ($exe in $RequiredBins) { Copy-Item -LiteralPath (Join-Path $Root "build\$exe") -Destination (Join-Path $destFull 'build') }
    foreach ($folder in @('assets','config','docs','portable','deployment')) {
        $source = Join-Path $Root $folder
        if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination $destFull -Recurse }
    }
    foreach ($folder in @('data','reports','logs')) { New-Item -ItemType Directory -Path (Join-Path $destFull $folder) -Force | Out-Null }
    Copy-Item -LiteralPath (Join-Path $Root 'deployment\Start-ITVIP.cmd') -Destination $destFull
    Copy-Item -LiteralPath (Join-Path $Root 'README.md') -Destination $destFull
    Copy-Item -LiteralPath (Join-Path $Root 'README_AR.md') -Destination $destFull
    $manifest = Join-Path $destFull 'PACKAGE_SHA256.txt'
    Get-ChildItem -LiteralPath $destFull -File -Recurse | Where-Object { $_.FullName -ne $manifest } | ForEach-Object {
        $relative = $_.FullName.Substring($destFull.Length).TrimStart('\')
        $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
        "$hash  $relative"
    } | Set-Content -LiteralPath $manifest -Encoding UTF8
    Write-Host "Portable package created: $destFull" -ForegroundColor Green
    Write-Host 'No installer, registry changes, services, or automatic elevation were created.'
}
function Test-PortablePackage {
    if ([string]::IsNullOrWhiteSpace($PackagePath)) { throw 'Supply -PackagePath pointing to a portable package folder.' }
    $dir = (Resolve-Path -LiteralPath $PackagePath).Path
    $manifest = Join-Path $dir 'PACKAGE_SHA256.txt'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'PACKAGE_SHA256.txt is missing.' }
    $bad = @()
    foreach ($line in Get-Content -LiteralPath $manifest) {
        if ($line -notmatch '^([A-Fa-f0-9]{64})\s+(.+)$') { $bad += "Malformed manifest row: $line"; continue }
        $expected = $Matches[1].ToUpperInvariant(); $rel = $Matches[2]
        if ([IO.Path]::IsPathRooted($rel) -or $rel.Contains('..')) { $bad += "Unsafe relative path: $rel"; continue }
        $file = Join-Path $dir $rel
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { $bad += "Missing: $rel"; continue }
        $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actual -ne $expected) { $bad += "Hash mismatch: $rel" }
    }
    if ($bad.Count) { $bad | ForEach-Object { Write-Error $_ }; throw "Package verification failed: $($bad.Count) issue(s)." }
    Write-Host 'Portable package SHA-256 verification: PASS' -ForegroundColor Green
}
switch ($Action) {
    'Preflight' { Get-Preflight | Format-List }
    'PackagePortable' { New-PortablePackage -Destination $OutputPath }
    'VerifyPackage' { Test-PortablePackage }
}
