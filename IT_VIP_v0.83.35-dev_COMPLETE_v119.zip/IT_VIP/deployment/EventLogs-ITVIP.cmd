@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo IT VIP - Event Viewer & Log Analyzer (READ-ONLY)
echo 1. System + Application / Warnings and above / 7 days
echo 2. System only / Errors and above / 7 days
echo 3. Application only / Errors and above / 7 days
echo 4. Custom query
set /p choice=Select action [1-4]:
if "%choice%"=="2" (set log=System&set level=Error&set days=7&set max=1000&set id=0) else if "%choice%"=="3" (set log=Application&set level=Error&set days=7&set max=1000&set id=0) else if "%choice%"=="4" (set /p log=Log [All/System/Application]: & set /p level=Level [Critical/Error/Warning/Information/All]: & set /p days=Days [1-90]: & set /p max=Maximum events [1-5000]: & set /p id=Event ID [0=any]:) else (set log=All&set level=Warning&set days=7&set max=1000&set id=0)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0EventLogs-ITVIP.ps1" -Log "%log%" -Level "%level%" -Days %days% -MaxEvents %max% -EventId %id%
set "RC=!ERRORLEVEL!"
echo.
echo Reports are saved in the reports folder. Review privacy-sensitive messages before sharing.
pause
endlocal & exit /b %RC%
