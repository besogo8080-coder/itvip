[CmdletBinding()]
param([ValidateSet('Inventory','Diagnostics','All')][string]$Action='All')
$ErrorActionPreference='Stop'
$root = Split-Path -Parent $PSScriptRoot
$reportDir = Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$warnings = New-Object System.Collections.Generic.List[string]
function Safe-Query([scriptblock]$Query,[string]$Label) {
  try { & $Query } catch { $warnings.Add("$Label : $($_.Exception.Message)"); @() }
}
$adapters = @(Safe-Query { Get-NetAdapter -IncludeHidden | Select-Object Name,InterfaceDescription,Status,MacAddress,LinkSpeed,MediaType,Virtual } 'Adapters')
$ip = @(Safe-Query { Get-NetIPConfiguration | ForEach-Object { [pscustomobject]@{ InterfaceAlias=$_.InterfaceAlias; IPv4Address=(@($_.IPv4Address | ForEach-Object IPAddress) -join ','); IPv6Address=(@($_.IPv6Address | ForEach-Object IPAddress) -join ','); IPv4Gateway=(@($_.IPv4DefaultGateway | ForEach-Object NextHop) -join ','); DNSServers=(@($_.DNSServer.ServerAddresses) -join ',') } } } 'IP configuration')
$stats = @(Safe-Query { Get-NetAdapterStatistics | Select-Object Name,ReceivedBytes,SentBytes,ReceivedUnicastPackets,SentUnicastPackets,ReceivedPacketErrors,OutboundPacketErrors } 'Adapter statistics')
$listeners = @(Safe-Query { Get-NetTCPConnection -State Listen | Sort-Object LocalPort | Select-Object LocalAddress,LocalPort,OwningProcess,@{n='ProcessName';e={ try {(Get-Process -Id $_.OwningProcess -ErrorAction Stop).ProcessName} catch {'Unknown'} }} } 'Listening TCP ports')
$tests = @()
if ($Action -in @('Diagnostics','All')) {
  $tests += [pscustomobject]@{Test='Gateway reachability';Target='Default gateways';Result='Not run';Details='No default gateway found'}
  $gateways = @($ip | ForEach-Object { $_.IPv4Gateway } | Where-Object { $_ } | ForEach-Object { $_ -split ',' } | Select-Object -Unique)
  if ($gateways.Count -gt 0) { foreach($gw in $gateways) { $ok=$false; try { $ok=Test-Connection -ComputerName $gw -Count 2 -Quiet -ErrorAction Stop } catch {}; $tests += [pscustomobject]@{Test='Gateway reachability';Target=$gw;Result=$(if($ok){'PASS'}else{'FAIL/No reply'});Details='ICMP may be blocked by network policy'} } }
  foreach($target in @('1.1.1.1','8.8.8.8')) { $ok=$false; try { $ok=Test-Connection -ComputerName $target -Count 2 -Quiet -ErrorAction Stop } catch {}; $tests += [pscustomobject]@{Test='Internet IP reachability';Target=$target;Result=$(if($ok){'PASS'}else{'FAIL/No reply'});Details='ICMP reachability only; not a full bandwidth test'} }
  try { $resolved=@(Resolve-DnsName -Name 'example.com' -Type A -DnsOnly -ErrorAction Stop); $tests += [pscustomobject]@{Test='DNS resolution';Target='example.com';Result='PASS';Details=(($resolved | ForEach-Object IPAddress | Where-Object {$_}) -join ',')} } catch { $tests += [pscustomobject]@{Test='DNS resolution';Target='example.com';Result='FAIL';Details=$_.Exception.Message} }
}
$result=[ordered]@{Product='IT VIP Network Manager';Schema='ITVIP-NETWORK-1';Timestamp=(Get-Date).ToString('o');ReadOnly=$true;Action=$Action;Adapters=$adapters;IPConfiguration=$ip;AdapterStatistics=$stats;ListeningTCPPorts=$listeners;Diagnostics=$tests;Warnings=@($warnings);Notes=@('Read-only inventory and connectivity checks.','Listening ports are local listeners only; this is not a remote port scanner.','Ping failures may reflect ICMP filtering.','No network settings, firewall rules, or adapters were changed.')}
$json=Join-Path $reportDir "itvip_network_$stamp.json"; $txt=Join-Path $reportDir "itvip_network_$stamp.txt"; $csv=Join-Path $reportDir "itvip_network_adapters_$stamp.csv"
$result | ConvertTo-Json -Depth 7 | Set-Content -Encoding UTF8 $json
@("IT VIP Network Manager",("Timestamp: {0}" -f $result.Timestamp),'Read-only: True','', 'ADAPTERS',($adapters | Format-Table -AutoSize | Out-String),'IP CONFIGURATION',($ip | Format-List | Out-String),'ADAPTER STATISTICS',($stats | Format-Table -AutoSize | Out-String),'LOCAL TCP LISTENERS',($listeners | Format-Table -AutoSize | Out-String),'CONNECTIVITY TESTS',($tests | Format-Table -AutoSize | Out-String),'WARNINGS',($warnings -join "`r`n"),$result.Notes) | Set-Content -Encoding UTF8 $txt
if ($adapters.Count -gt 0) { $adapters | Export-Csv -NoTypeInformation -Encoding UTF8 $csv }
Write-Host "Network inventory completed. Read-only mode: no settings changed." -ForegroundColor Cyan
Write-Host "JSON: $json`nTXT: $txt`nCSV: $csv"
Write-Host "Local listening ports only; no remote port scan was performed."
