@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "RC=0"
cd /d "%~dp0\.."
echo IT VIP - Windows Repair Center (READ-ONLY)
echo 1. Inventory only (quick)
echo 2. SFC verify-only
 echo 3. DISM ScanHealth
 echo 4. CHKDSK online scan
 echo 5. Run all checks (may take a long time)
set /p choice=Select action [1-5]:
if "%choice%"=="2" (set action=SystemFiles) else if "%choice%"=="3" (set action=ImageHealth) else if "%choice%"=="4" (set action=DiskOnline) else if "%choice%"=="5" (set action=All) else (set action=Inventory)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-ITVIP.ps1" -Action "%action%"
set "RC=!ERRORLEVEL!"
echo.
echo Reports are saved in the reports folder.
pause
endlocal & exit /b %RC%
