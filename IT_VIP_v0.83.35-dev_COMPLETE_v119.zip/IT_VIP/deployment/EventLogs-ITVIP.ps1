[CmdletBinding()]
param(
  [ValidateSet('All','System','Application')][string]$Log='All',
  [ValidateSet('Critical','Error','Warning','Information','All')][string]$Level='Warning',
  [ValidateRange(1,90)][int]$Days=7,
  [ValidateRange(1,5000)][int]$MaxEvents=1000,
  [int]$EventId=0
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$reportDir=Join-Path $root 'reports'
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$since=(Get-Date).AddDays(-$Days)
$logs=if($Log -eq 'All'){@('System','Application')}else{@($Log)}
$levels=switch($Level){'Critical'{@(1)}'Error'{@(2)}'Warning'{@(3)}'Information'{@(4)}default{@(1,2,3)}}
$warnings=New-Object System.Collections.Generic.List[string]
$events=New-Object System.Collections.Generic.List[object]
foreach($name in $logs){
  try {
    $filter=@{LogName=$name;StartTime=$since;Level=$levels}
    if($EventId -gt 0){$filter.Id=$EventId}
    $remaining=$MaxEvents-$events.Count
    if($remaining -le 0){break}
    $batch=@(Get-WinEvent -FilterHashtable $filter -MaxEvents $remaining -ErrorAction Stop)
    foreach($ev in $batch){
      $message=''
      try{$message=[string]$ev.Message}catch{$message='[Event message unavailable]'}
      if($message.Length -gt 12000){$message=$message.Substring(0,12000)+' [truncated]'}
      $events.Add([pscustomobject]@{
        TimeCreated=if($ev.TimeCreated){$ev.TimeCreated.ToString('o')}else{$null}
        LogName=$ev.LogName;ProviderName=$ev.ProviderName;Id=$ev.Id;Level=$ev.Level
        LevelDisplayName=$ev.LevelDisplayName;RecordId=$ev.RecordId;MachineName=$ev.MachineName
        Message=$message
      })
    }
  } catch {
    $warnings.Add("Could not read '$name': $($_.Exception.Message)")
  }
}
$ordered=@($events | Sort-Object TimeCreated -Descending)
$counts=[ordered]@{Critical=@($ordered|Where-Object Level -eq 1).Count;Error=@($ordered|Where-Object Level -eq 2).Count;Warning=@($ordered|Where-Object Level -eq 3).Count;Information=@($ordered|Where-Object Level -eq 4).Count}
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$result=[ordered]@{
 Product='IT VIP Event Viewer & Log Analyzer';Schema='ITVIP-EVENTLOG-1';Timestamp=(Get-Date).ToString('o')
 ReadOnly=$true;Query=[ordered]@{Logs=$logs;Level=$Level;Days=$Days;MaxEvents=$MaxEvents;EventId=$EventId;Since=$since.ToString('o')}
 RetrievedCount=$ordered.Count;Counts=$counts;Events=$ordered;Warnings=@($warnings)
 Limits=@('Only System and Application logs are queried. Security, Setup, ForwardedEvents, and custom channels are excluded.','The query is bounded by Days and MaxEvents; counts are only for returned events, not the full log.','Event messages can contain usernames, file paths, device names, or other private data. Review reports before sharing.','No event logs are cleared, modified, exported to external services, or used to change system settings.')
}
$json=Join-Path $reportDir "itvip_eventlogs_$stamp.json"
$txt=Join-Path $reportDir "itvip_eventlogs_$stamp.txt"
$csv=Join-Path $reportDir "itvip_eventlogs_$stamp.csv"
$result|ConvertTo-Json -Depth 8|Set-Content -Encoding UTF8 $json
$ordered|Select-Object TimeCreated,LogName,ProviderName,Id,LevelDisplayName,RecordId,Message|Export-Csv -NoTypeInformation -Encoding UTF8 $csv
$lines=@('IT VIP Event Viewer & Log Analyzer',"Timestamp: $($result.Timestamp)",'READ-ONLY WINDOWS EVENT LOG QUERY',"Logs: $($logs -join ', ')","Level: $Level | Days: $Days | Max events: $MaxEvents | Event ID: $EventId", "Retrieved: $($ordered.Count)",'',"Critical: $($counts.Critical) | Error: $($counts.Error) | Warning: $($counts.Warning) | Information: $($counts.Information)",'','LATEST EVENTS')
foreach($ev in ($ordered|Select-Object -First 100)){$lines+=@("[$($ev.TimeCreated)] [$($ev.LevelDisplayName)] [$($ev.LogName)] Event ID $($ev.Id) — $($ev.ProviderName)",$ev.Message,'')}
$lines+=@('WARNINGS')+$warnings+@('','Read-only: no logs or Windows settings were changed. Review privacy-sensitive event messages before sharing.')
$lines|Set-Content -Encoding UTF8 $txt
Write-Host 'Event log analysis completed (read-only).' -ForegroundColor Cyan
Write-Host "Retrieved: $($ordered.Count) | Critical: $($counts.Critical) | Error: $($counts.Error) | Warning: $($counts.Warning)"
Write-Host "JSON: $json`nTXT: $txt`nCSV: $csv"
