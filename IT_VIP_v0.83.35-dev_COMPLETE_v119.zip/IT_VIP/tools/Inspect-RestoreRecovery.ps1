[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$TransactionPath,
    [Parameter(Mandatory = $true)]
    [string]$AppRoot,
    [switch]$AsJson
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Stop-Invalid([string]$Message) {
    [Console]::Error.WriteLine("Invalid restore recovery journal: $Message")
    exit 2
}

try {
    $transaction = [IO.Path]::GetFullPath($TransactionPath)
    $root = [IO.Path]::GetFullPath($AppRoot)
    if (-not (Test-Path -LiteralPath $transaction -PathType Container)) { Stop-Invalid 'transaction directory does not exist' }
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { Stop-Invalid 'application root does not exist' }
    $journalPath = Join-Path $transaction 'restore.journal'
    if (-not (Test-Path -LiteralPath $journalPath -PathType Leaf)) { Stop-Invalid 'restore.journal is missing' }

    $lines = [IO.File]::ReadAllLines($journalPath, [Text.Encoding]::UTF8)
    if ($lines.Count -lt 3 -or $lines[0] -ne 'ITVIP_RESTORE_JOURNAL_V1') { Stop-Invalid 'unsupported header or truncated journal' }
    if ($lines[1] -notmatch '^PHASE\t(PREPARED|APPLYING|APPLIED|ROLLING_BACK|COMMITTED)$') { Stop-Invalid 'invalid phase record' }
    $phase = $Matches[1]
    if ($lines[2] -notmatch '^INDEX\t(0|[1-9][0-9]*)$') { Stop-Invalid 'invalid index record' }
    [long]$index = $Matches[1]
    if ($lines.Count -gt 100003) { Stop-Invalid 'journal exceeds the supported item limit' }

    $allowedRoots = @('config', 'data', 'assets', 'portable', 'reports')
    $strictUtf8 = [Text.UTF8Encoding]::new($false, $true)
    $items = @()
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    for ($lineNumber = 3; $lineNumber -lt $lines.Count; $lineNumber++) {
        $parts = $lines[$lineNumber].Split([char]9)
        if ($parts.Count -ne 3 -or $parts[0] -ne 'ITEM' -or $parts[1] -notmatch '^(?:[0-9A-Fa-f]{2})+$' -or $parts[2] -notmatch '^[01]$') {
            Stop-Invalid "malformed item record at line $($lineNumber + 1)"
        }
        $bytes = New-Object byte[] ($parts[1].Length / 2)
        for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [Convert]::ToByte($parts[1].Substring($i * 2, 2), 16) }
        try { $relative = $strictUtf8.GetString($bytes) } catch { Stop-Invalid "invalid UTF-8 path at line $($lineNumber + 1)" }
        if ([string]::IsNullOrWhiteSpace($relative) -or $relative.Contains('\') -or $relative.StartsWith('/') -or $relative.Contains(':')) { Stop-Invalid "unsafe relative path at line $($lineNumber + 1)" }
        $segments = $relative.Split('/')
        $badSegments = @($segments | Where-Object { $_ -in @('', '.', '..') -or $_.EndsWith('.') -or $_.EndsWith(' ') -or $_ -match '[<>:"|?*]' -or $_ -match '[\x00-\x1f]' })
        if ($segments.Count -lt 2 -or $badSegments.Count -gt 0) { Stop-Invalid "unsafe path component at line $($lineNumber + 1)" }
        foreach ($segment in $segments) { $stem = ($segment -split '\.', 2)[0]; if ($stem -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') { Stop-Invalid "reserved device-name component at line $($lineNumber + 1)" } }
        if ($segments[0] -cnotin $allowedRoots) { Stop-Invalid "path is outside approved application roots at line $($lineNumber + 1)" }
        if (-not $seen.Add($relative)) { Stop-Invalid "duplicate restore target: $relative" }

        $target = Join-Path $root ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        $old = Join-Path (Join-Path $transaction 'old') ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        $new = Join-Path (Join-Path $transaction 'new') ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
        $targetExists = Test-Path -LiteralPath $target
        $oldExists = Test-Path -LiteralPath $old -PathType Leaf
        $newExists = Test-Path -LiteralPath $new -PathType Leaf
        $items += [pscustomobject]@{
            RelativePath = $relative
            ExistedBefore = ($parts[2] -eq '1')
            TargetPresent = $targetExists
            OriginalSnapshotPresent = $oldExists
            StagedNewFilePresent = $newExists
        }
    }
    if ($index -gt $items.Count) { Stop-Invalid 'journal index exceeds item count' }

    $result = [pscustomobject]@{
        JournalVersion = 1
        Phase = $phase
        Index = $index
        ItemCount = $items.Count
        TransactionPath = $transaction
        AppRoot = $root
        InspectionOnly = $true
        Items = $items
        Warning = 'This report is diagnostic only. It does not restore, roll back, delete, or modify files.'
    }
    if ($AsJson) { $result | ConvertTo-Json -Depth 6 } else {
        Write-Output "Phase: $phase | Index: $index | Items: $($items.Count)"
        $items | Format-Table -AutoSize
        Write-Output $result.Warning
    }
    exit 0
}
catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 2
}
