#!/usr/bin/env python3
"""Static integrity checks for the IT VIP source tree (no Windows APIs or network)."""
from __future__ import annotations
import argparse
import datetime as dt
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

MODULES = {
    "scanner": "src/modules/scanner.cpp",
    "usb_guard": "src/modules/usb_guard.cpp",
    "tempclean": "src/modules/tempclean.cpp",
    "activator": "src/modules/activator.cpp",
    "pwrecover": "src/modules/pwrecover.cpp",
    "portable_manager": "src/modules/portable_manager.cpp",
    "security_center": "src/modules/security_center.cpp",
    "ai_assistant": "src/modules/ai_assistant.cpp",
    "github_hub": "src/modules/github_hub.cpp",
    "api_manager": "src/modules/api_manager.cpp",
    "agent_studio": "src/modules/agent_studio.cpp",
    "provider_hub": "src/modules/provider_hub.cpp",
    "provider_runtime": "src/modules/provider_runtime.cpp",
    "team_studio": "src/modules/team_studio.cpp",
    "team_runner": "src/modules/team_runner.cpp",
    "workflow_studio": "src/modules/workflow_studio.cpp",
    "workflow_runner": "src/modules/workflow_runner.cpp",
    "run_history": "src/modules/run_history.cpp",
    "memory_center": "src/modules/memory_center.cpp",
    "session_center": "src/modules/session_center.cpp",
    "backup_center": "src/modules/backup_center.cpp",
    "settings_center": "src/modules/settings_center.cpp",
    "permissions_center": "src/modules/permissions_center.cpp",
}
DOCS = ["README.md", "README_AR.md", "docs/ROADMAP.md", "docs/BUILD_STATUS.txt", "docs/TEAM_RUNNER.md", "docs/WORKFLOW_STUDIO.md", "docs/WORKFLOW_RUNNER.md", "docs/RUN_HISTORY.md", "docs/AGENT_MEMORY.md", "docs/CHAT_SESSION_HISTORY.md", "docs/BACKUP_RESTORE.md", "docs/BACKUP_CENTER.md", "docs/SETTINGS_CENTER.md", "docs/DEPLOYMENT_MANAGER.md", "docs/UPDATE_MANAGER.md", "docs/SECURITY_DIAGNOSTICS.md", "docs/HARDWARE_MANAGER.md", "docs/STARTUP_SERVICES_MANAGER.md", "docs/WINDOWS_REPAIR_CENTER.md", "docs/FIREWALL_PRIVACY_CENTER.md", "docs/EVENT_VIEWER_LOG_ANALYZER.md", "docs/SOFTWARE_INSTALLED_APPS_MANAGER.md", "docs/WINDOWS_UPDATE_MANAGER.md", "docs/PROJECT_AUDIT_v0.53.md", "docs/USER_PERMISSIONS_EDITION_BUILDER.md", "docs/USER_PROFILE_LIFECYCLE.md", "docs/ITVIP_LICENSE_SECURITY_AUTHORITY.md", "docs/CENTRAL_LICENSE_AUTHORITY.md", "docs/NATIVE_JSON_VALIDATION.md", "docs/NATIVE_JSON_FUZZING.md", "docs/PORTABLE_APPS_MANAGER.md", "docs/BILINGUAL_BRANDED_TOOL_GUI.md", "docs/SYSTEM_DIAGNOSTICS_CENTER.md", "docs/SYSTEM_DIAGNOSTICS_CENTER_AR.md"]

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--report", action="store_true", help="write a timestamped report under reports/")
    args = ap.parse_args()
    checks: list[tuple[str, bool, str]] = []
    def add(name: str, ok: bool, detail: str) -> None:
        checks.append((name, ok, detail))

    build = ROOT / "build.bat"
    main_cpp = ROOT / "src/app/main.cpp"
    add("build script exists", build.is_file(), str(build.relative_to(ROOT)))
    add("main GUI source exists", main_cpp.is_file(), str(main_cpp.relative_to(ROOT)))
    build_text = build.read_text(encoding="utf-8", errors="replace") if build.exists() else ""
    gui_text = main_cpp.read_text(encoding="utf-8", errors="replace") if main_cpp.exists() else ""

    for name, rel in MODULES.items():
        src = ROOT / rel
        add(f"source:{name}", src.is_file(), rel)
        base_loop = "for %%S in (scanner usb_guard tempclean activator pwrecover portable_manager security_center copy_manager)"
        explicit_target = f'"src\\modules\\{name}.cpp"' in build_text
        generic_target = name in base_loop and base_loop in build_text
        add(f"build-target:{name}", explicit_target or generic_target,
            f"expected source compile entry for {name}")
        gui_names = {"scanner":"scanner_gui", "usb_guard":"usb_guard_gui", "tempclean":"tempclean_gui", "activator":"activator_gui", "pwrecover":"pwrecover_gui", "security_center":"security_center_gui"}
        launch_name = gui_names.get(name, name)
        launcher_pattern = re.escape(f'launch(L"{launch_name}.exe"')
        add(f"launcher:{name}", re.search(launcher_pattern, gui_text) is not None,
            "dashboard launch reference (branded GUI where available)")

    tool_gui = ROOT / "src/app/branded_tool_gui.cpp"
    tool_gui_text = tool_gui.read_text(encoding="utf-8", errors="replace") if tool_gui.exists() else ""
    add("branded tool GUI source", tool_gui.is_file(), "src/app/branded_tool_gui.cpp")
    add("branded tool GUI bilingual setting", 'GetPrivateProfileStringW(L"Appearance",L"Language"' in tool_gui_text,
        "standalone GUI reads the shared persisted language")
    add("dashboard persists language", 'L"Language",arabic?L"ar":L"en"' in gui_text,
        "Arabic/English choice is saved to appearance.ini")
    add("six GUI build targets", all(f"{n}_gui" in build_text for n in ("scanner","usb_guard","tempclean","activator","pwrecover","security_center")),
        "MSVC and MinGW GUI target loops")
    add("tool GUI shared branding", "itvip::applyBranding(w" in tool_gui_text,
        "common IT VIP icon, dark theme and title bar")
    add("VIP Studio: responsive customizer window", "std::min(900,GetSystemMetrics(SM_CYSCREEN)-80)" in gui_text and "WS_VSCROLL" in gui_text,
        "customization window height adapts to the available desktop area")
    add("VIP Studio: mouse and scrollbar navigation", all(x in gui_text for x in ("case WM_VSCROLL", "case WM_MOUSEWHEEL", "scrollCustomizerTo", "updateCustomizerScroll")),
        "all customization controls remain reachable on shorter displays through wheel and scrollbar navigation")

    diagnostics_script = ROOT / "deployment/System-Diagnostics-ITVIP.ps1"
    diagnostics_launcher = ROOT / "deployment/System-Diagnostics-ITVIP.cmd"
    diagnostics_text = diagnostics_script.read_text(encoding="utf-8", errors="replace") if diagnostics_script.exists() else ""
    add("system diagnostics:threshold parameters", all(x in diagnostics_text for x in ("$CpuAlertPercent = 85", "$MemoryAlertPercent = 90", "$DiskFreeAlertPercent = 10")), "bounded CPU, RAM, and disk-free thresholds")
    add("system diagnostics:CPU and RAM alerts", "$cpuLoad -ge $CpuAlertPercent" in diagnostics_text and "$usedMemoryPercent -ge $MemoryAlertPercent" in diagnostics_text, "threshold crossings are collected per sample")
    add("system diagnostics:disk free alert", "$freePercent -le $DiskFreeAlertPercent" in diagnostics_text, "low free-space threshold is evaluated per fixed volume")
    add("system diagnostics:persistent bounded history", "system_diagnostics_history.csv" in diagnostics_text and "$allHistory.Count -gt 1000" in diagnostics_text, "local history retains at most 1,000 samples")
    add("system diagnostics:HTML alert summary", "$alertHtml" in diagnostics_text and "ConvertTo-Html" in diagnostics_text, "HTML report presents threshold status")
    add("system diagnostics:contract tests", (ROOT / "tests/test_system_diagnostics_contract.py").is_file(), "diagnostics parameter, alert, history, and report contracts")
    add("system diagnostics:launcher", diagnostics_launcher.is_file() and "System-Diagnostics-ITVIP.ps1" in diagnostics_launcher.read_text(encoding="utf-8", errors="replace"), "CMD launcher invokes the PowerShell workflow")
    add("system diagnostics:live mode bounds", "[switch]$LiveMonitoring" in diagnostics_text and "[ValidateRange(1,60)][int]$DurationMinutes = 5" in diagnostics_text and "$effectiveSamples = [math]::Min(3601" in diagnostics_text, "optional live sampling is bounded to 60 minutes and 3,601 samples")
    add("system diagnostics:network throughput deltas", "$rx - $prior.Rx" in diagnostics_text and "$tx - $prior.Tx" in diagnostics_text and "NetworkReceiveBytesPerSec" in diagnostics_text and "NetworkSendBytesPerSec" in diagnostics_text, "receive/send rates are estimated from cumulative counter deltas")
    add("system diagnostics:live status output", "LIVE {0}/{1}" in diagnostics_text and "LiveMonitoring=[bool]$LiveMonitoring" in diagnostics_text, "live status is visible and mode is recorded in report metadata")
    add("system diagnostics:live documentation", "Live monitoring and network rates" in (ROOT / "docs/SYSTEM_DIAGNOSTICS_CENTER.md").read_text(encoding="utf-8") and "المراقبة المباشرة" in (ROOT / "docs/SYSTEM_DIAGNOSTICS_CENTER_AR.md").read_text(encoding="utf-8"), "live mode and network-rate limitations are documented in both languages")

    for rel in DOCS:
        p = ROOT / rel
        add(f"documentation:{rel}", p.is_file(), rel)

    # Portable import must publish only complete copies and fail closed on unreadable entries.
    portable_text = (ROOT / "src/modules/portable_manager.cpp").read_text(encoding="utf-8", errors="replace")
    add("portable import:staging publish", "itvip_import_" in portable_text and "fs::rename(staging,dest,ec)" in portable_text, "copy to staging and publish only after successful completion")
    add("portable import:failure cleanup", "fs::remove_all(staging,cleanupEc)" in portable_text, "attempt cleanup of incomplete staging tree")
    add("portable import:no silent permission skip", "directory_options::skip_permission_denied" not in portable_text, "unreadable entries fail rather than silently disappear")
    add("portable import:copy size verification", "copiedSize!=z" in portable_text and "ctx.completed!=total||copied!=fileCount" in portable_text, "verify per-file size plus aggregate count and bytes")
    add("portable import:streaming SHA-256", "bool sha256File(" in portable_text and "BCRYPT_SHA256_ALGORITHM" in portable_text and "sourceHash!=copiedHash" in portable_text, "compare source and destination content using bounded-memory SHA-256")
    add("portable import:bounded hash memory", "std::array<char, 1024*1024> buffer" in portable_text, "hash files in fixed 1 MiB chunks")
    add("portable import:overflow-safe progress", "std::min<long double>" in portable_text, "wide intermediate avoids integer percentage overflow")
    add("portable manager:rename action", "ID_RENAME_FOLDER" in portable_text and "renameImportedFolder" in portable_text and "MoveFileExW" in portable_text, "rename selected imported folder without replacing an existing destination")
    add("portable manager:delete action", "ID_DELETE_FOLDER" in portable_text and "deleteImportedFolder" in portable_text and "fs::remove_all(folder,ec)" in portable_text, "explicitly confirmed deletion of selected imported folder")
    add("portable manager:path boundary", all(x in portable_text for x in ("portableCandidate", "rootCandidate", "fs::is_symlink", "canonicalFolder.parent_path()!=root", "pathWithin")), "reject symbolic-link roots and constrain operations to a direct child under portable/apps")
    add("portable manager:registered path updates", "app.path=stored_path(dest/rel)" in portable_text and "app.iconFile=stored_path(dest/rel)" in portable_text, "update registered executable and icon paths after folder rename")
    # Dedicated bidirectional fast-copy tool. Static checks only; Windows runtime is separate.
    copy_tool = ROOT / "src/modules/copy_manager.cpp"
    copy_text = copy_tool.read_text(encoding="utf-8", errors="replace") if copy_tool.exists() else ""
    add("fast copy:source present", copy_tool.is_file(), "dedicated Win32 copy utility source")
    add("fast copy:build target", "copy_manager" in build_text and "copy_manager" in build_text[build_text.find(":msvc"):build_text.find(":build_ai_msvc")] and "copy_manager" in build_text[build_text.find(":mingw"):build_text.find(":build_ai_mingw")], "included in MSVC and MinGW module build loops")
    add("fast copy:background worker", "std::thread g_worker" in copy_text and "std::thread(runCopy" in copy_text, "copy runs outside the UI thread")
    add("fast copy:cancel support", "CopyFileExW" in copy_text and "PROGRESS_CANCEL" in copy_text and "g_cancelRequested" in copy_text, "cancellable Windows streaming copy")
    add("fast copy:both directions", "اختر مجلد المصدر" in copy_text and "اختر مجلد الوجهة" in copy_text, "user can choose either USB or PC as source/destination")
    add("fast copy:no overwrite", "COPY_FILE_FAIL_IF_EXISTS" in copy_text and "fs::exists(job.destinationRoot" in copy_text, "refuses existing destination folder and files")
    add("fast copy:space preflight", "GetDiskFreeSpaceExW" in copy_text and "job.total>freeBytes.QuadPart" in copy_text, "checks free destination space before starting")
    add("fast copy:symlink exclusion", "fs::is_symlink(st)" in copy_text, "does not follow symbolic links")
    add("fast copy:partial cleanup", "fs::remove_all(job.destinationRoot,cleanup)" in copy_text, "best-effort cleanup after failure or cancellation")
    add("portable manager:fast copy launcher", "ID_FAST_COPY" in portable_text and "copy_manager.exe" in portable_text, "Portable Apps Manager launches dedicated copy utility")

    # Shared IT VIP visual identity: every existing standalone GUI entry point
    # must use the same runtime layer; CLI-only tools are documented separately.
    brand_header = ROOT / "src/app/itvip_branding.hpp"
    brand_text = brand_header.read_text(encoding="utf-8", errors="replace") if brand_header.exists() else ""
    gui_sources = [p for p in (ROOT / "src/modules").glob("*.cpp") if "int WINAPI wWinMain" in p.read_text(encoding="utf-8", errors="replace")]
    gui_sources.append(ROOT / "src/app/main.cpp")
    branded_gui = [p for p in gui_sources if "itvip::applyBranding(w,h)" in p.read_text(encoding="utf-8", errors="replace")]
    add("branding:shared helper", brand_header.is_file() and all(x in brand_text for x in ("SetWindowSubclass", "WM_CTLCOLORSTATIC", "DwmSetWindowAttribute", "itvip.ico")), "shared dark Win32 palette, DWM title bar, and icon loader")
    add("branding:all GUI entry points", len(gui_sources) == len(branded_gui), f"all {len(gui_sources)} existing standalone GUI entry points call the shared branding layer")
    add("branding:icon artwork", (ROOT / "assets/itvip.ico").is_file() and (ROOT / "assets/branding/itvip_app_icon_512.png").is_file(), "multi-resolution ICO and high-resolution crowned-V master artwork")
    add("branding:embedded build icon", "itvip_icon.res" in build_text and "IDI_ITVIP ICON" in (ROOT / "assets/itvip_icon.rc").read_text(encoding="utf-8"), "MSVC resource and MinGW manifest resource embed the common icon")
    add("branding:GUI subsystem", all(x in build_text for x in ('set "SUBSYSTEM=WINDOWS"', 'set "MINGW_SUBSYSTEM=windows"')), "Portable Apps Manager and Fast Copy are linked as Windows GUI applications")

    tool_gui = ROOT / "src/app/branded_tool_gui.cpp"
    tool_gui_text = tool_gui.read_text(encoding="utf-8", errors="replace") if tool_gui.exists() else ""
    add("tool-gui:dedicated heading control", "gHeading=CreateWindowW(L\"STATIC\"" in tool_gui_text and "label(gHeading," in tool_gui_text, "module name updates the visible heading rather than replacing the window caption")
    add("tool-gui:Windows argument quoting", "std::wstring quoteArg(" in tool_gui_text and "out.append(slashes*2+1" in tool_gui_text and "slashes=0;continue;" in tool_gui_text, "paths and user-supplied account names are quoted as individual Windows argv values")
    add("tool-gui:engine regular-file check", "!fs::is_regular_file(p)" in tool_gui_text, "engine launch rejects missing paths and non-regular files")
    add("tool-gui:redirected engine output", all(x in tool_gui_text for x in ("CreatePipe(&readPipe,&writePipe", "STARTF_USESTDHANDLES", "si.hStdOutput=writePipe", "si.hStdError=writePipe")), "engine stdout and stderr are redirected to an anonymous pipe")
    add("tool-gui:background worker", "gWorker=std::thread([readPipe,process,target]" in tool_gui_text and "ReadFile(readPipe" in tool_gui_text, "pipe output is consumed asynchronously without blocking the Win32 message loop")
    add("tool-gui:in-window output", all(x in tool_gui_text for x in ("gOutput=CreateWindowExW", "WM_ITVIP_OUTPUT", "appendOutput(*part)")), "captured engine output is appended to the read-only GUI log")
    add("tool-gui:process cancellation", "TerminateProcess(gProcess,ERROR_CANCELLED)" in tool_gui_text and "gStop=CreateWindowW" in tool_gui_text, "user can request cancellation of the active engine process")
    add("tool-gui:completion status", "WM_ITVIP_FINISHED" in tool_gui_text and "GetExitCodeProcess(process,&code)" in tool_gui_text, "completion reports the actual process exit code")
    add("tool-gui:marquee progress", "PBS_MARQUEE" in tool_gui_text and "ICC_PROGRESS_CLASS" in tool_gui_text, "indeterminate progress is shown while an engine is active")
    add("tool-gui:MinGW thread runtime", "-pthread" in build_text, "MinGW branded front-ends link the threading runtime")

    # System Diagnostics Center: bounded read-only hardware/performance sampling and reports.
    sysdiag = ROOT / "deployment/System-Diagnostics-ITVIP.ps1"
    sysdiag_text = sysdiag.read_text(encoding="utf-8", errors="replace") if sysdiag.exists() else ""
    sysdiag_cmd = ROOT / "deployment/System-Diagnostics-ITVIP.cmd"
    sysdiag_cmd_text = sysdiag_cmd.read_text(encoding="utf-8", errors="replace") if sysdiag_cmd.exists() else ""
    add("system-diagnostics:PowerShell source", sysdiag.is_file(), "deployment/System-Diagnostics-ITVIP.ps1")
    add("system-diagnostics:launcher", sysdiag_cmd.is_file() and "System-Diagnostics-ITVIP.ps1" in sysdiag_cmd_text and "%*" in sysdiag_cmd_text, "CMD launcher forwards bounded sampling options")
    add("system-diagnostics:bounded sampling", "[ValidateRange(1,30)][int]$Samples = 5" in sysdiag_text and "[ValidateRange(1,10)][int]$IntervalSeconds = 2" in sysdiag_text, "sample count and interval are constrained")
    add("system-diagnostics:CPU and memory", all(x in sysdiag_text for x in ("Win32_Processor", "Win32_OperatingSystem", "CpuLoadPercent", "MemoryUsedPercent")), "CPU load and physical memory inventory/samples")
    add("system-diagnostics:storage and network", all(x in sysdiag_text for x in ("Win32_LogicalDisk", "Get-NetAdapter -Physical", "Get-NetAdapterStatistics")), "fixed-volume capacity and active physical adapter counters")
    add("system-diagnostics:optional thermal", "MSAcpi_ThermalZoneTemperature" in sysdiag_text and "ThermalZones" in sysdiag_text, "thermal values only when the ACPI provider exposes them")
    add("system-diagnostics:report formats", all(x in sysdiag_text for x in ("ConvertTo-Json", "ConvertTo-Html", "Export-Csv", "itvip_system_diagnostics_")), "timestamped JSON, HTML, TXT, and CSV output")
    add("system-diagnostics:read-only boundary", "ReadOnly=$true" in sysdiag_text and "No settings, services, processes, drivers, disks, or network configuration were changed." in sysdiag_text, "no repair or configuration mutation")

    # Native live monitor is integrated into the dashboard and both Windows build paths.
    monitor_src = ROOT / "src/modules/system_monitor_gui.cpp"
    monitor_text = monitor_src.read_text(encoding="utf-8", errors="replace") if monitor_src.exists() else ""
    add("system-monitor:native GUI source", monitor_src.is_file(), "src/modules/system_monitor_gui.cpp")
    add("system-monitor:live sampling", all(x in monitor_text for x in ("GetSystemTimes", "GlobalMemoryStatusEx", "GetIfTable2", "GetDiskFreeSpaceExW")), "CPU, RAM, active network adapter and system-volume sampling")
    add("system-monitor:bounded graph history", "gHistory.size()>90" in monitor_text and "drawGraph" in monitor_text, "in-memory chart history is capped at 90 samples")
    add("system-monitor:controls and pause", all(x in monitor_text for x in ("ID_START", "ID_PAUSE", "ID_STOP", "gPaused")), "start, pause/resume, stop and duration controls")
    add("system-monitor:CSV history", "system_monitor_live.csv" in monitor_text and "timestamp,cpu_percent,ram_percent" in monitor_text, "local live samples are appended to reports CSV")
    add("system-monitor:read-only scope", "GetIfTable2" in monitor_text and "GetDiskFreeSpaceExW" in monitor_text and "TerminateProcess" not in monitor_text, "monitor performs read-only system counter queries")
    main_text = (ROOT / "src/app/main.cpp").read_text(encoding="utf-8", errors="replace")
    build_text = (ROOT / "build.bat").read_text(encoding="utf-8", errors="replace")
    verifier_text = (ROOT / "tools/verify_windows_build.ps1").read_text(encoding="utf-8", errors="replace")
    add("system-monitor:dashboard integration", "ID_SYSTEM_MONITOR" in main_text and "system_monitor_gui.exe" in main_text and "system_monitor" in main_text, "new bilingual Dashboard action launches the monitor")
    add("system-monitor:MSVC and MinGW targets", all(x in build_text for x in (":build_system_monitor_msvc", ":build_system_monitor_mingw", "call :build_system_monitor_msvc", "call :build_system_monitor_mingw")), "dedicated executable is included in both build paths")
    add("system-monitor:build verification", "system_monitor_gui.exe" in verifier_text, "Windows build verifier requires the monitor executable")
    edition_builder_text = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8", errors="replace")
    owner_text = (ROOT / "src/modules/permissions_center.cpp").read_text(encoding="utf-8", errors="replace")
    add("system-monitor:user-edition capability", "system_monitor=@{Exe='system_monitor_gui.exe'}" in edition_builder_text and "system_monitor" in owner_text, "owner capability profile and user-edition builder include the monitor executable")

    # Configuration files are data only; do not require user-created profiles to exist.
    for rel in ("config", "assets", "portable", "docs", "src/modules"):
        p = ROOT / rel
        add(f"directory:{rel}", p.is_dir(), rel)

    # Owner-controlled per-user capability profiles and edition packaging.
    permissions = ROOT / "src/modules/permissions_center.cpp"
    permissions_text = permissions.read_text(encoding="utf-8", errors="replace") if permissions.exists() else ""
    edition = ROOT / "deployment/Build-UserEdition.ps1"
    edition_text = edition.read_text(encoding="utf-8", errors="replace") if edition.exists() else ""
    add("permissions:owner console source", permissions.is_file() and "ITVIPPermissionsOwnerConsole" in permissions_text, "native owner GUI for per-user capability selection")
    profile_keys = set(re.findall(r'\{L"([a-z_]+)",L"', permissions_text))
    builder_keys = set(re.findall(r'([a-z_]+)=@\{', edition_text))
    command_map = gui_text[gui_text.find("const wchar_t* commandFeatureKey"):gui_text.find("void applyVisibility(HWND w){")]
    command_keys = set(re.findall(r'return L"([a-z_]+)";', command_map))
    add("permissions:feature catalog", len(profile_keys) == 36 and profile_keys.issubset(builder_keys) and profile_keys.issubset(command_keys), f"profile={len(profile_keys)}, builder={len(builder_keys)}, dashboard mappings={len(command_keys)}")
    add("command-center:dashboard integration", all(x in gui_text for x in ("ID_COMMAND_CENTER", "showCommandCenter()", "command_center")), "bilingual dashboard entry and capability mapping")
    command_center_doc = ROOT / "docs/COMMAND_CENTER.md"
    add("command-center:observational UI", all(x in gui_text for x in ("LVS_REPORT", "ID_CMD_SEARCH", "ID_CMD_FILTER", "exportCommandHistory")) and command_center_doc.is_file(), "live process view, search/filter, CSV export, and documented non-intervention boundary")
    add("command-center:permission catalog", "command_center" in permissions_text and "command_center=@{}" in edition_text, "owner profiles and exported editions can explicitly grant or deny the dashboard view")
    add("permissions:profile persistence", "profiles" in permissions_text and "WritePrivateProfileStringW" in permissions_text, "named INI profiles saved separately from owner's active policy")
    add("permissions:edition export UI", "Build-UserEdition.ps1" in permissions_text and "SHBrowseForFolderW" in permissions_text, "owner selects an output folder to export a user edition")
    add("permissions:build targets", ":build_permissions_msvc" in build_text and ":build_permissions_mingw" in build_text, "owner console has MSVC and MinGW build targets")
    add("permissions:dashboard enforcement", "featureAllowed" in gui_text and "commandFeatureKey" in gui_text and "OwnerMode" in gui_text, "dashboard hides and blocks disabled capabilities")
    add("permissions:dashboard entry", "ID_PERMISSIONS_CENTER" in gui_text and "permissions_center.exe" in gui_text and "const int ids[]={ID_AI_ASSISTANT" in gui_text, "owner console entry point and AI feature visibility gate")
    add("permissions:edition script", edition.is_file() and "ITVIP-USER-EDITION-2" in edition_text, "runtime edition builder with manifest")
    add("permissions:component omission", "if(-not $selected[$key]){continue}" in edition_text and "Required executable" in edition_text, "ungranted executables and launchers are omitted; missing granted components fail")
    add("permissions:strict profile validation", "Unsupported permission profile schema" in edition_text and "Missing or invalid permission value" in edition_text and "Only owner-created profiles" in edition_text, "schema, owner marker, and every capability bit must validate")
    add("permissions:output boundary", "Output must be outside the source project tree" in edition_text and "Output already exists" in edition_text, "no overwrite and no output inside source tree")
    add("permissions:integrity manifest", "Get-FileHash" in edition_text and "EDITION_SHA256.json" in edition_text, "SHA-256 manifest for exported runtime files")
    add("permissions:owner console excluded", "permissions_center.exe" not in edition_text and "OwnerMode=0" in edition_text and "Start-ITVIP.cmd" in edition_text, "user edition omits owner console and gets a root-relative launcher")
    add("permissions:build docs", (ROOT / "docs/USER_PERMISSIONS_EDITION_BUILDER.md").is_file(), "owner workflow, security limits, and deployment documented")
    add("permissions:profile manager UI", all(x in permissions_text for x in ("Manage users", "Load to edit", "Revoke access", "Delete profile", "New profile")), "owner can list, load, revoke, delete, and create profiles")
    add("permissions:profile revision metadata", all(x in permissions_text for x in ("Revision", "UpdatedUtc", "PROFILE_SAVED")), "profile revisions and UTC modification timestamps")
    add("permissions:revocation", all(x in permissions_text for x in ("PROFILE_REVOKED", "Status", "Revoked", "All 36 capabilities set to 0")), "revocation clears all grants and records an audit event")
    add("permissions:audit trail", all(x in permissions_text for x in ("permissions_audit.csv", "PROFILE_DELETED", "EDITION_EXPORT_REQUESTED")), "local append-only-style audit records for owner actions")
    add("permissions:profile path restriction", "Selected profile is outside the profiles folder" in permissions_text and "Select a profile from the profiles folder only" in permissions_text, "profile loading and editing restricted to owner profiles directory")
    add("permissions:revoked export blocked", "This permission profile is revoked or inactive" in edition_text and "ProfileRevision" in edition_text, "builder rejects revoked profiles and records revision in edition manifest")
    add("permissions:lifecycle documentation", (ROOT / "docs/USER_PROFILE_LIFECYCLE.md").is_file(), "create, edit, revoke, delete, audit and reissue workflow documented")

    # Native CNG verifier and bootstrap integration.
    native_verifier = ROOT / "src/app/license_native_verifier.cpp"
    native_text = native_verifier.read_text(encoding="utf-8", errors="replace") if native_verifier.exists() else ""
    bootstrap_text = (ROOT / "src/app/license_bootstrapper.cpp").read_text(encoding="utf-8", errors="replace")
    builder_text = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8", errors="replace")
    add("license-native:source", native_verifier.is_file(), "C++ native verifier source")
    add("license-native:CNG RSA", all(x in native_text for x in ("BCryptImportKeyPair", "BCryptVerifySignature", "BCRYPT_RSA_ALGORITHM", "BCRYPT_SHA256_ALGORITHM")), "RSA PKCS#1 SHA-256 verification through Windows CNG")
    add("license-native:signed inventory", all(x in native_text for x in ("EDITION_SHA256.json", "checkInventory", "SHA-256 mismatch", "EDITION_SIGNATURE.sha256rsa")), "native verifier checks signed file inventory")
    add("license-native:revocation signature", "EDITION_REVOCATIONS.sha256rsa" in native_text and "ITVIP-REVOCATIONS-1" in native_text, "native verifier validates signed revocation snapshot")
    add("license-native:bootstrap gate", "ITVIPNativeVerify.exe" in bootstrap_text and "nativeExit != 0" in bootstrap_text, "dashboard launch is blocked if native verification fails")
    add("license-native:edition packaging", "ITVIPNativeVerify.exe" in builder_text and "build/ITVIPNativeVerify.exe" in builder_text, "CNG verifier included in exported user edition")
    add("license-native:MSVC and MinGW", all(x in build_text for x in (":build_native_verifier_msvc", ":build_native_verifier_mingw", "license_native_verifier.cpp", "-lbcrypt -lcrypt32")), "native verifier build targets")

    # Branding regression check: exclude this validator and historical notes by checking shipped primary files.
    brand_files = [ROOT / "README.md", ROOT / "README_AR.md", main_cpp]
    stale = []
    for p in brand_files:
        if p.exists() and re.search(r"\bVEXA\s+IT\b", p.read_text(encoding="utf-8", errors="replace"), re.I):
            stale.append(str(p.relative_to(ROOT)))
    add("branding:IT VIP only", not stale, ", ".join(stale) if stale else "no legacy brand in primary files")
    add("workflow:dashboard command", "ID_WORKFLOW_STUDIO" in gui_text and "workflow_studio.exe" in gui_text, "workflow studio launcher and command")
    add("workflow:MSVC target", ":build_workflow_msvc" in build_text and "workflow_studio.cpp" in build_text, "MSVC compile target")
    add("workflow:MinGW target", ":build_workflow_mingw" in build_text and "workflow_studio.cpp" in build_text, "MinGW compile target")
    add("workflow-runner:dashboard command", "ID_WORKFLOW_RUNNER" in gui_text and "workflow_runner.exe" in gui_text, "workflow runner launcher and command")
    add("workflow-runner:MSVC target", ":build_workflow_runner_msvc" in build_text and "workflow_runner.cpp" in build_text, "MSVC compile target")
    add("workflow-runner:MinGW target", ":build_workflow_runner_mingw" in build_text and "workflow_runner.cpp" in build_text, "MinGW compile target")
    runner = ROOT / "src/modules/workflow_runner.cpp"
    runner_text = runner.read_text(encoding="utf-8", errors="replace") if runner.exists() else ""
    add("workflow-runner:approval gate", "RequireApproval" in runner_text and "Approve Workflow Run" in runner_text, "approval required before dispatch when configured")
    add("workflow-runner:ordered hand-off", "PREVIOUS WORKFLOW CONTEXT" in runner_text and "StopOnFailure" in runner_text, "previous Agent output hand-off and stop-on-failure policy")
    add("workflow-runner:report output", "workflow_run_" in runner_text and "reports" in runner_text, "timestamped workflow reports")
    add("history:dashboard command", "ID_RUN_HISTORY" in gui_text and "run_history.exe" in gui_text, "execution history launcher and command")
    add("history:MSVC target", ":build_history_msvc" in build_text and "run_history.cpp" in build_text, "MSVC compile target")
    add("history:MinGW target", ":build_history_mingw" in build_text and "run_history.cpp" in build_text, "MinGW compile target")
    history = ROOT / "src/modules/run_history.cpp"
    history_text = history.read_text(encoding="utf-8", errors="replace") if history.exists() else ""
    add("history:report allowlist", "workflow_run_" in history_text and "team_run_" in history_text and "project_validation_" in history_text, "only known report filename prefixes are listed")
    add("history:delete confirmation", "Delete this local report permanently?" in history_text, "explicit confirmation before deletion")
    memory = ROOT / "src/modules/memory_center.cpp"
    memory_text = memory.read_text(encoding="utf-8", errors="replace") if memory.exists() else ""
    add("memory:dashboard command", "ID_MEMORY_CENTER" in gui_text and "memory_center.exe" in gui_text, "Agent Memory Vault launcher and command")
    add("memory:MSVC target", ":build_memory_msvc" in build_text and "memory_center.cpp" in build_text, "MSVC compile target")
    add("memory:MinGW target", ":build_memory_mingw" in build_text and "memory_center.cpp" in build_text, "MinGW compile target")
    add("memory:versioned local store", "ITVIPMEM1" in memory_text and "data" in memory_text and "memory.v1" in memory_text, "versioned local-only storage format")
    add("memory:bounded fields", "262144" in memory_text and "256" in memory_text, "content and metadata size limits")
    add("memory:no automatic provider dispatch", "No provider request was made" in memory_text and "sent to AI automatically" in memory_text, "manual local vault; no provider dispatch")
    add("memory:delete confirmation", "Delete this memory record permanently?" in memory_text, "explicit confirmation before deletion")
    settings = ROOT / "src/modules/settings_center.cpp"
    settings_text = settings.read_text(encoding="utf-8", errors="replace") if settings.exists() else ""
    add("settings:dashboard command", "ID_SETTINGS_CENTER" in gui_text and "settings_center.exe" in gui_text, "settings center launcher and command")
    add("settings:MSVC target", ":build_settings_msvc" in build_text and "settings_center.cpp" in build_text, "MSVC compile target")
    add("settings:MinGW target", ":build_settings_mingw" in build_text and "settings_center.cpp" in build_text, "MinGW compile target")
    add("settings:folder validation", "validate()" in settings_text and "config" in settings_text and "reports" in settings_text, "core project folders and config files are inspected")
    add("settings:safe folder creation", "create_directories" in settings_text and "Create missing folders" in settings_text, "only standard project folders are created")
    add("settings:export credential exclusion", "Credential Manager secrets were not exported" in settings_text, "export excludes Windows Credential Manager secrets")
    add("settings:appearance backup", ".before-defaults-" in settings_text and "copy_file" in settings_text, "appearance file is backed up before reset")
    add("settings:reset confirmation", "Restore only the dashboard appearance defaults?" in settings_text, "appearance reset requires explicit confirmation")
    runtime = ROOT / "src/modules/provider_runtime.cpp"
    runtime_text = runtime.read_text(encoding="utf-8", errors="replace") if runtime.exists() else ""
    session = ROOT / "src/modules/session_center.cpp"
    session_text = session.read_text(encoding="utf-8", errors="replace") if session.exists() else ""
    add("sessions:dashboard command", "ID_SESSION_CENTER" in gui_text and "session_center.exe" in gui_text, "chat history launcher and command")
    add("sessions:MSVC target", ":build_session_msvc" in build_text and "session_center.cpp" in build_text, "MSVC compile target")
    add("sessions:MinGW target", ":build_session_mingw" in build_text and "session_center.cpp" in build_text, "MinGW compile target")
    add("sessions:runtime persistence", "appendArchive" in runtime_text and "ITVIPCHAT1" in runtime_text, "successful provider exchanges persisted in versioned local format")
    add("sessions:failure exclusion", "bool archived=appendArchive(x->provider,x->prompt,x->text)" in runtime_text, "failed provider requests are not persisted")
    add("sessions:archive isolation", "Older archived turns are not automatically sent" in (ROOT / "docs/CHAT_SESSION_HISTORY.md").read_text(encoding="utf-8"), "only active-session context is reused")
    add("sessions:search and preview", "hay.find(q)" in session_text and "display()" in session_text, "local text filtering and preview")
    add("sessions:export", "exportSelected" in session_text and "GetSaveFileNameW" in session_text, "selected conversation export")
    add("sessions:delete confirmation", "Delete this conversation turn permanently?" in session_text, "explicit confirmation before deletion")
    backup = ROOT / "src/modules/backup_center.cpp"
    backup_text = backup.read_text(encoding="utf-8", errors="replace") if backup.exists() else ""
    add("backup:dashboard command", "ID_BACKUP_CENTER" in gui_text and "backup_center.exe" in gui_text, "backup center launcher and command")
    add("backup:MSVC target", ":build_backup_msvc" in build_text and "backup_center.cpp" in build_text and "bcrypt.lib shell32.lib ole32.lib" in build_text, "MSVC target with SHA-256 and Shell APIs")
    add("backup:MinGW target", ":build_backup_mingw" in build_text and "backup_center.cpp" in build_text and "-lbcrypt -lshell32 -lole32" in build_text, "MinGW target with SHA-256 and Shell APIs")
    add("backup:versioned manifest", "ITVIP_BACKUP_V1" in backup_text and "validManifest" in backup_text, "versioned manifest is validated before restore")
    add("backup:approved folders", all(("L\"" + x + "\"") in backup_text for x in ("config", "data", "assets", "portable", "reports")), "only approved user-data folders are copied")
    add("backup:credential exclusion", "Credential Manager" in backup_text and "not" in backup_text, "Windows Credential Manager secrets are outside the backup")
    add("backup:restore confirmation", "Confirm IT VIP Restore" in backup_text, "explicit confirmation before overwrite")
    add("backup:destination boundary", "Choose a backup destination outside" in backup_text and "inside(destination,app)" in backup_text, "backup destination must be outside application tree")
    add("backup:SHA-256 integrity", "BCRYPT_SHA256_ALGORITHM" in backup_text and "actual!=digest" in backup_text, "manifest file hashes are checked before restore")
    add("backup:symlink exclusion", "fs::is_symlink(st)" in backup_text, "symbolic links are not followed")

    deploy = ROOT / "deployment/Deploy-ITVIP.ps1"
    deploy_text = deploy.read_text(encoding="utf-8", errors="replace") if deploy.exists() else ""
    launcher = ROOT / "deployment/Start-ITVIP.cmd"
    launcher_text = launcher.read_text(encoding="utf-8", errors="replace") if launcher.exists() else ""
    add("deployment:script exists", deploy.is_file(), "PowerShell preflight/package/verify script")
    add("deployment:required binaries", all((x + ".exe") in deploy_text for x in ("ITVIP", "scanner", "provider_runtime", "workflow_runner", "settings_center", "permissions_center", "copy_manager", "system_monitor_gui")), "portable packager requires complete app and module binaries")
    add("deployment:preflight action", "'Preflight'" in deploy_text and "Get-Preflight" in deploy_text, "OS and required executable preflight")
    add("deployment:portable packaging", "'PackagePortable'" in deploy_text and "New-PortablePackage" in deploy_text, "portable folder packaging action")
    add("deployment:hash manifest", "Get-FileHash" in deploy_text and "PACKAGE_SHA256.txt" in deploy_text, "SHA-256 package manifest generation and verification")
    add("deployment:no overwrite", "Output already exists" in deploy_text, "existing package destinations are not overwritten")
    add("deployment:no source-tree output", "Choose an output directory outside the source project folder" in deploy_text, "package destination must be outside source tree")
    add("deployment:manual launcher", launcher.is_file() and 'start "IT VIP"' in launcher_text, "manual launcher; no autorun")

    runtime = ROOT / "src/modules/provider_runtime.cpp"
    runtime_text = runtime.read_text(encoding="utf-8", errors="replace") if runtime.exists() else ""
    session = ROOT / "src/modules/session_center.cpp"
    session_text = session.read_text(encoding="utf-8", errors="replace") if session.exists() else ""
    add("sessions:runtime active store", "ITVIPACTIVE2" in runtime_text and "current.session" in runtime_text, "versioned active session storage")
    add("sessions:provider isolation", "activeProvider!=p" in runtime_text and "جلسة جديدة لهذا المزود" in runtime_text, "switching provider requires a new active context")
    add("sessions:bounded context", "prior.size()>12" in runtime_text, "only the latest 12 active turns are sent as context")
    add("sessions:shared archive schema", "ITVIPCHAT1" in runtime_text and "chat.v1" in runtime_text and "appendArchive" in runtime_text, "successful turns appended in shared Session Center format")
    add("sessions:archive viewer", "ITVIPCHAT1" in session_text and "chat.v1" in session_text, "Session Center reads the runtime archive")
    add("sessions:export and delete", "exportSelected" in session_text and "deleteSelected" in session_text and "Delete this conversation turn permanently?" in session_text, "archive export and confirmed deletion")
    updater = ROOT / "deployment/Update-ITVIP.ps1"
    updater_text = updater.read_text(encoding="utf-8", errors="replace") if updater.exists() else ""
    updater_cmd = ROOT / "deployment/Update-ITVIP.cmd"
    updater_cmd_text = updater_cmd.read_text(encoding="utf-8", errors="replace") if updater_cmd.exists() else ""
    add("update:script exists", updater.is_file(), "manual local-package updater")
    add("update:launcher exists", updater_cmd.is_file() and "Update-ITVIP.ps1" in updater_cmd_text, "interactive CMD launcher")
    add("update:manifest schema", "ITVIP-UPDATE-1" in updater_text and "ITVIP_UPDATE.json" in updater_text, "versioned package manifest")
    add("update:sha256 verification", "Get-FileHash" in updater_text and "SHA-256 mismatch" in updater_text, "package integrity validation")
    add("update:path allowlist", "AllowedRoots" in updater_text and "Get-SafeRelativePath" in updater_text, "only approved runtime paths can be updated")
    add("update:stage before apply", "StageUpdate" in updater_text and "No application files have been changed yet" in updater_text, "verified staging is separate from installation")
    add("update:backup and rollback", "data\\update-backups" in updater_text and "RollbackLatest" in updater_text and "ROLLBACK.json" in updater_text, "pre-update backups and rollback path")
    add("update:explicit apply confirmation", "Type APPLY to continue" in updater_text, "typed confirmation before replacement")
    add("update:no auto download", "NetworkDownload='Disabled'" in updater_text and "does not contact a server" in (ROOT / "docs/UPDATE_MANAGER.md").read_text(encoding="utf-8"), "no unattended network updater")
    add("update:dashboard launcher", "ID_UPDATE_MANAGER" in gui_text and "Update-ITVIP.cmd" in gui_text, "dashboard opens the update manager")
    diagnostics = ROOT / "deployment/Diagnostics-ITVIP.ps1"
    diagnostics_text = diagnostics.read_text(encoding="utf-8", errors="replace") if diagnostics.exists() else ""
    diagnostics_cmd = ROOT / "deployment/Diagnostics-ITVIP.cmd"
    diagnostics_cmd_text = diagnostics_cmd.read_text(encoding="utf-8", errors="replace") if diagnostics_cmd.exists() else ""
    diagnostics_doc = ROOT / "docs/SECURITY_DIAGNOSTICS.md"
    diagnostics_doc_text = diagnostics_doc.read_text(encoding="utf-8", errors="replace") if diagnostics_doc.exists() else ""
    add("diagnostics:script exists", diagnostics.is_file(), "read-only Windows diagnostics script")
    add("diagnostics:launcher exists", diagnostics_cmd.is_file() and "Diagnostics-ITVIP.ps1" in diagnostics_cmd_text, "CMD launcher")
    add("diagnostics:project checks", "requiredModules" in diagnostics_text and "Build output" in diagnostics_text, "checks source modules and executable presence")
    add("diagnostics:security checks", "Get-MpComputerStatus" in diagnostics_text and "Get-NetFirewallProfile" in diagnostics_text and "Confirm-SecureBootUEFI" in diagnostics_text, "Defender, Firewall, and Secure Boot status when available")
    add("diagnostics:read-only", "$summary = [ordered]@" in diagnostics_text and "ReadOnly=$true" in diagnostics_text and "No settings were changed" in diagnostics_text, "no repair or configuration writes")
    add("diagnostics:reports", "itvip_diagnostics_$stamp.json" in diagnostics_text and "itvip_diagnostics_$stamp.txt" in diagnostics_text, "timestamped JSON and TXT reports")
    add("diagnostics:dashboard launcher", "ID_DIAGNOSTICS" in gui_text and "Diagnostics-ITVIP.cmd" in gui_text, "dashboard opens diagnostics center")
    add("diagnostics:documentation", diagnostics_doc.is_file() and "read-only" in diagnostics_doc_text.lower(), "scope and limitations documented")

    hardware = ROOT / "deployment/Hardware-ITVIP.ps1"
    hardware_text = hardware.read_text(encoding="utf-8", errors="replace") if hardware.exists() else ""
    hardware_cmd = ROOT / "deployment/Hardware-ITVIP.cmd"
    hardware_cmd_text = hardware_cmd.read_text(encoding="utf-8", errors="replace") if hardware_cmd.exists() else ""
    hardware_doc = ROOT / "docs/HARDWARE_MANAGER.md"
    hardware_doc_text = hardware_doc.read_text(encoding="utf-8", errors="replace") if hardware_doc.exists() else ""
    add("hardware:script exists", hardware.is_file(), "PowerShell hardware inventory")
    add("hardware:launcher exists", hardware_cmd.is_file() and "Hardware-ITVIP.ps1" in hardware_cmd_text, "CMD launcher")
    add("hardware:device inventory", all(x in hardware_text for x in ("Win32_PnPEntity", "ConfigManagerErrorCode", "PNPDeviceID")), "PnP inventory and problem codes")
    add("hardware:component inventory", all(x in hardware_text for x in ("Win32_Processor", "Win32_VideoController", "Win32_DiskDrive", "Win32_NetworkAdapter")), "CPU, display, disk and network queries")
    add("hardware:signed driver option", "Win32_PnPSignedDriver" in hardware_text and "IncludeSignedDriverInventory" in hardware_text, "optional signed driver inventory")
    add("hardware:reports", all(x in hardware_text for x in ("itvip_hardware_$stamp.json", "itvip_hardware_$stamp.txt", "itvip_devices_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("hardware:read-only", "ReadOnly=$true" in hardware_text and "No driver changes were made" in hardware_text, "inventory only; no driver modifications")
    add("hardware:dashboard integration", "ID_HARDWARE_MANAGER" in gui_text and "Hardware-ITVIP.cmd" in gui_text, "dashboard command and launcher")
    add("hardware:documentation", hardware_doc.is_file() and "read-only" in hardware_doc_text.lower(), "scope and limitations documented")

    network = ROOT / "deployment/Network-ITVIP.ps1"
    network_text = network.read_text(encoding="utf-8", errors="replace") if network.exists() else ""
    network_cmd = ROOT / "deployment/Network-ITVIP.cmd"
    network_cmd_text = network_cmd.read_text(encoding="utf-8", errors="replace") if network_cmd.exists() else ""
    network_doc = ROOT / "docs/NETWORK_MANAGER.md"
    network_doc_text = network_doc.read_text(encoding="utf-8", errors="replace") if network_doc.exists() else ""
    add("network:script exists", network.is_file(), "read-only PowerShell network inventory")
    add("network:launcher exists", network_cmd.is_file() and "Network-ITVIP.ps1" in network_cmd_text, "CMD launcher")
    add("network:adapter inventory", all(x in network_text for x in ("Get-NetAdapter", "Get-NetIPConfiguration", "Get-NetAdapterStatistics")), "adapter, IP and statistics queries")
    add("network:local listeners only", "Get-NetTCPConnection -State Listen" in network_text and "local listeners only" in network_text.lower(), "local listening sockets; no remote scan")
    add("network:connectivity checks", all(x in network_text for x in ("Test-Connection", "Resolve-DnsName", "example.com")), "gateway/public IP ICMP and DNS diagnostics")
    add("network:reports", all(x in network_text for x in ("itvip_network_$stamp.json", "itvip_network_$stamp.txt", "itvip_network_adapters_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("network:read-only", "ReadOnly=$true" in network_text and "No network settings, firewall rules, or adapters were changed." in network_text, "no network configuration changes")
    add("network:dashboard integration", "ID_NETWORK_MANAGER" in gui_text and "Network-ITVIP.cmd" in gui_text, "dashboard command and launcher")
    add("network:documentation", network_doc.is_file() and "read-only" in network_doc_text.lower(), "scope and limitations documented")

    performance = ROOT / "deployment/Performance-ITVIP.ps1"
    performance_text = performance.read_text(encoding="utf-8", errors="replace") if performance.exists() else ""
    performance_cmd = ROOT / "deployment/Performance-ITVIP.cmd"
    performance_cmd_text = performance_cmd.read_text(encoding="utf-8", errors="replace") if performance_cmd.exists() else ""
    performance_doc = ROOT / "docs/PERFORMANCE_MANAGER.md"
    performance_doc_text = performance_doc.read_text(encoding="utf-8", errors="replace") if performance_doc.exists() else ""
    add("performance:script exists", performance.is_file(), "process and performance PowerShell manager")
    add("performance:launcher exists", performance_cmd.is_file() and "Performance-ITVIP.ps1" in performance_cmd_text, "interactive CMD launcher")
    add("performance:inventory", all(x in performance_text for x in ("Get-Process", "Win32_Processor", "Win32_OperatingSystem", "Win32_LogicalDisk")), "process, CPU, memory and disk inventory")
    add("performance:services", "Win32_Service" in performance_text and "Running" in performance_text, "running Windows services inventory")
    add("performance:stop safeguards", all(x in performance_text for x in ("$ProcessId -le 4", "protected", "STOP $ProcessId", "Stop-Process")), "PID guard, protected names and typed confirmation")
    add("performance:reports", all(x in performance_text for x in ("itvip_performance_$stamp.json", "itvip_performance_$stamp.txt", "itvip_processes_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("performance:dashboard integration", "ID_PERFORMANCE_MANAGER" in gui_text and "Performance-ITVIP.cmd" in gui_text, "bilingual dashboard command and launcher")
    add("performance:documentation", performance_doc.is_file() and "unsaved work" in performance_doc_text.lower(), "scope, limitations and process-stop warning documented")

    startup = ROOT / "deployment/Startup-ITVIP.ps1"
    startup_text = startup.read_text(encoding="utf-8", errors="replace") if startup.exists() else ""
    startup_cmd = ROOT / "deployment/Startup-ITVIP.cmd"
    startup_cmd_text = startup_cmd.read_text(encoding="utf-8", errors="replace") if startup_cmd.exists() else ""
    startup_doc = ROOT / "docs/STARTUP_SERVICES_MANAGER.md"
    startup_doc_text = startup_doc.read_text(encoding="utf-8", errors="replace") if startup_doc.exists() else ""
    add("startup:script exists", startup.is_file(), "startup and services inventory script")
    add("startup:launcher exists", startup_cmd.is_file() and "Startup-ITVIP.ps1" in startup_cmd_text, "CMD launcher")
    add("startup:inventory providers", all(x in startup_text for x in ("Win32_StartupCommand", "Win32_Service", "StartMode")), "startup command and Windows service inventory")
    add("startup:read-only", "ReadOnly=$true" in startup_text and "No startup entries, services, tasks, registry values, or system settings were modified." in startup_text, "no startup or service modifications")
    add("startup:reports", all(x in startup_text for x in ("itvip_startup_$stamp.json", "itvip_startup_$stamp.txt", "itvip_startup_apps_$stamp.csv", "itvip_services_$stamp.csv")), "timestamped JSON/TXT and CSV reports")
    add("startup:dashboard integration", "ID_STARTUP_MANAGER" in gui_text and "Startup-ITVIP.cmd" in gui_text, "bilingual dashboard command and launcher")
    add("startup:documentation", startup_doc.is_file() and "read-only" in startup_doc_text.lower(), "scope and limitations documented")

    optimize = ROOT / "deployment/Optimize-ITVIP.ps1"
    optimize_text = optimize.read_text(encoding="utf-8", errors="replace") if optimize.exists() else ""
    optimize_cmd = ROOT / "deployment/Optimize-ITVIP.cmd"
    optimize_cmd_text = optimize_cmd.read_text(encoding="utf-8", errors="replace") if optimize_cmd.exists() else ""
    optimize_doc = ROOT / "docs/WINDOWS_OPTIMIZATION_CENTER.md"
    optimize_doc_text = optimize_doc.read_text(encoding="utf-8", errors="replace") if optimize_doc.exists() else ""
    add("optimization:script exists", optimize.is_file(), "Windows optimization assessment script")
    add("optimization:launcher exists", optimize_cmd.is_file() and "Optimize-ITVIP.ps1" in optimize_cmd_text, "manual CMD launcher")
    add("optimization:storage inventory", "Win32_LogicalDisk" in optimize_text and "FreePercent" in optimize_text, "fixed disk capacity and free-space assessment")
    add("optimization:temporary inventory bounded", "Get-ChildItem" in optimize_text and "$MaxFiles" in optimize_text and "TemporaryFileInventory" in optimize_text, "temporary files are inventoried with a per-location cap")
    add("optimization:startup inventory", "Win32_StartupCommand" in optimize_text and "StartupEntries" in optimize_text, "startup entries are listed without boot-time claims")
    add("optimization:read-only", "ReadOnly=$true" in optimize_text and "No file is deleted" in optimize_doc_text and "No registry" in optimize_doc_text, "no cleanup or configuration changes")
    add("optimization:reports", all(x in optimize_text for x in ("itvip_optimization_$stamp.json", "itvip_optimization_$stamp.txt", "itvip_storage_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("optimization:dashboard integration", "ID_OPTIMIZATION_CENTER" in gui_text and "Optimize-ITVIP.cmd" in gui_text, "bilingual dashboard launcher")
    add("optimization:documentation", optimize_doc.is_file() and "read-only" in optimize_doc_text.lower(), "scope, scan limits and safety documented")

    repair = ROOT / "deployment/Repair-ITVIP.ps1"
    repair_text = repair.read_text(encoding="utf-8", errors="replace") if repair.exists() else ""
    repair_cmd = ROOT / "deployment/Repair-ITVIP.cmd"
    repair_cmd_text = repair_cmd.read_text(encoding="utf-8", errors="replace") if repair_cmd.exists() else ""
    repair_doc = ROOT / "docs/WINDOWS_REPAIR_CENTER.md"
    repair_doc_text = repair_doc.read_text(encoding="utf-8", errors="replace") if repair_doc.exists() else ""
    add("repair:script exists", repair.is_file(), "Windows repair assessment PowerShell script")
    add("repair:launcher exists", repair_cmd.is_file() and "Repair-ITVIP.ps1" in repair_cmd_text, "interactive CMD launcher")
    add("repair:inventory", all(x in repair_text for x in ("Win32_OperatingSystem", "Win32_Service", "Win32_LogicalDisk", "PendingRebootIndicator")), "OS, update services, disks and reboot indicator inventory")
    add("repair:safe scan commands", all(x in repair_text for x in ("/verifyonly", "/ScanHealth", "'/scan'", "ReadOnly=$true")), "verification and scan-only system diagnostics")
    add("repair:no destructive repair", all(x not in repair_text for x in ("/scannow", "/RestoreHealth", "'/f'", "'/r'", "Remove-Item", "Set-Service", "Stop-Service")), "no repair, cleanup, or service mutation command")
    add("repair:reports", all(x in repair_text for x in ("itvip_repair_$stamp.json", "itvip_repair_$stamp.txt")), "timestamped JSON and TXT reports")
    add("repair:dashboard integration", "ID_REPAIR_CENTER" in gui_text and "Repair-ITVIP.cmd" in gui_text, "bilingual dashboard launcher")
    add("repair:documentation", repair_doc.is_file() and "read-only" in repair_doc_text.lower() and "verifyonly" in repair_doc_text.lower(), "scope, safety and runtime limitations documented")

    firewall_privacy = ROOT / "deployment/FirewallPrivacy-ITVIP.ps1"
    firewall_privacy_text = firewall_privacy.read_text(encoding="utf-8", errors="replace") if firewall_privacy.exists() else ""
    firewall_privacy_cmd = ROOT / "deployment/FirewallPrivacy-ITVIP.cmd"
    firewall_privacy_cmd_text = firewall_privacy_cmd.read_text(encoding="utf-8", errors="replace") if firewall_privacy_cmd.exists() else ""
    firewall_privacy_doc = ROOT / "docs/FIREWALL_PRIVACY_CENTER.md"
    firewall_privacy_doc_text = firewall_privacy_doc.read_text(encoding="utf-8", errors="replace") if firewall_privacy_doc.exists() else ""
    add("firewall-privacy:script exists", firewall_privacy.is_file(), "read-only Firewall & Privacy assessment script")
    add("firewall-privacy:launcher exists", firewall_privacy_cmd.is_file() and "FirewallPrivacy-ITVIP.ps1" in firewall_privacy_cmd_text, "interactive CMD launcher")
    add("firewall-privacy:firewall inventory", all(x in firewall_privacy_text for x in ("Get-NetFirewallProfile", "Get-NetFirewallRule", "DefaultInboundAction", "InboundAllow", "OutboundBlock")), "firewall profile state and enabled rule summaries")
    add("firewall-privacy:privacy snapshots", all(x in firewall_privacy_text for x in ("EnableLUA", "SmartScreenEnabled", "AdvertisingInfo", "AppPrivacy", "AllowTelemetry")), "selected privacy and security policy registry snapshots")
    add("firewall-privacy:connection inventory", "Get-NetTCPConnection -State Established" in firewall_privacy_text and "-First 250" in firewall_privacy_text, "bounded established TCP connection inventory")
    add("firewall-privacy:read-only", "ReadOnly=$true" in firewall_privacy_text and all(x not in firewall_privacy_text for x in ("Set-NetFirewall", "New-NetFirewall", "Remove-NetFirewall", "Set-ItemProperty", "Remove-ItemProperty", "Set-NetIPInterface")), "no firewall, registry, or network configuration mutation")
    add("firewall-privacy:reports", all(x in firewall_privacy_text for x in ("itvip_firewall_privacy_$stamp.json", "itvip_firewall_privacy_$stamp.txt")), "timestamped JSON and TXT reports")
    add("firewall-privacy:dashboard integration", "ID_FIREWALL_PRIVACY" in gui_text and "FirewallPrivacy-ITVIP.cmd" in gui_text, "bilingual dashboard command and launcher")
    add("firewall-privacy:documentation", firewall_privacy_doc.is_file() and "read-only" in firewall_privacy_doc_text.lower() and "Missing registry values" in firewall_privacy_doc_text, "scope, safety, interpretation and privacy warnings documented")

    event_script = ROOT / "deployment/EventLogs-ITVIP.ps1"
    event_text = event_script.read_text(encoding="utf-8", errors="replace") if event_script.exists() else ""
    event_cmd = ROOT / "deployment/EventLogs-ITVIP.cmd"
    event_cmd_text = event_cmd.read_text(encoding="utf-8", errors="replace") if event_cmd.exists() else ""
    event_doc = ROOT / "docs/EVENT_VIEWER_LOG_ANALYZER.md"
    event_doc_text = event_doc.read_text(encoding="utf-8", errors="replace") if event_doc.exists() else ""
    add("event-logs:script exists", event_script.is_file(), "bounded Windows Event Log reader")
    add("event-logs:launcher exists", event_cmd.is_file() and "EventLogs-ITVIP.ps1" in event_cmd_text, "interactive CMD launcher")
    add("event-logs:log allowlist", all(x in event_text for x in ("System", "Application", "ValidateSet('All','System','Application')")), "only System and Application logs are accepted")
    add("event-logs:bounded query", all(x in event_text for x in ("ValidateRange(1,90)", "ValidateRange(1,5000)", "-MaxEvents $remaining", "Substring(0,12000)")), "bounded date, event count, and message size")
    add("event-logs:severity filters", all(x in event_text for x in ("Critical", "Error", "Warning", "Information", "Level=$levels")), "severity filtering")
    add("event-logs:read-only", "ReadOnly=$true" in event_text and all(x not in event_text for x in ("wevtutil cl", "Clear-EventLog", "Remove-EventLog", "Limit-EventLog", "Set-Service", "Stop-Service")), "no event-log clearing or system mutation")
    add("event-logs:reports", all(x in event_text for x in ("itvip_eventlogs_$stamp.json", "itvip_eventlogs_$stamp.txt", "itvip_eventlogs_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("event-logs:dashboard integration", "ID_EVENT_LOGS" in gui_text and "EventLogs-ITVIP.cmd" in gui_text, "bilingual dashboard command and launcher")
    add("event-logs:documentation", event_doc.is_file() and "privacy" in event_doc_text.lower() and "read-only" in event_doc_text.lower(), "scope, privacy, limits, and safety documented")

    software_script = ROOT / "deployment/Software-ITVIP.ps1"
    software_text = software_script.read_text(encoding="utf-8", errors="replace") if software_script.exists() else ""
    software_cmd = ROOT / "deployment/Software-ITVIP.cmd"
    software_cmd_text = software_cmd.read_text(encoding="utf-8", errors="replace") if software_cmd.exists() else ""
    software_doc = ROOT / "docs/SOFTWARE_INSTALLED_APPS_MANAGER.md"
    software_doc_text = software_doc.read_text(encoding="utf-8", errors="replace") if software_doc.exists() else ""
    add("software-manager:script exists", software_script.is_file(), "installed software inventory PowerShell script")
    add("software-manager:launcher exists", software_cmd.is_file() and "Software-ITVIP.ps1" in software_cmd_text, "interactive CMD launcher")
    add("software-manager:registry sources", all(x in software_text for x in ("HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "WOW6432Node", "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall")), "native, 32-bit and current-user uninstall registry inventory")
    add("software-manager:bounded inventory", all(x in software_text for x in ("ValidateRange(1,5000)", "MaxApps=2000", "NameLike", "EstimatedSizeMB")), "bounded result count, name filter, and estimated-size metadata")
    add("software-manager:read-only", "ReadOnly=$true" in software_text and all(x not in software_text for x in ("UninstallString", "QuietUninstallString", "Start-Process", "Remove-ItemProperty", "Set-ItemProperty", "winget upgrade", "winget uninstall")), "no uninstall command retrieval or software/registry mutation")
    add("software-manager:reports", all(x in software_text for x in ("itvip_software_$stamp.json", "itvip_software_$stamp.txt", "itvip_software_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("software-manager:dashboard integration", "ID_SOFTWARE_MANAGER" in gui_text and "Software-ITVIP.cmd" in gui_text, "bilingual dashboard command and launcher")
    add("software-manager:documentation", software_doc.is_file() and "read-only" in software_doc_text.lower() and "Limitations" in software_doc_text, "scope, safety, privacy and inventory limitations documented")


    wu_script = ROOT / "deployment/WindowsUpdate-ITVIP.ps1"
    wu_text = wu_script.read_text(encoding="utf-8", errors="replace") if wu_script.exists() else ""
    wu_cmd = ROOT / "deployment/WindowsUpdate-ITVIP.cmd"
    wu_cmd_text = wu_cmd.read_text(encoding="utf-8", errors="replace") if wu_cmd.exists() else ""
    wu_doc = ROOT / "docs/WINDOWS_UPDATE_MANAGER.md"
    wu_doc_text = wu_doc.read_text(encoding="utf-8", errors="replace") if wu_doc.exists() else ""
    add("windows-update:script exists", wu_script.is_file(), "Windows Update Agent inventory script")
    add("windows-update:launcher consent", wu_cmd.is_file() and "choice /C YN" in wu_cmd_text and "WindowsUpdate-ITVIP.ps1" in wu_cmd_text, "interactive launcher requires consent before contacting configured update source")
    add("windows-update:WUA search", all(x in wu_text for x in ("Microsoft.Update.Session", "IsInstalled=0 and IsHidden=0 and Type='Software'", "CreateUpdateSearcher", ".Search(")), "uses Windows Update Agent to list available software updates")
    add("windows-update:history", all(x in wu_text for x in ("GetTotalHistoryCount", "QueryHistory", "ResultCode", "HResult")), "recent Windows Update Agent history inventory")
    add("windows-update:bounded results", all(x in wu_text for x in ("ValidateRange(1,500)", "MaxUpdates=100", "HistoryCount=100", "Math]::Min")), "bounded available-update and history results")
    add("windows-update:read-only", "ReadOnly=$true" in wu_text and all(x not in wu_text for x in (".Download()", ".Install()", ".AcceptEula()", ".CopyFromCache", "Set-Service", "Start-Service", "Stop-Service", "Set-ItemProperty", "Remove-ItemProperty")), "no update download/install or Windows configuration mutation")
    add("windows-update:reports", all(x in wu_text for x in ("itvip_windows_update_$stamp.json", "itvip_windows_update_$stamp.txt", "itvip_windows_update_$stamp.csv")), "timestamped JSON/TXT/CSV reports")
    add("windows-update:dashboard integration", "ID_WINDOWS_UPDATE" in gui_text and "WindowsUpdate-ITVIP.cmd" in gui_text, "bilingual dashboard entry and launcher")
    add("windows-update:documentation", wu_doc.is_file() and "read-only" in wu_doc_text.lower() and "may contact" in wu_doc_text.lower(), "scope, network consent, safety and limitations documented")

    # Offline license authority foundation (source/static checks only).
    authority_scripts = {
        "keygen": ROOT / "deployment/New-ITVIPAuthorityKey.ps1",
        "sign": ROOT / "deployment/Sign-ITVIPUserEdition.ps1",
        "verify": ROOT / "deployment/Test-ITVIPUserEdition.ps1",
    }
    authority_text = {k: (p.read_text(encoding="utf-8", errors="replace") if p.is_file() else "") for k, p in authority_scripts.items()}
    add("authority:key generation", authority_scripts["keygen"].is_file() and all(x in authority_text["keygen"] for x in ("RSACryptoServiceProvider(3072)", "ConvertFrom-SecureString", "authority.public.xml")), "RSA-3072 keypair and DPAPI-protected private key source")
    add("authority:private key separation", "authority.private.dpapi.txt" in authority_text["keygen"] and "PrivateKeyFile" in authority_text["sign"] and "Copy-Item" not in authority_text["keygen"], "private key is created separately and not part of edition packaging")
    add("authority:manifest schema", "ITVIP-USER-EDITION-2" in edition_text and all(x in edition_text for x in ("EditionId", "IssuedUtc", "ExpiresUtc", "BindingMode='None'")), "edition UUID, timestamps, optional expiry and explicit no-binding mode")
    add("authority:detached signing", authority_scripts["sign"].is_file() and all(x in authority_text["sign"] for x in ("SignData", "SHA256", "EDITION_SIGNATURE.sha256rsa", "EDITION_SHA256.json")), "RSA/SHA-256 signature covers manifest and file inventory")
    add("authority:integrity verifier", authority_scripts["verify"].is_file() and all(x in authority_text["verify"] for x in ("VerifyData", "Get-FileHash", "Unsafe path", "ExpiresUtc")), "signature, path containment, file hashes and expiry validation")
    authority_doc = ROOT / "docs/ITVIP_LICENSE_SECURITY_AUTHORITY.md"
    authority_doc_text = authority_doc.read_text(encoding="utf-8", errors="replace") if authority_doc.exists() else ""
    add("authority:security boundaries documented", authority_doc.is_file() and all(x in authority_doc_text for x in ("does NOT yet verify", "BindingMode=None", "remote revocation", "DPAPI")), "manual verification and unimplemented enforcement limits are explicit")
    add("authority:prelaunch verifier integration", "ITVIPBootstrap.exe" in (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8", errors="replace") and all(x in (ROOT / "src/app/license_bootstrapper.cpp").read_text(encoding="utf-8", errors="replace") for x in ("verifier", "publicKey", "runAndWait", "verifierExit != 0")), "native launcher is packaged and waits for verifier success before dashboard launch")
    add("authority:public key bundled before signing", "authority.public.xml" in authority_text["sign"] and authority_text["sign"].find("Copy-Item -LiteralPath $publicPath") < authority_text["sign"].find("$items=@("), "public verification key is included in the signed inventory")
    add("authority:v118 signing root and reparse protection", "Edition root must not be a reparse point" in authority_text["sign"] and "Reparse points are not allowed in a signed edition" in authority_text["sign"], "signer rejects reparse-point edition roots and entries")
    add("authority:v118 signed inventory path policy", all(x in authority_text["sign"] for x in ("Unsafe signed inventory path", "Windows-reserved inventory path", "Duplicate case-insensitive inventory path", "Refusing to sign an edition with an empty file inventory", "-replace '\\\\','/'")), "signer normalizes and validates signed Windows inventory paths")
    add("authority:v118 RSA-3072 key-pair match", all(x in authority_text["sign"] for x in ("$rsa.KeySize -ne 3072", "$publicRsa.KeySize -ne 3072", "$rsa.ExportParameters($false)", "$publicRsa.ExportParameters($false)", "Private key does not match the supplied authority public key")), "signer requires RSA-3072 and matching private/public authority keys")
    signing_fixture = ROOT / "tests/windows/Test-EditionSigningHardening.ps1"
    workflow_text = (ROOT / ".github/workflows/windows-build.yml").read_text(encoding="utf-8", errors="replace")
    add("authority:v118 Windows signing fixture", signing_fixture.is_file() and all(x in signing_fixture.read_text(encoding="utf-8", errors="replace") for x in ("KeySize=3072", "VerifyData", "mismatched", "nested/payload.txt")), "Windows fixture verifies valid signing, signature, nested paths, and key mismatch rejection")
    add("authority:v118 PowerShell 5.1/7 CI wiring", "Test-EditionSigningHardening.ps1" in workflow_text and "${{ matrix.executable }}" in workflow_text, "edition signing fixture is scheduled in both Windows PowerShell runtime jobs")
    add("authority:extra file detection", "Unlisted files detected" in authority_text["verify"] and "Duplicate inventory path" in authority_text["verify"], "verifier rejects unlisted files and duplicate inventory paths")

    # v0.58 optional Windows SID binding and Boot Manager read-only preflight.
    signer_text = authority_text["sign"]
    verifier_text = authority_text["verify"]
    boot_script = ROOT / "deployment/BootManager-Preflight.ps1"
    boot_cmd = ROOT / "deployment/BootManager-Preflight.cmd"
    boot_doc = ROOT / "docs/BOOT_MANAGER_ENGINEERING_STATUS.md"
    boot_text = boot_script.read_text(encoding="utf-8", errors="replace") if boot_script.is_file() else ""
    add("authority:optional SID binding", "ValidateSet('None','WindowsSid')" in signer_text and "BindingValue" in signer_text and "BindingSid" in signer_text and "WindowsIdentity" in verifier_text, "opt-in Windows account SID hash is signed and checked")
    add("authority:SID privacy", "BindingMode='None'" in edition_text and "BindingValue" in signer_text, "no SID collection unless owner explicitly selects WindowsSid")
    add("authority:reparse point rejection", "ReparsePoint" in verifier_text and "symbolic links" in verifier_text, "signed edition verifier rejects reparse points")
    add("authority:manifest time and state", "IssuedUtc" in verifier_text and "future" in verifier_text and "Revoked" in verifier_text, "future-issued and revoked manifest states are rejected")
    add("boot-preflight:script and launcher", boot_script.is_file() and boot_cmd.is_file() and "BootManager-Preflight.ps1" in boot_cmd.read_text(encoding="utf-8", errors="replace"), "read-only boot inventory script and CMD launcher")
    add("boot-preflight:read-only disk inventory", all(x in boot_text for x in ("Get-Disk", "IsBoot", "IsSystem", "DestructiveOperationsPerformed=$false")), "firmware and disk inventory; no disk writes")
    add("boot-preflight:reports", all(x in boot_text for x in ("itvip_boot_preflight_$stamp.json", "itvip_boot_preflight_$stamp.txt")), "timestamped JSON and TXT reports")
    add("boot-preflight:v3 physical identity", all(x in boot_text for x in ("ITVIP-BOOT-PREFLIGHT-3", "SerialNumber", "UniqueId", "CandidateHintRequiresManualIdentityCheck")), "inventory includes available hardware identity but never authorizes device selection")
    add("boot-preflight:shareable report redaction", all(x in boot_text for x in ("RedactHardwareIdentifiers", "Protect-HardwareIdentifier", "[REDACTED]", "HardwareIdentifiersRedacted")) and "%*" in boot_cmd.read_text(encoding="utf-8", errors="replace"), "optional report-sharing mode redacts computer name, serial, and UniqueId; launcher forwards switches")
    add("boot-preflight:v2 partition and volume detail", all(x in boot_text for x in ("Get-Partition", "Get-Volume", "GptType", "FileSystem", "SizeRemainingBytes")), "read-only partition and volume inventory is included")
    add("boot-preflight:v2 warning collection", "Warnings=@($warnings.ToArray())" in boot_text and "Firmware mode unavailable" in boot_text, "partial inventory failures are reported rather than silently hidden")
    add("boot-preflight:no destructive storage commands", not re.search(r"(?im)^\s*(Clear-Disk|Format-Volume|Initialize-Disk|New-Partition|Remove-Partition|Set-Disk|Set-Partition)\b", boot_text), "preflight contains no disk mutation cmdlets")
    add("boot-preflight:limitations documented", boot_doc.is_file() and all(x in boot_doc.read_text(encoding="utf-8", errors="replace") for x in ("not a bootable USB creator", "Secure Boot", "No partitioning")), "no false claim of bootloader or Secure Boot support")

    # v0.59 offline signed revocation snapshot checks.
    add("authority:revocation snapshot generation", "RevokedEditionIds" in signer_text and "EDITION_REVOCATIONS.json" in signer_text and "RevocationFile" in signer_text, "owner can issue a signed offline EditionId revocation snapshot")
    add("authority:revocation snapshot signature", "EDITION_REVOCATIONS.sha256rsa" in signer_text and "SignData($revBytes" in signer_text, "revocation snapshot receives detached RSA/SHA-256 signature")
    add("authority:revocation verification", "VerifyData($revBytes" in verifier_text and "RevokedEditionIds" in verifier_text and "appears in the signed offline revocation list" in verifier_text, "verifier authenticates snapshot and rejects revoked EditionId")
    add("authority:offline revocation boundary", "offline snapshot" in authority_doc_text.lower() and "not live" in authority_doc_text.lower(), "documentation explicitly distinguishes offline snapshots from live remote revocation")

    # v0.60 central reference control-plane checks.
    service = ROOT / "server/license_authority.py"
    service_text = service.read_text(encoding="utf-8", errors="replace") if service.is_file() else ""
    service_tests = ROOT / "tests/test_license_authority.py"
    service_test_text = service_tests.read_text(encoding="utf-8", errors="replace") if service_tests.is_file() else ""
    service_doc = ROOT / "docs/CENTRAL_LICENSE_AUTHORITY.md"
    service_doc_text = service_doc.read_text(encoding="utf-8", errors="replace") if service_doc.is_file() else ""
    add("central-authority:service", service.is_file() and all(x in service_text for x in ("ThreadingHTTPServer", "sqlite3", "/v1/revoke", "/v1/restore", "/v1/revocations")), "stdlib SQLite control plane exposes revoke, restore and snapshot routes")
    add("central-authority:authentication", "ITVIP_ADMIN_TOKEN" in service_text and "compare_digest" in service_text and "Bearer " in service_text, "all administrative routes require constant-time bearer-token comparison")
    add("central-authority:loopback-default", "127.0.0.1" in service_text and "--allow-remote" in service_text and "requires --tls-cert and --tls-key" in service_text, "loopback by default; remote bind requires direct TLS certificate and key")
    add("central-authority:no-private-key", "does not sign licenses" in service_text and "RSA private key" in service_doc_text and "rsa private key" not in service_text.lower(), "server cannot access or store the owner signing private key")
    add("central-authority:audit-and-snapshot", all(x in service_text for x in ("CREATE TABLE IF NOT EXISTS audit", "RevokedEditionIds", "GeneratedUtc")), "persistent audit history and compatible revocation snapshot")
    add("central-authority:unit-tests", service_tests.is_file() and all(x in service_test_text for x in ("test_revoke_snapshot_and_idempotency", "test_restore_records_audit", "test_reject_invalid_uuid_and_empty_reason")), "unit tests cover revoke/restore, idempotency, snapshot and validation")
    add("central-authority:documentation", service_doc.is_file() and all(x in service_doc_text for x in ("TLS reverse proxy", "Sign-ITVIPUserEdition.ps1", "not signed by the server")), "API, signing handoff and security limitations documented")
    add("central-authority:monotonic revision", "_next_revision" in service_text and "Revision" in service_text and "revision INTEGER NOT NULL" in service_text, "state changes receive a monotonically increasing revision stored with audit events")
    add("central-authority:signing preserves revision", "revocationRevision" in authority_text["sign"] and "Revision=$revocationRevision" in authority_text["sign"], "offline owner signature covers the central snapshot revision")
    add("central-authority:revision validation", "Invalid revocation snapshot revision" in authority_text["verify"], "client verifier validates the optional signed snapshot revision")
    add("central-authority:revision tests", "test_revision_changes_only_when_state_changes" in service_test_text and "self.assertEqual(self.store.snapshot()['Revision'],2)" in service_test_text, "unit tests cover revision increments and idempotent state changes")

    # v0.62 local anti-rollback state checks.
    verifier_rollback = authority_text["verify"]
    add("authority:anti-rollback DPAPI state", all(x in verifier_rollback for x in ("LicenseState", "ProtectedData]::Protect", "ProtectedData]::Unprotect", "DataProtectionScope]::CurrentUser")), "per-EditionId high-water mark is protected with current-user DPAPI")
    add("authority:rollback rejection", "Rollback detected" in verifier_rollback and "HighestRevision" in verifier_rollback, "lower signed revocation revisions are rejected against persisted high-water mark")
    add("authority:atomic state update", "Move-Item -LiteralPath $tmp -Destination $statePath -Force" in verifier_rollback and "finally {if(Test-Path -LiteralPath $tmp)" in verifier_rollback, "state updates use temporary file and cleanup")
    add("authority:anti-rollback limitations documented", "local administrator" in service_doc_text and "profile backup" in service_doc_text and "hardware-backed" in service_doc_text, "documentation describes bypass boundaries and stronger future options")
    add("central-authority:read-admin separation", all(x in service_text for x in ("ITVIP_READ_TOKEN", "ITVIP_ADMIN_TOKEN", "authorized(write=True)", "authorized(write=False)")), "read-only and mutation credentials are separated")
    add("central-authority:server-controlled audit actor", "ITVIP_ADMIN_ACTOR" in service_text and "return self.server.admin_actor" in service_text and "X-ITVIP-Actor" not in service_text, "audit principal comes from validated server configuration, not caller headers")
    add("central-authority:direct TLS", all(x in service_text for x in ("--tls-cert", "--tls-key", "TLSVersion.TLSv1_2", "Remote binding requires --tls-cert")), "remote listener requires direct TLS with TLS 1.2 minimum")
    add("central-authority:sqlite durability", "PRAGMA journal_mode=WAL" in service_text and "PRAGMA synchronous=FULL" in service_text, "SQLite reference store enables WAL and FULL synchronous mode")
    add("central-authority:http tests", all(x in service_test_text for x in ("test_read_token_cannot_mutate_and_admin_can", "test_read_token_can_fetch_snapshot", "test_unauthenticated_health_only")), "HTTP tests cover role separation and unauthenticated route boundary")
    add("central-authority:hardening documentation", all(x in service_doc_text for x in ("TLS 1.2 minimum", "ITVIP_READ_TOKEN", "ITVIP_ADMIN_ACTOR", "not a human identity")), "credential roles, TLS and server-principal attribution limits documented")
    add("central-authority:audit hash chain", all(x in service_text for x in ("hashlib.sha256", "prev_hash", "audit_hash", "_append_audit")), "audit events are linked by canonical SHA-256 hashes")
    add("central-authority:audit integrity verifier", "def verify_audit" in service_text and "/v1/audit/verify" in service_text, "authenticated endpoint verifies the complete audit chain")
    add("central-authority:audit migration", "_migrate_audit_chain" in service_text and "ALTER TABLE audit ADD COLUMN prev_hash" in service_text, "existing audit rows are backfilled during schema migration")
    add("central-authority:audit tamper tests", all(x in service_test_text for x in ("test_audit_hash_chain_valid_and_detects_tampering", "test_audit_chain_migration_backfills_legacy_rows", "test_authenticated_audit_integrity_endpoint")), "tests cover valid chain, tampering, legacy migration and API")
    add("central-authority:connection lifecycle", "@contextmanager" in service_text and "db.close()" in service_text, "SQLite connections commit or rollback and always close")
    add("central-authority:v115 strict JSON parser", all(x in service_text for x in ("object_pairs_hook=self._unique_object", "Duplicate JSON property", "parse_constant=self._reject_json_constant", "errors='strict'")), "HTTP mutation bodies reject duplicate keys, non-standard constants, and invalid UTF-8")
    add("central-authority:v115 request framing", all(x in service_text for x in ("Transfer-Encoding", "Content-Length", "Content-Type must be application/json", "Request body ended")), "request body framing and content type are bounded and explicit")
    add("central-authority:v115 serialized writers", service_text.count("db.execute('BEGIN IMMEDIATE')") >= 2, "revoke/restore writers serialize revision and audit-head updates")
    add("central-authority:v115 regression tests", all(x in service_test_text for x in ("test_reject_duplicate_json_properties", "test_reject_non_json_content_type", "test_reject_nonstandard_json_constants", "test_concurrent_writers_keep_revision_and_audit_chain_serialized")), "tests cover strict JSON handling and concurrent revision/audit integrity")
    add("central-authority:v117 actor spoof regression", "test_caller_cannot_spoof_audit_actor_header" in service_test_text and "configured-license-admin" in service_test_text, "caller-supplied actor header cannot override server-configured audit principal")

    # v0.65 native launch orchestrator integration (not native cryptographic verification).
    bootstrap_cpp = ROOT / "src/app/license_bootstrapper.cpp"
    bootstrap_text = bootstrap_cpp.read_text(encoding="utf-8", errors="replace") if bootstrap_cpp.is_file() else ""
    builder_text = (ROOT / "deployment/Build-UserEdition.ps1").read_text(encoding="utf-8", errors="replace")
    bootstrap_doc = ROOT / "docs/NATIVE_LICENSE_BOOTSTRAPPER.md"
    bootstrap_doc_text = bootstrap_doc.read_text(encoding="utf-8", errors="replace") if bootstrap_doc.is_file() else ""
    add("bootstrapper: native source", bootstrap_cpp.is_file() and all(x in bootstrap_text for x in ("wWinMain", "CreateProcessW", "WaitForSingleObject", "Test-ITVIPUserEdition.ps1", "ShellExecuteExW")), "native Windows launcher waits for verifier and starts dashboard only on success")
    add("bootstrapper: fail closed", all(x in bootstrap_text for x in ("verifierExit != 0", "Launch blocked", "authority.public.xml", "ITVIP.exe")), "missing files and non-zero verifier result block dashboard launch")
    add("bootstrapper: MSVC and MinGW targets", all(x in build_text for x in (":build_bootstrapper_msvc", ":build_bootstrapper_mingw", "ITVIPBootstrap.exe", "license_bootstrapper.cpp")), "both supported Windows compiler paths define native bootstrapper target")
    add("bootstrapper: edition packaging", "build/ITVIPBootstrap.exe" in builder_text and "ITVIPBootstrap.exe" in builder_text and "Start-ITVIP.cmd" in builder_text, "user-edition builder requires and packages bootstrapper with compatibility CMD shim")
    add("bootstrapper: security boundary documented", bootstrap_doc.is_file() and all(x in bootstrap_doc_text for x in ("not Authenticode-signed", "PowerShell policy verifier", "local administrator", "CNG verification stage")), "documentation does not overstate native cryptographic enforcement")
    native_verifier = ROOT / "src/app/license_native_verifier.cpp"
    native_text = native_verifier.read_text(encoding="utf-8", errors="replace") if native_verifier.is_file() else ""
    add("native-policy: expiry and issue-time enforcement", all(x in native_text for x in ("IssuedUtc", "ExpiresUtc", "parseUtc", "Edition has expired")), "C++ policy verifier checks signed UTC issue and expiry timestamps")
    add("native-policy: optional Windows SID binding", all(x in native_text for x in ("WindowsSid", "OpenProcessToken", "TokenUser", "currentWindowsSidHash")), "C++ checks opt-in SID binding without collecting SID in None mode")
    add("native-policy: DPAPI anti-rollback", all(x in native_text for x in ("CryptProtectData", "CryptUnprotectData", "CRYPTPROTECT_UI_FORBIDDEN", "HighestRevision", "MoveFileExW")), "C++ protects monotonic revocation revision state with CurrentUser DPAPI and atomic replacement")
    add("native-policy: fail-closed state", all(x in native_text for x in ("anti-rollback state cannot be protected", "refusing launch", "Rollback detected")), "C++ refuses launch when protected state cannot be validated or snapshot rolls back")
    add("native-policy: status and schema", all(x in native_text for x in ("ITVIP-USER-EDITION-2", "ITVIP-REVOCATIONS-1", "Status", "Revoked")), "C++ validates manifest/revocation schemas and revoked profile state")
    add("native-policy: limits documented", bootstrap_doc.is_file() and all(x in bootstrap_doc_text for x in ("DPAPI", "Windows SID", "not hardware-backed", "NOT RUN")), "documentation states native runtime test gaps and DPAPI limits")
    add("native-policy:reparse-point defense", all(x in native_text for x in ("rejectReparsePoint", "FILE_ATTRIBUTE_REPARSE_POINT", "forbidden in a signed edition")), "native inventory rejects reparse points in every path component and throughout the edition tree")
    add("native-policy:exact-tree inventory", all(x in native_text for x in ("Unlisted file in signed edition", "EDITION_SHA256.json", "EDITION_REVOCATIONS.sha256rsa", "recursive_directory_iterator")), "native verifier rejects unlisted payload files and allows only defined signature metadata")
    add("native-policy:case-insensitive duplicate paths", "Duplicate inventory path (case-insensitive)" in native_text and "pathKey" in native_text, "inventory duplicate detection follows Windows case-insensitive path semantics")
    add("native-policy:validate schema before state mutation", native_text.find("ITVIP-REVOCATIONS-1") < native_text.find("enforceAntiRollback(manifestDoc,revocationDoc)"), "revocation schema is validated before DPAPI high-water state can be updated")
    typed_json = ROOT / "src/app/strict_json.hpp"
    typed_json_text = typed_json.read_text(encoding="utf-8", errors="replace") if typed_json.is_file() else ""
    add("native-policy:typed JSON DOM", typed_json.is_file() and all(x in typed_json_text for x in ("struct Value", "class Parser", "duplicate object key", "validateRawUtf8", "maxNodes", "maxDepth")), "dependency-free typed JSON DOM validates Unicode, duplicates, and resource limits")
    add("native-policy:no regex JSON extraction", "std::regex_search(json" not in native_text and "std::sregex_iterator it(json" not in native_text and "itvip::json::Parser(m).parse()" in native_text, "signed JSON policy and inventory use typed DOM rather than regex extraction")
    add("native-policy:typed inventory schema", all(x in native_text for x in ("inventory.array", "entry.object.size()!=2", "stringField(entry,\"Path\",true)", "stringField(entry,\"SHA256\",true)")), "inventory is a typed array of exact Path/SHA256 objects")
    add("native-policy:typed revocation schema", all(x in native_text for x in ("find(\"RevokedEditionIds\")", "validGuid", "integerField")), "revocation list and revision use typed fields with GUID validation")
    add("native-policy:strict revocation snapshot", all(x in native_text for x in ("revocationDoc.object.size()!=4", "GeneratedUtc", "parseUtc(generatedUtc", "uniqueRevokedIds", "Duplicate EditionId in signed revocation list")), "revocation snapshot enforces exact fields, timestamp, bounded count, and unique GUIDs")
    add("native-policy:strict timestamp syntax", "std::regex_match(value,utcPattern)" in native_text and "(\\.[0-9]{1,7})?" in native_text, "UTC timestamp parser rejects trailing data and unsupported offset forms")
    add("native-policy:inventory resource caps", all(x in native_text for x in ("inventory.array.size()>100000", "512ULL*1024ULL*1024ULL", "4ULL*1024ULL*1024ULL*1024ULL")), "signed inventory applies entry, per-file, and aggregate byte limits")
    add("native-policy:bounded file reads", all(x in native_text for x in ("file_size(p, sizeError)", "bounded read limit", "readBytes(statePath, 64ULL * 1024ULL)", "readBytes(root/L\"EDITION_MANIFEST.json\", 4ULL * 1024ULL * 1024ULL)", "readBytes(root/L\"EDITION_SHA256.json\", 64ULL * 1024ULL * 1024ULL)", "readBytes(root/L\"EDITION_REVOCATIONS.json\", 16ULL * 1024ULL * 1024ULL)")), "native verifier checks file sizes before allocation and applies tighter caps to metadata and DPAPI state")
    add("native-policy:portable parser tests", (ROOT / "tests/native/test_strict_json.cpp").is_file() and (ROOT / "tests/native/run_strict_json_tests.sh").is_file(), "portable C++17 parser test harness and runner are included")
    add("native-policy:libFuzzer target", (ROOT / "tests/native/fuzz_strict_json.cpp").is_file() and "LLVMFuzzerTestOneInput" in (ROOT / "tests/native/fuzz_strict_json.cpp").read_text(encoding="utf-8"), "coverage-guided fuzz target feeds arbitrary bytes into bounded parser")
    add("native-policy:deterministic fuzz smoke", (ROOT / "tests/native/fuzz_strict_json_smoke.cpp").is_file() and (ROOT / "tests/native/run_strict_json_fuzz_smoke.sh").is_file() and "50000" in (ROOT / "tests/native/fuzz_strict_json_smoke.cpp").read_text(encoding="utf-8"), "50,000 reproducible mutations under ASan and UBSan")
    add("native-policy:fuzz corpus and runner", (ROOT / "tests/native/corpus/manifest.json").is_file() and (ROOT / "tests/native/corpus/revocations.json").is_file() and (ROOT / "tests/native/corpus/inventory.json").is_file() and (ROOT / "tests/native/run_libfuzzer.sh").is_file(), "seed corpus and Clang libFuzzer runner are packaged")
    fuzz_doc = ROOT / "docs/NATIVE_JSON_FUZZING.md"
    fuzz_doc_text = fuzz_doc.read_text(encoding="utf-8") if fuzz_doc.is_file() else ""
    add("native-policy:fuzz documentation", fuzz_doc.is_file() and all(x in fuzz_doc_text for x in ("20,000 executions", "50,000", "Windows CNG")), "fuzzing commands, recorded bounded run, and platform limitations documented")
    add("native-policy:revocation before anti-rollback mutation", native_text.find("if(candidate==target)") != -1 and native_text.find("if(candidate==target)") < native_text.find("enforceAntiRollback(manifestDoc,revocationDoc)"), "typed revocation membership decision precedes protected high-water state mutation")
    add("native-policy:typed JSON documentation", (ROOT / "docs/NATIVE_JSON_VALIDATION.md").is_file() and all(x in (ROOT / "docs/NATIVE_JSON_VALIDATION.md").read_text(encoding="utf-8") for x in ("typed JSON DOM", "paired UTF-16 surrogates", "12 test groups")), "documents typed parser semantics, limits, tests, and Windows runtime gaps")

    passed = sum(ok for _, ok, _ in checks)
    failed = len(checks) - passed
    lines = ["IT VIP — Static Project Validation", f"Root: {ROOT}",
             f"Timestamp: {dt.datetime.now().astimezone().isoformat(timespec='seconds')}",
             f"Summary: {passed} PASS / {failed} FAIL", ""]
    lines += [f"{'PASS' if ok else 'FAIL'} | {name} | {detail}" for name, ok, detail in checks]
    lines += ["", "Scope: source-tree/static integration only. This does NOT compile or run Windows binaries,"]
    lines += ["test live APIs, validate driver/boot behavior, or prove runtime security."]
    output = "\n".join(lines) + "\n"
    print(output, end="")
    if args.report:
        outdir = ROOT / "reports"
        outdir.mkdir(parents=True, exist_ok=True)
        target = outdir / f"project_validation_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        target.write_text(output, encoding="utf-8")
        print(f"Report: {target}")
    return 1 if failed else 0

if __name__ == "__main__":
    raise SystemExit(main())
