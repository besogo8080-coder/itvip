param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('x64','x86')]
    [string]$ExpectedArchitecture,
    [ValidateSet('dumpbin','objdump')]
    [string]$Compiler = 'dumpbin'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$build = Join-Path $root 'build'

# Keep this list aligned with the executable targets dispatched by build.bat.
# Include console modules, standalone GUIs, dashboard, verifier, and bootstrapper.
$expected = @(
    'scanner.exe','usb_guard.exe','tempclean.exe','activator.exe','pwrecover.exe',
    'portable_manager.exe','security_center.exe','copy_manager.exe',
    'ai_assistant.exe','github_hub.exe','api_manager.exe','agent_studio.exe',
    'provider_hub.exe','provider_runtime.exe','team_studio.exe','team_runner.exe',
    'workflow_studio.exe','workflow_runner.exe','run_history.exe','memory_center.exe',
    'session_center.exe','backup_center.exe','settings_center.exe','permissions_center.exe',
    'scanner_gui.exe','usb_guard_gui.exe','tempclean_gui.exe','activator_gui.exe',
    'pwrecover_gui.exe','security_center_gui.exe','system_monitor_gui.exe',
    'ITVIP.exe','ITVIPNativeVerify.exe','ITVIPBootstrap.exe'
)
$missing = @($expected | Where-Object { -not (Test-Path (Join-Path $build $_) -PathType Leaf) })
if ($missing.Count -gt 0) { throw "Build is incomplete. Missing: $($missing -join ', ')" }

if ($Compiler -eq 'dumpbin') {
    $tool = Get-Command dumpbin.exe -ErrorAction Stop
    $machinePattern = if ($ExpectedArchitecture -eq 'x64') { '(?im)\b8664 machine \(x64\)' } else { '(?im)\b14C machine \(x86\)' }
    foreach ($name in $expected) {
        $path = Join-Path $build $name
        $headers = & $tool.Source /nologo /headers $path 2>&1 | Out-String
        if ($LASTEXITCODE -ne 0) { throw "dumpbin failed for $name" }
        if ($headers -notmatch $machinePattern) {
            throw "Unexpected PE machine type for $name; expected $ExpectedArchitecture"
        }
    }
} else {
    $tool = Get-Command objdump.exe -ErrorAction Stop
    $formatPattern = if ($ExpectedArchitecture -eq 'x64') { '(?im)file format pei-x86-64\b' } else { '(?im)file format pei-i386\b' }
    foreach ($name in $expected) {
        $path = Join-Path $build $name
        $headers = & $tool.Source -f $path 2>&1 | Out-String
        if ($LASTEXITCODE -ne 0) { throw "objdump failed for $name" }
        if ($headers -notmatch $formatPattern) {
            throw "Unexpected PE format for $name; expected $ExpectedArchitecture"
        }
    }
}
Write-Host "PASS: $($expected.Count) executables exist and match $ExpectedArchitecture ($Compiler)."
