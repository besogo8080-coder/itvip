[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('x64', 'x86')]
    [string]$Architecture
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = Split-Path -Parent $PSScriptRoot
$build = Join-Path $root 'build'
$dist = Join-Path $root 'dist'
$packageName = "IT-VIP-Windows-$Architecture"
$stage = Join-Path $dist $packageName
$zip = Join-Path $dist "$packageName.zip"

$expected = @(
    'scanner.exe','usb_guard.exe','tempclean.exe','activator.exe','pwrecover.exe',
    'portable_manager.exe','security_center.exe','copy_manager.exe',
    'ai_assistant.exe','github_hub.exe','api_manager.exe','agent_studio.exe',
    'provider_hub.exe','provider_runtime.exe','team_studio.exe','team_runner.exe',
    'workflow_studio.exe','workflow_runner.exe','run_history.exe','memory_center.exe',
    'session_center.exe','backup_center.exe','settings_center.exe','permissions_center.exe',
    'scanner_gui.exe','usb_guard_gui.exe','tempclean_gui.exe','activator_gui.exe',
    'pwrecover_gui.exe','security_center_gui.exe','system_monitor_gui.exe',
    'ITVIP.exe','ITVIPNativeVerify.exe','ITVIPBootstrap.exe'
)
$missing = @($expected | Where-Object { -not (Test-Path -LiteralPath (Join-Path $build $_) -PathType Leaf) })
if ($missing.Count -gt 0) { throw "Refusing incomplete package. Missing executables: $($missing -join ', ')" }

# The application derives its project root as the parent of the build directory.
# Keep all executables in <package>\build and assets/config/deployment beside it.
if (-not (Test-Path -LiteralPath (Join-Path $root 'assets\itvip.ico') -PathType Leaf)) {
    throw 'Required application icon/assets are missing.'
}
foreach ($directory in @('assets','config','deployment','portable','docs','reports')) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $directory) -PathType Container)) {
        throw "Required runtime/source directory is missing: $directory"
    }
}

New-Item -ItemType Directory -Path $dist -Force | Out-Null
if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
New-Item -ItemType Directory -Path (Join-Path $stage 'build') -Force | Out-Null
foreach ($name in $expected) {
    Copy-Item -LiteralPath (Join-Path $build $name) -Destination (Join-Path $stage "build\$name")
}
foreach ($directory in @('assets','config','deployment','portable','docs','reports')) {
    Copy-Item -LiteralPath (Join-Path $root $directory) -Destination (Join-Path $stage $directory) -Recurse
}
foreach ($file in @('README.md','README_AR.md')) {
    Copy-Item -LiteralPath (Join-Path $root $file) -Destination (Join-Path $stage $file)
}

$launcher = @'
@echo off
setlocal
pushd "%~dp0"
if not exist "build\ITVIP.exe" (
  echo IT VIP dashboard executable is missing. Rebuild the package.
  popd
  exit /b 20
)
start "IT VIP" "%~dp0build\ITVIP.exe"
popd
exit /b 0
'@
[IO.File]::WriteAllText((Join-Path $stage 'Start-ITVIP.cmd'), $launcher, [Text.Encoding]::ASCII)

$manifest = [ordered]@{
    Product = 'IT VIP'
    Version = '0.83.35-dev'
    Package = $packageName
    Architecture = $Architecture
    BuiltUtc = [DateTime]::UtcNow.ToString('o')
    ExecutableCount = $expected.Count
    Executables = $expected
    EntryPoint = 'Start-ITVIP.cmd'
    Qualification = 'Locally built; Windows GUI and hardware/runtime qualification must be performed separately.'
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'BUILD_MANIFEST.json') -Encoding UTF8

Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
if (-not (Test-Path -LiteralPath $zip -PathType Leaf)) { throw 'ZIP creation failed.' }
$archive = [IO.Compression.ZipFile]::OpenRead($zip)
try {
    $names = @($archive.Entries | ForEach-Object { $_.FullName })
    foreach ($name in @('build/ITVIP.exe','Start-ITVIP.cmd','BUILD_MANIFEST.json','assets/itvip.ico')) {
        if ($names -notcontains $name) { throw "Package archive is missing required entry: $name" }
    }
    foreach ($exe in $expected) {
        if ($names -notcontains "build/$exe") { throw "Package archive is missing executable: $exe" }
    }
} finally { $archive.Dispose() }

$hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
[IO.File]::WriteAllText("$zip.sha256", "$hash  $([IO.Path]::GetFileName($zip))`r`n", [Text.Encoding]::ASCII)
Write-Host "Created: $zip" -ForegroundColor Green
Write-Host "Executables: $($expected.Count) ($Architecture)" -ForegroundColor Cyan
Write-Host "SHA-256: $hash" -ForegroundColor Cyan
